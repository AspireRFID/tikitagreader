/*      */ package org.apache.commons.beanutils;
/*      */ 
/*      */ import java.beans.BeanInfo;
/*      */ import java.beans.IndexedPropertyDescriptor;
/*      */ import java.beans.IntrospectionException;
/*      */ import java.beans.Introspector;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.lang.reflect.Method;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.collections.FastHashMap;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class PropertyUtilsBean
/*      */ {
/*  110 */   private FastHashMap descriptorsCache = null;
/*  111 */   private FastHashMap mappedDescriptorsCache = null;
/*      */ 
/*  114 */   private Log log = LogFactory.getLog(PropertyUtils.class);
/*      */ 
/*      */   protected static PropertyUtilsBean getInstance()
/*      */   {
/*  101 */     return BeanUtilsBean.getInstance().getPropertyUtils();
/*      */   }
/*      */ 
/*      */   public PropertyUtilsBean()
/*      */   {
/*  120 */     this.descriptorsCache = new FastHashMap();
/*  121 */     this.descriptorsCache.setFast(true);
/*  122 */     this.mappedDescriptorsCache = new FastHashMap();
/*  123 */     this.mappedDescriptorsCache.setFast(true);
/*      */   }
/*      */ 
/*      */   public void clearDescriptors()
/*      */   {
/*  137 */     this.descriptorsCache.clear();
/*  138 */     this.mappedDescriptorsCache.clear();
/*  139 */     Introspector.flushCaches();
/*      */   }
/*      */ 
/*      */   public void copyProperties(Object dest, Object orig)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*      */     int i;
/*      */     String name;
/*      */     Object value;
/*  176 */     if (dest == null) {
/*  177 */       throw new IllegalArgumentException("No destination bean specified");
/*      */     }
/*      */ 
/*  180 */     if (orig == null) {
/*  181 */       throw new IllegalArgumentException("No origin bean specified");
/*      */     }
/*      */ 
/*  184 */     if (orig instanceof DynaBean) {
/*  185 */       DynaProperty[] origDescriptors = ((DynaBean)orig).getDynaClass().getDynaProperties();
/*      */ 
/*  187 */       for (i = 0; i < origDescriptors.length; ++i) {
/*  188 */         name = origDescriptors[i].getName();
/*  189 */         if (dest instanceof DynaBean) {
/*  190 */           if (isWriteable(dest, name)) {
/*  191 */             value = ((DynaBean)orig).get(name);
/*  192 */             ((DynaBean)dest).set(name, value);
/*      */           }
/*      */         }
/*  195 */         else if (isWriteable(dest, name)) {
/*  196 */           value = ((DynaBean)orig).get(name);
/*  197 */           setSimpleProperty(dest, name, value);
/*      */         }
/*      */       }
/*      */     }
/*  201 */     else if (orig instanceof Map) {
/*  202 */       Iterator names = ((Map)orig).keySet().iterator();
/*  203 */       while (names.hasNext())
/*      */       {
/*      */         Object value;
/*  204 */         String name = (String)names.next();
/*  205 */         if (dest instanceof DynaBean) {
/*  206 */           if (isWriteable(dest, name)) {
/*  207 */             value = ((Map)orig).get(name);
/*  208 */             ((DynaBean)dest).set(name, value);
/*      */           }
/*      */         }
/*  211 */         else if (isWriteable(dest, name)) {
/*  212 */           value = ((Map)orig).get(name);
/*  213 */           setSimpleProperty(dest, name, value);
/*      */         }
/*      */       }
/*      */     }
/*      */     else {
/*  218 */       PropertyDescriptor[] origDescriptors = getPropertyDescriptors(orig);
/*      */ 
/*  220 */       for (i = 0; i < origDescriptors.length; ++i) {
/*  221 */         name = origDescriptors[i].getName();
/*  222 */         if (isReadable(orig, name))
/*  223 */           if (dest instanceof DynaBean) {
/*  224 */             if (isWriteable(dest, name)) {
/*  225 */               value = getSimpleProperty(orig, name);
/*  226 */               ((DynaBean)dest).set(name, value);
/*      */             }
/*      */           }
/*  229 */           else if (isWriteable(dest, name)) {
/*  230 */             value = getSimpleProperty(orig, name);
/*  231 */             setSimpleProperty(dest, name, value);
/*      */           }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map describe(Object bean)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*      */     int i;
/*      */     String name;
/*  263 */     if (bean == null) {
/*  264 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  266 */     Map description = new HashMap();
/*  267 */     if (bean instanceof DynaBean) {
/*  268 */       DynaProperty[] descriptors = ((DynaBean)bean).getDynaClass().getDynaProperties();
/*      */ 
/*  270 */       for (i = 0; i < descriptors.length; ++i) {
/*  271 */         name = descriptors[i].getName();
/*  272 */         description.put(name, getProperty(bean, name));
/*      */       }
/*      */     } else {
/*  275 */       PropertyDescriptor[] descriptors = getPropertyDescriptors(bean);
/*      */ 
/*  277 */       for (i = 0; i < descriptors.length; ++i) {
/*  278 */         name = descriptors[i].getName();
/*  279 */         if (descriptors[i].getReadMethod() != null)
/*  280 */           description.put(name, getProperty(bean, name));
/*      */       }
/*      */     }
/*  283 */     return description;
/*      */   }
/*      */ 
/*      */   public Object getIndexedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  315 */     if (bean == null) {
/*  316 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  318 */     if (name == null) {
/*  319 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*  323 */     int delim = name.indexOf(91);
/*  324 */     int delim2 = name.indexOf(93);
/*  325 */     if ((delim < 0) || (delim2 <= delim)) {
/*  326 */       throw new IllegalArgumentException("Invalid indexed property '" + name + "'");
/*      */     }
/*      */ 
/*  329 */     int index = -1;
/*      */     try {
/*  331 */       String subscript = name.substring(delim + 1, delim2);
/*  332 */       index = Integer.parseInt(subscript);
/*      */     } catch (NumberFormatException e) {
/*  334 */       throw new IllegalArgumentException("Invalid indexed property '" + name + "'");
/*      */     }
/*      */ 
/*  337 */     name = name.substring(0, delim);
/*      */ 
/*  340 */     return getIndexedProperty(bean, name, index);
/*      */   }
/*      */ 
/*      */   public Object getIndexedProperty(Object bean, String name, int index)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  371 */     if (bean == null) {
/*  372 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  374 */     if (name == null) {
/*  375 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*  379 */     if (bean instanceof DynaBean) {
/*  380 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/*  382 */       if (descriptor == null) {
/*  383 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/*  386 */       return ((DynaBean)bean).get(name, index);
/*      */     }
/*      */ 
/*  390 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/*  392 */     if (descriptor == null) {
/*  393 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/*  398 */     if (descriptor instanceof IndexedPropertyDescriptor) {
/*  399 */       readMethod = ((IndexedPropertyDescriptor)descriptor).getIndexedReadMethod();
/*      */ 
/*  401 */       if (readMethod != null) {
/*  402 */         Object[] subscript = new Object[1];
/*  403 */         subscript[0] = new Integer(index);
/*      */         try {
/*  405 */           return invokeMethod(readMethod, bean, subscript);
/*      */         } catch (InvocationTargetException e) {
/*  407 */           if (e.getTargetException() instanceof ArrayIndexOutOfBoundsException)
/*      */           {
/*  409 */             throw ((ArrayIndexOutOfBoundsException)e.getTargetException());
/*      */           }
/*      */ 
/*  412 */           throw e;
/*      */         }
/*      */ 
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  419 */     Method readMethod = getReadMethod(descriptor);
/*  420 */     if (readMethod == null) {
/*  421 */       throw new NoSuchMethodException("Property '" + name + "' has no getter method");
/*      */     }
/*      */ 
/*  426 */     Object value = invokeMethod(readMethod, bean, new Object[0]);
/*  427 */     if (!(value.getClass().isArray())) {
/*  428 */       if (!(value instanceof List)) {
/*  429 */         throw new IllegalArgumentException("Property '" + name + "' is not indexed");
/*      */       }
/*      */ 
/*  433 */       return ((List)value).get(index);
/*      */     }
/*      */ 
/*  437 */     return Array.get(value, index);
/*      */   }
/*      */ 
/*      */   public Object getMappedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  465 */     if (bean == null) {
/*  466 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  468 */     if (name == null) {
/*  469 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*  473 */     int delim = name.indexOf(40);
/*  474 */     int delim2 = name.indexOf(41);
/*  475 */     if ((delim < 0) || (delim2 <= delim)) {
/*  476 */       throw new IllegalArgumentException("Invalid mapped property '" + name + "'");
/*      */     }
/*      */ 
/*  481 */     String key = name.substring(delim + 1, delim2);
/*  482 */     name = name.substring(0, delim);
/*      */ 
/*  485 */     return getMappedProperty(bean, name, key);
/*      */   }
/*      */ 
/*      */   public Object getMappedProperty(Object bean, String name, String key)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*      */     Method readMethod;
/*  510 */     if (bean == null) {
/*  511 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  513 */     if (name == null) {
/*  514 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*  516 */     if (key == null) {
/*  517 */       throw new IllegalArgumentException("No key specified");
/*      */     }
/*      */ 
/*  521 */     if (bean instanceof DynaBean) {
/*  522 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/*  524 */       if (descriptor == null) {
/*  525 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/*  528 */       return ((DynaBean)bean).get(name, key);
/*      */     }
/*      */ 
/*  531 */     Object result = null;
/*      */ 
/*  534 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*  535 */     if (descriptor == null) {
/*  536 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/*  540 */     if (descriptor instanceof MappedPropertyDescriptor)
/*      */     {
/*  542 */       readMethod = ((MappedPropertyDescriptor)descriptor).getMappedReadMethod();
/*      */ 
/*  544 */       if (readMethod != null) {
/*  545 */         Object[] keyArray = new Object[1];
/*  546 */         keyArray[0] = key;
/*  547 */         result = invokeMethod(readMethod, bean, keyArray);
/*      */       } else {
/*  549 */         throw new NoSuchMethodException("Property '" + name + "' has no mapped getter method");
/*      */       }
/*      */     }
/*      */     else
/*      */     {
/*  554 */       readMethod = descriptor.getReadMethod();
/*  555 */       if (readMethod != null) {
/*  556 */         Object invokeResult = invokeMethod(readMethod, bean, new Object[0]);
/*      */ 
/*  558 */         if (invokeResult instanceof Map)
/*  559 */           result = ((Map)invokeResult).get(key);
/*      */       }
/*      */       else {
/*  562 */         throw new NoSuchMethodException("Property '" + name + "' has no mapped getter method");
/*      */       }
/*      */     }
/*      */ 
/*  566 */     return result;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public FastHashMap getMappedPropertyDescriptors(Class beanClass)
/*      */   {
/*  581 */     if (beanClass == null) {
/*  582 */       return null;
/*      */     }
/*      */ 
/*  586 */     return ((FastHashMap)this.mappedDescriptorsCache.get(beanClass));
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public FastHashMap getMappedPropertyDescriptors(Object bean)
/*      */   {
/*  601 */     if (bean == null) {
/*  602 */       return null;
/*      */     }
/*  604 */     return getMappedPropertyDescriptors(bean.getClass());
/*      */   }
/*      */ 
/*      */   public Object getNestedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  631 */     if (bean == null) {
/*  632 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  634 */     if (name == null) {
/*  635 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*  638 */     int indexOfINDEXED_DELIM = -1;
/*  639 */     int indexOfMAPPED_DELIM = -1;
/*  640 */     int indexOfMAPPED_DELIM2 = -1;
/*  641 */     int indexOfNESTED_DELIM = -1;
/*      */     while (true) {
/*  643 */       indexOfNESTED_DELIM = name.indexOf(46);
/*  644 */       indexOfMAPPED_DELIM = name.indexOf(40);
/*  645 */       indexOfMAPPED_DELIM2 = name.indexOf(41);
/*  646 */       if ((indexOfMAPPED_DELIM2 >= 0) && (indexOfMAPPED_DELIM >= 0) && (((indexOfNESTED_DELIM < 0) || (indexOfNESTED_DELIM > indexOfMAPPED_DELIM))))
/*      */       {
/*  648 */         indexOfNESTED_DELIM = name.indexOf(46, indexOfMAPPED_DELIM2);
/*      */       }
/*      */       else {
/*  651 */         indexOfNESTED_DELIM = name.indexOf(46);
/*      */       }
/*  653 */       if (indexOfNESTED_DELIM < 0) {
/*      */         break;
/*      */       }
/*  656 */       String next = name.substring(0, indexOfNESTED_DELIM);
/*  657 */       indexOfINDEXED_DELIM = next.indexOf(91);
/*  658 */       indexOfMAPPED_DELIM = next.indexOf(40);
/*  659 */       if (bean instanceof Map)
/*  660 */         bean = ((Map)bean).get(next);
/*  661 */       else if (indexOfMAPPED_DELIM >= 0)
/*  662 */         bean = getMappedProperty(bean, next);
/*  663 */       else if (indexOfINDEXED_DELIM >= 0)
/*  664 */         bean = getIndexedProperty(bean, next);
/*      */       else {
/*  666 */         bean = getSimpleProperty(bean, next);
/*      */       }
/*  668 */       if (bean == null) {
/*  669 */         throw new NestedNullException("Null property value for '" + name.substring(0, indexOfNESTED_DELIM) + "'");
/*      */       }
/*      */ 
/*  673 */       name = name.substring(indexOfNESTED_DELIM + 1);
/*      */     }
/*      */ 
/*  676 */     indexOfINDEXED_DELIM = name.indexOf(91);
/*  677 */     indexOfMAPPED_DELIM = name.indexOf(40);
/*      */ 
/*  679 */     if (bean instanceof Map)
/*  680 */       bean = ((Map)bean).get(name);
/*  681 */     else if (indexOfMAPPED_DELIM >= 0)
/*  682 */       bean = getMappedProperty(bean, name);
/*  683 */     else if (indexOfINDEXED_DELIM >= 0)
/*  684 */       bean = getIndexedProperty(bean, name);
/*      */     else {
/*  686 */       bean = getSimpleProperty(bean, name);
/*      */     }
/*  688 */     return bean;
/*      */   }
/*      */ 
/*      */   public Object getProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  715 */     return getNestedProperty(bean, name);
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor getPropertyDescriptor(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  750 */     if (bean == null) {
/*  751 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  753 */     if (name == null) {
/*  754 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*      */     while (true)
/*      */     {
/*  759 */       int period = findNextNestedIndex(name);
/*  760 */       if (period < 0) {
/*      */         break;
/*      */       }
/*  763 */       String next = name.substring(0, period);
/*  764 */       int indexOfINDEXED_DELIM = next.indexOf(91);
/*  765 */       int indexOfMAPPED_DELIM = next.indexOf(40);
/*  766 */       if ((indexOfMAPPED_DELIM >= 0) && (((indexOfINDEXED_DELIM < 0) || (indexOfMAPPED_DELIM < indexOfINDEXED_DELIM))))
/*      */       {
/*  769 */         bean = getMappedProperty(bean, next);
/*      */       }
/*  771 */       else if (indexOfINDEXED_DELIM >= 0)
/*  772 */         bean = getIndexedProperty(bean, next);
/*      */       else {
/*  774 */         bean = getSimpleProperty(bean, next);
/*      */       }
/*      */ 
/*  777 */       if (bean == null) {
/*  778 */         throw new IllegalArgumentException("Null property value for '" + name.substring(0, period) + "'");
/*      */       }
/*      */ 
/*  782 */       name = name.substring(period + 1);
/*      */     }
/*      */ 
/*  786 */     int left = name.indexOf(91);
/*  787 */     if (left >= 0) {
/*  788 */       name = name.substring(0, left);
/*      */     }
/*  790 */     left = name.indexOf(40);
/*  791 */     if (left >= 0) {
/*  792 */       name = name.substring(0, left);
/*      */     }
/*      */ 
/*  797 */     if ((bean == null) || (name == null)) {
/*  798 */       return null;
/*      */     }
/*      */ 
/*  801 */     PropertyDescriptor[] descriptors = getPropertyDescriptors(bean);
/*  802 */     if (descriptors != null)
/*      */     {
/*  804 */       for (int i = 0; i < descriptors.length; ++i) {
/*  805 */         if (name.equals(descriptors[i].getName())) {
/*  806 */           return descriptors[i];
/*      */         }
/*      */       }
/*      */     }
/*  810 */     PropertyDescriptor result = null;
/*  811 */     FastHashMap mappedDescriptors = getMappedPropertyDescriptors(bean);
/*      */ 
/*  813 */     if (mappedDescriptors == null) {
/*  814 */       mappedDescriptors = new FastHashMap();
/*  815 */       mappedDescriptors.setFast(true);
/*  816 */       this.mappedDescriptorsCache.put(bean.getClass(), mappedDescriptors);
/*      */     }
/*  818 */     result = (PropertyDescriptor)mappedDescriptors.get(name);
/*  819 */     if (result == null)
/*      */     {
/*      */       try {
/*  822 */         result = new MappedPropertyDescriptor(name, bean.getClass());
/*      */       }
/*      */       catch (IntrospectionException ie) {
/*      */       }
/*  826 */       if (result != null) {
/*  827 */         mappedDescriptors.put(name, result);
/*      */       }
/*      */     }
/*      */ 
/*  831 */     return result;
/*      */   }
/*      */ 
/*      */   private int findNextNestedIndex(String expression)
/*      */   {
/*  839 */     int bracketCount = 0;
/*  840 */     int i = 0; for (int size = expression.length(); i < size; ++i) {
/*  841 */       char at = expression.charAt(i);
/*  842 */       switch (at)
/*      */       {
/*      */       case '.':
/*  844 */         if (bracketCount < 1)
/*  845 */           return i;
/*      */       case '(':
/*      */       case '[':
/*  852 */         ++bracketCount;
/*  853 */         break;
/*      */       case ')':
/*      */       case ']':
/*  858 */         --bracketCount;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  863 */     return -1;
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor[] getPropertyDescriptors(Class beanClass)
/*      */   {
/*  881 */     if (beanClass == null) {
/*  882 */       throw new IllegalArgumentException("No bean class specified");
/*      */     }
/*      */ 
/*  886 */     PropertyDescriptor[] descriptors = null;
/*  887 */     descriptors = (PropertyDescriptor[])this.descriptorsCache.get(beanClass);
/*      */ 
/*  889 */     if (descriptors != null) {
/*  890 */       return descriptors;
/*      */     }
/*      */ 
/*  894 */     BeanInfo beanInfo = null;
/*      */     try {
/*  896 */       beanInfo = Introspector.getBeanInfo(beanClass);
/*      */     } catch (IntrospectionException e) {
/*  898 */       return new PropertyDescriptor[0];
/*      */     }
/*  900 */     descriptors = beanInfo.getPropertyDescriptors();
/*  901 */     if (descriptors == null) {
/*  902 */       descriptors = new PropertyDescriptor[0];
/*      */     }
/*  904 */     this.descriptorsCache.put(beanClass, descriptors);
/*  905 */     return descriptors;
/*      */   }
/*      */ 
/*      */   public PropertyDescriptor[] getPropertyDescriptors(Object bean)
/*      */   {
/*  923 */     if (bean == null) {
/*  924 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  926 */     return getPropertyDescriptors(bean.getClass());
/*      */   }
/*      */ 
/*      */   public Class getPropertyEditorClass(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  964 */     if (bean == null) {
/*  965 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/*  967 */     if (name == null) {
/*  968 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/*  971 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/*  973 */     if (descriptor != null) {
/*  974 */       return descriptor.getPropertyEditorClass();
/*      */     }
/*  976 */     return null;
/*      */   }
/*      */ 
/*      */   public Class getPropertyType(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1010 */     if (bean == null) {
/* 1011 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1013 */     if (name == null) {
/* 1014 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1018 */     if (bean instanceof DynaBean) {
/* 1019 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/* 1021 */       if (descriptor == null) {
/* 1022 */         return null;
/*      */       }
/* 1024 */       Class type = descriptor.getType();
/* 1025 */       if (type == null)
/* 1026 */         return null;
/* 1027 */       if (type.isArray()) {
/* 1028 */         return type.getComponentType();
/*      */       }
/* 1030 */       return type;
/*      */     }
/*      */ 
/* 1034 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1036 */     if (descriptor == null)
/* 1037 */       return null;
/* 1038 */     if (descriptor instanceof IndexedPropertyDescriptor) {
/* 1039 */       return ((IndexedPropertyDescriptor)descriptor).getIndexedPropertyType();
/*      */     }
/* 1041 */     if (descriptor instanceof MappedPropertyDescriptor) {
/* 1042 */       return ((MappedPropertyDescriptor)descriptor).getMappedPropertyType();
/*      */     }
/*      */ 
/* 1045 */     return descriptor.getPropertyType();
/*      */   }
/*      */ 
/*      */   public Method getReadMethod(PropertyDescriptor descriptor)
/*      */   {
/* 1061 */     return MethodUtils.getAccessibleMethod(descriptor.getReadMethod());
/*      */   }
/*      */ 
/*      */   public Object getSimpleProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1088 */     if (bean == null) {
/* 1089 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1091 */     if (name == null) {
/* 1092 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1096 */     if (name.indexOf(46) >= 0) {
/* 1097 */       throw new IllegalArgumentException("Nested property names are not allowed");
/*      */     }
/* 1099 */     if (name.indexOf(91) >= 0) {
/* 1100 */       throw new IllegalArgumentException("Indexed property names are not allowed");
/*      */     }
/* 1102 */     if (name.indexOf(40) >= 0) {
/* 1103 */       throw new IllegalArgumentException("Mapped property names are not allowed");
/*      */     }
/*      */ 
/* 1108 */     if (bean instanceof DynaBean) {
/* 1109 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/* 1111 */       if (descriptor == null) {
/* 1112 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/* 1115 */       return ((DynaBean)bean).get(name);
/*      */     }
/*      */ 
/* 1119 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1121 */     if (descriptor == null) {
/* 1122 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/* 1125 */     Method readMethod = getReadMethod(descriptor);
/* 1126 */     if (readMethod == null) {
/* 1127 */       throw new NoSuchMethodException("Property '" + name + "' has no getter method");
/*      */     }
/*      */ 
/* 1132 */     Object value = invokeMethod(readMethod, bean, new Object[0]);
/* 1133 */     return value;
/*      */   }
/*      */ 
/*      */   public Method getWriteMethod(PropertyDescriptor descriptor)
/*      */   {
/* 1148 */     return MethodUtils.getAccessibleMethod(descriptor.getWriteMethod());
/*      */   }
/*      */ 
/*      */   public boolean isReadable(Object bean, String name)
/*      */   {
/* 1169 */     if (bean == null) {
/* 1170 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1172 */     if (name == null) {
/* 1173 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1177 */     if (bean instanceof DynaBean)
/*      */     {
/* 1179 */       return (((DynaBean)bean).getDynaClass().getDynaProperty(name) != null);
/*      */     }
/*      */     try {
/* 1182 */       PropertyDescriptor desc = getPropertyDescriptor(bean, name);
/*      */ 
/* 1184 */       if (desc != null) {
/* 1185 */         Method readMethod = desc.getReadMethod();
/* 1186 */         if ((readMethod == null) && (desc instanceof IndexedPropertyDescriptor))
/*      */         {
/* 1188 */           readMethod = ((IndexedPropertyDescriptor)desc).getIndexedReadMethod();
/*      */         }
/* 1190 */         return (readMethod != null);
/*      */       }
/* 1192 */       return false;
/*      */     }
/*      */     catch (IllegalAccessException e) {
/* 1195 */       return false;
/*      */     } catch (InvocationTargetException e) {
/* 1197 */       return false; } catch (NoSuchMethodException e) {
/*      */     }
/* 1199 */     return false;
/*      */   }
/*      */ 
/*      */   public boolean isWriteable(Object bean, String name)
/*      */   {
/* 1222 */     if (bean == null) {
/* 1223 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1225 */     if (name == null) {
/* 1226 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1230 */     if (bean instanceof DynaBean)
/*      */     {
/* 1232 */       return (((DynaBean)bean).getDynaClass().getDynaProperty(name) != null);
/*      */     }
/*      */     try {
/* 1235 */       PropertyDescriptor desc = getPropertyDescriptor(bean, name);
/*      */ 
/* 1237 */       if (desc != null) {
/* 1238 */         Method writeMethod = desc.getWriteMethod();
/* 1239 */         if ((writeMethod == null) && (desc instanceof IndexedPropertyDescriptor))
/*      */         {
/* 1241 */           writeMethod = ((IndexedPropertyDescriptor)desc).getIndexedWriteMethod();
/*      */         }
/* 1243 */         return (writeMethod != null);
/*      */       }
/* 1245 */       return false;
/*      */     }
/*      */     catch (IllegalAccessException e) {
/* 1248 */       return false;
/*      */     } catch (InvocationTargetException e) {
/* 1250 */       return false; } catch (NoSuchMethodException e) {
/*      */     }
/* 1252 */     return false;
/*      */   }
/*      */ 
/*      */   public void setIndexedProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1289 */     if (bean == null) {
/* 1290 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1292 */     if (name == null) {
/* 1293 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1297 */     int delim = name.indexOf(91);
/* 1298 */     int delim2 = name.indexOf(93);
/* 1299 */     if ((delim < 0) || (delim2 <= delim)) {
/* 1300 */       throw new IllegalArgumentException("Invalid indexed property '" + name + "'");
/*      */     }
/*      */ 
/* 1303 */     int index = -1;
/*      */     try {
/* 1305 */       String subscript = name.substring(delim + 1, delim2);
/* 1306 */       index = Integer.parseInt(subscript);
/*      */     } catch (NumberFormatException e) {
/* 1308 */       throw new IllegalArgumentException("Invalid indexed property '" + name + "'");
/*      */     }
/*      */ 
/* 1311 */     name = name.substring(0, delim);
/*      */ 
/* 1314 */     setIndexedProperty(bean, name, index, value);
/*      */   }
/*      */ 
/*      */   public void setIndexedProperty(Object bean, String name, int index, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1346 */     if (bean == null) {
/* 1347 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1349 */     if (name == null) {
/* 1350 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1354 */     if (bean instanceof DynaBean) {
/* 1355 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/* 1357 */       if (descriptor == null) {
/* 1358 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/* 1361 */       ((DynaBean)bean).set(name, index, value);
/* 1362 */       return;
/*      */     }
/*      */ 
/* 1366 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1368 */     if (descriptor == null) {
/* 1369 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/* 1374 */     if (descriptor instanceof IndexedPropertyDescriptor) {
/* 1375 */       Method writeMethod = ((IndexedPropertyDescriptor)descriptor).getIndexedWriteMethod();
/*      */ 
/* 1377 */       if (writeMethod != null) {
/* 1378 */         Object[] subscript = new Object[2];
/* 1379 */         subscript[0] = new Integer(index);
/* 1380 */         subscript[1] = value;
/*      */         try {
/* 1382 */           if (this.log.isTraceEnabled()) {
/* 1383 */             String valueClassName = (value == null) ? "<null>" : value.getClass().getName();
/*      */ 
/* 1386 */             this.log.trace("setSimpleProperty: Invoking method " + writeMethod + " with index=" + index + ", value=" + value + " (class " + valueClassName + ")");
/*      */           }
/*      */ 
/* 1391 */           invokeMethod(writeMethod, bean, subscript);
/*      */         } catch (InvocationTargetException e) {
/* 1393 */           if (e.getTargetException() instanceof ArrayIndexOutOfBoundsException)
/*      */           {
/* 1395 */             throw ((ArrayIndexOutOfBoundsException)e.getTargetException());
/*      */           }
/*      */ 
/* 1398 */           throw e;
/*      */         }
/*      */ 
/* 1401 */         return;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1406 */     Method readMethod = descriptor.getReadMethod();
/* 1407 */     if (readMethod == null) {
/* 1408 */       throw new NoSuchMethodException("Property '" + name + "' has no getter method");
/*      */     }
/*      */ 
/* 1413 */     Object array = invokeMethod(readMethod, bean, new Object[0]);
/* 1414 */     if (!(array.getClass().isArray())) {
/* 1415 */       if (array instanceof List)
/*      */       {
/* 1417 */         ((List)array).set(index, value); return;
/*      */       }
/* 1419 */       throw new IllegalArgumentException("Property '" + name + "' is not indexed");
/*      */     }
/*      */ 
/* 1424 */     Array.set(array, index, value);
/*      */   }
/*      */ 
/*      */   public void setMappedProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1454 */     if (bean == null) {
/* 1455 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1457 */     if (name == null) {
/* 1458 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1462 */     int delim = name.indexOf(40);
/* 1463 */     int delim2 = name.indexOf(41);
/* 1464 */     if ((delim < 0) || (delim2 <= delim)) {
/* 1465 */       throw new IllegalArgumentException("Invalid mapped property '" + name + "'");
/*      */     }
/*      */ 
/* 1470 */     String key = name.substring(delim + 1, delim2);
/* 1471 */     name = name.substring(0, delim);
/*      */ 
/* 1474 */     setMappedProperty(bean, name, key, value);
/*      */   }
/*      */ 
/*      */   public void setMappedProperty(Object bean, String name, String key, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1500 */     if (bean == null) {
/* 1501 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1503 */     if (name == null) {
/* 1504 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/* 1506 */     if (key == null) {
/* 1507 */       throw new IllegalArgumentException("No key specified");
/*      */     }
/*      */ 
/* 1511 */     if (bean instanceof DynaBean) {
/* 1512 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/* 1514 */       if (descriptor == null) {
/* 1515 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/* 1518 */       ((DynaBean)bean).set(name, key, value);
/* 1519 */       return;
/*      */     }
/*      */ 
/* 1523 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1525 */     if (descriptor == null) {
/* 1526 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/* 1530 */     if (descriptor instanceof MappedPropertyDescriptor)
/*      */     {
/* 1532 */       Method mappedWriteMethod = ((MappedPropertyDescriptor)descriptor).getMappedWriteMethod();
/*      */ 
/* 1535 */       if (mappedWriteMethod != null) {
/* 1536 */         Object[] params = new Object[2];
/* 1537 */         params[0] = key;
/* 1538 */         params[1] = value;
/* 1539 */         if (this.log.isTraceEnabled()) {
/* 1540 */           String valueClassName = (value == null) ? "<null>" : value.getClass().getName();
/*      */ 
/* 1542 */           this.log.trace("setSimpleProperty: Invoking method " + mappedWriteMethod + " with key=" + key + ", value=" + value + " (class " + valueClassName + ")");
/*      */         }
/*      */ 
/* 1547 */         invokeMethod(mappedWriteMethod, bean, params);
/*      */       } else {
/* 1549 */         throw new NoSuchMethodException("Property '" + name + "' has no mapped setter method");
/*      */       }
/*      */ 
/*      */     }
/*      */     else
/*      */     {
/* 1555 */       Method readMethod = descriptor.getReadMethod();
/* 1556 */       if (readMethod != null) {
/* 1557 */         Object invokeResult = invokeMethod(readMethod, bean, new Object[0]);
/*      */ 
/* 1559 */         if (invokeResult instanceof Map)
/* 1560 */           ((Map)invokeResult).put(key, value);
/*      */       }
/*      */       else {
/* 1563 */         throw new NoSuchMethodException("Property '" + name + "' has no mapped getter method");
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setNestedProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1595 */     if (bean == null) {
/* 1596 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1598 */     if (name == null) {
/* 1599 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1602 */     int indexOfINDEXED_DELIM = -1;
/* 1603 */     int indexOfMAPPED_DELIM = -1;
/*      */     while (true) {
/* 1605 */       int delim = name.indexOf(46);
/* 1606 */       if (delim < 0) {
/*      */         break;
/*      */       }
/* 1609 */       String next = name.substring(0, delim);
/* 1610 */       indexOfINDEXED_DELIM = next.indexOf(91);
/* 1611 */       indexOfMAPPED_DELIM = next.indexOf(40);
/* 1612 */       if (bean instanceof Map)
/* 1613 */         bean = ((Map)bean).get(next);
/* 1614 */       else if (indexOfMAPPED_DELIM >= 0)
/* 1615 */         bean = getMappedProperty(bean, next);
/* 1616 */       else if (indexOfINDEXED_DELIM >= 0)
/* 1617 */         bean = getIndexedProperty(bean, next);
/*      */       else {
/* 1619 */         bean = getSimpleProperty(bean, next);
/*      */       }
/* 1621 */       if (bean == null) {
/* 1622 */         throw new IllegalArgumentException("Null property value for '" + name.substring(0, delim) + "'");
/*      */       }
/*      */ 
/* 1626 */       name = name.substring(delim + 1);
/*      */     }
/*      */ 
/* 1629 */     indexOfINDEXED_DELIM = name.indexOf(91);
/* 1630 */     indexOfMAPPED_DELIM = name.indexOf(40);
/*      */ 
/* 1632 */     if (bean instanceof Map)
/*      */     {
/* 1634 */       PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1636 */       if (descriptor == null)
/*      */       {
/* 1638 */         ((Map)bean).put(name, value);
/*      */       }
/*      */       else
/* 1641 */         setSimpleProperty(bean, name, value);
/*      */     }
/* 1643 */     else if (indexOfMAPPED_DELIM >= 0) {
/* 1644 */       setMappedProperty(bean, name, value);
/* 1645 */     } else if (indexOfINDEXED_DELIM >= 0) {
/* 1646 */       setIndexedProperty(bean, name, value);
/*      */     } else {
/* 1648 */       setSimpleProperty(bean, name, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1677 */     setNestedProperty(bean, name, value);
/*      */   }
/*      */ 
/*      */   public void setSimpleProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/* 1706 */     if (bean == null) {
/* 1707 */       throw new IllegalArgumentException("No bean specified");
/*      */     }
/* 1709 */     if (name == null) {
/* 1710 */       throw new IllegalArgumentException("No name specified");
/*      */     }
/*      */ 
/* 1714 */     if (name.indexOf(46) >= 0) {
/* 1715 */       throw new IllegalArgumentException("Nested property names are not allowed");
/*      */     }
/* 1717 */     if (name.indexOf(91) >= 0) {
/* 1718 */       throw new IllegalArgumentException("Indexed property names are not allowed");
/*      */     }
/* 1720 */     if (name.indexOf(40) >= 0) {
/* 1721 */       throw new IllegalArgumentException("Mapped property names are not allowed");
/*      */     }
/*      */ 
/* 1726 */     if (bean instanceof DynaBean) {
/* 1727 */       DynaProperty descriptor = ((DynaBean)bean).getDynaClass().getDynaProperty(name);
/*      */ 
/* 1729 */       if (descriptor == null) {
/* 1730 */         throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */       }
/*      */ 
/* 1733 */       ((DynaBean)bean).set(name, value);
/* 1734 */       return;
/*      */     }
/*      */ 
/* 1738 */     PropertyDescriptor descriptor = getPropertyDescriptor(bean, name);
/*      */ 
/* 1740 */     if (descriptor == null) {
/* 1741 */       throw new NoSuchMethodException("Unknown property '" + name + "'");
/*      */     }
/*      */ 
/* 1744 */     Method writeMethod = getWriteMethod(descriptor);
/* 1745 */     if (writeMethod == null) {
/* 1746 */       throw new NoSuchMethodException("Property '" + name + "' has no setter method");
/*      */     }
/*      */ 
/* 1751 */     Object[] values = new Object[1];
/* 1752 */     values[0] = value;
/* 1753 */     if (this.log.isTraceEnabled()) {
/* 1754 */       String valueClassName = (value == null) ? "<null>" : value.getClass().getName();
/*      */ 
/* 1756 */       this.log.trace("setSimpleProperty: Invoking method " + writeMethod + " with value " + value + " (class " + valueClassName + ")");
/*      */     }
/*      */ 
/* 1759 */     invokeMethod(writeMethod, bean, values);
/*      */   }
/*      */ 
/*      */   private Object invokeMethod(Method method, Object bean, Object[] values)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*      */     try
/*      */     {
/* 1773 */       return method.invoke(bean, values);
/*      */     }
/*      */     catch (IllegalArgumentException e)
/*      */     {
/* 1777 */       this.log.error("Method invocation failed.", e);
/* 1778 */       throw new IllegalArgumentException("Cannot invoke " + method.getDeclaringClass().getName() + "." + method.getName() + " - " + e.getMessage());
/*      */     }
/*      */   }
/*      */ }