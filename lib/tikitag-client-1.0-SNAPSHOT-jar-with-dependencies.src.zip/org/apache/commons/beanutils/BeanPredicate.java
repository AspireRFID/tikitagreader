/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanPredicate
/*     */   implements Predicate
/*     */ {
/*  32 */   private final Log log = LogFactory.getLog(super.getClass());
/*     */   private String propertyName;
/*     */   private Predicate predicate;
/*     */ 
/*     */   public BeanPredicate(String propertyName, Predicate predicate)
/*     */   {
/*  48 */     this.propertyName = propertyName;
/*  49 */     this.predicate = predicate;
/*     */   }
/*     */ 
/*     */   public boolean evaluate(Object object)
/*     */   {
/*  59 */     boolean evaluation = false;
/*     */     try
/*     */     {
/*  62 */       Object propValue = PropertyUtils.getProperty(object, this.propertyName);
/*  63 */       evaluation = this.predicate.evaluate(propValue);
/*     */     } catch (IllegalArgumentException e) {
/*  65 */       String errorMsg = "Problem during evaluation.";
/*  66 */       this.log.error("ERROR: Problem during evaluation.", e);
/*  67 */       throw e;
/*     */     } catch (IllegalAccessException e) {
/*  69 */       String errorMsg = "Unable to access the property provided.";
/*  70 */       this.log.error("Unable to access the property provided.", e);
/*  71 */       throw new IllegalArgumentException("Unable to access the property provided.");
/*     */     } catch (InvocationTargetException e) {
/*  73 */       String errorMsg = "Exception occurred in property's getter";
/*  74 */       this.log.error("Exception occurred in property's getter", e);
/*  75 */       throw new IllegalArgumentException("Exception occurred in property's getter");
/*     */     } catch (NoSuchMethodException e) {
/*  77 */       String errorMsg = "Property not found.";
/*  78 */       this.log.error("Property not found.", e);
/*  79 */       throw new IllegalArgumentException("Property not found.");
/*     */     }
/*     */ 
/*  82 */     return evaluation;
/*     */   }
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/*  91 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   public void setPropertyName(String propertyName)
/*     */   {
/* 100 */     this.propertyName = propertyName;
/*     */   }
/*     */ 
/*     */   public Predicate getPredicate()
/*     */   {
/* 109 */     return this.predicate;
/*     */   }
/*     */ 
/*     */   public void setPredicate(Predicate predicate)
/*     */   {
/* 118 */     this.predicate = predicate;
/*     */   }
/*     */ }