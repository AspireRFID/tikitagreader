/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ public class ConvertUtils
/*     */ {
/*     */   /** @deprecated */
/*     */   public static boolean getDefaultBoolean()
/*     */   {
/*  45 */     return ConvertUtilsBean.getInstance().getDefaultBoolean();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultBoolean(boolean newDefaultBoolean)
/*     */   {
/*  54 */     ConvertUtilsBean.getInstance().setDefaultBoolean(newDefaultBoolean);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static byte getDefaultByte()
/*     */   {
/*  64 */     return ConvertUtilsBean.getInstance().getDefaultByte();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultByte(byte newDefaultByte)
/*     */   {
/*  73 */     ConvertUtilsBean.getInstance().setDefaultByte(newDefaultByte);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static char getDefaultCharacter()
/*     */   {
/*  83 */     return ConvertUtilsBean.getInstance().getDefaultCharacter();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultCharacter(char newDefaultCharacter)
/*     */   {
/*  92 */     ConvertUtilsBean.getInstance().setDefaultCharacter(newDefaultCharacter);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static double getDefaultDouble()
/*     */   {
/* 102 */     return ConvertUtilsBean.getInstance().getDefaultDouble();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultDouble(double newDefaultDouble)
/*     */   {
/* 111 */     ConvertUtilsBean.getInstance().setDefaultDouble(newDefaultDouble);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static float getDefaultFloat()
/*     */   {
/* 121 */     return ConvertUtilsBean.getInstance().getDefaultFloat();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultFloat(float newDefaultFloat)
/*     */   {
/* 130 */     ConvertUtilsBean.getInstance().setDefaultFloat(newDefaultFloat);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static int getDefaultInteger()
/*     */   {
/* 140 */     return ConvertUtilsBean.getInstance().getDefaultInteger();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultInteger(int newDefaultInteger)
/*     */   {
/* 149 */     ConvertUtilsBean.getInstance().setDefaultInteger(newDefaultInteger);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static long getDefaultLong()
/*     */   {
/* 159 */     return ConvertUtilsBean.getInstance().getDefaultLong();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultLong(long newDefaultLong)
/*     */   {
/* 168 */     ConvertUtilsBean.getInstance().setDefaultLong(newDefaultLong);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static short getDefaultShort()
/*     */   {
/* 178 */     return ConvertUtilsBean.getInstance().getDefaultShort();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDefaultShort(short newDefaultShort)
/*     */   {
/* 187 */     ConvertUtilsBean.getInstance().setDefaultShort(newDefaultShort);
/*     */   }
/*     */ 
/*     */   public static String convert(Object value)
/*     */   {
/* 202 */     return ConvertUtilsBean.getInstance().convert(value);
/*     */   }
/*     */ 
/*     */   public static Object convert(String value, Class clazz)
/*     */   {
/* 217 */     return ConvertUtilsBean.getInstance().convert(value, clazz);
/*     */   }
/*     */ 
/*     */   public static Object convert(String[] values, Class clazz)
/*     */   {
/* 232 */     return ConvertUtilsBean.getInstance().convert(values, clazz);
/*     */   }
/*     */ 
/*     */   public static void deregister()
/*     */   {
/* 247 */     ConvertUtilsBean.getInstance().deregister();
/*     */   }
/*     */ 
/*     */   public static void deregister(Class clazz)
/*     */   {
/* 262 */     ConvertUtilsBean.getInstance().deregister(clazz);
/*     */   }
/*     */ 
/*     */   public static Converter lookup(Class clazz)
/*     */   {
/* 278 */     return ConvertUtilsBean.getInstance().lookup(clazz);
/*     */   }
/*     */ 
/*     */   public static void register(Converter converter, Class clazz)
/*     */   {
/* 293 */     ConvertUtilsBean.getInstance().register(converter, clazz);
/*     */   }
/*     */ }