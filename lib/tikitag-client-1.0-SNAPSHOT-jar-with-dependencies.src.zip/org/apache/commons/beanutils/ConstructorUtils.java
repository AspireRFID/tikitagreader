/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Modifier;
/*     */ 
/*     */ public class ConstructorUtils
/*     */ {
/*  52 */   private static final Class[] emptyClassArray = new Class[0];
/*     */ 
/*  54 */   private static final Object[] emptyObjectArray = new Object[0];
/*     */ 
/*     */   public static Object invokeConstructor(Class klass, Object arg)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/*  78 */     Object[] args = { arg };
/*  79 */     return invokeConstructor(klass, args);
/*     */   }
/*     */ 
/*     */   public static Object invokeConstructor(Class klass, Object[] args)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 103 */     if (null == args) {
/* 104 */       args = emptyObjectArray;
/*     */     }
/* 106 */     int arguments = args.length;
/* 107 */     Class[] parameterTypes = new Class[arguments];
/* 108 */     for (int i = 0; i < arguments; ++i) {
/* 109 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/* 111 */     return invokeConstructor(klass, args, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Object invokeConstructor(Class klass, Object[] args, Class[] parameterTypes)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 142 */     if (parameterTypes == null) {
/* 143 */       parameterTypes = emptyClassArray;
/*     */     }
/* 145 */     if (args == null) {
/* 146 */       args = emptyObjectArray;
/*     */     }
/*     */ 
/* 149 */     Constructor ctor = getMatchingAccessibleConstructor(klass, parameterTypes);
/*     */ 
/* 151 */     if (null == ctor) {
/* 152 */       throw new NoSuchMethodException("No such accessible constructor on object: " + klass.getName());
/*     */     }
/*     */ 
/* 155 */     return ctor.newInstance(args);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactConstructor(Class klass, Object arg)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 179 */     Object[] args = { arg };
/* 180 */     return invokeExactConstructor(klass, args);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactConstructor(Class klass, Object[] args)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 203 */     if (null == args) {
/* 204 */       args = emptyObjectArray;
/*     */     }
/* 206 */     int arguments = args.length;
/* 207 */     Class[] parameterTypes = new Class[arguments];
/* 208 */     for (int i = 0; i < arguments; ++i) {
/* 209 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/* 211 */     return invokeExactConstructor(klass, args, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactConstructor(Class klass, Object[] args, Class[] parameterTypes)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException
/*     */   {
/* 243 */     if (args == null) {
/* 244 */       args = emptyObjectArray;
/*     */     }
/*     */ 
/* 247 */     if (parameterTypes == null) {
/* 248 */       parameterTypes = emptyClassArray;
/*     */     }
/*     */ 
/* 251 */     Constructor ctor = getAccessibleConstructor(klass, parameterTypes);
/* 252 */     if (null == ctor) {
/* 253 */       throw new NoSuchMethodException("No such accessible constructor on object: " + klass.getName());
/*     */     }
/*     */ 
/* 256 */     return ctor.newInstance(args);
/*     */   }
/*     */ 
/*     */   public static Constructor getAccessibleConstructor(Class klass, Class parameterType)
/*     */   {
/* 271 */     Class[] parameterTypes = { parameterType };
/* 272 */     return getAccessibleConstructor(klass, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Constructor getAccessibleConstructor(Class klass, Class[] parameterTypes)
/*     */   {
/*     */     try
/*     */     {
/* 289 */       return getAccessibleConstructor(klass.getConstructor(parameterTypes));
/*     */     } catch (NoSuchMethodException e) {
/*     */     }
/* 292 */     return null;
/*     */   }
/*     */ 
/*     */   public static Constructor getAccessibleConstructor(Constructor ctor)
/*     */   {
/* 306 */     if (ctor == null) {
/* 307 */       return null;
/*     */     }
/*     */ 
/* 311 */     if (!(Modifier.isPublic(ctor.getModifiers()))) {
/* 312 */       return null;
/*     */     }
/*     */ 
/* 316 */     Class clazz = ctor.getDeclaringClass();
/* 317 */     if (Modifier.isPublic(clazz.getModifiers())) {
/* 318 */       return ctor;
/*     */     }
/*     */ 
/* 322 */     return null;
/*     */   }
/*     */ 
/*     */   private static Constructor getMatchingAccessibleConstructor(Class clazz, Class[] parameterTypes)
/*     */   {
/*     */     try
/*     */     {
/* 348 */       Constructor ctor = clazz.getConstructor(parameterTypes);
/*     */       try
/*     */       {
/* 366 */         ctor.setAccessible(true); } catch (SecurityException se) {
/*     */       }
/* 368 */       return ctor;
/*     */     }
/*     */     catch (NoSuchMethodException paramSize)
/*     */     {
/* 374 */       int paramSize = parameterTypes.length;
/* 375 */       Constructor[] ctors = clazz.getConstructors();
/* 376 */       int i = 0; for (int size = ctors.length; i < size; ++i)
/*     */       {
/* 378 */         Class[] ctorParams = ctors[i].getParameterTypes();
/* 379 */         int ctorParamSize = ctorParams.length;
/* 380 */         if (ctorParamSize == paramSize) {
/* 381 */           boolean match = true;
/* 382 */           for (int n = 0; n < ctorParamSize; ++n) {
/* 383 */             if (MethodUtils.isAssignmentCompatible(ctorParams[n], parameterTypes[n])) {
/*     */               continue;
/*     */             }
/*     */ 
/* 387 */             match = false;
/* 388 */             break;
/*     */           }
/*     */ 
/* 392 */           if (!(match))
/*     */             continue;
/* 394 */           Constructor ctor = getAccessibleConstructor(ctors[i]);
/* 395 */           if (ctor == null) continue;
/*     */           try {
/* 397 */             ctor.setAccessible(true); } catch (SecurityException se) {
/*     */           }
/* 399 */           return ctor;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 405 */     return null;
/*     */   }
/*     */ }