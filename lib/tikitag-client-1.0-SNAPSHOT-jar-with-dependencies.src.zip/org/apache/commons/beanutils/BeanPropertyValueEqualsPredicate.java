/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.apache.commons.collections.Predicate;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanPropertyValueEqualsPredicate
/*     */   implements Predicate
/*     */ {
/*     */   private final Log log;
/*     */   private String propertyName;
/*     */   private Object propertyValue;
/*     */   private boolean ignoreNull;
/*     */ 
/*     */   public BeanPropertyValueEqualsPredicate(String propertyName, Object propertyValue)
/*     */   {
/* 148 */     this(propertyName, propertyValue, false);
/*     */   }
/*     */ 
/*     */   public BeanPropertyValueEqualsPredicate(String propertyName, Object propertyValue, boolean ignoreNull)
/*     */   {
/* 111 */     this.log = LogFactory.getLog(super.getClass());
/*     */ 
/* 165 */     if ((propertyName != null) && (propertyName.length() > 0)) {
/* 166 */       this.propertyName = propertyName;
/* 167 */       this.propertyValue = propertyValue;
/* 168 */       this.ignoreNull = ignoreNull;
/*     */     } else {
/* 170 */       throw new IllegalArgumentException("propertyName cannot be null or empty");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean evaluate(Object object)
/*     */   {
/* 194 */     boolean evaluation = false;
/*     */     try
/*     */     {
/* 197 */       evaluation = evaluateValue(this.propertyValue, PropertyUtils.getProperty(object, this.propertyName));
/*     */     }
/*     */     catch (IllegalArgumentException e) {
/* 200 */       String errorMsg = "Problem during evaluation. Null value encountered in property path...";
/*     */ 
/* 202 */       if (this.ignoreNull) {
/* 203 */         this.log.warn("WARNING: Problem during evaluation. Null value encountered in property path...", e);
/*     */       } else {
/* 205 */         this.log.error("ERROR: Problem during evaluation. Null value encountered in property path...", e);
/* 206 */         throw e;
/*     */       }
/*     */     } catch (IllegalAccessException e) {
/* 209 */       String errorMsg = "Unable to access the property provided.";
/* 210 */       this.log.error("Unable to access the property provided.", e);
/* 211 */       throw new IllegalArgumentException("Unable to access the property provided.");
/*     */     } catch (InvocationTargetException e) {
/* 213 */       String errorMsg = "Exception occurred in property's getter";
/* 214 */       this.log.error("Exception occurred in property's getter", e);
/* 215 */       throw new IllegalArgumentException("Exception occurred in property's getter");
/*     */     } catch (NoSuchMethodException e) {
/* 217 */       String errorMsg = "Property not found.";
/* 218 */       this.log.error("Property not found.", e);
/* 219 */       throw new IllegalArgumentException("Property not found.");
/*     */     }
/*     */ 
/* 222 */     return evaluation;
/*     */   }
/*     */ 
/*     */   private boolean evaluateValue(Object expected, Object actual)
/*     */   {
/* 234 */     return ((expected == actual) || ((expected != null) && (expected.equals(actual))));
/*     */   }
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 245 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   public Object getPropertyValue()
/*     */   {
/* 256 */     return this.propertyValue;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreNull()
/*     */   {
/* 273 */     return this.ignoreNull;
/*     */   }
/*     */ }