/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.apache.commons.collections.Closure;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanPropertyValueChangeClosure
/*     */   implements Closure
/*     */ {
/*     */   private final Log log;
/*     */   private String propertyName;
/*     */   private Object propertyValue;
/*     */   private boolean ignoreNull;
/*     */ 
/*     */   public BeanPropertyValueChangeClosure(String propertyName, Object propertyValue)
/*     */   {
/* 118 */     this(propertyName, propertyValue, false);
/*     */   }
/*     */ 
/*     */   public BeanPropertyValueChangeClosure(String propertyName, Object propertyValue, boolean ignoreNull)
/*     */   {
/*  82 */     this.log = LogFactory.getLog(super.getClass());
/*     */ 
/* 137 */     if ((propertyName != null) && (propertyName.length() > 0)) {
/* 138 */       this.propertyName = propertyName;
/* 139 */       this.propertyValue = propertyValue;
/* 140 */       this.ignoreNull = ignoreNull;
/*     */     } else {
/* 142 */       throw new IllegalArgumentException("propertyName cannot be null or empty");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void execute(Object object)
/*     */   {
/*     */     try
/*     */     {
/* 163 */       PropertyUtils.setProperty(object, this.propertyName, this.propertyValue);
/*     */     } catch (IllegalArgumentException e) {
/* 165 */       String errorMsg = "Unable to execute Closure. Null value encountered in property path...";
/*     */ 
/* 167 */       if (this.ignoreNull) {
/* 168 */         this.log.warn("WARNING: Unable to execute Closure. Null value encountered in property path...", e);
/*     */       } else {
/* 170 */         this.log.error("ERROR: Unable to execute Closure. Null value encountered in property path...", e);
/* 171 */         throw e;
/*     */       }
/*     */     } catch (IllegalAccessException e) {
/* 174 */       String errorMsg = "Unable to access the property provided.";
/* 175 */       this.log.error("Unable to access the property provided.", e);
/* 176 */       throw new IllegalArgumentException("Unable to access the property provided.");
/*     */     } catch (InvocationTargetException e) {
/* 178 */       String errorMsg = "Exception occurred in property's getter";
/* 179 */       this.log.error("Exception occurred in property's getter", e);
/* 180 */       throw new IllegalArgumentException("Exception occurred in property's getter");
/*     */     } catch (NoSuchMethodException e) {
/* 182 */       String errorMsg = "Property not found";
/* 183 */       this.log.error("Property not found", e);
/* 184 */       throw new IllegalArgumentException("Property not found");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 194 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   public Object getPropertyValue()
/*     */   {
/* 205 */     return this.propertyValue;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreNull()
/*     */   {
/* 222 */     return this.ignoreNull;
/*     */   }
/*     */ }