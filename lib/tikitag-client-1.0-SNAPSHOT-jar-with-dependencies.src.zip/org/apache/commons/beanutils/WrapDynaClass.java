/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class WrapDynaClass
/*     */   implements DynaClass
/*     */ {
/*  73 */   protected Class beanClass = null;
/*     */ 
/*  79 */   protected PropertyDescriptor[] descriptors = null;
/*     */ 
/*  87 */   protected HashMap descriptorsMap = new HashMap();
/*     */ 
/*  93 */   protected DynaProperty[] properties = null;
/*     */ 
/* 101 */   protected HashMap propertiesMap = new HashMap();
/*     */ 
/* 111 */   protected static HashMap dynaClasses = new HashMap();
/*     */ 
/*     */   private WrapDynaClass(Class beanClass)
/*     */   {
/*  60 */     this.beanClass = beanClass;
/*  61 */     introspect();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 125 */     return this.beanClass.getName();
/*     */   }
/*     */ 
/*     */   public DynaProperty getDynaProperty(String name)
/*     */   {
/* 141 */     if (name == null) {
/* 142 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 145 */     return ((DynaProperty)this.propertiesMap.get(name));
/*     */   }
/*     */ 
/*     */   public DynaProperty[] getDynaProperties()
/*     */   {
/* 161 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public DynaBean newInstance()
/*     */     throws IllegalAccessException, InstantiationException
/*     */   {
/* 193 */     return new WrapDynaBean(this.beanClass.newInstance());
/*     */   }
/*     */ 
/*     */   public PropertyDescriptor getPropertyDescriptor(String name)
/*     */   {
/* 209 */     return ((PropertyDescriptor)this.descriptorsMap.get(name));
/*     */   }
/*     */ 
/*     */   public static void clear()
/*     */   {
/* 222 */     synchronized (dynaClasses) {
/* 223 */       dynaClasses.clear();
/*     */     }
/*     */   }
/*     */ 
/*     */   public static WrapDynaClass createDynaClass(Class beanClass)
/*     */   {
/* 237 */     synchronized (dynaClasses) {
/* 238 */       WrapDynaClass dynaClass = (WrapDynaClass)dynaClasses.get(beanClass);
/*     */ 
/* 240 */       if (dynaClass == null) {
/* 241 */         dynaClass = new WrapDynaClass(beanClass);
/* 242 */         dynaClasses.put(beanClass, dynaClass);
/*     */       }
/* 244 */       return dynaClass;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void introspect()
/*     */   {
/* 259 */     PropertyDescriptor[] regulars = PropertyUtils.getPropertyDescriptors(this.beanClass);
/*     */ 
/* 261 */     if (regulars == null) {
/* 262 */       regulars = new PropertyDescriptor[0];
/*     */     }
/* 264 */     HashMap mappeds = PropertyUtils.getMappedPropertyDescriptors(this.beanClass);
/*     */ 
/* 266 */     if (mappeds == null) {
/* 267 */       mappeds = new HashMap();
/*     */     }
/*     */ 
/* 271 */     this.properties = new DynaProperty[regulars.length + mappeds.size()];
/* 272 */     for (int i = 0; i < regulars.length; ++i) {
/* 273 */       this.descriptorsMap.put(regulars[i].getName(), regulars[i]);
/*     */ 
/* 275 */       this.properties[i] = new DynaProperty(regulars[i].getName(), regulars[i].getPropertyType());
/*     */ 
/* 278 */       this.propertiesMap.put(this.properties[i].getName(), this.properties[i]);
/*     */     }
/*     */ 
/* 281 */     int j = regulars.length;
/* 282 */     Iterator names = mappeds.keySet().iterator();
/* 283 */     while (names.hasNext()) {
/* 284 */       String name = (String)names.next();
/* 285 */       PropertyDescriptor descriptor = (PropertyDescriptor)mappeds.get(name);
/*     */ 
/* 287 */       this.properties[j] = new DynaProperty(descriptor.getName(), Map.class);
/*     */ 
/* 290 */       this.propertiesMap.put(this.properties[j].getName(), this.properties[j]);
/*     */ 
/* 292 */       ++j;
/*     */     }
/*     */   }
/*     */ }