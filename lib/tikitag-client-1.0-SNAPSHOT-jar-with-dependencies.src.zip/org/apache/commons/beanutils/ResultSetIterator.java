/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ import java.util.NoSuchElementException;
/*     */ 
/*     */ public class ResultSetIterator
/*     */   implements DynaBean, Iterator
/*     */ {
/*  65 */   protected boolean current = false;
/*     */ 
/*  71 */   protected ResultSetDynaClass dynaClass = null;
/*     */ 
/*  78 */   protected boolean eof = false;
/*     */ 
/*     */   ResultSetIterator(ResultSetDynaClass dynaClass)
/*     */   {
/*  52 */     this.dynaClass = dynaClass;
/*     */   }
/*     */ 
/*     */   public boolean contains(String name, String key)
/*     */   {
/*  96 */     throw new UnsupportedOperationException("FIXME - mapped properties not currently supported");
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 112 */     if (this.dynaClass.getDynaProperty(name) == null)
/* 113 */       throw new IllegalArgumentException(name);
/*     */     try
/*     */     {
/* 116 */       return this.dynaClass.getResultSet().getObject(name);
/*     */     } catch (SQLException e) {
/* 118 */       throw new RuntimeException("get(" + name + "): SQLException: " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object get(String name, int index)
/*     */   {
/* 142 */     throw new UnsupportedOperationException("FIXME - indexed properties not currently supported");
/*     */   }
/*     */ 
/*     */   public Object get(String name, String key)
/*     */   {
/* 162 */     throw new UnsupportedOperationException("FIXME - mapped properties not currently supported");
/*     */   }
/*     */ 
/*     */   public DynaClass getDynaClass()
/*     */   {
/* 174 */     return this.dynaClass;
/*     */   }
/*     */ 
/*     */   public void remove(String name, String key)
/*     */   {
/* 192 */     throw new UnsupportedOperationException("FIXME - mapped operations not currently supported");
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value)
/*     */   {
/* 213 */     if (this.dynaClass.getDynaProperty(name) == null)
/* 214 */       throw new IllegalArgumentException(name);
/*     */     try
/*     */     {
/* 217 */       this.dynaClass.getResultSet().updateObject(name, value);
/*     */     } catch (SQLException e) {
/* 219 */       throw new RuntimeException("set(" + name + "): SQLException: " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(String name, int index, Object value)
/*     */   {
/* 244 */     throw new UnsupportedOperationException("FIXME - indexed properties not currently supported");
/*     */   }
/*     */ 
/*     */   public void set(String name, String key, Object value)
/*     */   {
/* 266 */     throw new UnsupportedOperationException("FIXME - mapped properties not currently supported");
/*     */   }
/*     */ 
/*     */   public boolean hasNext()
/*     */   {
/*     */     try
/*     */     {
/* 281 */       advance();
/* 282 */       return (!(this.eof));
/*     */     } catch (SQLException e) {
/* 284 */       throw new RuntimeException("hasNext():  SQLException:  " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object next()
/*     */   {
/*     */     try
/*     */     {
/* 296 */       advance();
/* 297 */       if (this.eof) {
/* 298 */         throw new NoSuchElementException();
/*     */       }
/* 300 */       this.current = false;
/* 301 */       return this;
/*     */     } catch (SQLException e) {
/* 303 */       throw new RuntimeException("next():  SQLException:  " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void remove()
/*     */   {
/* 315 */     throw new UnsupportedOperationException("remove()");
/*     */   }
/*     */ 
/*     */   protected void advance()
/*     */     throws SQLException
/*     */   {
/* 331 */     if ((!(this.current)) && (!(this.eof)))
/* 332 */       if (this.dynaClass.getResultSet().next()) {
/* 333 */         this.current = true;
/* 334 */         this.eof = false;
/*     */       } else {
/* 336 */         this.current = false;
/* 337 */         this.eof = true;
/*     */       }
/*     */   }
/*     */ }