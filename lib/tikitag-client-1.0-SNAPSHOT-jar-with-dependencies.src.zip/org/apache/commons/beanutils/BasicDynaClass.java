/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class BasicDynaClass
/*     */   implements DynaClass, Serializable
/*     */ {
/*     */   protected transient Constructor constructor;
/* 104 */   protected static Class[] constructorTypes = { Serializable.class };
/*     */   protected Object[] constructorValues;
/*     */   protected Class dynaBeanClass;
/*     */   protected String name;
/*     */   protected DynaProperty[] properties;
/*     */   protected HashMap propertiesMap;
/*     */ 
/*     */   public BasicDynaClass()
/*     */   {
/*  50 */     this(null, null, null);
/*     */   }
/*     */ 
/*     */   public BasicDynaClass(String name, Class dynaBeanClass)
/*     */   {
/*  63 */     this(name, dynaBeanClass, null);
/*     */   }
/*     */ 
/*     */   public BasicDynaClass(String name, Class dynaBeanClass, DynaProperty[] properties)
/*     */   {
/*  97 */     this.constructor = null;
/*     */ 
/* 111 */     this.constructorValues = new Object[] { this };
/*     */ 
/* 118 */     this.dynaBeanClass = BasicDynaBean.class;
/*     */ 
/* 124 */     this.name = super.getClass().getName();
/*     */ 
/* 130 */     this.properties = new DynaProperty[0];
/*     */ 
/* 138 */     this.propertiesMap = new HashMap();
/*     */ 
/*  79 */     if (name != null)
/*  80 */       this.name = name;
/*  81 */     if (dynaBeanClass == null)
/*  82 */       dynaBeanClass = BasicDynaBean.class;
/*  83 */     setDynaBeanClass(dynaBeanClass);
/*  84 */     if (properties != null)
/*  85 */       setProperties(properties);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 152 */     return this.name;
/*     */   }
/*     */ 
/*     */   public DynaProperty getDynaProperty(String name)
/*     */   {
/* 168 */     if (name == null) {
/* 169 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 172 */     return ((DynaProperty)this.propertiesMap.get(name));
/*     */   }
/*     */ 
/*     */   public DynaProperty[] getDynaProperties()
/*     */   {
/* 188 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public DynaBean newInstance()
/*     */     throws IllegalAccessException, InstantiationException
/*     */   {
/*     */     try
/*     */     {
/* 208 */       if (this.constructor == null) {
/* 209 */         setDynaBeanClass(this.dynaBeanClass);
/*     */       }
/*     */ 
/* 212 */       return ((DynaBean)this.constructor.newInstance(this.constructorValues));
/*     */     } catch (InvocationTargetException e) {
/* 214 */       throw new InstantiationException(e.getTargetException().getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public Class getDynaBeanClass()
/*     */   {
/* 231 */     return this.dynaBeanClass;
/*     */   }
/*     */ 
/*     */   protected void setDynaBeanClass(Class dynaBeanClass)
/*     */   {
/* 252 */     if (dynaBeanClass.isInterface()) {
/* 253 */       throw new IllegalArgumentException("Class " + dynaBeanClass.getName() + " is an interface, not a class");
/*     */     }
/*     */ 
/* 256 */     if (!(DynaBean.class.isAssignableFrom(dynaBeanClass))) {
/* 257 */       throw new IllegalArgumentException("Class " + dynaBeanClass.getName() + " does not implement DynaBean");
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 263 */       this.constructor = dynaBeanClass.getConstructor(constructorTypes);
/*     */     } catch (NoSuchMethodException e) {
/* 265 */       throw new IllegalArgumentException("Class " + dynaBeanClass.getName() + " does not have an appropriate constructor");
/*     */     }
/*     */ 
/* 269 */     this.dynaBeanClass = dynaBeanClass;
/*     */   }
/*     */ 
/*     */   protected void setProperties(DynaProperty[] properties)
/*     */   {
/* 281 */     this.properties = properties;
/* 282 */     this.propertiesMap.clear();
/* 283 */     for (int i = 0; i < properties.length; ++i)
/* 284 */       this.propertiesMap.put(properties[i].getName(), properties[i]);
/*     */   }
/*     */ }