/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public final class LongArrayConverter extends AbstractArrayConverter
/*     */ {
/*  75 */   private static long[] model = new long[0];
/*     */ 
/*     */   public LongArrayConverter()
/*     */   {
/*  49 */     this.jdField_defaultValue_of_type_JavaLangObject = null;
/*  50 */     this.jdField_useDefault_of_type_Boolean = false;
/*     */   }
/*     */ 
/*     */   public LongArrayConverter(Object defaultValue)
/*     */   {
/*  63 */     this.jdField_defaultValue_of_type_JavaLangObject = defaultValue;
/*  64 */     this.jdField_useDefault_of_type_Boolean = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*     */     long[] results;
/*     */     int i;
/*  94 */     if (value == null) {
/*  95 */       if (this.jdField_useDefault_of_type_Boolean) {
/*  96 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/*  98 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 103 */     if (model.getClass() == value.getClass()) {
/* 104 */       return value;
/*     */     }
/*     */ 
/* 108 */     if (AbstractArrayConverter.strings.getClass() == value.getClass()) {
/*     */       try {
/* 110 */         String[] values = (String[])value;
/* 111 */         results = new long[values.length];
/* 112 */         for (i = 0; i < values.length; ++i) {
/* 113 */           results[i] = Long.parseLong(values[i]);
/*     */         }
/* 115 */         return results;
/*     */       } catch (Exception e) {
/* 117 */         if (this.jdField_useDefault_of_type_Boolean) {
/* 118 */           return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */         }
/* 120 */         throw new ConversionException(value.toString(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 128 */       List list = parseElements(value.toString());
/* 129 */       results = new long[list.size()];
/* 130 */       for (i = 0; i < results.length; ++i) {
/* 131 */         results[i] = Long.parseLong((String)list.get(i));
/*     */       }
/* 133 */       return results;
/*     */     } catch (Exception list) {
/* 135 */       if (this.jdField_useDefault_of_type_Boolean) {
/* 136 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/* 138 */       throw new ConversionException(value.toString(), e);
/*     */     }
/*     */   }
/*     */ }