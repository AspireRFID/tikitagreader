/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.StreamTokenizer;
/*     */ import java.io.StringReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public abstract class AbstractArrayConverter
/*     */   implements Converter
/*     */ {
/*     */   protected Object defaultValue;
/*  65 */   protected static String[] strings = new String[0];
/*     */   protected boolean useDefault;
/*     */ 
/*     */   public AbstractArrayConverter()
/*     */   {
/*  59 */     this.defaultValue = null;
/*     */ 
/*  71 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public abstract Object convert(Class paramClass, Object paramObject);
/*     */ 
/*     */   protected List parseElements(String svalue)
/*     */   {
/* 116 */     if (svalue == null) {
/* 117 */       throw new NullPointerException();
/*     */     }
/*     */ 
/* 121 */     svalue = svalue.trim();
/* 122 */     if ((svalue.startsWith("{")) && (svalue.endsWith("}"))) {
/* 123 */       svalue = svalue.substring(1, svalue.length() - 1);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 129 */       StreamTokenizer st = new StreamTokenizer(new StringReader(svalue));
/*     */ 
/* 131 */       st.whitespaceChars(44, 44);
/* 132 */       st.ordinaryChars(48, 57);
/* 133 */       st.ordinaryChars(46, 46);
/* 134 */       st.ordinaryChars(45, 45);
/* 135 */       st.wordChars(48, 57);
/* 136 */       st.wordChars(46, 46);
/* 137 */       st.wordChars(45, 45);
/*     */ 
/* 140 */       ArrayList list = new ArrayList();
/*     */       while (true) {
/* 142 */         int ttype = st.nextToken();
/* 143 */         if ((ttype == -3) || (ttype > 0))
/*     */         {
/* 145 */           list.add(st.sval); } else {
/* 146 */           if (ttype == -1) {
/*     */             break;
/*     */           }
/* 149 */           throw new ConversionException("Encountered token of type " + ttype);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 155 */       return list;
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 159 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }