/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public final class StringArrayConverter extends AbstractArrayConverter
/*     */ {
/*  75 */   private static String[] model = new String[0];
/*     */ 
/*  80 */   private static int[] ints = new int[0];
/*     */ 
/*     */   public StringArrayConverter()
/*     */   {
/*  49 */     this.jdField_defaultValue_of_type_JavaLangObject = null;
/*  50 */     this.jdField_useDefault_of_type_Boolean = false;
/*     */   }
/*     */ 
/*     */   public StringArrayConverter(Object defaultValue)
/*     */   {
/*  63 */     this.jdField_defaultValue_of_type_JavaLangObject = defaultValue;
/*  64 */     this.jdField_useDefault_of_type_Boolean = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*     */     String[] results;
/*     */     int i;
/* 100 */     if (value == null) {
/* 101 */       if (this.jdField_useDefault_of_type_Boolean) {
/* 102 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/* 104 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 109 */     if (model.getClass() == value.getClass()) {
/* 110 */       return value;
/*     */     }
/*     */ 
/* 114 */     if (ints.getClass() == value.getClass())
/*     */     {
/* 116 */       int[] values = (int[])value;
/* 117 */       results = new String[values.length];
/* 118 */       i = 0; break label87:
/*     */       while (true) {
/* 120 */         results[i] = Integer.toString(values[i]);
/*     */ 
/* 118 */         ++i; if (i >= values.length)
/*     */         {
/* 123 */           label87: return results;
/*     */         }
/*     */       }
/*     */     }
/*     */     try
/*     */     {
/* 129 */       List list = parseElements(value.toString());
/* 130 */       results = new String[list.size()];
/* 131 */       for (i = 0; i < results.length; ++i) {
/* 132 */         results[i] = ((String)list.get(i));
/*     */       }
/* 134 */       return results;
/*     */     } catch (Exception e) {
/* 136 */       if (this.jdField_useDefault_of_type_Boolean) {
/* 137 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/* 139 */       throw new ConversionException(value.toString(), e);
/*     */     }
/*     */   }
/*     */ }