/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.io.File;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class FileConverter
/*     */   implements Converter
/*     */ {
/*  42 */   private Object defaultValue = null;
/*     */ 
/*  48 */   private boolean useDefault = true;
/*     */ 
/*     */   public FileConverter()
/*     */   {
/*  60 */     this.defaultValue = null;
/*  61 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public FileConverter(Object defaultValue)
/*     */   {
/*  74 */     this.defaultValue = defaultValue;
/*  75 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*  96 */     if (value == null) {
/*  97 */       if (this.useDefault) {
/*  98 */         return this.defaultValue;
/*     */       }
/* 100 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 104 */     if (value instanceof File) {
/* 105 */       return value;
/*     */     }
/*     */ 
/* 108 */     return new File(value.toString());
/*     */   }
/*     */ }