/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class ByteConverter
/*     */   implements Converter
/*     */ {
/*  74 */   private Object defaultValue = null;
/*     */ 
/*  80 */   private boolean useDefault = true;
/*     */ 
/*     */   public ByteConverter()
/*     */   {
/*  48 */     this.defaultValue = null;
/*  49 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public ByteConverter(Object defaultValue)
/*     */   {
/*  62 */     this.defaultValue = defaultValue;
/*  63 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*  98 */     if (value == null) {
/*  99 */       if (this.useDefault) {
/* 100 */         return this.defaultValue;
/*     */       }
/* 102 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 108 */     if (value instanceof Byte)
/* 109 */       return value;
/* 110 */     if (value instanceof Number) {
/* 111 */       return new Byte(((Number)value).byteValue());
/*     */     }
/*     */     try
/*     */     {
/* 115 */       return new Byte(value.toString());
/*     */     } catch (Exception e) {
/* 117 */       if (this.useDefault) {
/* 118 */         return this.defaultValue;
/*     */       }
/* 120 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }