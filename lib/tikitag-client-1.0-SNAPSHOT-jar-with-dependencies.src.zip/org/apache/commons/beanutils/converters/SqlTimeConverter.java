/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.sql.Time;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class SqlTimeConverter
/*     */   implements Converter
/*     */ {
/*  75 */   private Object defaultValue = null;
/*     */ 
/*  81 */   private boolean useDefault = true;
/*     */ 
/*     */   public SqlTimeConverter()
/*     */   {
/*  49 */     this.defaultValue = null;
/*  50 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public SqlTimeConverter(Object defaultValue)
/*     */   {
/*  63 */     this.defaultValue = defaultValue;
/*  64 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*  99 */     if (value == null) {
/* 100 */       if (this.useDefault) {
/* 101 */         return this.defaultValue;
/*     */       }
/* 103 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 107 */     if (value instanceof Time) {
/* 108 */       return value;
/*     */     }
/*     */     try
/*     */     {
/* 112 */       return Time.valueOf(value.toString());
/*     */     } catch (Exception e) {
/* 114 */       if (this.useDefault) {
/* 115 */         return this.defaultValue;
/*     */       }
/* 117 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }