/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public final class BooleanArrayConverter extends AbstractArrayConverter
/*     */ {
/*  75 */   private static boolean[] model = new boolean[0];
/*     */ 
/*     */   public BooleanArrayConverter()
/*     */   {
/*  49 */     this.jdField_defaultValue_of_type_JavaLangObject = null;
/*  50 */     this.jdField_useDefault_of_type_Boolean = false;
/*     */   }
/*     */ 
/*     */   public BooleanArrayConverter(Object defaultValue)
/*     */   {
/*  63 */     this.jdField_defaultValue_of_type_JavaLangObject = defaultValue;
/*  64 */     this.jdField_useDefault_of_type_Boolean = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*     */     boolean[] results;
/*     */     int i;
/*     */     String stringValue;
/*  94 */     if (value == null) {
/*  95 */       if (this.jdField_useDefault_of_type_Boolean) {
/*  96 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/*  98 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 103 */     if (model.getClass() == value.getClass()) {
/* 104 */       return value;
/*     */     }
/*     */ 
/* 108 */     if (AbstractArrayConverter.strings.getClass() == value.getClass()) {
/*     */       try {
/* 110 */         String[] values = (String[])value;
/* 111 */         results = new boolean[values.length];
/* 112 */         for (i = 0; i < values.length; ++i) {
/* 113 */           stringValue = values[i];
/* 114 */           if ((stringValue.equalsIgnoreCase("yes")) || (stringValue.equalsIgnoreCase("y")) || (stringValue.equalsIgnoreCase("true")) || (stringValue.equalsIgnoreCase("on")) || (stringValue.equalsIgnoreCase("1")))
/*     */           {
/* 119 */             results[i] = true;
/* 120 */           } else if ((stringValue.equalsIgnoreCase("no")) || (stringValue.equalsIgnoreCase("n")) || (stringValue.equalsIgnoreCase("false")) || (stringValue.equalsIgnoreCase("off")) || (stringValue.equalsIgnoreCase("0")))
/*     */           {
/* 125 */             results[i] = false;
/*     */           } else {
/* 127 */             if (this.jdField_useDefault_of_type_Boolean) {
/* 128 */               return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */             }
/* 130 */             throw new ConversionException(value.toString());
/*     */           }
/*     */         }
/*     */ 
/* 134 */         return results;
/*     */       } catch (Exception e) {
/* 136 */         if (this.jdField_useDefault_of_type_Boolean) {
/* 137 */           return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */         }
/* 139 */         throw new ConversionException(value.toString(), e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 147 */       List list = parseElements(value.toString());
/* 148 */       results = new boolean[list.size()];
/* 149 */       for (i = 0; i < results.length; ++i) {
/* 150 */         stringValue = (String)list.get(i);
/* 151 */         if ((stringValue.equalsIgnoreCase("yes")) || (stringValue.equalsIgnoreCase("y")) || (stringValue.equalsIgnoreCase("true")) || (stringValue.equalsIgnoreCase("on")) || (stringValue.equalsIgnoreCase("1")))
/*     */         {
/* 156 */           results[i] = true;
/* 157 */         } else if ((stringValue.equalsIgnoreCase("no")) || (stringValue.equalsIgnoreCase("n")) || (stringValue.equalsIgnoreCase("false")) || (stringValue.equalsIgnoreCase("off")) || (stringValue.equalsIgnoreCase("0")))
/*     */         {
/* 162 */           results[i] = false;
/*     */         } else {
/* 164 */           if (this.jdField_useDefault_of_type_Boolean) {
/* 165 */             return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */           }
/* 167 */           throw new ConversionException(value.toString());
/*     */         }
/*     */       }
/*     */ 
/* 171 */       return results;
/*     */     } catch (Exception list) {
/* 173 */       if (this.jdField_useDefault_of_type_Boolean) {
/* 174 */         return this.jdField_defaultValue_of_type_JavaLangObject;
/*     */       }
/* 176 */       throw new ConversionException(value.toString(), e);
/*     */     }
/*     */   }
/*     */ }