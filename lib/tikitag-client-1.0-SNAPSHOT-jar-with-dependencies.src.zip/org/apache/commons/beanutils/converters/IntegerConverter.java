/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class IntegerConverter
/*     */   implements Converter
/*     */ {
/*  74 */   private Object defaultValue = null;
/*     */ 
/*  80 */   private boolean useDefault = true;
/*     */ 
/*     */   public IntegerConverter()
/*     */   {
/*  48 */     this.defaultValue = null;
/*  49 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public IntegerConverter(Object defaultValue)
/*     */   {
/*  62 */     this.defaultValue = defaultValue;
/*  63 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/*  98 */     if (value == null) {
/*  99 */       if (this.useDefault) {
/* 100 */         return this.defaultValue;
/*     */       }
/* 102 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 106 */     if (value instanceof Integer)
/* 107 */       return value;
/* 108 */     if (value instanceof Number) {
/* 109 */       return new Integer(((Number)value).intValue());
/*     */     }
/*     */     try
/*     */     {
/* 113 */       return new Integer(value.toString());
/*     */     } catch (Exception e) {
/* 115 */       if (this.useDefault) {
/* 116 */         return this.defaultValue;
/*     */       }
/* 118 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }