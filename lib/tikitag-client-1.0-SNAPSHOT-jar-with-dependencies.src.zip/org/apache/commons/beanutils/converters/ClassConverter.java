/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class ClassConverter
/*     */   implements Converter
/*     */ {
/*  76 */   private Object defaultValue = null;
/*     */ 
/*  82 */   private boolean useDefault = true;
/*     */ 
/*     */   public ClassConverter()
/*     */   {
/*  50 */     this.defaultValue = null;
/*  51 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public ClassConverter(Object defaultValue)
/*     */   {
/*  64 */     this.defaultValue = defaultValue;
/*  65 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/* 100 */     if (value == null) {
/* 101 */       if (this.useDefault) {
/* 102 */         return this.defaultValue;
/*     */       }
/* 104 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 108 */     if (value instanceof Class) {
/* 109 */       return value;
/*     */     }
/*     */     try
/*     */     {
/* 113 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*     */ 
/* 115 */       if (classLoader == null) {
/* 116 */         classLoader = ClassConverter.class.getClassLoader();
/*     */       }
/* 118 */       return classLoader.loadClass(value.toString());
/*     */     } catch (Exception e) {
/* 120 */       if (this.useDefault) {
/* 121 */         return this.defaultValue;
/*     */       }
/* 123 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }