/*     */ package org.apache.commons.beanutils.converters;
/*     */ 
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.beanutils.Converter;
/*     */ 
/*     */ public final class URLConverter
/*     */   implements Converter
/*     */ {
/*  78 */   private Object defaultValue = null;
/*     */ 
/*  84 */   private boolean useDefault = true;
/*     */ 
/*     */   public URLConverter()
/*     */   {
/*  52 */     this.defaultValue = null;
/*  53 */     this.useDefault = false;
/*     */   }
/*     */ 
/*     */   public URLConverter(Object defaultValue)
/*     */   {
/*  66 */     this.defaultValue = defaultValue;
/*  67 */     this.useDefault = true;
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/* 102 */     if (value == null) {
/* 103 */       if (this.useDefault) {
/* 104 */         return this.defaultValue;
/*     */       }
/* 106 */       throw new ConversionException("No value specified");
/*     */     }
/*     */ 
/* 110 */     if (value instanceof URL) {
/* 111 */       return value;
/*     */     }
/*     */     try
/*     */     {
/* 115 */       return new URL(value.toString());
/*     */     } catch (MalformedURLException murle) {
/* 117 */       if (this.useDefault) {
/* 118 */         return this.defaultValue;
/*     */       }
/* 120 */       throw new ConversionException(murle);
/*     */     }
/*     */   }
/*     */ }