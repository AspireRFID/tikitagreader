/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.security.AccessController;
/*     */ import java.security.PrivilegedAction;
/*     */ import java.util.Hashtable;
/*     */ 
/*     */ public class MappedPropertyDescriptor extends PropertyDescriptor
/*     */ {
/*     */   private Class mappedPropertyType;
/*     */   private Method mappedReadMethod;
/*     */   private Method mappedWriteMethod;
/*  68 */   private static final Class[] stringClassArray = { String.class };
/*     */ 
/* 322 */   private static Hashtable declaredMethodCache = new Hashtable();
/*     */ 
/*     */   public MappedPropertyDescriptor(String propertyName, Class beanClass)
/*     */     throws IntrospectionException
/*     */   {
/*  91 */     super(propertyName, null, null);
/*     */ 
/*  93 */     if ((propertyName == null) || (propertyName.length() == 0)) {
/*  94 */       throw new IntrospectionException("bad property name: " + propertyName + " on class: " + beanClass.getClass().getName());
/*     */     }
/*     */ 
/*  98 */     setName(propertyName);
/*  99 */     String base = capitalizePropertyName(propertyName);
/*     */     try
/*     */     {
/* 103 */       this.mappedReadMethod = findMethod(beanClass, "get" + base, 1, stringClassArray);
/*     */ 
/* 105 */       Class[] params = { String.class, this.mappedReadMethod.getReturnType() };
/* 106 */       this.mappedWriteMethod = findMethod(beanClass, "set" + base, 2, params);
/*     */     }
/*     */     catch (IntrospectionException e)
/*     */     {
/*     */     }
/*     */ 
/* 112 */     if (this.mappedReadMethod == null) {
/* 113 */       this.mappedWriteMethod = findMethod(beanClass, "set" + base, 2);
/*     */     }
/*     */ 
/* 116 */     if ((this.mappedReadMethod == null) && (this.mappedWriteMethod == null)) {
/* 117 */       throw new IntrospectionException("Property '" + propertyName + "' not found on " + beanClass.getName());
/*     */     }
/*     */ 
/* 122 */     findMappedPropertyType();
/*     */   }
/*     */ 
/*     */   public MappedPropertyDescriptor(String propertyName, Class beanClass, String mappedGetterName, String mappedSetterName)
/*     */     throws IntrospectionException
/*     */   {
/* 147 */     super(propertyName, null, null);
/*     */ 
/* 149 */     if ((propertyName == null) || (propertyName.length() == 0)) {
/* 150 */       throw new IntrospectionException("bad property name: " + propertyName);
/*     */     }
/*     */ 
/* 153 */     setName(propertyName);
/*     */ 
/* 156 */     this.mappedReadMethod = findMethod(beanClass, mappedGetterName, 1, stringClassArray);
/*     */ 
/* 159 */     if (this.mappedReadMethod != null) {
/* 160 */       Class[] params = { String.class, this.mappedReadMethod.getReturnType() };
/* 161 */       this.mappedWriteMethod = findMethod(beanClass, mappedSetterName, 2, params);
/*     */     }
/*     */     else {
/* 164 */       this.mappedWriteMethod = findMethod(beanClass, mappedSetterName, 2);
/*     */     }
/*     */ 
/* 168 */     findMappedPropertyType();
/*     */   }
/*     */ 
/*     */   public MappedPropertyDescriptor(String propertyName, Method mappedGetter, Method mappedSetter)
/*     */     throws IntrospectionException
/*     */   {
/* 189 */     super(propertyName, mappedGetter, mappedSetter);
/*     */ 
/* 191 */     if ((propertyName == null) || (propertyName.length() == 0)) {
/* 192 */       throw new IntrospectionException("bad property name: " + propertyName);
/*     */     }
/*     */ 
/* 196 */     setName(propertyName);
/* 197 */     this.mappedReadMethod = mappedGetter;
/* 198 */     this.mappedWriteMethod = mappedSetter;
/* 199 */     findMappedPropertyType();
/*     */   }
/*     */ 
/*     */   public Class getMappedPropertyType()
/*     */   {
/* 215 */     return this.mappedPropertyType;
/*     */   }
/*     */ 
/*     */   public Method getMappedReadMethod()
/*     */   {
/* 225 */     return this.mappedReadMethod;
/*     */   }
/*     */ 
/*     */   public void setMappedReadMethod(Method mappedGetter)
/*     */     throws IntrospectionException
/*     */   {
/* 235 */     this.mappedReadMethod = mappedGetter;
/* 236 */     findMappedPropertyType();
/*     */   }
/*     */ 
/*     */   public Method getMappedWriteMethod()
/*     */   {
/* 246 */     return this.mappedWriteMethod;
/*     */   }
/*     */ 
/*     */   public void setMappedWriteMethod(Method mappedSetter)
/*     */     throws IntrospectionException
/*     */   {
/* 256 */     this.mappedWriteMethod = mappedSetter;
/* 257 */     findMappedPropertyType();
/*     */   }
/*     */ 
/*     */   private void findMappedPropertyType()
/*     */     throws IntrospectionException
/*     */   {
/*     */     try
/*     */     {
/* 268 */       this.mappedPropertyType = null;
/* 269 */       if (this.mappedReadMethod != null) {
/* 270 */         if (this.mappedReadMethod.getParameterTypes().length != 1) {
/* 271 */           throw new IntrospectionException("bad mapped read method arg count");
/*     */         }
/*     */ 
/* 274 */         this.mappedPropertyType = this.mappedReadMethod.getReturnType();
/* 275 */         if (this.mappedPropertyType == Void.TYPE) {
/* 276 */           throw new IntrospectionException("mapped read method " + this.mappedReadMethod.getName() + " returns void");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 282 */       if (this.mappedWriteMethod != null) {
/* 283 */         Class[] params = this.mappedWriteMethod.getParameterTypes();
/* 284 */         if (params.length != 2) {
/* 285 */           throw new IntrospectionException("bad mapped write method arg count");
/*     */         }
/*     */ 
/* 288 */         if ((this.mappedPropertyType != null) && (this.mappedPropertyType != params[1]))
/*     */         {
/* 290 */           throw new IntrospectionException("type mismatch between mapped read and write methods");
/*     */         }
/*     */ 
/* 293 */         this.mappedPropertyType = params[1];
/*     */       }
/*     */     } catch (IntrospectionException ex) {
/* 296 */       throw ex;
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String capitalizePropertyName(String s)
/*     */   {
/* 307 */     if (s.length() == 0) {
/* 308 */       return s;
/*     */     }
/*     */ 
/* 311 */     char[] chars = s.toCharArray();
/* 312 */     chars[0] = Character.toUpperCase(chars[0]);
/* 313 */     return new String(chars);
/*     */   }
/*     */ 
/*     */   private static synchronized Method[] getPublicDeclaredMethods(Class clz)
/*     */   {
/* 330 */     Class fclz = clz;
/* 331 */     Method[] result = (Method[])declaredMethodCache.get(fclz);
/* 332 */     if (result != null) {
/* 333 */       return result;
/*     */     }
/*     */ 
/* 337 */     result = (Method[])AccessController.doPrivileged(new PrivilegedAction(fclz) {
/*     */       private final Class val$fclz;
/*     */ 
/*     */       public Object run() {
/*     */         Method[] methods;
/*     */         try { return this.val$fclz.getDeclaredMethods();
/*     */         }
/*     */         catch (SecurityException ex)
/*     */         {
/* 349 */           methods = this.val$fclz.getMethods();
/* 350 */           int i = 0; for (int size = methods.length; i < size; ++i) {
/* 351 */             Method method = methods[i];
/* 352 */             if (!(this.val$fclz.equals(method.getDeclaringClass())))
/* 353 */               methods[i] = null;
/*     */           }
/*     */         }
/* 356 */         return methods;
/*     */       }
/*     */     });
/* 362 */     for (int i = 0; i < result.length; ++i) {
/* 363 */       Method method = result[i];
/* 364 */       if (method != null) {
/* 365 */         int mods = method.getModifiers();
/* 366 */         if (!(Modifier.isPublic(mods))) {
/* 367 */           result[i] = null;
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 373 */     declaredMethodCache.put(clz, result);
/* 374 */     return result;
/*     */   }
/*     */ 
/*     */   private static Method internalFindMethod(Class start, String methodName, int argCount)
/*     */   {
/* 384 */     for (Class cl = start; cl != null; cl = cl.getSuperclass()) {
/* 385 */       Method[] methods = getPublicDeclaredMethods(cl);
/* 386 */       for (i = 0; i < methods.length; ++i) {
/* 387 */         Method method = methods[i];
/* 388 */         if (method == null) {
/*     */           continue;
/*     */         }
/*     */ 
/* 392 */         int mods = method.getModifiers();
/* 393 */         if (Modifier.isStatic(mods)) {
/*     */           continue;
/*     */         }
/* 396 */         if ((method.getName().equals(methodName)) && (method.getParameterTypes().length == argCount))
/*     */         {
/* 398 */           return method;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 406 */     Class[] ifcs = start.getInterfaces();
/* 407 */     for (int i = 0; i < ifcs.length; ++i) {
/* 408 */       Method m = internalFindMethod(ifcs[i], methodName, argCount);
/* 409 */       if (m != null) {
/* 410 */         return m;
/*     */       }
/*     */     }
/*     */ 
/* 414 */     return null;
/*     */   }
/*     */ 
/*     */   private static Method internalFindMethod(Class start, String methodName, int argCount, Class[] args)
/*     */   {
/* 425 */     for (Class cl = start; cl != null; cl = cl.getSuperclass()) {
/* 426 */       Method[] methods = getPublicDeclaredMethods(cl);
/* 427 */       for (i = 0; i < methods.length; ++i) {
/* 428 */         Method method = methods[i];
/* 429 */         if (method == null) {
/*     */           continue;
/*     */         }
/*     */ 
/* 433 */         int mods = method.getModifiers();
/* 434 */         if (Modifier.isStatic(mods)) {
/*     */           continue;
/*     */         }
/*     */ 
/* 438 */         Class[] params = method.getParameterTypes();
/* 439 */         if ((!(method.getName().equals(methodName))) || (params.length != argCount))
/*     */           continue;
/* 441 */         boolean different = false;
/* 442 */         if (argCount > 0) {
/* 443 */           for (int j = 0; j < argCount; ++j) {
/* 444 */             if (params[j] != args[j]) {
/* 445 */               different = true;
/*     */             }
/*     */           }
/*     */ 
/* 449 */           if (different) {
/*     */             continue;
/*     */           }
/*     */         }
/* 453 */         return method;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 461 */     Class[] ifcs = start.getInterfaces();
/* 462 */     for (int i = 0; i < ifcs.length; ++i) {
/* 463 */       Method m = internalFindMethod(ifcs[i], methodName, argCount);
/* 464 */       if (m != null) {
/* 465 */         return m;
/*     */       }
/*     */     }
/*     */ 
/* 469 */     return null;
/*     */   }
/*     */ 
/*     */   static Method findMethod(Class cls, String methodName, int argCount)
/*     */     throws IntrospectionException
/*     */   {
/* 477 */     if (methodName == null) {
/* 478 */       return null;
/*     */     }
/*     */ 
/* 481 */     Method m = internalFindMethod(cls, methodName, argCount);
/* 482 */     if (m != null) {
/* 483 */       return m;
/*     */     }
/*     */ 
/* 487 */     throw new IntrospectionException("No method \"" + methodName + "\" with " + argCount + " arg(s)");
/*     */   }
/*     */ 
/*     */   static Method findMethod(Class cls, String methodName, int argCount, Class[] args)
/*     */     throws IntrospectionException
/*     */   {
/* 496 */     if (methodName == null) {
/* 497 */       return null;
/*     */     }
/*     */ 
/* 500 */     Method m = internalFindMethod(cls, methodName, argCount, args);
/* 501 */     if (m != null) {
/* 502 */       return m;
/*     */     }
/*     */ 
/* 506 */     throw new IntrospectionException("No method \"" + methodName + "\" with " + argCount + " arg(s) of matching types.");
/*     */   }
/*     */ 
/*     */   static boolean isSubclass(Class a, Class b)
/*     */   {
/* 520 */     if (a == b) {
/* 521 */       return true;
/*     */     }
/*     */ 
/* 524 */     if ((a == null) || (b == null)) {
/* 525 */       return false;
/*     */     }
/*     */ 
/* 528 */     for (Class x = a; x != null; x = x.getSuperclass()) {
/* 529 */       if (x == b) {
/* 530 */         return true;
/*     */       }
/*     */ 
/* 533 */       if (b.isInterface()) {
/* 534 */         Class[] interfaces = x.getInterfaces();
/* 535 */         for (int i = 0; i < interfaces.length; ++i) {
/* 536 */           if (isSubclass(interfaces[i], b)) {
/* 537 */             return true;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 543 */     return false;
/*     */   }
/*     */ 
/*     */   private boolean throwsException(Method method, Class exception)
/*     */   {
/* 553 */     Class[] exs = method.getExceptionTypes();
/* 554 */     for (int i = 0; i < exs.length; ++i) {
/* 555 */       if (exs[i] == exception) {
/* 556 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 560 */     return false;
/*     */   }
/*     */ }