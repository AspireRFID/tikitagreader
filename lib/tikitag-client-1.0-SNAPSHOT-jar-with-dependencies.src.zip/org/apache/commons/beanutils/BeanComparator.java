/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Comparator;
/*     */ import org.apache.commons.collections.comparators.ComparableComparator;
/*     */ 
/*     */ public class BeanComparator
/*     */   implements Comparator, Serializable
/*     */ {
/*     */   private String property;
/*     */   private Comparator comparator;
/*     */ 
/*     */   public BeanComparator()
/*     */   {
/*  58 */     this(null);
/*     */   }
/*     */ 
/*     */   public BeanComparator(String property)
/*     */   {
/*  80 */     this(property, ComparableComparator.getInstance());
/*     */   }
/*     */ 
/*     */   public BeanComparator(String property, Comparator comparator)
/*     */   {
/* 100 */     setProperty(property);
/* 101 */     this.comparator = comparator;
/*     */   }
/*     */ 
/*     */   public void setProperty(String property)
/*     */   {
/* 111 */     this.property = property;
/*     */   }
/*     */ 
/*     */   public String getProperty()
/*     */   {
/* 122 */     return this.property;
/*     */   }
/*     */ 
/*     */   public Comparator getComparator()
/*     */   {
/* 130 */     return this.comparator;
/*     */   }
/*     */ 
/*     */   public int compare(Object o1, Object o2)
/*     */   {
/* 144 */     if (this.property == null)
/*     */     {
/* 146 */       return this.comparator.compare(o1, o2);
/*     */     }
/*     */     try
/*     */     {
/* 150 */       Object value1 = PropertyUtils.getProperty(o1, this.property);
/* 151 */       Object value2 = PropertyUtils.getProperty(o2, this.property);
/* 152 */       return this.comparator.compare(value1, value2);
/*     */     }
/*     */     catch (Exception e) {
/* 155 */       throw new ClassCastException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 165 */     if (this == o) return true;
/* 166 */     if (!(o instanceof BeanComparator)) return false;
/*     */ 
/* 168 */     BeanComparator beanComparator = (BeanComparator)o;
/*     */ 
/* 170 */     if (!(this.comparator.equals(beanComparator.comparator))) return false;
/* 171 */     if (this.property != null)
/*     */     {
/* 173 */       if (this.property.equals(beanComparator.property)) break label75; return false;
/*     */     }
/*     */ 
/* 177 */     return (beanComparator.property == null);
/*     */ 
/* 180 */     label75: return true;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 188 */     int result = this.comparator.hashCode();
/* 189 */     return result;
/*     */   }
/*     */ }