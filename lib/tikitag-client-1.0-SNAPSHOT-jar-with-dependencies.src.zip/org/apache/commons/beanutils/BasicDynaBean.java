/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class BasicDynaBean
/*     */   implements DynaBean, Serializable
/*     */ {
/*  70 */   protected DynaClass dynaClass = null;
/*     */ 
/*  76 */   protected HashMap values = new HashMap();
/*     */ 
/*     */   public BasicDynaBean(DynaClass dynaClass)
/*     */   {
/*  58 */     this.dynaClass = dynaClass;
/*     */   }
/*     */ 
/*     */   public boolean contains(String name, String key)
/*     */   {
/*  94 */     Object value = this.values.get(name);
/*  95 */     if (value == null) {
/*  96 */       throw new NullPointerException("No mapped value for '" + name + "(" + key + ")'");
/*     */     }
/*  98 */     if (value instanceof Map) {
/*  99 */       return ((Map)value).containsKey(key);
/*     */     }
/* 101 */     throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'");
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 119 */     Object value = this.values.get(name);
/* 120 */     if (value != null) {
/* 121 */       return value;
/*     */     }
/*     */ 
/* 125 */     Class type = getDynaProperty(name).getType();
/* 126 */     if (!(type.isPrimitive())) {
/* 127 */       return value;
/*     */     }
/*     */ 
/* 131 */     if (type == Boolean.TYPE)
/* 132 */       return Boolean.FALSE;
/* 133 */     if (type == Byte.TYPE)
/* 134 */       return new Byte(0);
/* 135 */     if (type == Character.TYPE)
/* 136 */       return new Character('\0');
/* 137 */     if (type == Double.TYPE)
/* 138 */       return new Double(0.0D);
/* 139 */     if (type == Float.TYPE)
/* 140 */       return new Float(0.0F);
/* 141 */     if (type == Integer.TYPE)
/* 142 */       return new Integer(0);
/* 143 */     if (type == Long.TYPE)
/* 144 */       return new Long(0L);
/* 145 */     if (type == Short.TYPE) {
/* 146 */       return new Short(0);
/*     */     }
/* 148 */     return null;
/*     */   }
/*     */ 
/*     */   public Object get(String name, int index)
/*     */   {
/* 171 */     Object value = this.values.get(name);
/* 172 */     if (value == null) {
/* 173 */       throw new NullPointerException("No indexed value for '" + name + "[" + index + "]'");
/*     */     }
/* 175 */     if (value.getClass().isArray())
/* 176 */       return Array.get(value, index);
/* 177 */     if (value instanceof List) {
/* 178 */       return ((List)value).get(index);
/*     */     }
/* 180 */     throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]'");
/*     */   }
/*     */ 
/*     */   public Object get(String name, String key)
/*     */   {
/* 201 */     Object value = this.values.get(name);
/* 202 */     if (value == null) {
/* 203 */       throw new NullPointerException("No mapped value for '" + name + "(" + key + ")'");
/*     */     }
/* 205 */     if (value instanceof Map) {
/* 206 */       return ((Map)value).get(key);
/*     */     }
/* 208 */     throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'");
/*     */   }
/*     */ 
/*     */   public DynaClass getDynaClass()
/*     */   {
/* 221 */     return this.dynaClass;
/*     */   }
/*     */ 
/*     */   public void remove(String name, String key)
/*     */   {
/* 239 */     Object value = this.values.get(name);
/* 240 */     if (value == null) {
/* 241 */       throw new NullPointerException("No mapped value for '" + name + "(" + key + ")'");
/*     */     }
/* 243 */     if (value instanceof Map)
/* 244 */       ((Map)value).remove(key);
/*     */     else
/* 246 */       throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'");
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value)
/*     */   {
/* 268 */     DynaProperty descriptor = getDynaProperty(name);
/* 269 */     if (value == null) {
/* 270 */       if (!(descriptor.getType().isPrimitive())) break label129;
/* 271 */       throw new NullPointerException("Primitive value for '" + name + "'");
/*     */     }
/*     */ 
/* 274 */     if (!(isAssignable(descriptor.getType(), value.getClass()))) {
/* 275 */       throw new ConversionException("Cannot assign value of type '" + value.getClass().getName() + "' to property '" + name + "' of type '" + descriptor.getType().getName() + "'");
/*     */     }
/*     */ 
/* 281 */     label129: this.values.put(name, value);
/*     */   }
/*     */ 
/*     */   public void set(String name, int index, Object value)
/*     */   {
/* 304 */     Object prop = this.values.get(name);
/* 305 */     if (prop == null) {
/* 306 */       throw new NullPointerException("No indexed value for '" + name + "[" + index + "]'");
/*     */     }
/* 308 */     if (prop.getClass().isArray())
/* 309 */       Array.set(prop, index, value);
/* 310 */     else if (prop instanceof List)
/*     */       try {
/* 312 */         ((List)prop).set(index, value);
/*     */       } catch (ClassCastException e) {
/* 314 */         throw new ConversionException(e.getMessage());
/*     */       }
/*     */     else
/* 317 */       throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]'");
/*     */   }
/*     */ 
/*     */   public void set(String name, String key, Object value)
/*     */   {
/* 340 */     Object prop = this.values.get(name);
/* 341 */     if (prop == null) {
/* 342 */       throw new NullPointerException("No mapped value for '" + name + "(" + key + ")'");
/*     */     }
/* 344 */     if (prop instanceof Map)
/* 345 */       ((Map)prop).put(key, value);
/*     */     else
/* 347 */       throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'");
/*     */   }
/*     */ 
/*     */   protected DynaProperty getDynaProperty(String name)
/*     */   {
/* 367 */     DynaProperty descriptor = getDynaClass().getDynaProperty(name);
/* 368 */     if (descriptor == null) {
/* 369 */       throw new IllegalArgumentException("Invalid property name '" + name + "'");
/*     */     }
/*     */ 
/* 372 */     return descriptor;
/*     */   }
/*     */ 
/*     */   protected boolean isAssignable(Class dest, Class source)
/*     */   {
/* 394 */     return ((!(dest.isAssignableFrom(source))) && (((dest != Boolean.TYPE) || (source != Boolean.class))) && (((dest != Byte.TYPE) || (source != Byte.class))) && (((dest != Character.TYPE) || (source != Character.class))) && (((dest != Double.TYPE) || (source != Double.class))) && (((dest != Float.TYPE) || (source != Float.class))) && (((dest != Integer.TYPE) || (source != Integer.class))) && (((dest != Long.TYPE) || (source != Long.class))) && (((dest != Short.TYPE) || (source != Short.class))));
/*     */   }
/*     */ }