/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ 
/*     */ abstract class JDBCDynaClass
/*     */   implements DynaClass, Serializable
/*     */ {
/*     */   protected boolean lowerCase;
/*     */   protected DynaProperty[] properties;
/*     */   protected Map propertiesMap;
/*     */ 
/*     */   JDBCDynaClass()
/*     */   {
/*  43 */     this.lowerCase = true;
/*     */ 
/*  49 */     this.properties = null;
/*     */ 
/*  57 */     this.propertiesMap = new HashMap();
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  69 */     return super.getClass().getName();
/*     */   }
/*     */ 
/*     */   public DynaProperty getDynaProperty(String name)
/*     */   {
/*  84 */     if (name == null) {
/*  85 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*  87 */     return ((DynaProperty)this.propertiesMap.get(name));
/*     */   }
/*     */ 
/*     */   public DynaProperty[] getDynaProperties()
/*     */   {
/*  98 */     return this.properties;
/*     */   }
/*     */ 
/*     */   public DynaBean newInstance()
/*     */     throws IllegalAccessException, InstantiationException
/*     */   {
/* 116 */     throw new UnsupportedOperationException("newInstance() not supported");
/*     */   }
/*     */ 
/*     */   protected Class loadClass(String className)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 132 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 133 */       if (cl == null) {
/* 134 */         cl = super.getClass().getClassLoader();
/*     */       }
/* 136 */       return cl.loadClass(className);
/*     */     } catch (Exception e) {
/* 138 */       throw new SQLException("Cannot load column class '" + className + "': " + e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected DynaProperty createDynaProperty(ResultSetMetaData metadata, int i)
/*     */     throws SQLException
/*     */   {
/* 157 */     String name = null;
/* 158 */     if (this.lowerCase)
/* 159 */       name = metadata.getColumnName(i).toLowerCase();
/*     */     else {
/* 161 */       name = metadata.getColumnName(i);
/*     */     }
/* 163 */     String className = null;
/*     */     try {
/* 165 */       className = metadata.getColumnClassName(i);
/*     */     }
/*     */     catch (SQLException e)
/*     */     {
/*     */     }
/*     */ 
/* 173 */     Class clazz = Object.class;
/* 174 */     if (className != null) {
/* 175 */       clazz = loadClass(className);
/*     */     }
/* 177 */     return new DynaProperty(name, clazz);
/*     */   }
/*     */ 
/*     */   protected void introspect(ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 195 */     ArrayList list = new ArrayList();
/* 196 */     ResultSetMetaData metadata = resultSet.getMetaData();
/* 197 */     int n = metadata.getColumnCount();
/* 198 */     for (int i = 1; i <= n; ++i) {
/* 199 */       DynaProperty dynaProperty = createDynaProperty(metadata, i);
/* 200 */       if (dynaProperty != null) {
/* 201 */         list.add(dynaProperty);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 206 */     this.properties = ((DynaProperty[])list.toArray(new DynaProperty[list.size()]));
/*     */ 
/* 208 */     for (int i = 0; i < this.properties.length; ++i)
/* 209 */       this.propertiesMap.put(this.properties[i].getName(), this.properties[i]);
/*     */   }
/*     */ }