/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ 
/*     */ public class BeanUtils
/*     */ {
/*  55 */   private static FastHashMap dummy = new FastHashMap();
/*     */ 
/*     */   /** @deprecated */
/*  63 */   private static int debug = 0;
/*     */ 
/*     */   /** @deprecated */
/*     */   public static int getDebug()
/*     */   {
/*  71 */     return debug;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static void setDebug(int newDebug)
/*     */   {
/*  80 */     debug = newDebug;
/*     */   }
/*     */ 
/*     */   public static Object cloneBean(Object bean)
/*     */     throws IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException
/*     */   {
/*  98 */     return BeanUtilsBean.getInstance().cloneBean(bean);
/*     */   }
/*     */ 
/*     */   public static void copyProperties(Object dest, Object orig)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 114 */     BeanUtilsBean.getInstance().copyProperties(dest, orig);
/*     */   }
/*     */ 
/*     */   public static void copyProperty(Object bean, String name, Object value)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 129 */     BeanUtilsBean.getInstance().copyProperty(bean, name, value);
/*     */   }
/*     */ 
/*     */   public static Map describe(Object bean)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 145 */     return BeanUtilsBean.getInstance().describe(bean);
/*     */   }
/*     */ 
/*     */   public static String[] getArrayProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 161 */     return BeanUtilsBean.getInstance().getArrayProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 177 */     return BeanUtilsBean.getInstance().getIndexedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name, int index)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 196 */     return BeanUtilsBean.getInstance().getIndexedProperty(bean, name, index);
/*     */   }
/*     */ 
/*     */   public static String getMappedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 213 */     return BeanUtilsBean.getInstance().getMappedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getMappedProperty(Object bean, String name, String key)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 231 */     return BeanUtilsBean.getInstance().getMappedProperty(bean, name, key);
/*     */   }
/*     */ 
/*     */   public static String getNestedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 248 */     return BeanUtilsBean.getInstance().getNestedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 265 */     return BeanUtilsBean.getInstance().getProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getSimpleProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 282 */     return BeanUtilsBean.getInstance().getSimpleProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static void populate(Object bean, Map properties)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 298 */     BeanUtilsBean.getInstance().populate(bean, properties);
/*     */   }
/*     */ 
/*     */   public static void setProperty(Object bean, String name, Object value)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 313 */     BeanUtilsBean.getInstance().setProperty(bean, name, value);
/*     */   }
/*     */ }