/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.beans.BeanInfo;
/*     */ import java.beans.IntrospectionException;
/*     */ import java.beans.Introspector;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.io.PrintStream;
/*     */ import java.lang.reflect.Constructor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.AbstractMap;
/*     */ import java.util.AbstractSet;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.Transformer;
/*     */ import org.apache.commons.collections.keyvalue.AbstractMapEntry;
/*     */ import org.apache.commons.collections.list.UnmodifiableList;
/*     */ import org.apache.commons.collections.set.UnmodifiableSet;
/*     */ 
/*     */ public class BeanMap extends AbstractMap
/*     */   implements Cloneable
/*     */ {
/*     */   private transient Object bean;
/*  54 */   private transient HashMap readMethods = new HashMap();
/*  55 */   private transient HashMap writeMethods = new HashMap();
/*  56 */   private transient HashMap types = new HashMap();
/*     */ 
/*  61 */   public static final Object[] NULL_ARGUMENTS = new Object[0];
/*     */ 
/*  67 */   public static HashMap defaultTransformers = new HashMap();
/*     */ 
/*     */   public BeanMap()
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanMap(Object bean)
/*     */   {
/* 154 */     this.bean = bean;
/* 155 */     initialise();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 166 */     return "BeanMap<" + String.valueOf(this.bean) + ">";
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */     throws CloneNotSupportedException
/*     */   {
/* 193 */     BeanMap newMap = (BeanMap)super.clone();
/*     */ 
/* 195 */     if (this.bean == null)
/*     */     {
/* 198 */       return newMap;
/*     */     }
/*     */ 
/* 201 */     Object newBean = null;
/* 202 */     Class beanClass = null;
/*     */     try {
/* 204 */       beanClass = this.bean.getClass();
/* 205 */       newBean = beanClass.newInstance();
/*     */     }
/*     */     catch (Exception e) {
/* 208 */       throw new CloneNotSupportedException("Unable to instantiate the underlying bean \"" + beanClass.getName() + "\": " + e);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 214 */       newMap.setBean(newBean);
/*     */     } catch (Exception exception) {
/* 216 */       throw new CloneNotSupportedException("Unable to set bean in the cloned bean map: " + exception);
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 225 */       Iterator readableKeys = this.readMethods.keySet().iterator();
/* 226 */       while (readableKeys.hasNext()) {
/* 227 */         Object key = readableKeys.next();
/* 228 */         if (getWriteMethod(key) != null)
/* 229 */           newMap.put(key, get(key));
/*     */       }
/*     */     }
/*     */     catch (Exception readableKeys) {
/* 233 */       throw new CloneNotSupportedException("Unable to copy bean values to cloned bean map: " + exception);
/*     */     }
/*     */ 
/* 238 */     return newMap;
/*     */   }
/*     */ 
/*     */   public void putAllWriteable(BeanMap map)
/*     */   {
/* 248 */     Iterator readableKeys = map.readMethods.keySet().iterator();
/* 249 */     while (readableKeys.hasNext()) {
/* 250 */       Object key = readableKeys.next();
/* 251 */       if (getWriteMethod(key) != null)
/* 252 */         put(key, map.get(key));
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 267 */     if (this.bean == null) return;
/*     */ 
/* 269 */     Class beanClass = null;
/*     */     try {
/* 271 */       beanClass = this.bean.getClass();
/* 272 */       this.bean = beanClass.newInstance();
/*     */     }
/*     */     catch (Exception e) {
/* 275 */       throw new UnsupportedOperationException("Could not create new instance of class: " + beanClass);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object name)
/*     */   {
/* 295 */     Method method = getReadMethod(name);
/* 296 */     return (method != null);
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 309 */     return super.containsValue(value);
/*     */   }
/*     */ 
/*     */   public Object get(Object name)
/*     */   {
/* 328 */     if (this.bean != null) {
/* 329 */       Method method = getReadMethod(name);
/* 330 */       if (method != null) {
/*     */         try {
/* 332 */           return method.invoke(this.bean, NULL_ARGUMENTS);
/*     */         }
/*     */         catch (IllegalAccessException e) {
/* 335 */           logWarn(e);
/*     */         }
/*     */         catch (IllegalArgumentException e) {
/* 338 */           logWarn(e);
/*     */         }
/*     */         catch (InvocationTargetException e) {
/* 341 */           logWarn(e);
/*     */         }
/*     */         catch (NullPointerException e) {
/* 344 */           logWarn(e);
/*     */         }
/*     */       }
/*     */     }
/* 348 */     return null;
/*     */   }
/*     */ 
/*     */   public Object put(Object name, Object value)
/*     */     throws IllegalArgumentException, ClassCastException
/*     */   {
/* 363 */     if (this.bean != null) {
/* 364 */       Object oldValue = get(name);
/* 365 */       Method method = getWriteMethod(name);
/* 366 */       if (method == null)
/* 367 */         throw new IllegalArgumentException("The bean of type: " + this.bean.getClass().getName() + " has no property called: " + name);
/*     */       try
/*     */       {
/* 370 */         Object[] arguments = createWriteMethodArguments(method, value);
/* 371 */         method.invoke(this.bean, arguments);
/*     */ 
/* 373 */         Object newValue = get(name);
/* 374 */         firePropertyChange(name, oldValue, newValue);
/*     */       }
/*     */       catch (InvocationTargetException e) {
/* 377 */         logInfo(e);
/* 378 */         throw new IllegalArgumentException(e.getMessage());
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 381 */         logInfo(e);
/* 382 */         throw new IllegalArgumentException(e.getMessage());
/*     */       }
/* 384 */       return oldValue;
/*     */     }
/* 386 */     return null;
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 395 */     return this.readMethods.size();
/*     */   }
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 410 */     return UnmodifiableSet.decorate(this.readMethods.keySet());
/*     */   }
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 421 */     return UnmodifiableSet.decorate(new AbstractSet() {
/*     */       public Iterator iterator() {
/* 423 */         return BeanMap.this.entryIterator(); }
/*     */ 
/*     */       public int size() {
/* 426 */         return BeanMap.this.readMethods.size();
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 438 */     ArrayList answer = new ArrayList(this.readMethods.size());
/* 439 */     for (Iterator iter = valueIterator(); iter.hasNext(); ) {
/* 440 */       answer.add(iter.next());
/*     */     }
/* 442 */     return UnmodifiableList.decorate(answer);
/*     */   }
/*     */ 
/*     */   public Class getType(String name)
/*     */   {
/* 457 */     return ((Class)this.types.get(name));
/*     */   }
/*     */ 
/*     */   public Iterator keyIterator()
/*     */   {
/* 468 */     return this.readMethods.keySet().iterator();
/*     */   }
/*     */ 
/*     */   public Iterator valueIterator()
/*     */   {
/* 477 */     Iterator iter = keyIterator();
/* 478 */     return new Iterator(iter) { private final Iterator val$iter;
/*     */ 
/*     */       public boolean hasNext() { return this.val$iter.hasNext(); }
/*     */ 
/*     */       public Object next() {
/* 483 */         Object key = this.val$iter.next();
/* 484 */         return BeanMap.this.get(key); }
/*     */ 
/*     */       public void remove() {
/* 487 */         throw new UnsupportedOperationException("remove() not supported for BeanMap");
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Iterator entryIterator()
/*     */   {
/* 498 */     Iterator iter = keyIterator();
/* 499 */     return new Iterator(iter) { private final Iterator val$iter;
/*     */ 
/*     */       public boolean hasNext() { return this.val$iter.hasNext(); }
/*     */ 
/*     */       public Object next() {
/* 504 */         Object key = this.val$iter.next();
/* 505 */         Object value = BeanMap.this.get(key);
/* 506 */         return new BeanMap.Entry(BeanMap.this, key, value); }
/*     */ 
/*     */       public void remove() {
/* 509 */         throw new UnsupportedOperationException("remove() not supported for BeanMap");
/*     */       }
/*     */     };
/*     */   }
/*     */ 
/*     */   public Object getBean()
/*     */   {
/* 525 */     return this.bean;
/*     */   }
/*     */ 
/*     */   public void setBean(Object newBean)
/*     */   {
/* 535 */     this.bean = newBean;
/* 536 */     reinitialise();
/*     */   }
/*     */ 
/*     */   public Method getReadMethod(String name)
/*     */   {
/* 546 */     return ((Method)this.readMethods.get(name));
/*     */   }
/*     */ 
/*     */   public Method getWriteMethod(String name)
/*     */   {
/* 556 */     return ((Method)this.writeMethods.get(name));
/*     */   }
/*     */ 
/*     */   protected Method getReadMethod(Object name)
/*     */   {
/* 572 */     return ((Method)this.readMethods.get(name));
/*     */   }
/*     */ 
/*     */   protected Method getWriteMethod(Object name)
/*     */   {
/* 584 */     return ((Method)this.writeMethods.get(name));
/*     */   }
/*     */ 
/*     */   protected void reinitialise()
/*     */   {
/* 592 */     this.readMethods.clear();
/* 593 */     this.writeMethods.clear();
/* 594 */     this.types.clear();
/* 595 */     initialise();
/*     */   }
/*     */ 
/*     */   private void initialise() {
/* 599 */     if (getBean() == null) return;
/*     */ 
/* 601 */     Class beanClass = getBean().getClass();
/*     */     try
/*     */     {
/* 604 */       BeanInfo beanInfo = Introspector.getBeanInfo(beanClass);
/* 605 */       PropertyDescriptor[] propertyDescriptors = beanInfo.getPropertyDescriptors();
/* 606 */       if (propertyDescriptors != null)
/* 607 */         for (int i = 0; i < propertyDescriptors.length; ++i) {
/* 608 */           PropertyDescriptor propertyDescriptor = propertyDescriptors[i];
/* 609 */           if (propertyDescriptor != null) {
/* 610 */             String name = propertyDescriptor.getName();
/* 611 */             Method readMethod = propertyDescriptor.getReadMethod();
/* 612 */             Method writeMethod = propertyDescriptor.getWriteMethod();
/* 613 */             Class aType = propertyDescriptor.getPropertyType();
/*     */ 
/* 615 */             if (readMethod != null) {
/* 616 */               this.readMethods.put(name, readMethod);
/*     */             }
/* 618 */             if (this.writeMethods != null) {
/* 619 */               this.writeMethods.put(name, writeMethod);
/*     */             }
/* 621 */             this.types.put(name, aType);
/*     */           }
/*     */         }
/*     */     }
/*     */     catch (IntrospectionException e)
/*     */     {
/* 627 */       logWarn(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected void firePropertyChange(Object key, Object oldValue, Object newValue)
/*     */   {
/*     */   }
/*     */ 
/*     */   protected Object[] createWriteMethodArguments(Method method, Object value)
/*     */     throws IllegalAccessException, ClassCastException
/*     */   {
/*     */     try
/*     */     {
/* 697 */       if (value != null) {
/* 698 */         Class[] types = method.getParameterTypes();
/* 699 */         if ((types != null) && (types.length > 0)) {
/* 700 */           Class paramType = types[0];
/* 701 */           if (!(paramType.isAssignableFrom(value.getClass()))) {
/* 702 */             value = convertType(paramType, value);
/*     */           }
/*     */         }
/*     */       }
/* 706 */       Object[] answer = { value };
/* 707 */       return answer;
/*     */     }
/*     */     catch (InvocationTargetException e) {
/* 710 */       logInfo(e);
/* 711 */       throw new IllegalArgumentException(e.getMessage());
/*     */     }
/*     */     catch (InstantiationException e) {
/* 714 */       logInfo(e);
/* 715 */       throw new IllegalArgumentException(e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Object convertType(Class newType, Object value)
/*     */     throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException
/*     */   {
/* 754 */     Class[] types = { value.getClass() };
/*     */     try {
/* 756 */       Constructor constructor = newType.getConstructor(types);
/* 757 */       Object[] arguments = { value };
/* 758 */       return constructor.newInstance(arguments);
/*     */     }
/*     */     catch (NoSuchMethodException e)
/*     */     {
/* 762 */       Transformer transformer = getTypeTransformer(newType);
/* 763 */       if (transformer != null)
/* 764 */         return transformer.transform(value);
/*     */     }
/* 766 */     return value;
/*     */   }
/*     */ 
/*     */   protected Transformer getTypeTransformer(Class aType)
/*     */   {
/* 778 */     return ((Transformer)defaultTransformers.get(aType));
/*     */   }
/*     */ 
/*     */   protected void logInfo(Exception ex)
/*     */   {
/* 789 */     System.out.println("INFO: Exception: " + ex);
/*     */   }
/*     */ 
/*     */   protected void logWarn(Exception ex)
/*     */   {
/* 800 */     System.out.println("WARN: Exception: " + ex);
/* 801 */     ex.printStackTrace();
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*  70 */     defaultTransformers.put(Boolean.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/*  74 */         return Boolean.valueOf(input.toString());
/*     */       }
/*     */     });
/*  78 */     defaultTransformers.put(Character.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/*  82 */         return new Character(input.toString().charAt(0));
/*     */       }
/*     */     });
/*  86 */     defaultTransformers.put(Byte.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/*  90 */         return Byte.valueOf(input.toString());
/*     */       }
/*     */     });
/*  94 */     defaultTransformers.put(Short.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/*  98 */         return Short.valueOf(input.toString());
/*     */       }
/*     */     });
/* 102 */     defaultTransformers.put(Integer.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/* 106 */         return Integer.valueOf(input.toString());
/*     */       }
/*     */     });
/* 110 */     defaultTransformers.put(Long.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/* 114 */         return Long.valueOf(input.toString());
/*     */       }
/*     */     });
/* 118 */     defaultTransformers.put(Float.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/* 122 */         return Float.valueOf(input.toString());
/*     */       }
/*     */     });
/* 126 */     defaultTransformers.put(Double.TYPE, new Transformer()
/*     */     {
/*     */       public Object transform(Object input)
/*     */       {
/* 130 */         return Double.valueOf(input.toString());
/*     */       }
/*     */     });
/*     */   }
/*     */ 
/*     */   protected static class Entry extends AbstractMapEntry
/*     */   {
/*     */     private BeanMap owner;
/*     */ 
/*     */     protected Entry(BeanMap owner, Object key, Object value)
/*     */     {
/* 660 */       super(key, value);
/* 661 */       this.owner = owner;
/*     */     }
/*     */ 
/*     */     public Object setValue(Object value)
/*     */     {
/* 671 */       Object key = getKey();
/* 672 */       Object oldValue = this.owner.get(key);
/*     */ 
/* 674 */       this.owner.put(key, value);
/* 675 */       Object newValue = this.owner.get(key);
/* 676 */       super.setValue(newValue);
/* 677 */       return oldValue;
/*     */     }
/*     */   }
/*     */ }