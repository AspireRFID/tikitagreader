/*     */ package org.apache.commons.beanutils.locale;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public abstract class BaseLocaleConverter
/*     */   implements LocaleConverter
/*     */ {
/*  43 */   private static Log log = LogFactory.getLog(BaseLocaleConverter.class);
/*     */   private Object defaultValue;
/*     */   protected boolean useDefault;
/*     */   protected Locale locale;
/*     */   protected String pattern;
/*     */   protected boolean locPattern;
/*     */ 
/*     */   protected BaseLocaleConverter(Locale locale, String pattern)
/*     */   {
/*  72 */     this(null, locale, pattern, false, false);
/*     */   }
/*     */ 
/*     */   protected BaseLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/*  85 */     this(null, locale, pattern, false, locPattern);
/*     */   }
/*     */ 
/*     */   protected BaseLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/*  99 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   protected BaseLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 113 */     this(defaultValue, locale, pattern, true, locPattern);
/*     */   }
/*     */ 
/*     */   private BaseLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean useDefault, boolean locPattern)
/*     */   {
/*  46 */     this.defaultValue = null;
/*     */ 
/*  49 */     this.useDefault = false;
/*     */ 
/*  52 */     this.locale = Locale.getDefault();
/*     */ 
/*  55 */     this.pattern = null;
/*     */ 
/*  58 */     this.locPattern = false;
/*     */ 
/* 129 */     if (useDefault) {
/* 130 */       this.defaultValue = defaultValue;
/* 131 */       this.useDefault = true;
/*     */     }
/*     */ 
/* 134 */     if (locale != null) {
/* 135 */       this.locale = locale;
/*     */     }
/*     */ 
/* 138 */     this.pattern = pattern;
/* 139 */     this.locPattern = locPattern;
/*     */   }
/*     */ 
/*     */   protected abstract Object parse(Object paramObject, String paramString)
/*     */     throws ParseException;
/*     */ 
/*     */   public Object convert(Object value)
/*     */   {
/* 168 */     return convert(value, null);
/*     */   }
/*     */ 
/*     */   public Object convert(Object value, String pattern)
/*     */   {
/* 181 */     return convert(null, value, pattern);
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value)
/*     */   {
/* 195 */     return convert(type, value, null);
/*     */   }
/*     */ 
/*     */   public Object convert(Class type, Object value, String pattern)
/*     */   {
/* 210 */     if (value == null) {
/* 211 */       if (this.useDefault) {
/* 212 */         return this.defaultValue;
/*     */       }
/*     */ 
/* 216 */       log.debug("Null value specified for conversion, returing null");
/* 217 */       return null;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 222 */       if (pattern != null) {
/* 223 */         return parse(value, pattern);
/*     */       }
/* 225 */       return parse(value, this.pattern);
/*     */     }
/*     */     catch (Exception e) {
/* 228 */       if (this.useDefault) {
/* 229 */         return this.defaultValue;
/*     */       }
/* 231 */       throw new ConversionException(e);
/*     */     }
/*     */   }
/*     */ }