/*     */ package org.apache.commons.beanutils.locale;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.locale.converters.BigDecimalLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.BigIntegerLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.ByteLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.DoubleLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.FloatLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.IntegerLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.LongLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.ShortLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.SqlDateLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.SqlTimeLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.SqlTimestampLocaleConverter;
/*     */ import org.apache.commons.beanutils.locale.converters.StringLocaleConverter;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocaleConvertUtilsBean
/*     */ {
/*  86 */   private Locale defaultLocale = Locale.getDefault();
/*     */ 
/*  89 */   private boolean applyLocalized = false;
/*     */ 
/*  92 */   private Log log = LogFactory.getLog(LocaleConvertUtils.class);
/*     */ 
/*  98 */   private FastHashMap mapConverters = new FastHashMap();
/*     */ 
/*     */   public static LocaleConvertUtilsBean getInstance()
/*     */   {
/*  80 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getLocaleConvertUtils();
/*     */   }
/*     */ 
/*     */   public LocaleConvertUtilsBean()
/*     */   {
/* 107 */     deregister();
/*     */   }
/*     */ 
/*     */   public Locale getDefaultLocale()
/*     */   {
/* 117 */     return this.defaultLocale;
/*     */   }
/*     */ 
/*     */   public void setDefaultLocale(Locale locale)
/*     */   {
/* 125 */     if (locale == null) {
/* 126 */       this.defaultLocale = Locale.getDefault();
/*     */     }
/*     */     else
/* 129 */       this.defaultLocale = locale;
/*     */   }
/*     */ 
/*     */   public boolean getApplyLocalized()
/*     */   {
/* 137 */     return this.applyLocalized;
/*     */   }
/*     */ 
/*     */   public void setApplyLocalized(boolean newApplyLocalized)
/*     */   {
/* 144 */     this.applyLocalized = newApplyLocalized;
/*     */   }
/*     */ 
/*     */   public String convert(Object value)
/*     */   {
/* 157 */     return convert(value, this.defaultLocale, null);
/*     */   }
/*     */ 
/*     */   public String convert(Object value, String pattern)
/*     */   {
/* 170 */     return convert(value, this.defaultLocale, pattern);
/*     */   }
/*     */ 
/*     */   public String convert(Object value, Locale locale, String pattern)
/*     */   {
/* 185 */     LocaleConverter converter = lookup(String.class, locale);
/*     */ 
/* 187 */     return ((String)converter.convert(String.class, value, pattern));
/*     */   }
/*     */ 
/*     */   public Object convert(String value, Class clazz)
/*     */   {
/* 201 */     return convert(value, clazz, this.defaultLocale, null);
/*     */   }
/*     */ 
/*     */   public Object convert(String value, Class clazz, String pattern)
/*     */   {
/* 217 */     return convert(value, clazz, this.defaultLocale, pattern);
/*     */   }
/*     */ 
/*     */   public Object convert(String value, Class clazz, Locale locale, String pattern)
/*     */   {
/* 234 */     if (this.log.isDebugEnabled()) {
/* 235 */       this.log.debug("Convert string " + value + " to class " + clazz.getName() + " using " + locale.toString() + " locale and " + pattern + " pattern");
/*     */     }
/*     */ 
/* 240 */     LocaleConverter converter = lookup(clazz, locale);
/*     */ 
/* 242 */     if (converter == null) {
/* 243 */       converter = lookup(String.class, locale);
/*     */     }
/* 245 */     if (this.log.isTraceEnabled()) {
/* 246 */       this.log.trace("  Using converter " + converter);
/*     */     }
/*     */ 
/* 249 */     return converter.convert(clazz, value, pattern);
/*     */   }
/*     */ 
/*     */   public Object convert(String[] values, Class clazz, String pattern)
/*     */   {
/* 264 */     return convert(values, clazz, getDefaultLocale(), pattern);
/*     */   }
/*     */ 
/*     */   public Object convert(String[] values, Class clazz)
/*     */   {
/* 278 */     return convert(values, clazz, getDefaultLocale(), null);
/*     */   }
/*     */ 
/*     */   public Object convert(String[] values, Class clazz, Locale locale, String pattern)
/*     */   {
/* 294 */     Class type = clazz;
/* 295 */     if (clazz.isArray()) {
/* 296 */       type = clazz.getComponentType();
/*     */     }
/* 298 */     if (this.log.isDebugEnabled()) {
/* 299 */       this.log.debug("Convert String[" + values.length + "] to class " + type.getName() + "[] using " + locale.toString() + " locale and " + pattern + " pattern");
/*     */     }
/*     */ 
/* 304 */     Object array = Array.newInstance(type, values.length);
/* 305 */     for (int i = 0; i < values.length; ++i) {
/* 306 */       Array.set(array, i, convert(values[i], type, locale, pattern));
/*     */     }
/*     */ 
/* 309 */     return array;
/*     */   }
/*     */ 
/*     */   public void register(LocaleConverter converter, Class clazz, Locale locale)
/*     */   {
/* 323 */     lookup(locale).put(clazz, converter);
/*     */   }
/*     */ 
/*     */   public void deregister()
/*     */   {
/* 331 */     FastHashMap defaultConverter = lookup(this.defaultLocale);
/*     */ 
/* 333 */     this.mapConverters.setFast(false);
/*     */ 
/* 335 */     this.mapConverters.clear();
/* 336 */     this.mapConverters.put(this.defaultLocale, defaultConverter);
/*     */ 
/* 338 */     this.mapConverters.setFast(true);
/*     */   }
/*     */ 
/*     */   public void deregister(Locale locale)
/*     */   {
/* 349 */     this.mapConverters.remove(locale);
/*     */   }
/*     */ 
/*     */   public void deregister(Class clazz, Locale locale)
/*     */   {
/* 361 */     lookup(locale).remove(clazz);
/*     */   }
/*     */ 
/*     */   public LocaleConverter lookup(Class clazz, Locale locale)
/*     */   {
/* 374 */     LocaleConverter converter = (LocaleConverter)lookup(locale).get(clazz);
/*     */ 
/* 376 */     if (this.log.isTraceEnabled()) {
/* 377 */       this.log.trace("LocaleConverter:" + converter);
/*     */     }
/*     */ 
/* 380 */     return converter;
/*     */   }
/*     */ 
/*     */   protected FastHashMap lookup(Locale locale)
/*     */   {
/*     */     FastHashMap localeConverters;
/* 394 */     if (locale == null) {
/* 395 */       localeConverters = (FastHashMap)this.mapConverters.get(this.defaultLocale);
/*     */     }
/*     */     else {
/* 398 */       localeConverters = (FastHashMap)this.mapConverters.get(locale);
/*     */ 
/* 400 */       if (localeConverters == null) {
/* 401 */         localeConverters = create(locale);
/* 402 */         this.mapConverters.put(locale, localeConverters);
/*     */       }
/*     */     }
/*     */ 
/* 406 */     return localeConverters;
/*     */   }
/*     */ 
/*     */   protected FastHashMap create(Locale locale)
/*     */   {
/* 418 */     FastHashMap converter = new FastHashMap();
/* 419 */     converter.setFast(false);
/*     */ 
/* 421 */     converter.put(BigDecimal.class, new BigDecimalLocaleConverter(locale, this.applyLocalized));
/* 422 */     converter.put(BigInteger.class, new BigIntegerLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 424 */     converter.put(Byte.class, new ByteLocaleConverter(locale, this.applyLocalized));
/* 425 */     converter.put(Byte.TYPE, new ByteLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 427 */     converter.put(Double.class, new DoubleLocaleConverter(locale, this.applyLocalized));
/* 428 */     converter.put(Double.TYPE, new DoubleLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 430 */     converter.put(Float.class, new FloatLocaleConverter(locale, this.applyLocalized));
/* 431 */     converter.put(Float.TYPE, new FloatLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 433 */     converter.put(Integer.class, new IntegerLocaleConverter(locale, this.applyLocalized));
/* 434 */     converter.put(Integer.TYPE, new IntegerLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 436 */     converter.put(Long.class, new LongLocaleConverter(locale, this.applyLocalized));
/* 437 */     converter.put(Long.TYPE, new LongLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 439 */     converter.put(Short.class, new ShortLocaleConverter(locale, this.applyLocalized));
/* 440 */     converter.put(Short.TYPE, new ShortLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 442 */     converter.put(String.class, new StringLocaleConverter(locale, this.applyLocalized));
/*     */ 
/* 446 */     converter.put(Date.class, new SqlDateLocaleConverter(locale, "yyyy-MM-dd"));
/* 447 */     converter.put(Time.class, new SqlTimeLocaleConverter(locale, "HH:mm:ss"));
/* 448 */     converter.put(Timestamp.class, new SqlTimestampLocaleConverter(locale, "yyyy-MM-dd HH:mm:ss.S"));
/*     */ 
/* 452 */     converter.setFast(true);
/*     */ 
/* 454 */     return converter;
/*     */   }
/*     */ }