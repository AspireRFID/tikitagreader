/*     */ package org.apache.commons.beanutils.locale;
/*     */ 
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ 
/*     */ public class LocaleConvertUtils
/*     */ {
/*     */   public static Locale getDefaultLocale()
/*     */   {
/*  48 */     return LocaleConvertUtilsBean.getInstance().getDefaultLocale();
/*     */   }
/*     */ 
/*     */   public static void setDefaultLocale(Locale locale)
/*     */   {
/*  61 */     LocaleConvertUtilsBean.getInstance().setDefaultLocale(locale);
/*     */   }
/*     */ 
/*     */   public static boolean getApplyLocalized()
/*     */   {
/*  72 */     return LocaleConvertUtilsBean.getInstance().getApplyLocalized();
/*     */   }
/*     */ 
/*     */   public static void setApplyLocalized(boolean newApplyLocalized)
/*     */   {
/*  83 */     LocaleConvertUtilsBean.getInstance().setApplyLocalized(newApplyLocalized);
/*     */   }
/*     */ 
/*     */   public static String convert(Object value)
/*     */   {
/*  96 */     return LocaleConvertUtilsBean.getInstance().convert(value);
/*     */   }
/*     */ 
/*     */   public static String convert(Object value, String pattern)
/*     */   {
/* 108 */     return LocaleConvertUtilsBean.getInstance().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public static String convert(Object value, Locale locale, String pattern)
/*     */   {
/* 121 */     return LocaleConvertUtilsBean.getInstance().convert(value, locale, pattern);
/*     */   }
/*     */ 
/*     */   public static Object convert(String value, Class clazz)
/*     */   {
/* 134 */     return LocaleConvertUtilsBean.getInstance().convert(value, clazz);
/*     */   }
/*     */ 
/*     */   public static Object convert(String value, Class clazz, String pattern)
/*     */   {
/* 148 */     return LocaleConvertUtilsBean.getInstance().convert(value, clazz, pattern);
/*     */   }
/*     */ 
/*     */   public static Object convert(String value, Class clazz, Locale locale, String pattern)
/*     */   {
/* 162 */     return LocaleConvertUtilsBean.getInstance().convert(value, clazz, locale, pattern);
/*     */   }
/*     */ 
/*     */   public static Object convert(String[] values, Class clazz, String pattern)
/*     */   {
/* 175 */     return LocaleConvertUtilsBean.getInstance().convert(values, clazz, pattern);
/*     */   }
/*     */ 
/*     */   public static Object convert(String[] values, Class clazz)
/*     */   {
/* 188 */     return LocaleConvertUtilsBean.getInstance().convert(values, clazz);
/*     */   }
/*     */ 
/*     */   public static Object convert(String[] values, Class clazz, Locale locale, String pattern)
/*     */   {
/* 201 */     return LocaleConvertUtilsBean.getInstance().convert(values, clazz, locale, pattern);
/*     */   }
/*     */ 
/*     */   public static void register(LocaleConverter converter, Class clazz, Locale locale)
/*     */   {
/* 214 */     LocaleConvertUtilsBean.getInstance().register(converter, clazz, locale);
/*     */   }
/*     */ 
/*     */   public static void deregister()
/*     */   {
/* 226 */     LocaleConvertUtilsBean.getInstance().deregister();
/*     */   }
/*     */ 
/*     */   public static void deregister(Locale locale)
/*     */   {
/* 239 */     LocaleConvertUtilsBean.getInstance().deregister(locale);
/*     */   }
/*     */ 
/*     */   public static void deregister(Class clazz, Locale locale)
/*     */   {
/* 252 */     LocaleConvertUtilsBean.getInstance().deregister(clazz, locale);
/*     */   }
/*     */ 
/*     */   public static LocaleConverter lookup(Class clazz, Locale locale)
/*     */   {
/* 266 */     return LocaleConvertUtilsBean.getInstance().lookup(clazz, locale);
/*     */   }
/*     */ 
/*     */   protected static FastHashMap lookup(Locale locale)
/*     */   {
/* 277 */     return LocaleConvertUtilsBean.getInstance().lookup(locale);
/*     */   }
/*     */ 
/*     */   protected static FastHashMap create(Locale locale)
/*     */   {
/* 289 */     return LocaleConvertUtilsBean.getInstance().create(locale);
/*     */   }
/*     */ }