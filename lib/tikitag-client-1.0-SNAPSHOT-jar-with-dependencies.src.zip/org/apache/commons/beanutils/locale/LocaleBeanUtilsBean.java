/*     */ package org.apache.commons.beanutils.locale;
/*     */ 
/*     */ import java.beans.IndexedPropertyDescriptor;
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.BeanUtilsBean;
/*     */ import org.apache.commons.beanutils.ContextClassLoaderLocal;
/*     */ import org.apache.commons.beanutils.ConvertUtils;
/*     */ import org.apache.commons.beanutils.ConvertUtilsBean;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.beanutils.MappedPropertyDescriptor;
/*     */ import org.apache.commons.beanutils.PropertyUtilsBean;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocaleBeanUtilsBean extends BeanUtilsBean
/*     */ {
/*  50 */   private static final ContextClassLoaderLocal localeBeansByClassLoader = new ContextClassLoaderLocal()
/*     */   {
/*     */     protected Object initialValue() {
/*  53 */       return new LocaleBeanUtilsBean(); } } ;
/*     */ 
/*  72 */   private static Log log = LogFactory.getLog(LocaleBeanUtilsBean.class);
/*     */   private LocaleConvertUtilsBean localeConvertUtils;
/*     */ 
/*     */   public static synchronized LocaleBeanUtilsBean getLocaleBeanUtilsInstance() {
/*  59 */     return ((LocaleBeanUtilsBean)localeBeansByClassLoader.get());
/*     */   }
/*     */ 
/*     */   public static synchronized void setInstance(LocaleBeanUtilsBean newInstance)
/*     */   {
/*  68 */     localeBeansByClassLoader.set(newInstance);
/*     */   }
/*     */ 
/*     */   public LocaleBeanUtilsBean()
/*     */   {
/*  83 */     this.localeConvertUtils = new LocaleConvertUtilsBean();
/*     */   }
/*     */ 
/*     */   public LocaleBeanUtilsBean(LocaleConvertUtilsBean localeConvertUtils, ConvertUtilsBean convertUtilsBean, PropertyUtilsBean propertyUtilsBean)
/*     */   {
/*  98 */     super(convertUtilsBean, propertyUtilsBean);
/*  99 */     this.localeConvertUtils = localeConvertUtils;
/*     */   }
/*     */ 
/*     */   public LocaleBeanUtilsBean(LocaleConvertUtilsBean localeConvertUtils)
/*     */   {
/* 109 */     this.localeConvertUtils = localeConvertUtils;
/*     */   }
/*     */ 
/*     */   public LocaleConvertUtilsBean getLocaleConvertUtils()
/*     */   {
/* 116 */     return this.localeConvertUtils;
/*     */   }
/*     */ 
/*     */   public Locale getDefaultLocale()
/*     */   {
/* 124 */     return getLocaleConvertUtils().getDefaultLocale();
/*     */   }
/*     */ 
/*     */   public void setDefaultLocale(Locale locale)
/*     */   {
/* 133 */     getLocaleConvertUtils().setDefaultLocale(locale);
/*     */   }
/*     */ 
/*     */   public boolean getApplyLocalized()
/*     */   {
/* 142 */     return getLocaleConvertUtils().getApplyLocalized();
/*     */   }
/*     */ 
/*     */   public void setApplyLocalized(boolean newApplyLocalized)
/*     */   {
/* 151 */     getLocaleConvertUtils().setApplyLocalized(newApplyLocalized);
/*     */   }
/*     */ 
/*     */   public String getIndexedProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 185 */     Object value = getPropertyUtils().getIndexedProperty(bean, name);
/* 186 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getIndexedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 215 */     return getIndexedProperty(bean, name, null);
/*     */   }
/*     */ 
/*     */   public String getIndexedProperty(Object bean, String name, int index, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 241 */     Object value = getPropertyUtils().getIndexedProperty(bean, name, index);
/* 242 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getIndexedProperty(Object bean, String name, int index)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 267 */     return getIndexedProperty(bean, name, index, null);
/*     */   }
/*     */ 
/*     */   public String getSimpleProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 290 */     Object value = getPropertyUtils().getSimpleProperty(bean, name);
/* 291 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getSimpleProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 313 */     return getSimpleProperty(bean, name, null);
/*     */   }
/*     */ 
/*     */   public String getMappedProperty(Object bean, String name, String key, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 344 */     Object value = getPropertyUtils().getMappedProperty(bean, name, key);
/* 345 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getMappedProperty(Object bean, String name, String key)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 370 */     return getMappedProperty(bean, name, key, null);
/*     */   }
/*     */ 
/*     */   public String getMappedPropertyLocale(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 403 */     Object value = getPropertyUtils().getMappedProperty(bean, name);
/* 404 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getMappedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 434 */     return getMappedPropertyLocale(bean, name, null);
/*     */   }
/*     */ 
/*     */   public String getNestedProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 464 */     Object value = getPropertyUtils().getNestedProperty(bean, name);
/* 465 */     return getLocaleConvertUtils().convert(value, pattern);
/*     */   }
/*     */ 
/*     */   public String getNestedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 491 */     return getNestedProperty(bean, name, null);
/*     */   }
/*     */ 
/*     */   public String getProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 517 */     return getNestedProperty(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public String getProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 543 */     return getNestedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public void setProperty(Object bean, String name, Object value)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 565 */     setProperty(bean, name, value, null);
/*     */   }
/*     */ 
/*     */   public void setProperty(Object bean, String name, Object value, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 593 */     if (log.isTraceEnabled()) {
/* 594 */       StringBuffer sb = new StringBuffer("  setProperty(");
/* 595 */       sb.append(bean);
/* 596 */       sb.append(", ");
/* 597 */       sb.append(name);
/* 598 */       sb.append(", ");
/* 599 */       if (value == null) {
/* 600 */         sb.append("<NULL>");
/*     */       }
/* 602 */       else if (value instanceof String) {
/* 603 */         sb.append((String)value);
/*     */       }
/* 605 */       else if (value instanceof String[]) {
/* 606 */         String[] values = (String[])value;
/* 607 */         sb.append('[');
/* 608 */         for (int i = 0; i < values.length; ++i) {
/* 609 */           if (i > 0) {
/* 610 */             sb.append(',');
/*     */           }
/* 612 */           sb.append(values[i]);
/*     */         }
/* 614 */         sb.append(']');
/*     */       }
/*     */       else {
/* 617 */         sb.append(value.toString());
/*     */       }
/* 619 */       sb.append(')');
/* 620 */       log.trace(sb.toString());
/*     */     }
/*     */ 
/* 623 */     Descriptor propInfo = calculate(bean, name);
/*     */ 
/* 625 */     if (propInfo != null) {
/* 626 */       Class type = definePropertyType(propInfo.getTarget(), name, propInfo.getPropName());
/*     */ 
/* 628 */       if (type == null)
/*     */         return;
/* 630 */       Object newValue = convert(type, propInfo.getIndex(), value, pattern);
/* 631 */       invokeSetter(propInfo.getTarget(), propInfo.getPropName(), propInfo.getKey(), propInfo.getIndex(), newValue);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Class definePropertyType(Object target, String name, String propName)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 652 */     Class type = null;
/*     */ 
/* 654 */     if (target instanceof DynaBean) {
/* 655 */       DynaClass dynaClass = ((DynaBean)target).getDynaClass();
/* 656 */       DynaProperty dynaProperty = dynaClass.getDynaProperty(propName);
/* 657 */       if (dynaProperty == null) {
/* 658 */         return null;
/*     */       }
/* 660 */       type = dynaProperty.getType();
/*     */     }
/*     */     else {
/* 663 */       PropertyDescriptor descriptor = null;
/*     */       try {
/* 665 */         descriptor = getPropertyUtils().getPropertyDescriptor(target, name);
/*     */ 
/* 667 */         if (descriptor == null)
/* 668 */           return null;
/*     */       }
/*     */       catch (NoSuchMethodException e)
/*     */       {
/* 672 */         return null;
/*     */       }
/* 674 */       if (descriptor instanceof MappedPropertyDescriptor) {
/* 675 */         type = ((MappedPropertyDescriptor)descriptor).getMappedPropertyType();
/*     */       }
/* 678 */       else if (descriptor instanceof IndexedPropertyDescriptor) {
/* 679 */         type = ((IndexedPropertyDescriptor)descriptor).getIndexedPropertyType();
/*     */       }
/*     */       else
/*     */       {
/* 683 */         type = descriptor.getPropertyType();
/*     */       }
/*     */     }
/* 686 */     return type;
/*     */   }
/*     */ 
/*     */   protected Object convert(Class type, int index, Object value, String pattern)
/*     */   {
/* 700 */     if (log.isTraceEnabled()) {
/* 701 */       log.trace("Converting value '" + value + "' to type:" + type);
/*     */     }
/*     */ 
/* 704 */     Object newValue = null;
/*     */ 
/* 706 */     if ((type.isArray()) && (index < 0)) {
/* 707 */       if (value instanceof String) {
/* 708 */         String[] values = new String[1];
/* 709 */         values[0] = ((String)value);
/* 710 */         newValue = getLocaleConvertUtils().convert((String[])values, type, pattern);
/*     */       }
/* 712 */       else if (value instanceof String[]) {
/* 713 */         newValue = getLocaleConvertUtils().convert((String[])value, type, pattern);
/*     */       }
/*     */       else {
/* 716 */         newValue = value;
/*     */       }
/*     */     }
/* 719 */     else if (type.isArray()) {
/* 720 */       if (value instanceof String) {
/* 721 */         newValue = getLocaleConvertUtils().convert((String)value, type.getComponentType(), pattern);
/*     */       }
/* 724 */       else if (value instanceof String[]) {
/* 725 */         newValue = getLocaleConvertUtils().convert(((String[])value)[0], type.getComponentType(), pattern);
/*     */       }
/*     */       else
/*     */       {
/* 729 */         newValue = value;
/*     */       }
/*     */ 
/*     */     }
/* 733 */     else if (value instanceof String) {
/* 734 */       newValue = getLocaleConvertUtils().convert((String)value, type, pattern);
/*     */     }
/* 736 */     else if (value instanceof String[]) {
/* 737 */       newValue = getLocaleConvertUtils().convert(((String[])value)[0], type, pattern);
/*     */     }
/*     */     else
/*     */     {
/* 741 */       newValue = value;
/*     */     }
/*     */ 
/* 744 */     return newValue;
/*     */   }
/*     */ 
/*     */   protected Object convert(Class type, int index, Object value)
/*     */   {
/* 756 */     Object newValue = null;
/*     */ 
/* 758 */     if ((type.isArray()) && (index < 0)) {
/* 759 */       if (value instanceof String) {
/* 760 */         String[] values = new String[1];
/* 761 */         values[0] = ((String)value);
/* 762 */         newValue = ConvertUtils.convert((String[])values, type);
/*     */       }
/* 764 */       else if (value instanceof String[]) {
/* 765 */         newValue = ConvertUtils.convert((String[])value, type);
/*     */       }
/*     */       else {
/* 768 */         newValue = value;
/*     */       }
/*     */     }
/* 771 */     else if (type.isArray()) {
/* 772 */       if (value instanceof String) {
/* 773 */         newValue = ConvertUtils.convert((String)value, type.getComponentType());
/*     */       }
/* 776 */       else if (value instanceof String[]) {
/* 777 */         newValue = ConvertUtils.convert(((String[])value)[0], type.getComponentType());
/*     */       }
/*     */       else
/*     */       {
/* 781 */         newValue = value;
/*     */       }
/*     */ 
/*     */     }
/* 785 */     else if (value instanceof String) {
/* 786 */       newValue = ConvertUtils.convert((String)value, type);
/*     */     }
/* 788 */     else if (value instanceof String[]) {
/* 789 */       newValue = ConvertUtils.convert(((String[])value)[0], type);
/*     */     }
/*     */     else
/*     */     {
/* 793 */       newValue = value;
/*     */     }
/*     */ 
/* 796 */     return newValue;
/*     */   }
/*     */ 
/*     */   protected void invokeSetter(Object target, String propName, String key, int index, Object newValue)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/*     */     try
/*     */     {
/* 817 */       if (index >= 0) {
/* 818 */         getPropertyUtils().setIndexedProperty(target, propName, index, newValue);
/*     */       }
/* 821 */       else if (key != null) {
/* 822 */         getPropertyUtils().setMappedProperty(target, propName, key, newValue);
/*     */       }
/*     */       else
/*     */       {
/* 826 */         getPropertyUtils().setProperty(target, propName, newValue);
/*     */       }
/*     */     }
/*     */     catch (NoSuchMethodException e) {
/* 830 */       throw new InvocationTargetException(e, "Cannot set " + propName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected Descriptor calculate(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 849 */     String propName = null;
/* 850 */     int index = -1;
/* 851 */     String key = null;
/*     */ 
/* 853 */     Object target = bean;
/* 854 */     int delim = name.lastIndexOf(46);
/* 855 */     if (delim >= 0) {
/*     */       try {
/* 857 */         target = getPropertyUtils().getProperty(bean, name.substring(0, delim));
/*     */       }
/*     */       catch (NoSuchMethodException e)
/*     */       {
/* 861 */         return null;
/*     */       }
/* 863 */       name = name.substring(delim + 1);
/* 864 */       if (log.isTraceEnabled()) {
/* 865 */         log.trace("    Target bean = " + target);
/* 866 */         log.trace("    Target name = " + name);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 871 */     propName = name;
/* 872 */     int i = propName.indexOf(91);
/* 873 */     if (i >= 0) {
/* 874 */       int k = propName.indexOf(93);
/*     */       try {
/* 876 */         index = Integer.parseInt(propName.substring(i + 1, k));
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/*     */       }
/*     */ 
/* 882 */       propName = propName.substring(0, i);
/*     */     }
/* 884 */     int j = propName.indexOf(40);
/* 885 */     if (j >= 0) {
/* 886 */       int k = propName.indexOf(41);
/*     */       try {
/* 888 */         key = propName.substring(j + 1, k);
/*     */       }
/*     */       catch (IndexOutOfBoundsException e)
/*     */       {
/*     */       }
/* 893 */       propName = propName.substring(0, j);
/*     */     }
/* 895 */     return new Descriptor(target, name, propName, key, index);
/*     */   }
/*     */ 
/*     */   protected class Descriptor
/*     */   {
/* 900 */     private int index = -1;
/*     */     private String name;
/*     */     private String propName;
/*     */     private String key;
/*     */     private Object target;
/*     */ 
/*     */     public Descriptor(Object target, String name, String propName, String key, int index)
/*     */     {
/* 908 */       setTarget(target);
/* 909 */       setName(name);
/* 910 */       setPropName(propName);
/* 911 */       setKey(key);
/* 912 */       setIndex(index);
/*     */     }
/*     */ 
/*     */     public Object getTarget() {
/* 916 */       return this.target;
/*     */     }
/*     */ 
/*     */     public void setTarget(Object target) {
/* 920 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public String getKey() {
/* 924 */       return this.key;
/*     */     }
/*     */ 
/*     */     public void setKey(String key) {
/* 928 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public int getIndex() {
/* 932 */       return this.index;
/*     */     }
/*     */ 
/*     */     public void setIndex(int index) {
/* 936 */       this.index = index;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 940 */       return this.name;
/*     */     }
/*     */ 
/*     */     public void setName(String name) {
/* 944 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String getPropName() {
/* 948 */       return this.propName;
/*     */     }
/*     */ 
/*     */     public void setPropName(String propName) {
/* 952 */       this.propName = propName;
/*     */     }
/*     */   }
/*     */ }