package org.apache.commons.beanutils.locale;

import org.apache.commons.beanutils.Converter;

public abstract interface LocaleConverter extends Converter
{
  public abstract Object convert(Class paramClass, Object paramObject, String paramString);
}