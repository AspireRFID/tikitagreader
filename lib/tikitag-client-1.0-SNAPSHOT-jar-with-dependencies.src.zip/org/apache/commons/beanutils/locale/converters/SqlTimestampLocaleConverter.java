/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.sql.Timestamp;
/*     */ import java.text.ParseException;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class SqlTimestampLocaleConverter extends DateLocaleConverter
/*     */ {
/*     */   public SqlTimestampLocaleConverter()
/*     */   {
/*  49 */     this(false);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(boolean locPattern)
/*     */   {
/*  62 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Locale locale)
/*     */   {
/*  74 */     this(locale, (String)null);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  87 */     this(locale, (String)null);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 100 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 114 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue)
/*     */   {
/* 127 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 141 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 154 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 168 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 182 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public SqlTimestampLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 197 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 214 */     return new Timestamp(((Date)super.parse(value, pattern)).getTime());
/*     */   }
/*     */ }