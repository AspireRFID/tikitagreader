/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.locale.BaseLocaleConverter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class StringLocaleConverter extends BaseLocaleConverter
/*     */ {
/*  49 */   private static Log log = LogFactory.getLog(StringLocaleConverter.class);
/*     */ 
/*     */   public StringLocaleConverter()
/*     */   {
/*  64 */     this(false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(boolean locPattern)
/*     */   {
/*  77 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Locale locale)
/*     */   {
/*  89 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/* 102 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 115 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 129 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue)
/*     */   {
/* 143 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 157 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 170 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 184 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 198 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public StringLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 213 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 230 */     String result = null;
/*     */ 
/* 232 */     if ((value instanceof Integer) || (value instanceof Long) || (value instanceof BigInteger) || (value instanceof Byte) || (value instanceof Short))
/*     */     {
/* 238 */       result = getDecimalFormat(this.jdField_locale_of_type_JavaUtilLocale, pattern).format(((Number)value).longValue());
/*     */     }
/* 240 */     else if ((value instanceof Double) || (value instanceof BigDecimal) || (value instanceof Float))
/*     */     {
/* 244 */       result = getDecimalFormat(this.jdField_locale_of_type_JavaUtilLocale, pattern).format(((Number)value).doubleValue());
/*     */     }
/* 246 */     else if (value instanceof Date)
/*     */     {
/* 248 */       SimpleDateFormat dateFormat = new SimpleDateFormat(pattern, this.jdField_locale_of_type_JavaUtilLocale);
/*     */ 
/* 251 */       result = dateFormat.format(value);
/*     */     }
/*     */     else {
/* 254 */       result = value.toString();
/*     */     }
/*     */ 
/* 257 */     return result;
/*     */   }
/*     */ 
/*     */   private DecimalFormat getDecimalFormat(Locale locale, String pattern)
/*     */   {
/* 271 */     DecimalFormat numberFormat = (DecimalFormat)NumberFormat.getInstance(locale);
/*     */ 
/* 274 */     if (pattern != null) {
/* 275 */       if (this.locPattern)
/* 276 */         numberFormat.applyLocalizedPattern(pattern);
/*     */       else
/* 278 */         numberFormat.applyPattern(pattern);
/*     */     }
/*     */     else {
/* 281 */       log.warn("No pattern provided, using default.");
/*     */     }
/*     */ 
/* 284 */     return numberFormat;
/*     */   }
/*     */ }