/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class SqlDateLocaleConverter extends DateLocaleConverter
/*     */ {
/*     */   public SqlDateLocaleConverter()
/*     */   {
/*  49 */     this(false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(boolean locPattern)
/*     */   {
/*  62 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Locale locale)
/*     */   {
/*  74 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  87 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 100 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 114 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue)
/*     */   {
/* 128 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 142 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 155 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 169 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 183 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public SqlDateLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 198 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 216 */     return new java.sql.Date(((java.util.Date)super.parse((String)value, pattern)).getTime());
/*     */   }
/*     */ }