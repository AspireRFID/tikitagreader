/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class DoubleLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public DoubleLocaleConverter()
/*     */   {
/*  50 */     this(false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(boolean locPattern)
/*     */   {
/*  63 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Locale locale)
/*     */   {
/*  75 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  88 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 101 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 115 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue)
/*     */   {
/* 129 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 143 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 156 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 170 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 184 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DoubleLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 199 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern) throws ParseException {
/* 203 */     Number result = (Number)super.parse(value, pattern);
/* 204 */     if (result instanceof Long) {
/* 205 */       return new Double(result.doubleValue());
/*     */     }
/* 207 */     return result;
/*     */   }
/*     */ }