/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.locale.BaseLocaleConverter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DecimalLocaleConverter extends BaseLocaleConverter
/*     */ {
/*  47 */   private static Log log = LogFactory.getLog(DecimalLocaleConverter.class);
/*     */ 
/*     */   public DecimalLocaleConverter()
/*     */   {
/*  61 */     this(false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(boolean locPattern)
/*     */   {
/*  74 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Locale locale)
/*     */   {
/*  86 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  99 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 112 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 126 */     this(null, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue)
/*     */   {
/* 140 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 154 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 167 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 181 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 195 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DecimalLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 210 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 228 */     DecimalFormat formatter = (DecimalFormat)DecimalFormat.getInstance(this.locale);
/*     */ 
/* 230 */     if (pattern != null) {
/* 231 */       if (this.locPattern)
/* 232 */         formatter.applyLocalizedPattern(pattern);
/*     */       else
/* 234 */         formatter.applyPattern(pattern);
/*     */     }
/*     */     else {
/* 237 */       log.warn("No pattern provided, using default.");
/*     */     }
/*     */ 
/* 240 */     return formatter.parse((String)value);
/*     */   }
/*     */ }