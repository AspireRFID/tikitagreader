/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class LongLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public LongLocaleConverter()
/*     */   {
/*  48 */     this(false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(boolean locPattern)
/*     */   {
/*  61 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Locale locale)
/*     */   {
/*  73 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  86 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Locale locale, String pattern)
/*     */   {
/*  99 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 113 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue)
/*     */   {
/* 127 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 141 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 154 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 168 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 182 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public LongLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 197 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ }