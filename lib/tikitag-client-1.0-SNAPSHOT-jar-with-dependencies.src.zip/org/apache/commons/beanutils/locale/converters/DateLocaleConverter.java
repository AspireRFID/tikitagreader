/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.locale.BaseLocaleConverter;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class DateLocaleConverter extends BaseLocaleConverter
/*     */ {
/*  46 */   private static Log log = LogFactory.getLog(DateLocaleConverter.class);
/*     */   boolean isLenient;
/*     */ 
/*     */   public DateLocaleConverter()
/*     */   {
/*  63 */     this(false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(boolean locPattern)
/*     */   {
/*  76 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Locale locale)
/*     */   {
/*  88 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/* 101 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 114 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 128 */     super(locale, pattern, locPattern);
/*     */ 
/*  49 */     this.isLenient = false;
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue)
/*     */   {
/* 142 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 156 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 169 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 183 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 198 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public DateLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 213 */     super(defaultValue, locale, pattern, locPattern);
/*     */ 
/*  49 */     this.isLenient = false;
/*     */   }
/*     */ 
/*     */   public boolean isLenient()
/*     */   {
/* 225 */     return this.isLenient;
/*     */   }
/*     */ 
/*     */   public void setLenient(boolean lenient)
/*     */   {
/* 235 */     this.isLenient = lenient;
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 251 */     SimpleDateFormat formatter = getFormatter(pattern, this.locale);
/* 252 */     if (this.jdField_locPattern_of_type_Boolean) {
/* 253 */       formatter.applyLocalizedPattern(pattern);
/*     */     }
/*     */     else {
/* 256 */       formatter.applyPattern(pattern);
/*     */     }
/* 258 */     return formatter.parse((String)value);
/*     */   }
/*     */ 
/*     */   private SimpleDateFormat getFormatter(String pattern, Locale locale)
/*     */   {
/* 270 */     if (pattern == null) {
/* 271 */       pattern = (this.jdField_locPattern_of_type_Boolean) ? new SimpleDateFormat().toLocalizedPattern() : new SimpleDateFormat().toPattern();
/*     */ 
/* 273 */       log.warn("Null pattern was provided, defaulting to: " + pattern);
/*     */     }
/* 275 */     SimpleDateFormat format = new SimpleDateFormat(pattern, locale);
/* 276 */     format.setLenient(this.isLenient);
/* 277 */     return format;
/*     */   }
/*     */ }