/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public class FloatLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public FloatLocaleConverter()
/*     */   {
/*  51 */     this(false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(boolean locPattern)
/*     */   {
/*  64 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Locale locale)
/*     */   {
/*  76 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  89 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 102 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 116 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue)
/*     */   {
/* 130 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 144 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 157 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 171 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 185 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public FloatLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 200 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 215 */     Number parsed = (Number)super.parse(value, pattern);
/* 216 */     if (Math.abs(parsed.doubleValue() - parsed.floatValue()) > parsed.floatValue() * 1.E-005D) {
/* 217 */       throw new ConversionException("Suplied number is not of type Float: " + parsed.longValue());
/*     */     }
/* 219 */     return new Float(parsed.floatValue());
/*     */   }
/*     */ }