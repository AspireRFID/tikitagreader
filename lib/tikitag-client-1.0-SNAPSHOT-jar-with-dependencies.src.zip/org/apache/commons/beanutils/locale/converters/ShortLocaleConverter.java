/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class ShortLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public ShortLocaleConverter()
/*     */   {
/*  47 */     this(false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(boolean locPattern)
/*     */   {
/*  60 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Locale locale)
/*     */   {
/*  72 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  85 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Locale locale, String pattern)
/*     */   {
/*  98 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 112 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue)
/*     */   {
/* 126 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 140 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 153 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 167 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 181 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public ShortLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 196 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ }