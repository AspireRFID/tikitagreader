/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class BigDecimalLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public BigDecimalLocaleConverter()
/*     */   {
/*  47 */     this(false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(boolean locPattern)
/*     */   {
/*  60 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Locale locale)
/*     */   {
/*  72 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  85 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Locale locale, String pattern)
/*     */   {
/*  98 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 112 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue)
/*     */   {
/* 126 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 140 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 153 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 167 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 181 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public BigDecimalLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 196 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ }