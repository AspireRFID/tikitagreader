/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public class IntegerLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public IntegerLocaleConverter()
/*     */   {
/*  52 */     this(false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(boolean locPattern)
/*     */   {
/*  65 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Locale locale)
/*     */   {
/*  77 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  90 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 103 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 117 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue)
/*     */   {
/* 131 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 145 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 158 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 172 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 186 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public IntegerLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 201 */     super(defaultValue, locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 215 */     Number parsed = (Number)super.parse(value, pattern);
/* 216 */     if (parsed.longValue() != parsed.intValue()) {
/* 217 */       throw new ConversionException("Suplied number is not of type Integer: " + parsed.longValue());
/*     */     }
/* 219 */     return new Integer(parsed.intValue());
/*     */   }
/*     */ }