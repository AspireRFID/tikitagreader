/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.text.ParseException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.ConversionException;
/*     */ 
/*     */ public class ByteLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public ByteLocaleConverter()
/*     */   {
/*  51 */     this(false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(boolean locPattern)
/*     */   {
/*  64 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Locale locale)
/*     */   {
/*  76 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  89 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Locale locale, String pattern)
/*     */   {
/* 102 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 116 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue)
/*     */   {
/* 130 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 144 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 157 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 171 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 185 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public ByteLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 200 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ 
/*     */   protected Object parse(Object value, String pattern)
/*     */     throws ParseException
/*     */   {
/* 214 */     Number parsed = (Number)super.parse(value, pattern);
/* 215 */     if (parsed.longValue() != parsed.byteValue()) {
/* 216 */       throw new ConversionException("Supplied number is not of type Byte: " + parsed.longValue());
/*     */     }
/*     */ 
/* 219 */     return new Byte(parsed.byteValue());
/*     */   }
/*     */ }