/*     */ package org.apache.commons.beanutils.locale.converters;
/*     */ 
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class BigIntegerLocaleConverter extends DecimalLocaleConverter
/*     */ {
/*     */   public BigIntegerLocaleConverter()
/*     */   {
/*  47 */     this(false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(boolean locPattern)
/*     */   {
/*  60 */     this(Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Locale locale)
/*     */   {
/*  72 */     this(locale, false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Locale locale, boolean locPattern)
/*     */   {
/*  85 */     this(locale, (String)null, locPattern);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Locale locale, String pattern)
/*     */   {
/*  98 */     this(locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 112 */     super(locale, pattern, locPattern);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue)
/*     */   {
/* 126 */     this(defaultValue, false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue, boolean locPattern)
/*     */   {
/* 140 */     this(defaultValue, Locale.getDefault(), locPattern);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue, Locale locale)
/*     */   {
/* 153 */     this(defaultValue, locale, false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue, Locale locale, boolean locPattern)
/*     */   {
/* 167 */     this(defaultValue, locale, null, locPattern);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue, Locale locale, String pattern)
/*     */   {
/* 181 */     this(defaultValue, locale, pattern, false);
/*     */   }
/*     */ 
/*     */   public BigIntegerLocaleConverter(Object defaultValue, Locale locale, String pattern, boolean locPattern)
/*     */   {
/* 196 */     super(defaultValue, locale, pattern);
/*     */   }
/*     */ }