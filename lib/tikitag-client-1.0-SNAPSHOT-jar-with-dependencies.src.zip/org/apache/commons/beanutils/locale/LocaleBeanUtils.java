/*     */ package org.apache.commons.beanutils.locale;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LocaleBeanUtils extends BeanUtils
/*     */ {
/*  51 */   private static Log log = LogFactory.getLog(LocaleBeanUtils.class);
/*     */ 
/*     */   public static Locale getDefaultLocale()
/*     */   {
/*  62 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getDefaultLocale();
/*     */   }
/*     */ 
/*     */   public static void setDefaultLocale(Locale locale)
/*     */   {
/*  75 */     LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().setDefaultLocale(locale);
/*     */   }
/*     */ 
/*     */   public static boolean getApplyLocalized()
/*     */   {
/*  87 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getApplyLocalized();
/*     */   }
/*     */ 
/*     */   public static void setApplyLocalized(boolean newApplyLocalized)
/*     */   {
/*  99 */     LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().setApplyLocalized(newApplyLocalized);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 117 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getIndexedProperty(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 133 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getIndexedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name, int index, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 149 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getIndexedProperty(bean, name, index, pattern);
/*     */   }
/*     */ 
/*     */   public static String getIndexedProperty(Object bean, String name, int index)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 165 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getIndexedProperty(bean, name, index);
/*     */   }
/*     */ 
/*     */   public static String getSimpleProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 181 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getSimpleProperty(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public static String getSimpleProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 197 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getSimpleProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getMappedProperty(Object bean, String name, String key, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 213 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getMappedProperty(bean, name, key, pattern);
/*     */   }
/*     */ 
/*     */   public static String getMappedProperty(Object bean, String name, String key)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 231 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getMappedProperty(bean, name, key);
/*     */   }
/*     */ 
/*     */   public static String getMappedPropertyLocale(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 247 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getMappedPropertyLocale(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public static String getMappedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 264 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getMappedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getNestedProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 280 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getNestedProperty(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public static String getNestedProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 295 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getNestedProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static String getProperty(Object bean, String name, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 310 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getProperty(bean, name, pattern);
/*     */   }
/*     */ 
/*     */   public static String getProperty(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*     */   {
/* 325 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().getProperty(bean, name);
/*     */   }
/*     */ 
/*     */   public static void setProperty(Object bean, String name, Object value)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 340 */     LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().setProperty(bean, name, value);
/*     */   }
/*     */ 
/*     */   public static void setProperty(Object bean, String name, Object value, String pattern)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 355 */     LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().setProperty(bean, name, value, pattern);
/*     */   }
/*     */ 
/*     */   protected static Class definePropertyType(Object target, String name, String propName)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 368 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().definePropertyType(target, name, propName);
/*     */   }
/*     */ 
/*     */   protected static Object convert(Class type, int index, Object value, String pattern)
/*     */   {
/* 381 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().convert(type, index, value, pattern);
/*     */   }
/*     */ 
/*     */   protected static Object convert(Class type, int index, Object value)
/*     */   {
/* 393 */     return LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().convert(type, index, value);
/*     */   }
/*     */ 
/*     */   protected static void invokeSetter(Object target, String propName, String key, int index, Object newValue)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 406 */     LocaleBeanUtilsBean.getLocaleBeanUtilsInstance().invokeSetter(target, propName, key, index, newValue);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   protected static Descriptor calculate(Object bean, String name)
/*     */     throws IllegalAccessException, InvocationTargetException
/*     */   {
/* 424 */     String propName = null;
/* 425 */     int index = -1;
/* 426 */     String key = null;
/*     */ 
/* 428 */     Object target = bean;
/* 429 */     int delim = name.lastIndexOf(46);
/* 430 */     if (delim >= 0) {
/*     */       try {
/* 432 */         target = PropertyUtils.getProperty(bean, name.substring(0, delim));
/*     */       }
/*     */       catch (NoSuchMethodException e)
/*     */       {
/* 436 */         return null;
/*     */       }
/* 438 */       name = name.substring(delim + 1);
/* 439 */       if (log.isTraceEnabled()) {
/* 440 */         log.trace("    Target bean = " + target);
/* 441 */         log.trace("    Target name = " + name);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 446 */     propName = name;
/* 447 */     int i = propName.indexOf(91);
/* 448 */     if (i >= 0) {
/* 449 */       int k = propName.indexOf(93);
/*     */       try {
/* 451 */         index = Integer.parseInt(propName.substring(i + 1, k));
/*     */       }
/*     */       catch (NumberFormatException e)
/*     */       {
/*     */       }
/*     */ 
/* 457 */       propName = propName.substring(0, i);
/*     */     }
/* 459 */     int j = propName.indexOf(40);
/* 460 */     if (j >= 0) {
/* 461 */       int k = propName.indexOf(41);
/*     */       try {
/* 463 */         key = propName.substring(j + 1, k);
/*     */       }
/*     */       catch (IndexOutOfBoundsException e)
/*     */       {
/*     */       }
/* 468 */       propName = propName.substring(0, j);
/*     */     }
/* 470 */     return new Descriptor(target, name, propName, key, index);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   protected static class Descriptor
/*     */   {
/* 476 */     private int index = -1;
/*     */     private String name;
/*     */     private String propName;
/*     */     private String key;
/*     */     private Object target;
/*     */ 
/*     */     public Descriptor(Object target, String name, String propName, String key, int index)
/*     */     {
/* 484 */       setTarget(target);
/* 485 */       setName(name);
/* 486 */       setPropName(propName);
/* 487 */       setKey(key);
/* 488 */       setIndex(index);
/*     */     }
/*     */ 
/*     */     public Object getTarget() {
/* 492 */       return this.target;
/*     */     }
/*     */ 
/*     */     public void setTarget(Object target) {
/* 496 */       this.target = target;
/*     */     }
/*     */ 
/*     */     public String getKey() {
/* 500 */       return this.key;
/*     */     }
/*     */ 
/*     */     public void setKey(String key) {
/* 504 */       this.key = key;
/*     */     }
/*     */ 
/*     */     public int getIndex() {
/* 508 */       return this.index;
/*     */     }
/*     */ 
/*     */     public void setIndex(int index) {
/* 512 */       this.index = index;
/*     */     }
/*     */ 
/*     */     public String getName() {
/* 516 */       return this.name;
/*     */     }
/*     */ 
/*     */     public void setName(String name) {
/* 520 */       this.name = name;
/*     */     }
/*     */ 
/*     */     public String getPropName() {
/* 524 */       return this.propName;
/*     */     }
/*     */ 
/*     */     public void setPropName(String propName) {
/* 528 */       this.propName = propName;
/*     */     }
/*     */   }
/*     */ }