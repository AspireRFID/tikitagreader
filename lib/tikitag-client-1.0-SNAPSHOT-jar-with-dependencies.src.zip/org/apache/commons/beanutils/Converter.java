package org.apache.commons.beanutils;

public abstract interface Converter
{
  public abstract Object convert(Class paramClass, Object paramObject);
}