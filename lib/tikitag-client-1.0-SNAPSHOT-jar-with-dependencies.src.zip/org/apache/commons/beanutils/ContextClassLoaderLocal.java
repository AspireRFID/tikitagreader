/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.util.Map;
/*     */ import java.util.WeakHashMap;
/*     */ 
/*     */ public class ContextClassLoaderLocal
/*     */ {
/*  34 */   private Map valueByClassLoader = new WeakHashMap();
/*  35 */   private boolean globalValueInitialized = false;
/*     */   private Object globalValue;
/*     */ 
/*     */   protected Object initialValue()
/*     */   {
/*  56 */     return null;
/*     */   }
/*     */ 
/*     */   public synchronized Object get()
/*     */   {
/*  71 */     this.valueByClassLoader.isEmpty();
/*     */     try
/*     */     {
/*  74 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/*  75 */       if (contextClassLoader != null)
/*     */       {
/*  77 */         Object value = this.valueByClassLoader.get(contextClassLoader);
/*  78 */         if ((value == null) && (!(this.valueByClassLoader.containsKey(contextClassLoader))))
/*     */         {
/*  80 */           value = initialValue();
/*  81 */           this.valueByClassLoader.put(contextClassLoader, value);
/*     */         }
/*  83 */         return value;
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */ 
/*  90 */     if (!(this.globalValueInitialized)) {
/*  91 */       this.globalValue = initialValue();
/*  92 */       this.globalValueInitialized = true;
/*     */     }
/*  94 */     return this.globalValue;
/*     */   }
/*     */ 
/*     */   public synchronized void set(Object value)
/*     */   {
/* 108 */     this.valueByClassLoader.isEmpty();
/*     */     try
/*     */     {
/* 111 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 112 */       if (contextClassLoader != null) {
/* 113 */         this.valueByClassLoader.put(contextClassLoader, value);
/* 114 */         return;
/*     */       }
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/* 120 */     this.globalValue = value;
/* 121 */     this.globalValueInitialized = true;
/*     */   }
/*     */ 
/*     */   public synchronized void unset()
/*     */   {
/*     */     try
/*     */     {
/* 130 */       ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
/* 131 */       unset(contextClassLoader);
/*     */     }
/*     */     catch (SecurityException e)
/*     */     {
/*     */     }
/*     */   }
/*     */ 
/*     */   public synchronized void unset(ClassLoader classLoader)
/*     */   {
/* 140 */     this.valueByClassLoader.remove(classLoader);
/*     */   }
/*     */ }