/*      */ package org.apache.commons.beanutils;
/*      */ 
/*      */ import java.beans.IndexedPropertyDescriptor;
/*      */ import java.beans.PropertyDescriptor;
/*      */ import java.lang.reflect.Array;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collection;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Map;
/*      */ import java.util.Set;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ 
/*      */ public class BeanUtilsBean
/*      */ {
/*   65 */   private static final ContextClassLoaderLocal beansByClassLoader = new ContextClassLoaderLocal()
/*      */   {
/*      */     protected Object initialValue() {
/*   68 */       return new BeanUtilsBean();
/*      */     }
/*   65 */   };
/*      */   private Log log;
/*      */   private ConvertUtilsBean convertUtilsBean;
/*      */   private PropertyUtilsBean propertyUtilsBean;
/*      */ 
/*      */   public static synchronized BeanUtilsBean getInstance()
/*      */   {
/*   78 */     return ((BeanUtilsBean)beansByClassLoader.get());
/*      */   }
/*      */ 
/*      */   public static synchronized void setInstance(BeanUtilsBean newInstance)
/*      */   {
/*   87 */     beansByClassLoader.set(newInstance);
/*      */   }
/*      */ 
/*      */   public BeanUtilsBean()
/*      */   {
/*  110 */     this(new ConvertUtilsBean(), new PropertyUtilsBean());
/*      */   }
/*      */ 
/*      */   public BeanUtilsBean(ConvertUtilsBean convertUtilsBean, PropertyUtilsBean propertyUtilsBean)
/*      */   {
/*   95 */     this.log = LogFactory.getLog(BeanUtils.class);
/*      */ 
/*  125 */     this.convertUtilsBean = convertUtilsBean;
/*  126 */     this.propertyUtilsBean = propertyUtilsBean;
/*      */   }
/*      */ 
/*      */   public Object cloneBean(Object bean)
/*      */     throws IllegalAccessException, InstantiationException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  156 */     if (this.log.isDebugEnabled()) {
/*  157 */       this.log.debug("Cloning bean: " + bean.getClass().getName());
/*      */     }
/*  159 */     Class clazz = bean.getClass();
/*  160 */     Object newBean = null;
/*  161 */     if (bean instanceof DynaBean)
/*  162 */       newBean = ((DynaBean)bean).getDynaClass().newInstance();
/*      */     else {
/*  164 */       newBean = bean.getClass().newInstance();
/*      */     }
/*  166 */     getPropertyUtils().copyProperties(newBean, bean);
/*  167 */     return newBean;
/*      */   }
/*      */ 
/*      */   public void copyProperties(Object dest, Object orig)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*      */     int i;
/*      */     String name;
/*      */     Object value;
/*  216 */     if (dest == null) {
/*  217 */       throw new IllegalArgumentException("No destination bean specified");
/*      */     }
/*      */ 
/*  220 */     if (orig == null) {
/*  221 */       throw new IllegalArgumentException("No origin bean specified");
/*      */     }
/*  223 */     if (this.log.isDebugEnabled()) {
/*  224 */       this.log.debug("BeanUtils.copyProperties(" + dest + ", " + orig + ")");
/*      */     }
/*      */ 
/*  229 */     if (orig instanceof DynaBean) {
/*  230 */       DynaProperty[] origDescriptors = ((DynaBean)orig).getDynaClass().getDynaProperties();
/*      */ 
/*  232 */       for (i = 0; i < origDescriptors.length; ++i) {
/*  233 */         name = origDescriptors[i].getName();
/*  234 */         if (getPropertyUtils().isWriteable(dest, name)) {
/*  235 */           value = ((DynaBean)orig).get(name);
/*  236 */           copyProperty(dest, name, value);
/*      */         }
/*      */       }
/*  239 */     } else if (orig instanceof Map) {
/*  240 */       Iterator names = ((Map)orig).keySet().iterator();
/*  241 */       while (names.hasNext()) {
/*  242 */         String name = (String)names.next();
/*  243 */         if (getPropertyUtils().isWriteable(dest, name)) {
/*  244 */           Object value = ((Map)orig).get(name);
/*  245 */           copyProperty(dest, name, value);
/*      */         }
/*      */       }
/*      */     } else {
/*  249 */       PropertyDescriptor[] origDescriptors = getPropertyUtils().getPropertyDescriptors(orig);
/*      */ 
/*  251 */       for (i = 0; i < origDescriptors.length; ++i) {
/*  252 */         name = origDescriptors[i].getName();
/*  253 */         if ("class".equals(name)) {
/*      */           continue;
/*      */         }
/*  256 */         if ((!(getPropertyUtils().isReadable(orig, name))) || (!(getPropertyUtils().isWriteable(dest, name))))
/*      */           continue;
/*      */         try {
/*  259 */           value = getPropertyUtils().getSimpleProperty(orig, name);
/*      */ 
/*  261 */           copyProperty(dest, name, value);
/*      */         }
/*      */         catch (NoSuchMethodException e)
/*      */         {
/*      */         }
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public void copyProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*      */     Converter converter;
/*  307 */     if (this.log.isTraceEnabled()) {
/*  308 */       StringBuffer sb = new StringBuffer("  copyProperty(");
/*  309 */       sb.append(bean);
/*  310 */       sb.append(", ");
/*  311 */       sb.append(name);
/*  312 */       sb.append(", ");
/*  313 */       if (value == null) {
/*  314 */         sb.append("<NULL>");
/*  315 */       } else if (value instanceof String) {
/*  316 */         sb.append((String)value);
/*  317 */       } else if (value instanceof String[]) {
/*  318 */         String[] values = (String[])value;
/*  319 */         sb.append('[');
/*  320 */         for (int i = 0; i < values.length; ++i) {
/*  321 */           if (i > 0) {
/*  322 */             sb.append(',');
/*      */           }
/*  324 */           sb.append(values[i]);
/*      */         }
/*  326 */         sb.append(']');
/*      */       } else {
/*  328 */         sb.append(value.toString());
/*      */       }
/*  330 */       sb.append(')');
/*  331 */       this.log.trace(sb.toString());
/*      */     }
/*      */ 
/*  335 */     Object target = bean;
/*  336 */     int delim = name.lastIndexOf(46);
/*  337 */     if (delim >= 0) {
/*      */       try {
/*  339 */         target = getPropertyUtils().getProperty(bean, name.substring(0, delim));
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  342 */         return;
/*      */       }
/*  344 */       name = name.substring(delim + 1);
/*  345 */       if (this.log.isTraceEnabled()) {
/*  346 */         this.log.trace("    Target bean = " + target);
/*  347 */         this.log.trace("    Target name = " + name);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  352 */     String propName = null;
/*  353 */     Class type = null;
/*  354 */     int index = -1;
/*  355 */     String key = null;
/*      */ 
/*  358 */     propName = name;
/*  359 */     int i = propName.indexOf(91);
/*  360 */     if (i >= 0) {
/*  361 */       int k = propName.indexOf(93);
/*      */       try {
/*  363 */         index = Integer.parseInt(propName.substring(i + 1, k));
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*  368 */       propName = propName.substring(0, i);
/*      */     }
/*  370 */     int j = propName.indexOf(40);
/*  371 */     if (j >= 0) {
/*  372 */       int k = propName.indexOf(41);
/*      */       try {
/*  374 */         key = propName.substring(j + 1, k);
/*      */       }
/*      */       catch (IndexOutOfBoundsException e) {
/*      */       }
/*  378 */       propName = propName.substring(0, j);
/*      */     }
/*      */ 
/*  382 */     if (target instanceof DynaBean) {
/*  383 */       DynaClass dynaClass = ((DynaBean)target).getDynaClass();
/*  384 */       DynaProperty dynaProperty = dynaClass.getDynaProperty(propName);
/*  385 */       if (dynaProperty == null) {
/*  386 */         return;
/*      */       }
/*  388 */       type = dynaProperty.getType();
/*      */     } else {
/*  390 */       PropertyDescriptor descriptor = null;
/*      */       try {
/*  392 */         descriptor = getPropertyUtils().getPropertyDescriptor(target, name);
/*      */ 
/*  394 */         if (descriptor == null)
/*  395 */           return;
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  398 */         return;
/*      */       }
/*  400 */       type = descriptor.getPropertyType();
/*  401 */       if (type == null)
/*      */       {
/*  403 */         if (this.log.isTraceEnabled()) {
/*  404 */           this.log.trace("    target type for property '" + propName + "' is null, so skipping ths setter");
/*      */         }
/*      */ 
/*  407 */         return;
/*      */       }
/*      */     }
/*  410 */     if (this.log.isTraceEnabled()) {
/*  411 */       this.log.trace("    target propName=" + propName + ", type=" + type + ", index=" + index + ", key=" + key);
/*      */     }
/*      */ 
/*  416 */     if (index >= 0) {
/*  417 */       converter = getConvertUtils().lookup(type.getComponentType());
/*  418 */       if (converter != null) {
/*  419 */         this.log.trace("        USING CONVERTER " + converter);
/*  420 */         value = converter.convert(type, value);
/*      */       }
/*      */       try {
/*  423 */         getPropertyUtils().setIndexedProperty(target, propName, index, value);
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  426 */         throw new InvocationTargetException(e, "Cannot set " + propName);
/*      */       }
/*      */     }
/*  429 */     else if (key != null)
/*      */     {
/*      */       try
/*      */       {
/*  434 */         getPropertyUtils().setMappedProperty(target, propName, key, value);
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  437 */         throw new InvocationTargetException(e, "Cannot set " + propName);
/*      */       }
/*      */     }
/*      */     else {
/*  441 */       converter = getConvertUtils().lookup(type);
/*  442 */       if (converter != null) {
/*  443 */         this.log.trace("        USING CONVERTER " + converter);
/*  444 */         value = converter.convert(type, value);
/*      */       }
/*      */       try {
/*  447 */         getPropertyUtils().setSimpleProperty(target, propName, value);
/*      */       } catch (NoSuchMethodException e) {
/*  449 */         throw new InvocationTargetException(e, "Cannot set " + propName);
/*      */       }
/*      */     }
/*      */   }
/*      */ 
/*      */   public Map describe(Object bean)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*      */     int i;
/*      */     String name;
/*  481 */     if (bean == null)
/*      */     {
/*  483 */       return new HashMap();
/*      */     }
/*      */ 
/*  486 */     if (this.log.isDebugEnabled()) {
/*  487 */       this.log.debug("Describing bean: " + bean.getClass().getName());
/*      */     }
/*      */ 
/*  490 */     Map description = new HashMap();
/*  491 */     if (bean instanceof DynaBean) {
/*  492 */       DynaProperty[] descriptors = ((DynaBean)bean).getDynaClass().getDynaProperties();
/*      */ 
/*  494 */       for (i = 0; i < descriptors.length; ++i) {
/*  495 */         name = descriptors[i].getName();
/*  496 */         description.put(name, getProperty(bean, name));
/*      */       }
/*      */     } else {
/*  499 */       PropertyDescriptor[] descriptors = getPropertyUtils().getPropertyDescriptors(bean);
/*      */ 
/*  501 */       for (i = 0; i < descriptors.length; ++i) {
/*  502 */         name = descriptors[i].getName();
/*  503 */         if (descriptors[i].getReadMethod() != null)
/*  504 */           description.put(name, getProperty(bean, name));
/*      */       }
/*      */     }
/*  507 */     return description;
/*      */   }
/*      */ 
/*      */   public String[] getArrayProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  530 */     Object value = getPropertyUtils().getProperty(bean, name);
/*  531 */     if (value == null)
/*  532 */       return null;
/*  533 */     if (value instanceof Collection) {
/*  534 */       ArrayList values = new ArrayList();
/*  535 */       Iterator items = ((Collection)value).iterator();
/*  536 */       break label88:
/*      */       while (true) { Object item = items.next();
/*  538 */         if (item == null) {
/*  539 */           values.add((String)null);
/*      */         }
/*      */         else
/*  542 */           values.add(getConvertUtils().convert(item));
/*  536 */         if (!(items.hasNext()))
/*      */         {
/*  545 */           label88: return ((String[])values.toArray(new String[values.size()])); } } }
/*  546 */     if (value.getClass().isArray()) {
/*  547 */       int n = Array.getLength(value);
/*  548 */       String[] results = new String[n];
/*  549 */       int i = 0; break label183:
/*      */       while (true) { Object item = Array.get(value, i);
/*  551 */         if (item == null) {
/*  552 */           results[i] = null;
/*      */         }
/*      */         else
/*  555 */           results[i] = getConvertUtils().convert(item);
/*  549 */         ++i; if (i >= n)
/*      */         {
/*  558 */           label183: return results; } }
/*      */     }
/*  560 */     String[] results = new String[1];
/*  561 */     results[0] = value.toString();
/*  562 */     return results;
/*      */   }
/*      */ 
/*      */   public String getIndexedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  590 */     Object value = getPropertyUtils().getIndexedProperty(bean, name);
/*  591 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public String getIndexedProperty(Object bean, String name, int index)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  617 */     Object value = getPropertyUtils().getIndexedProperty(bean, name, index);
/*  618 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public String getMappedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  645 */     Object value = getPropertyUtils().getMappedProperty(bean, name);
/*  646 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public String getMappedProperty(Object bean, String name, String key)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  672 */     Object value = getPropertyUtils().getMappedProperty(bean, name, key);
/*  673 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public String getNestedProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  698 */     Object value = getPropertyUtils().getNestedProperty(bean, name);
/*  699 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public String getProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  723 */     return getNestedProperty(bean, name);
/*      */   }
/*      */ 
/*      */   public String getSimpleProperty(Object bean, String name)
/*      */     throws IllegalAccessException, InvocationTargetException, NoSuchMethodException
/*      */   {
/*  746 */     Object value = getPropertyUtils().getSimpleProperty(bean, name);
/*  747 */     return getConvertUtils().convert(value);
/*      */   }
/*      */ 
/*      */   public void populate(Object bean, Map properties)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*  791 */     if ((bean == null) || (properties == null)) {
/*  792 */       return;
/*      */     }
/*  794 */     if (this.log.isDebugEnabled()) {
/*  795 */       this.log.debug("BeanUtils.populate(" + bean + ", " + properties + ")");
/*      */     }
/*      */ 
/*  800 */     Iterator names = properties.keySet().iterator();
/*  801 */     while (names.hasNext())
/*      */     {
/*  804 */       String name = (String)names.next();
/*  805 */       if (name == null) {
/*      */         continue;
/*      */       }
/*  808 */       Object value = properties.get(name);
/*      */ 
/*  811 */       setProperty(bean, name, value);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void setProperty(Object bean, String name, Object value)
/*      */     throws IllegalAccessException, InvocationTargetException
/*      */   {
/*  852 */     if (this.log.isTraceEnabled()) {
/*  853 */       StringBuffer sb = new StringBuffer("  setProperty(");
/*  854 */       sb.append(bean);
/*  855 */       sb.append(", ");
/*  856 */       sb.append(name);
/*  857 */       sb.append(", ");
/*  858 */       if (value == null) {
/*  859 */         sb.append("<NULL>");
/*  860 */       } else if (value instanceof String) {
/*  861 */         sb.append((String)value);
/*  862 */       } else if (value instanceof String[]) {
/*  863 */         String[] values = (String[])value;
/*  864 */         sb.append('[');
/*  865 */         for (int i = 0; i < values.length; ++i) {
/*  866 */           if (i > 0) {
/*  867 */             sb.append(',');
/*      */           }
/*  869 */           sb.append(values[i]);
/*      */         }
/*  871 */         sb.append(']');
/*      */       } else {
/*  873 */         sb.append(value.toString());
/*      */       }
/*  875 */       sb.append(')');
/*  876 */       this.log.trace(sb.toString());
/*      */     }
/*      */ 
/*  880 */     Object target = bean;
/*  881 */     int delim = findLastNestedIndex(name);
/*  882 */     if (delim >= 0) {
/*      */       try {
/*  884 */         target = getPropertyUtils().getProperty(bean, name.substring(0, delim));
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  887 */         return;
/*      */       }
/*  889 */       name = name.substring(delim + 1);
/*  890 */       if (this.log.isTraceEnabled()) {
/*  891 */         this.log.trace("    Target bean = " + target);
/*  892 */         this.log.trace("    Target name = " + name);
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  897 */     String propName = null;
/*  898 */     Class type = null;
/*  899 */     int index = -1;
/*  900 */     String key = null;
/*      */ 
/*  903 */     propName = name;
/*  904 */     int i = propName.indexOf(91);
/*  905 */     if (i >= 0) {
/*  906 */       int k = propName.indexOf(93);
/*      */       try {
/*  908 */         index = Integer.parseInt(propName.substring(i + 1, k));
/*      */       }
/*      */       catch (NumberFormatException e)
/*      */       {
/*      */       }
/*  913 */       propName = propName.substring(0, i);
/*      */     }
/*  915 */     int j = propName.indexOf(40);
/*  916 */     if (j >= 0) {
/*  917 */       int k = propName.indexOf(41);
/*      */       try {
/*  919 */         key = propName.substring(j + 1, k);
/*      */       }
/*      */       catch (IndexOutOfBoundsException e) {
/*      */       }
/*  923 */       propName = propName.substring(0, j);
/*      */     }
/*      */ 
/*  927 */     if (target instanceof DynaBean) {
/*  928 */       DynaClass dynaClass = ((DynaBean)target).getDynaClass();
/*  929 */       DynaProperty dynaProperty = dynaClass.getDynaProperty(propName);
/*  930 */       if (dynaProperty == null) {
/*  931 */         return;
/*      */       }
/*  933 */       type = dynaProperty.getType();
/*      */     } else {
/*  935 */       PropertyDescriptor descriptor = null;
/*      */       try {
/*  937 */         descriptor = getPropertyUtils().getPropertyDescriptor(target, name);
/*      */ 
/*  939 */         if (descriptor == null)
/*  940 */           return;
/*      */       }
/*      */       catch (NoSuchMethodException e) {
/*  943 */         return;
/*      */       }
/*  945 */       if (descriptor instanceof MappedPropertyDescriptor) {
/*  946 */         if (((MappedPropertyDescriptor)descriptor).getMappedWriteMethod() == null) {
/*  947 */           if (this.log.isDebugEnabled()) {
/*  948 */             this.log.debug("Skipping read-only property");
/*      */           }
/*  950 */           return;
/*      */         }
/*  952 */         type = ((MappedPropertyDescriptor)descriptor).getMappedPropertyType();
/*      */       }
/*  954 */       else if (descriptor instanceof IndexedPropertyDescriptor) {
/*  955 */         if (((IndexedPropertyDescriptor)descriptor).getIndexedWriteMethod() == null) {
/*  956 */           if (this.log.isDebugEnabled()) {
/*  957 */             this.log.debug("Skipping read-only property");
/*      */           }
/*  959 */           return;
/*      */         }
/*  961 */         type = ((IndexedPropertyDescriptor)descriptor).getIndexedPropertyType();
/*      */       }
/*      */       else {
/*  964 */         if (descriptor.getWriteMethod() == null) {
/*  965 */           if (this.log.isDebugEnabled()) {
/*  966 */             this.log.debug("Skipping read-only property");
/*      */           }
/*  968 */           return;
/*      */         }
/*  970 */         type = descriptor.getPropertyType();
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  975 */     Object newValue = null;
/*  976 */     if ((type.isArray()) && (index < 0))
/*      */     {
/*      */       String[] values;
/*  977 */       if (value == null) {
/*  978 */         values = new String[1];
/*  979 */         values[0] = ((String)value);
/*  980 */         newValue = getConvertUtils().convert((String[])values, type);
/*  981 */       } else if (value instanceof String) {
/*  982 */         values = new String[1];
/*  983 */         values[0] = ((String)value);
/*  984 */         newValue = getConvertUtils().convert((String[])values, type);
/*  985 */       } else if (value instanceof String[]) {
/*  986 */         newValue = getConvertUtils().convert((String[])value, type);
/*      */       } else {
/*  988 */         newValue = value;
/*      */       }
/*  990 */     } else if (type.isArray()) {
/*  991 */       if (value instanceof String) {
/*  992 */         newValue = getConvertUtils().convert((String)value, type.getComponentType());
/*      */       }
/*  994 */       else if (value instanceof String[]) {
/*  995 */         newValue = getConvertUtils().convert(((String[])value)[0], type.getComponentType());
/*      */       }
/*      */       else {
/*  998 */         newValue = value;
/*      */       }
/*      */     }
/* 1001 */     else if ((value instanceof String) || (value == null)) {
/* 1002 */       newValue = getConvertUtils().convert((String)value, type);
/* 1003 */     } else if (value instanceof String[]) {
/* 1004 */       newValue = getConvertUtils().convert(((String[])value)[0], type);
/*      */     }
/* 1006 */     else if (getConvertUtils().lookup(value.getClass()) != null) {
/* 1007 */       newValue = getConvertUtils().convert(value.toString(), type);
/*      */     } else {
/* 1009 */       newValue = value;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/* 1015 */       if (index >= 0) {
/* 1016 */         getPropertyUtils().setIndexedProperty(target, propName, index, newValue);
/*      */       }
/* 1018 */       else if (key != null) {
/* 1019 */         getPropertyUtils().setMappedProperty(target, propName, key, newValue);
/*      */       }
/*      */       else
/* 1022 */         getPropertyUtils().setProperty(target, propName, newValue);
/*      */     }
/*      */     catch (NoSuchMethodException values) {
/* 1025 */       throw new InvocationTargetException(e, "Cannot set " + propName);
/*      */     }
/*      */   }
/*      */ 
/*      */   private int findLastNestedIndex(String expression)
/*      */   {
/* 1035 */     int bracketCount = 0;
/* 1036 */     for (int i = expression.length() - 1; i >= 0; --i) {
/* 1037 */       char at = expression.charAt(i);
/* 1038 */       switch (at)
/*      */       {
/*      */       case '.':
/* 1040 */         if (bracketCount < 1)
/* 1041 */           return i;
/*      */       case '(':
/*      */       case '[':
/* 1048 */         --bracketCount;
/* 1049 */         break;
/*      */       case ')':
/*      */       case ']':
/* 1054 */         ++bracketCount;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1059 */     return -1;
/*      */   }
/*      */ 
/*      */   public ConvertUtilsBean getConvertUtils()
/*      */   {
/* 1066 */     return this.convertUtilsBean;
/*      */   }
/*      */ 
/*      */   public PropertyUtilsBean getPropertyUtils()
/*      */   {
/* 1073 */     return this.propertyUtilsBean;
/*      */   }
/*      */ }