/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class LazyDynaBean
/*     */   implements DynaBean, Serializable
/*     */ {
/* 115 */   private static Log logger = LogFactory.getLog(LazyDynaBean.class);
/*     */ 
/* 117 */   protected static final BigInteger BigInteger_ZERO = new BigInteger("0");
/* 118 */   protected static final BigDecimal BigDecimal_ZERO = new BigDecimal("0");
/* 119 */   protected static final Character Character_SPACE = new Character(' ');
/* 120 */   protected static final Byte Byte_ZERO = new Byte(0);
/* 121 */   protected static final Short Short_ZERO = new Short(0);
/* 122 */   protected static final Integer Integer_ZERO = new Integer(0);
/* 123 */   protected static final Long Long_ZERO = new Long(0L);
/* 124 */   protected static final Float Float_ZERO = new Float(0.0F);
/* 125 */   protected static final Double Double_ZERO = new Double(0.0D);
/*     */   protected Map values;
/*     */   protected MutableDynaClass dynaClass;
/*     */ 
/*     */   public LazyDynaBean()
/*     */   {
/* 146 */     this(new LazyDynaClass());
/*     */   }
/*     */ 
/*     */   public LazyDynaBean(String name)
/*     */   {
/* 155 */     this(new LazyDynaClass(name));
/*     */   }
/*     */ 
/*     */   public LazyDynaBean(DynaClass dynaClass)
/*     */   {
/* 167 */     this.values = newMap();
/*     */ 
/* 169 */     if (dynaClass instanceof MutableDynaClass)
/* 170 */       this.dynaClass = ((MutableDynaClass)dynaClass);
/*     */     else
/* 172 */       this.dynaClass = new LazyDynaClass(dynaClass.getName(), dynaClass.getDynaProperties());
/*     */   }
/*     */ 
/*     */   public Map getMap()
/*     */   {
/* 184 */     return this.values;
/*     */   }
/*     */ 
/*     */   public int size(String name)
/*     */   {
/* 195 */     if (name == null) {
/* 196 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 199 */     Object value = this.values.get(name);
/* 200 */     if (value == null) {
/* 201 */       return 0;
/*     */     }
/*     */ 
/* 204 */     if (value instanceof Map) {
/* 205 */       return ((Map)value).size();
/*     */     }
/*     */ 
/* 208 */     if (value instanceof List) {
/* 209 */       return ((List)value).size();
/*     */     }
/*     */ 
/* 212 */     if (value.getClass().isArray()) {
/* 213 */       return Array.getLength(value);
/*     */     }
/*     */ 
/* 216 */     return 0;
/*     */   }
/*     */ 
/*     */   public boolean contains(String name, String key)
/*     */   {
/* 233 */     if (name == null) {
/* 234 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 237 */     Object value = this.values.get(name);
/* 238 */     if (value == null) {
/* 239 */       return false;
/*     */     }
/*     */ 
/* 242 */     if (value instanceof Map) {
/* 243 */       return ((Map)value).containsKey(key);
/*     */     }
/*     */ 
/* 246 */     return false;
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 261 */     if (name == null) {
/* 262 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 266 */     Object value = this.values.get(name);
/* 267 */     if (value != null) {
/* 268 */       return value;
/*     */     }
/*     */ 
/* 272 */     if (!(isDynaProperty(name))) {
/* 273 */       return null;
/*     */     }
/*     */ 
/* 277 */     value = createProperty(name, this.dynaClass.getDynaProperty(name).getType());
/*     */ 
/* 279 */     if (value != null) {
/* 280 */       set(name, value);
/*     */     }
/*     */ 
/* 283 */     return value;
/*     */   }
/*     */ 
/*     */   public Object get(String name, int index)
/*     */   {
/* 304 */     if (!(isDynaProperty(name))) {
/* 305 */       set(name, defaultIndexedProperty(name));
/*     */     }
/*     */ 
/* 309 */     Object indexedProperty = get(name);
/*     */ 
/* 312 */     if (!(this.dynaClass.getDynaProperty(name).isIndexed())) {
/* 313 */       throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]' " + this.dynaClass.getDynaProperty(name).getName());
/*     */     }
/*     */ 
/* 319 */     indexedProperty = growIndexedProperty(name, indexedProperty, index);
/*     */ 
/* 322 */     if (indexedProperty.getClass().isArray())
/* 323 */       return Array.get(indexedProperty, index);
/* 324 */     if (indexedProperty instanceof List) {
/* 325 */       return ((List)indexedProperty).get(index);
/*     */     }
/* 327 */     throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]' " + indexedProperty.getClass().getName());
/*     */   }
/*     */ 
/*     */   public Object get(String name, String key)
/*     */   {
/* 349 */     if (!(isDynaProperty(name))) {
/* 350 */       set(name, defaultMappedProperty(name));
/*     */     }
/*     */ 
/* 354 */     Object mappedProperty = get(name);
/*     */ 
/* 357 */     if (!(this.dynaClass.getDynaProperty(name).isMapped())) {
/* 358 */       throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")' " + this.dynaClass.getDynaProperty(name).getType().getName());
/*     */     }
/*     */ 
/* 364 */     if (mappedProperty instanceof Map) {
/* 365 */       return ((Map)mappedProperty).get(key);
/*     */     }
/* 367 */     throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'" + mappedProperty.getClass().getName());
/*     */   }
/*     */ 
/*     */   public DynaClass getDynaClass()
/*     */   {
/* 380 */     return this.dynaClass;
/*     */   }
/*     */ 
/*     */   public void remove(String name, String key)
/*     */   {
/* 396 */     if (name == null) {
/* 397 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 400 */     Object value = this.values.get(name);
/* 401 */     if (value == null) {
/* 402 */       return;
/*     */     }
/*     */ 
/* 405 */     if (value instanceof Map)
/* 406 */       ((Map)value).remove(key);
/*     */     else
/* 408 */       throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'" + value.getClass().getName());
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value)
/*     */   {
/* 431 */     if (!(isDynaProperty(name)))
/*     */     {
/* 433 */       if (this.dynaClass.isRestricted()) {
/* 434 */         throw new IllegalArgumentException("Invalid property name '" + name + "' (DynaClass is restricted)");
/*     */       }
/*     */ 
/* 437 */       if (value == null)
/* 438 */         this.dynaClass.add(name);
/*     */       else {
/* 440 */         this.dynaClass.add(name, value.getClass());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 445 */     DynaProperty descriptor = this.dynaClass.getDynaProperty(name);
/*     */ 
/* 447 */     if (value == null) {
/* 448 */       if (!(descriptor.getType().isPrimitive())) break label217;
/* 449 */       throw new NullPointerException("Primitive value for '" + name + "'");
/*     */     }
/*     */ 
/* 452 */     if (!(isAssignable(descriptor.getType(), value.getClass()))) {
/* 453 */       throw new ConversionException("Cannot assign value of type '" + value.getClass().getName() + "' to property '" + name + "' of type '" + descriptor.getType().getName() + "'");
/*     */     }
/*     */ 
/* 461 */     label217: this.values.put(name, value);
/*     */   }
/*     */ 
/*     */   public void set(String name, int index, Object value)
/*     */   {
/* 484 */     if (!(isDynaProperty(name))) {
/* 485 */       set(name, defaultIndexedProperty(name));
/*     */     }
/*     */ 
/* 489 */     Object indexedProperty = get(name);
/*     */ 
/* 492 */     if (!(this.dynaClass.getDynaProperty(name).isIndexed())) {
/* 493 */       throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]'" + this.dynaClass.getDynaProperty(name).getType().getName());
/*     */     }
/*     */ 
/* 499 */     indexedProperty = growIndexedProperty(name, indexedProperty, index);
/*     */ 
/* 502 */     if (indexedProperty.getClass().isArray())
/* 503 */       Array.set(indexedProperty, index, value);
/* 504 */     else if (indexedProperty instanceof List)
/* 505 */       ((List)indexedProperty).set(index, value);
/*     */     else
/* 507 */       throw new IllegalArgumentException("Non-indexed property for '" + name + "[" + index + "]' " + indexedProperty.getClass().getName());
/*     */   }
/*     */ 
/*     */   public void set(String name, String key, Object value)
/*     */   {
/* 531 */     if (!(isDynaProperty(name))) {
/* 532 */       set(name, defaultMappedProperty(name));
/*     */     }
/*     */ 
/* 536 */     Object mappedProperty = get(name);
/*     */ 
/* 539 */     if (!(this.dynaClass.getDynaProperty(name).isMapped())) {
/* 540 */       throw new IllegalArgumentException("Non-mapped property for '" + name + "(" + key + ")'" + this.dynaClass.getDynaProperty(name).getType().getName());
/*     */     }
/*     */ 
/* 546 */     ((Map)mappedProperty).put(key, value);
/*     */   }
/*     */ 
/*     */   protected Object growIndexedProperty(String name, Object indexedProperty, int index)
/*     */   {
/* 555 */     if (indexedProperty instanceof List)
/*     */     {
/* 557 */       List list = (List)indexedProperty;
/* 558 */       while (index >= list.size()) {
/* 559 */         list.add(null);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 565 */     if (indexedProperty.getClass().isArray())
/*     */     {
/* 567 */       int length = Array.getLength(indexedProperty);
/* 568 */       if (index >= length) {
/* 569 */         Class componentType = indexedProperty.getClass().getComponentType();
/* 570 */         Object newArray = Array.newInstance(componentType, index + 1);
/* 571 */         System.arraycopy(indexedProperty, 0, newArray, 0, length);
/* 572 */         indexedProperty = newArray;
/* 573 */         set(name, indexedProperty);
/* 574 */         int newLength = Array.getLength(indexedProperty);
/* 575 */         for (int i = length; i < newLength; ++i) {
/* 576 */           Array.set(indexedProperty, i, createProperty(name + "[" + i + "]", componentType));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 581 */     return indexedProperty;
/*     */   }
/*     */ 
/*     */   protected Object createProperty(String name, Class type)
/*     */   {
/* 591 */     if ((type.isArray()) || (List.class.isAssignableFrom(type))) {
/* 592 */       return createIndexedProperty(name, type);
/*     */     }
/*     */ 
/* 595 */     if (Map.class.isAssignableFrom(type)) {
/* 596 */       return createMappedProperty(name, type);
/*     */     }
/*     */ 
/* 599 */     if (Serializable.class.isAssignableFrom(type)) {
/* 600 */       return createDynaBeanProperty(name, type);
/*     */     }
/*     */ 
/* 603 */     if (type.isPrimitive()) {
/* 604 */       return createPrimitiveProperty(name, type);
/*     */     }
/*     */ 
/* 607 */     if (Number.class.isAssignableFrom(type)) {
/* 608 */       return createNumberProperty(name, type);
/*     */     }
/*     */ 
/* 611 */     return createOtherProperty(name, type);
/*     */   }
/*     */ 
/*     */   protected Object createIndexedProperty(String name, Class type)
/*     */   {
/* 621 */     Object indexedProperty = null;
/*     */ 
/* 623 */     if (type == null)
/*     */     {
/* 625 */       indexedProperty = defaultIndexedProperty(name);
/*     */     }
/* 627 */     else if (type.isArray())
/*     */     {
/* 629 */       indexedProperty = Array.newInstance(type.getComponentType(), 0);
/*     */     }
/* 631 */     else if (List.class.isAssignableFrom(type)) {
/* 632 */       if (type.isInterface())
/* 633 */         indexedProperty = defaultIndexedProperty(name);
/*     */       else {
/*     */         try {
/* 636 */           indexedProperty = type.newInstance();
/*     */         }
/*     */         catch (Exception ex) {
/* 639 */           throw new IllegalArgumentException("Error instantiating indexed property of type '" + type.getName() + "' for '" + name + "' " + ex);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */     else {
/* 646 */       throw new IllegalArgumentException("Non-indexed property of type '" + type.getName() + "' for '" + name + "'");
/*     */     }
/*     */ 
/* 650 */     return indexedProperty;
/*     */   }
/*     */ 
/*     */   protected Object createMappedProperty(String name, Class type)
/*     */   {
/* 660 */     Object mappedProperty = null;
/*     */ 
/* 662 */     if (type == null)
/*     */     {
/* 664 */       mappedProperty = defaultMappedProperty(name);
/*     */     }
/* 666 */     else if (type.isInterface())
/*     */     {
/* 668 */       mappedProperty = defaultMappedProperty(name);
/*     */     }
/* 670 */     else if (Map.class.isAssignableFrom(type)) {
/*     */       try {
/* 672 */         mappedProperty = type.newInstance();
/*     */       }
/*     */       catch (Exception ex) {
/* 675 */         throw new IllegalArgumentException("Error instantiating mapped property of type '" + type.getName() + "' for '" + name + "' " + ex);
/*     */       }
/*     */ 
/*     */     }
/*     */     else {
/* 680 */       throw new IllegalArgumentException("Non-mapped property of type '" + type.getName() + "' for '" + name + "'");
/*     */     }
/*     */ 
/* 684 */     return mappedProperty;
/*     */   }
/*     */ 
/*     */   protected Object createDynaBeanProperty(String name, Class type)
/*     */   {
/*     */     try
/*     */     {
/* 693 */       return type.newInstance();
/*     */     }
/*     */     catch (Exception ex) {
/* 696 */       if (logger.isWarnEnabled())
/* 697 */         logger.warn("Error instantiating DynaBean property of type '" + type.getName() + "' for '" + name + "' " + ex);
/*     */     }
/* 699 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object createPrimitiveProperty(String name, Class type)
/*     */   {
/* 708 */     if (type == Boolean.TYPE)
/* 709 */       return Boolean.FALSE;
/* 710 */     if (type == Integer.TYPE)
/* 711 */       return Integer_ZERO;
/* 712 */     if (type == Long.TYPE)
/* 713 */       return Long_ZERO;
/* 714 */     if (type == Double.TYPE)
/* 715 */       return Double_ZERO;
/* 716 */     if (type == Float.TYPE)
/* 717 */       return Float_ZERO;
/* 718 */     if (type == Byte.TYPE)
/* 719 */       return Byte_ZERO;
/* 720 */     if (type == Short.TYPE)
/* 721 */       return Short_ZERO;
/* 722 */     if (type == Character.TYPE) {
/* 723 */       return Character_SPACE;
/*     */     }
/* 725 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object createNumberProperty(String name, Class type)
/*     */   {
/* 735 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object createOtherProperty(String name, Class type)
/*     */   {
/* 744 */     if ((type == String.class) || (type == Boolean.class) || (type == Character.class) || (Date.class.isAssignableFrom(type)))
/*     */     {
/* 746 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 750 */       return type.newInstance();
/*     */     }
/*     */     catch (Exception ex) {
/* 753 */       if (logger.isWarnEnabled())
/* 754 */         logger.warn("Error instantiating property of type '" + type.getName() + "' for '" + name + "' " + ex);
/*     */     }
/* 756 */     return null;
/*     */   }
/*     */ 
/*     */   protected Object defaultIndexedProperty(String name)
/*     */   {
/* 770 */     return new ArrayList();
/*     */   }
/*     */ 
/*     */   protected Map defaultMappedProperty(String name)
/*     */   {
/* 783 */     return new HashMap();
/*     */   }
/*     */ 
/*     */   protected boolean isDynaProperty(String name)
/*     */   {
/* 791 */     if (name == null) {
/* 792 */       throw new IllegalArgumentException("No property name specified");
/*     */     }
/*     */ 
/* 796 */     if (this.dynaClass instanceof LazyDynaClass) {
/* 797 */       return ((LazyDynaClass)this.dynaClass).isDynaProperty(name);
/*     */     }
/*     */ 
/* 801 */     return (this.dynaClass.getDynaProperty(name) != null);
/*     */   }
/*     */ 
/*     */   protected boolean isAssignable(Class dest, Class source)
/*     */   {
/* 822 */     return ((!(dest.isAssignableFrom(source))) && (((dest != Boolean.TYPE) || (source != Boolean.class))) && (((dest != Byte.TYPE) || (source != Byte.class))) && (((dest != Character.TYPE) || (source != Character.class))) && (((dest != Double.TYPE) || (source != Double.class))) && (((dest != Float.TYPE) || (source != Float.class))) && (((dest != Integer.TYPE) || (source != Integer.class))) && (((dest != Long.TYPE) || (source != Long.class))) && (((dest != Short.TYPE) || (source != Short.class))));
/*     */   }
/*     */ 
/*     */   protected Map newMap()
/*     */   {
/* 833 */     return new HashMap();
/*     */   }
/*     */ }