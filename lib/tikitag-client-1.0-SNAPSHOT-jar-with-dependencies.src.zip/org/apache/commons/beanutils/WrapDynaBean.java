/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ public class WrapDynaBean
/*     */   implements DynaBean
/*     */ {
/*  75 */   protected WrapDynaClass dynaClass = null;
/*     */ 
/*  81 */   protected Object instance = null;
/*     */ 
/*     */   public WrapDynaBean(Object instance)
/*     */   {
/*  62 */     this.instance = instance;
/*  63 */     this.dynaClass = WrapDynaClass.createDynaClass(instance.getClass());
/*     */   }
/*     */ 
/*     */   public boolean contains(String name, String key)
/*     */   {
/*  99 */     throw new UnsupportedOperationException("WrapDynaBean does not support contains()");
/*     */   }
/*     */ 
/*     */   public Object get(String name)
/*     */   {
/* 115 */     Object value = null;
/*     */     try {
/* 117 */       value = PropertyUtils.getSimpleProperty(this.instance, name);
/*     */     } catch (Throwable t) {
/* 119 */       throw new IllegalArgumentException("Property '" + name + "' has no read method");
/*     */     }
/*     */ 
/* 122 */     return value;
/*     */   }
/*     */ 
/*     */   public Object get(String name, int index)
/*     */   {
/* 144 */     Object value = null;
/*     */     try {
/* 146 */       value = PropertyUtils.getIndexedProperty(this.instance, name, index);
/*     */     } catch (IndexOutOfBoundsException e) {
/* 148 */       throw e;
/*     */     } catch (Throwable t) {
/* 150 */       throw new IllegalArgumentException("Property '" + name + "' has no indexed read method");
/*     */     }
/*     */ 
/* 153 */     return value;
/*     */   }
/*     */ 
/*     */   public Object get(String name, String key)
/*     */   {
/* 172 */     Object value = null;
/*     */     try {
/* 174 */       value = PropertyUtils.getMappedProperty(this.instance, name, key);
/*     */     } catch (Throwable t) {
/* 176 */       throw new IllegalArgumentException("Property '" + name + "' has no mapped read method");
/*     */     }
/*     */ 
/* 179 */     return value;
/*     */   }
/*     */ 
/*     */   public DynaClass getDynaClass()
/*     */   {
/* 190 */     return this.dynaClass;
/*     */   }
/*     */ 
/*     */   public void remove(String name, String key)
/*     */   {
/* 209 */     throw new UnsupportedOperationException("WrapDynaBean does not support remove()");
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 231 */       PropertyUtils.setSimpleProperty(this.instance, name, value);
/*     */     } catch (Throwable t) {
/* 233 */       throw new IllegalArgumentException("Property '" + name + "' has no write method");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(String name, int index, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 259 */       PropertyUtils.setIndexedProperty(this.instance, name, index, value);
/*     */     } catch (IndexOutOfBoundsException e) {
/* 261 */       throw e;
/*     */     } catch (Throwable t) {
/* 263 */       throw new IllegalArgumentException("Property '" + name + "' has no indexed write method");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void set(String name, String key, Object value)
/*     */   {
/*     */     try
/*     */     {
/* 287 */       PropertyUtils.setMappedProperty(this.instance, name, key, value);
/*     */     } catch (Throwable t) {
/* 289 */       throw new IllegalArgumentException("Property '" + name + "' has no mapped write method");
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object getInstance()
/*     */   {
/* 306 */     return this.instance;
/*     */   }
/*     */ 
/*     */   protected DynaProperty getDynaProperty(String name)
/*     */   {
/* 323 */     DynaProperty descriptor = getDynaClass().getDynaProperty(name);
/* 324 */     if (descriptor == null) {
/* 325 */       throw new IllegalArgumentException("Invalid property name '" + name + "'");
/*     */     }
/*     */ 
/* 328 */     return descriptor;
/*     */   }
/*     */ }