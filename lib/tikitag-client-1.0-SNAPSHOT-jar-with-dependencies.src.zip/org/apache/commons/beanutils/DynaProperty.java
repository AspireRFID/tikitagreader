/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.StreamCorruptedException;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class DynaProperty
/*     */   implements Serializable
/*     */ {
/*     */   private static final int BOOLEAN_TYPE = 1;
/*     */   private static final int BYTE_TYPE = 2;
/*     */   private static final int CHAR_TYPE = 3;
/*     */   private static final int DOUBLE_TYPE = 4;
/*     */   private static final int FLOAT_TYPE = 5;
/*     */   private static final int INT_TYPE = 6;
/*     */   private static final int LONG_TYPE = 7;
/*     */   private static final int SHORT_TYPE = 8;
/*     */   protected String name;
/*     */   protected transient Class type;
/*     */   protected transient Class contentType;
/*     */ 
/*     */   public DynaProperty(String name)
/*     */   {
/*  76 */     this(name, Object.class);
/*     */   }
/*     */ 
/*     */   public DynaProperty(String name, Class type)
/*     */   {
/* 115 */     this.name = null;
/*     */ 
/* 124 */     this.type = null;
/*     */ 
/*  90 */     this.name = name;
/*  91 */     this.type = type;
/*     */   }
/*     */ 
/*     */   public DynaProperty(String name, Class type, Class contentType)
/*     */   {
/* 115 */     this.name = null;
/*     */ 
/* 124 */     this.type = null;
/*     */ 
/* 106 */     this.name = name;
/* 107 */     this.type = type;
/* 108 */     this.contentType = contentType;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 120 */     return this.name;
/*     */   }
/*     */ 
/*     */   public Class getType()
/*     */   {
/* 136 */     return this.type;
/*     */   }
/*     */ 
/*     */   public Class getContentType()
/*     */   {
/* 154 */     return this.contentType;
/*     */   }
/*     */ 
/*     */   public boolean isIndexed()
/*     */   {
/* 165 */     if (this.type == null)
/* 166 */       return false;
/* 167 */     if (this.type.isArray()) {
/* 168 */       return true;
/*     */     }
/* 170 */     return (!(List.class.isAssignableFrom(this.type)));
/*     */   }
/*     */ 
/*     */   public boolean isMapped()
/*     */   {
/* 183 */     if (this.type == null) {
/* 184 */       return false;
/*     */     }
/* 186 */     return Map.class.isAssignableFrom(this.type);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 197 */     StringBuffer sb = new StringBuffer("DynaProperty[name=");
/* 198 */     sb.append(this.name);
/* 199 */     sb.append(",type=");
/* 200 */     sb.append(this.type);
/* 201 */     if ((isMapped()) || (isIndexed())) {
/* 202 */       sb.append(" <").append(this.contentType).append(">");
/*     */     }
/* 204 */     sb.append("]");
/* 205 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   private void writeObject(ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 219 */     writeAnyClass(this.type, out);
/*     */ 
/* 221 */     if ((isMapped()) || (isIndexed())) {
/* 222 */       writeAnyClass(this.contentType, out);
/*     */     }
/*     */ 
/* 226 */     out.defaultWriteObject();
/*     */   }
/*     */ 
/*     */   private void writeAnyClass(Class clazz, ObjectOutputStream out)
/*     */     throws IOException
/*     */   {
/* 234 */     int primitiveType = 0;
/* 235 */     if (Boolean.TYPE.equals(clazz))
/* 236 */       primitiveType = 1;
/* 237 */     else if (Byte.TYPE.equals(clazz))
/* 238 */       primitiveType = 2;
/* 239 */     else if (Character.TYPE.equals(clazz))
/* 240 */       primitiveType = 3;
/* 241 */     else if (Double.TYPE.equals(clazz))
/* 242 */       primitiveType = 4;
/* 243 */     else if (Float.TYPE.equals(clazz))
/* 244 */       primitiveType = 5;
/* 245 */     else if (Integer.TYPE.equals(clazz))
/* 246 */       primitiveType = 6;
/* 247 */     else if (Long.TYPE.equals(clazz))
/* 248 */       primitiveType = 7;
/* 249 */     else if (Short.TYPE.equals(clazz)) {
/* 250 */       primitiveType = 8;
/*     */     }
/*     */ 
/* 253 */     if (primitiveType == 0)
/*     */     {
/* 255 */       out.writeBoolean(false);
/* 256 */       out.writeObject(clazz);
/*     */     }
/*     */     else {
/* 259 */       out.writeBoolean(true);
/* 260 */       out.writeInt(primitiveType);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void readObject(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 274 */     this.type = readAnyClass(in);
/*     */ 
/* 276 */     if ((isMapped()) || (isIndexed())) {
/* 277 */       this.contentType = readAnyClass(in);
/*     */     }
/*     */ 
/* 281 */     in.defaultReadObject();
/*     */   }
/*     */ 
/*     */   private Class readAnyClass(ObjectInputStream in)
/*     */     throws IOException, ClassNotFoundException
/*     */   {
/* 290 */     if (in.readBoolean())
/*     */     {
/* 292 */       switch (in.readInt())
/*     */       {
/*     */       case 1:
/* 294 */         return Boolean.TYPE;
/*     */       case 2:
/* 295 */         return Byte.TYPE;
/*     */       case 3:
/* 296 */         return Character.TYPE;
/*     */       case 4:
/* 297 */         return Double.TYPE;
/*     */       case 5:
/* 298 */         return Float.TYPE;
/*     */       case 6:
/* 299 */         return Integer.TYPE;
/*     */       case 7:
/* 300 */         return Long.TYPE;
/*     */       case 8:
/* 301 */         return Short.TYPE;
/*     */       }
/*     */ 
/* 304 */       throw new StreamCorruptedException("Invalid primitive type. Check version of beanutils used to serialize is compatible.");
/*     */     }
/*     */ 
/* 312 */     return ((Class)in.readObject());
/*     */   }
/*     */ }