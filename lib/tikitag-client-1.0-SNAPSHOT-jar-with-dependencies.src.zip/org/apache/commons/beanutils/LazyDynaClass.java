/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class LazyDynaClass extends BasicDynaClass
/*     */   implements MutableDynaClass
/*     */ {
/*     */   protected boolean restricted;
/*     */   protected boolean returnNull;
/*     */ 
/*     */   public LazyDynaClass()
/*     */   {
/*  63 */     this(null, (DynaProperty[])null);
/*     */   }
/*     */ 
/*     */   public LazyDynaClass(String name)
/*     */   {
/*  72 */     this(name, (DynaProperty[])null);
/*     */   }
/*     */ 
/*     */   public LazyDynaClass(String name, Class dynaBeanClass)
/*     */   {
/*  82 */     this(name, dynaBeanClass, null);
/*     */   }
/*     */ 
/*     */   public LazyDynaClass(String name, DynaProperty[] properties)
/*     */   {
/*  92 */     this(name, LazyDynaBean.class, properties);
/*     */   }
/*     */ 
/*     */   public LazyDynaClass(String name, Class dynaBeanClass, DynaProperty[] properties)
/*     */   {
/* 103 */     super(name, dynaBeanClass, properties);
/*     */ 
/*  57 */     this.returnNull = false;
/*     */   }
/*     */ 
/*     */   public boolean isRestricted()
/*     */   {
/* 112 */     return this.restricted;
/*     */   }
/*     */ 
/*     */   public void setRestricted(boolean restricted)
/*     */   {
/* 121 */     this.restricted = restricted;
/*     */   }
/*     */ 
/*     */   public boolean isReturnNull()
/*     */   {
/* 130 */     return this.returnNull;
/*     */   }
/*     */ 
/*     */   public void setReturnNull(boolean returnNull)
/*     */   {
/* 139 */     this.returnNull = returnNull;
/*     */   }
/*     */ 
/*     */   public void add(String name)
/*     */   {
/* 153 */     add(new DynaProperty(name));
/*     */   }
/*     */ 
/*     */   public void add(String name, Class type)
/*     */   {
/* 169 */     add(new DynaProperty(name, type));
/*     */   }
/*     */ 
/*     */   public void add(String name, Class type, boolean readable, boolean writeable)
/*     */   {
/* 194 */     throw new UnsupportedOperationException("readable/writable properties not supported");
/*     */   }
/*     */ 
/*     */   protected void add(DynaProperty property)
/*     */   {
/* 208 */     if (property.getName() == null) {
/* 209 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 212 */     if (isRestricted()) {
/* 213 */       throw new IllegalStateException("DynaClass is currently restricted. No new properties can be added.");
/*     */     }
/*     */ 
/* 217 */     if (this.jdField_propertiesMap_of_type_JavaUtilHashMap.get(property.getName()) != null) {
/* 218 */       return;
/*     */     }
/*     */ 
/* 222 */     DynaProperty[] oldProperties = getDynaProperties();
/* 223 */     DynaProperty[] newProperties = new DynaProperty[oldProperties.length + 1];
/* 224 */     System.arraycopy(oldProperties, 0, newProperties, 0, oldProperties.length);
/* 225 */     newProperties[oldProperties.length] = property;
/*     */ 
/* 228 */     setProperties(newProperties);
/*     */   }
/*     */ 
/*     */   public void remove(String name)
/*     */   {
/* 247 */     if (name == null) {
/* 248 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 251 */     if (isRestricted()) {
/* 252 */       throw new IllegalStateException("DynaClass is currently restricted. No properties can be removed.");
/*     */     }
/*     */ 
/* 256 */     if (this.jdField_propertiesMap_of_type_JavaUtilHashMap.get(name) == null) {
/* 257 */       return;
/*     */     }
/*     */ 
/* 262 */     DynaProperty[] oldProperties = getDynaProperties();
/* 263 */     DynaProperty[] newProperties = new DynaProperty[oldProperties.length - 1];
/* 264 */     int j = 0;
/* 265 */     for (int i = 0; i < oldProperties.length; ++i) {
/* 266 */       if (!(name.equals(oldProperties[i].getName()))) {
/* 267 */         newProperties[j] = oldProperties[i];
/* 268 */         ++j;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 273 */     setProperties(newProperties);
/*     */   }
/*     */ 
/*     */   public DynaProperty getDynaProperty(String name)
/*     */   {
/* 301 */     if (name == null) {
/* 302 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 305 */     DynaProperty dynaProperty = (DynaProperty)this.jdField_propertiesMap_of_type_JavaUtilHashMap.get(name);
/*     */ 
/* 309 */     if ((dynaProperty == null) && (!(isReturnNull())) && (!(isRestricted()))) {
/* 310 */       dynaProperty = new DynaProperty(name);
/*     */     }
/*     */ 
/* 313 */     return dynaProperty;
/*     */   }
/*     */ 
/*     */   public boolean isDynaProperty(String name)
/*     */   {
/* 329 */     if (name == null) {
/* 330 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 333 */     return (this.jdField_propertiesMap_of_type_JavaUtilHashMap.get(name) != null);
/*     */   }
/*     */ }