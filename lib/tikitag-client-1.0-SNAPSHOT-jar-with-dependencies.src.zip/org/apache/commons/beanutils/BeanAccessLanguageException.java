/*    */ package org.apache.commons.beanutils;
/*    */ 
/*    */ public class BeanAccessLanguageException extends IllegalArgumentException
/*    */ {
/*    */   public BeanAccessLanguageException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public BeanAccessLanguageException(String message)
/*    */   {
/* 45 */     super(message);
/*    */   }
/*    */ }