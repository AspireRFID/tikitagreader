/*    */ package org.apache.commons.beanutils;
/*    */ 
/*    */ public class ConvertingWrapDynaBean extends WrapDynaBean
/*    */ {
/*    */   public ConvertingWrapDynaBean(Object instance)
/*    */   {
/* 46 */     super(instance);
/*    */   }
/*    */ 
/*    */   public void set(String name, Object value)
/*    */   {
/*    */     try
/*    */     {
/* 69 */       BeanUtils.copyProperty(this.instance, name, value);
/*    */     } catch (Throwable t) {
/* 71 */       throw new IllegalArgumentException("Property '" + name + "' has no write method");
/*    */     }
/*    */   }
/*    */ }