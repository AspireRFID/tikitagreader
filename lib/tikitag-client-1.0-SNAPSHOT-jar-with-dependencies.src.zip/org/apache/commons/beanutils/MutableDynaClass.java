package org.apache.commons.beanutils;

public abstract interface MutableDynaClass extends DynaClass
{
  public abstract void add(String paramString);

  public abstract void add(String paramString, Class paramClass);

  public abstract void add(String paramString, Class paramClass, boolean paramBoolean1, boolean paramBoolean2);

  public abstract boolean isRestricted();

  public abstract void remove(String paramString);

  public abstract void setRestricted(boolean paramBoolean);
}