/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import org.apache.commons.collections.Transformer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class BeanToPropertyValueTransformer
/*     */   implements Transformer
/*     */ {
/*     */   private final Log log;
/*     */   private String propertyName;
/*     */   private boolean ignoreNull;
/*     */ 
/*     */   public BeanToPropertyValueTransformer(String propertyName)
/*     */   {
/* 104 */     this(propertyName, false);
/*     */   }
/*     */ 
/*     */   public BeanToPropertyValueTransformer(String propertyName, boolean ignoreNull)
/*     */   {
/*  74 */     this.log = LogFactory.getLog(super.getClass());
/*     */ 
/* 122 */     if ((propertyName != null) && (propertyName.length() > 0)) {
/* 123 */       this.propertyName = propertyName;
/* 124 */       this.ignoreNull = ignoreNull;
/*     */     } else {
/* 126 */       throw new IllegalArgumentException("propertyName cannot be null or empty");
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object transform(Object object)
/*     */   {
/* 149 */     Object propertyValue = null;
/*     */     try
/*     */     {
/* 152 */       propertyValue = PropertyUtils.getProperty(object, this.propertyName);
/*     */     } catch (IllegalArgumentException e) {
/* 154 */       String errorMsg = "Problem during transformation. Null value encountered in property path...";
/*     */ 
/* 156 */       if (this.ignoreNull) {
/* 157 */         this.log.warn("WARNING: Problem during transformation. Null value encountered in property path...", e);
/*     */       } else {
/* 159 */         this.log.error("ERROR: Problem during transformation. Null value encountered in property path...", e);
/* 160 */         throw e;
/*     */       }
/*     */     } catch (IllegalAccessException e) {
/* 163 */       String errorMsg = "Unable to access the property provided.";
/* 164 */       this.log.error("Unable to access the property provided.", e);
/* 165 */       throw new IllegalArgumentException("Unable to access the property provided.");
/*     */     } catch (InvocationTargetException e) {
/* 167 */       String errorMsg = "Exception occurred in property's getter";
/* 168 */       this.log.error("Exception occurred in property's getter", e);
/* 169 */       throw new IllegalArgumentException("Exception occurred in property's getter");
/*     */     } catch (NoSuchMethodException e) {
/* 171 */       String errorMsg = "No property found for name [" + this.propertyName + "]";
/*     */ 
/* 173 */       this.log.error(errorMsg, e);
/* 174 */       throw new IllegalArgumentException(errorMsg);
/*     */     }
/*     */ 
/* 177 */     return propertyValue;
/*     */   }
/*     */ 
/*     */   public String getPropertyName()
/*     */   {
/* 186 */     return this.propertyName;
/*     */   }
/*     */ 
/*     */   public boolean isIgnoreNull()
/*     */   {
/* 203 */     return this.ignoreNull;
/*     */   }
/*     */ }