package org.apache.commons.beanutils;

public abstract interface DynaBean
{
  public abstract boolean contains(String paramString1, String paramString2);

  public abstract Object get(String paramString);

  public abstract Object get(String paramString, int paramInt);

  public abstract Object get(String paramString1, String paramString2);

  public abstract DynaClass getDynaClass();

  public abstract void remove(String paramString1, String paramString2);

  public abstract void set(String paramString, Object paramObject);

  public abstract void set(String paramString, int paramInt, Object paramObject);

  public abstract void set(String paramString1, String paramString2, Object paramObject);
}