/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.Arrays;
/*     */ import java.util.WeakHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class MethodUtils
/*     */ {
/*  62 */   private static Log log = LogFactory.getLog(MethodUtils.class);
/*     */ 
/*  64 */   private static boolean loggedAccessibleWarning = false;
/*     */ 
/*  67 */   private static final Class[] emptyClassArray = new Class[0];
/*     */ 
/*  69 */   private static final Object[] emptyObjectArray = new Object[0];
/*     */ 
/*  74 */   private static WeakHashMap cache = new WeakHashMap();
/*     */ 
/*     */   public static Object invokeMethod(Object object, String methodName, Object arg)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 113 */     Object[] args = { arg };
/* 114 */     return invokeMethod(object, methodName, args);
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(Object object, String methodName, Object[] args)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 154 */     if (args == null) {
/* 155 */       args = emptyObjectArray;
/*     */     }
/* 157 */     int arguments = args.length;
/* 158 */     Class[] parameterTypes = new Class[arguments];
/* 159 */     for (int i = 0; i < arguments; ++i) {
/* 160 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/* 162 */     return invokeMethod(object, methodName, args, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Object invokeMethod(Object object, String methodName, Object[] args, Class[] parameterTypes)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 202 */     if (parameterTypes == null) {
/* 203 */       parameterTypes = emptyClassArray;
/*     */     }
/* 205 */     if (args == null) {
/* 206 */       args = emptyObjectArray;
/*     */     }
/*     */ 
/* 209 */     Method method = getMatchingAccessibleMethod(object.getClass(), methodName, parameterTypes);
/*     */ 
/* 213 */     if (method == null) {
/* 214 */       throw new NoSuchMethodException("No such accessible method: " + methodName + "() on object: " + object.getClass().getName());
/*     */     }
/* 216 */     return method.invoke(object, args);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactMethod(Object object, String methodName, Object arg)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 247 */     Object[] args = { arg };
/* 248 */     return invokeExactMethod(object, methodName, args);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactMethod(Object object, String methodName, Object[] args)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 278 */     if (args == null) {
/* 279 */       args = emptyObjectArray;
/*     */     }
/* 281 */     int arguments = args.length;
/* 282 */     Class[] parameterTypes = new Class[arguments];
/* 283 */     for (int i = 0; i < arguments; ++i) {
/* 284 */       parameterTypes[i] = args[i].getClass();
/*     */     }
/* 286 */     return invokeExactMethod(object, methodName, args, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Object invokeExactMethod(Object object, String methodName, Object[] args, Class[] parameterTypes)
/*     */     throws NoSuchMethodException, IllegalAccessException, InvocationTargetException
/*     */   {
/* 319 */     if (args == null) {
/* 320 */       args = emptyObjectArray;
/*     */     }
/*     */ 
/* 323 */     if (parameterTypes == null) {
/* 324 */       parameterTypes = emptyClassArray;
/*     */     }
/*     */ 
/* 327 */     Method method = getAccessibleMethod(object.getClass(), methodName, parameterTypes);
/*     */ 
/* 331 */     if (method == null) {
/* 332 */       throw new NoSuchMethodException("No such accessible method: " + methodName + "() on object: " + object.getClass().getName());
/*     */     }
/* 334 */     return method.invoke(object, args);
/*     */   }
/*     */ 
/*     */   public static Method getAccessibleMethod(Class clazz, String methodName, Class parameterType)
/*     */   {
/* 355 */     Class[] parameterTypes = { parameterType };
/* 356 */     return getAccessibleMethod(clazz, methodName, parameterTypes);
/*     */   }
/*     */ 
/*     */   public static Method getAccessibleMethod(Class clazz, String methodName, Class[] parameterTypes)
/*     */   {
/*     */     try
/*     */     {
/* 378 */       MethodDescriptor md = new MethodDescriptor(clazz, methodName, parameterTypes, true);
/*     */ 
/* 380 */       Method method = (Method)cache.get(md);
/* 381 */       if (method != null) {
/* 382 */         return method;
/*     */       }
/*     */ 
/* 385 */       method = getAccessibleMethod(clazz.getMethod(methodName, parameterTypes));
/*     */ 
/* 387 */       cache.put(md, method);
/* 388 */       return method; } catch (NoSuchMethodException e) {
/*     */     }
/* 390 */     return null;
/*     */   }
/*     */ 
/*     */   public static Method getAccessibleMethod(Method method)
/*     */   {
/* 406 */     if (method == null) {
/* 407 */       return null;
/*     */     }
/*     */ 
/* 411 */     if (!(Modifier.isPublic(method.getModifiers()))) {
/* 412 */       return null;
/*     */     }
/*     */ 
/* 416 */     Class clazz = method.getDeclaringClass();
/* 417 */     if (Modifier.isPublic(clazz.getModifiers())) {
/* 418 */       return method;
/*     */     }
/*     */ 
/* 422 */     method = getAccessibleMethodFromInterfaceNest(clazz, method.getName(), method.getParameterTypes());
/*     */ 
/* 426 */     return method;
/*     */   }
/*     */ 
/*     */   private static Method getAccessibleMethodFromInterfaceNest(Class clazz, String methodName, Class[] parameterTypes)
/*     */   {
/* 450 */     Method method = null;
/*     */ 
/* 453 */     for (; clazz != null; clazz = clazz.getSuperclass())
/*     */     {
/* 456 */       Class[] interfaces = clazz.getInterfaces();
/* 457 */       for (int i = 0; i < interfaces.length; ++i)
/*     */       {
/* 460 */         if (!(Modifier.isPublic(interfaces[i].getModifiers()))) {
/*     */           continue;
/*     */         }
/*     */         try
/*     */         {
/* 465 */           method = interfaces[i].getDeclaredMethod(methodName, parameterTypes);
/*     */         }
/*     */         catch (NoSuchMethodException e)
/*     */         {
/*     */         }
/* 470 */         if (method != null) {
/*     */           break;
/*     */         }
/*     */ 
/* 474 */         method = getAccessibleMethodFromInterfaceNest(interfaces[i], methodName, parameterTypes);
/*     */ 
/* 478 */         if (method != null) {
/*     */           break;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 486 */     if (method != null) {
/* 487 */       return method;
/*     */     }
/*     */ 
/* 490 */     return null;
/*     */   }
/*     */ 
/*     */   public static Method getMatchingAccessibleMethod(Class clazz, String methodName, Class[] parameterTypes)
/*     */   {
/* 521 */     if (log.isTraceEnabled()) {
/* 522 */       log.trace("Matching name=" + methodName + " on " + clazz);
/*     */     }
/* 524 */     MethodDescriptor md = new MethodDescriptor(clazz, methodName, parameterTypes, false);
/*     */     try
/*     */     {
/* 530 */       Method method = (Method)cache.get(md);
/* 531 */       if (method != null) {
/* 532 */         return method;
/*     */       }
/*     */ 
/* 535 */       method = clazz.getMethod(methodName, parameterTypes);
/* 536 */       if (log.isTraceEnabled()) {
/* 537 */         log.trace("Found straight match: " + method);
/* 538 */         log.trace("isPublic:" + Modifier.isPublic(method.getModifiers()));
/*     */       }
/*     */ 
/*     */       try
/*     */       {
/* 558 */         method.setAccessible(true);
/*     */       }
/*     */       catch (SecurityException se)
/*     */       {
/* 562 */         if (!(loggedAccessibleWarning)) {
/* 563 */           boolean vunerableJVM = false;
/*     */           try {
/* 565 */             String specVersion = System.getProperty("java.specification.version");
/* 566 */             if ((specVersion.charAt(0) == '1') && (((specVersion.charAt(0) == '0') || (specVersion.charAt(0) == '1') || (specVersion.charAt(0) == '2') || (specVersion.charAt(0) == '3'))))
/*     */             {
/* 572 */               vunerableJVM = true;
/*     */             }
/*     */           }
/*     */           catch (SecurityException e) {
/* 576 */             vunerableJVM = true;
/*     */           }
/* 578 */           if (vunerableJVM) {
/* 579 */             log.warn("Current Security Manager restricts use of workarounds for reflection bugs  in pre-1.4 JVMs.");
/*     */           }
/*     */ 
/* 583 */           loggedAccessibleWarning = true;
/*     */         }
/* 585 */         log.debug("Cannot setAccessible on method. Therefore cannot use jvm access bug workaround.", se);
/*     */       }
/*     */ 
/* 589 */       cache.put(md, method);
/* 590 */       return method;
/*     */     }
/*     */     catch (NoSuchMethodException paramSize)
/*     */     {
/* 595 */       int paramSize = parameterTypes.length;
/* 596 */       Method[] methods = clazz.getMethods();
/* 597 */       int i = 0; for (int size = methods.length; i < size; ++i) {
/* 598 */         if (!(methods[i].getName().equals(methodName)))
/*     */           continue;
/* 600 */         if (log.isTraceEnabled()) {
/* 601 */           log.trace("Found matching name:");
/* 602 */           log.trace(methods[i]);
/*     */         }
/*     */ 
/* 606 */         Class[] methodsParams = methods[i].getParameterTypes();
/* 607 */         int methodParamSize = methodsParams.length;
/* 608 */         if (methodParamSize == paramSize) {
/* 609 */           boolean match = true;
/* 610 */           for (int n = 0; n < methodParamSize; ++n) {
/* 611 */             if (log.isTraceEnabled()) {
/* 612 */               log.trace("Param=" + parameterTypes[n].getName());
/* 613 */               log.trace("Method=" + methodsParams[n].getName());
/*     */             }
/* 615 */             if (!(isAssignmentCompatible(methodsParams[n], parameterTypes[n]))) {
/* 616 */               if (log.isTraceEnabled()) {
/* 617 */                 log.trace(methodsParams[n] + " is not assignable from " + parameterTypes[n]);
/*     */               }
/*     */ 
/* 620 */               match = false;
/* 621 */               break;
/*     */             }
/*     */           }
/*     */ 
/* 625 */           if (!(match))
/*     */             continue;
/* 627 */           Method method = getAccessibleMethod(methods[i]);
/* 628 */           if (method != null) {
/* 629 */             if (log.isTraceEnabled()) {
/* 630 */               log.trace(method + " accessible version of " + methods[i]);
/*     */             }
/*     */ 
/*     */             try
/*     */             {
/* 638 */               method.setAccessible(true);
/*     */             }
/*     */             catch (SecurityException se)
/*     */             {
/* 642 */               if (!(loggedAccessibleWarning)) {
/* 643 */                 log.warn("Cannot use JVM pre-1.4 access bug workaround due to restrictive security manager.");
/*     */ 
/* 645 */                 loggedAccessibleWarning = true;
/*     */               }
/* 647 */               log.debug("Cannot setAccessible on method. Therefore cannot use jvm access bug workaround.", se);
/*     */             }
/*     */ 
/* 651 */             cache.put(md, method);
/* 652 */             return method;
/*     */           }
/*     */ 
/* 655 */           log.trace("Couldn't find accessible method.");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 662 */       log.trace("No match found."); }
/* 663 */     return null;
/*     */   }
/*     */ 
/*     */   public static final boolean isAssignmentCompatible(Class parameterType, Class parameterization)
/*     */   {
/* 685 */     if (parameterType.isAssignableFrom(parameterization)) {
/* 686 */       return true;
/*     */     }
/*     */ 
/* 689 */     if (parameterType.isPrimitive())
/*     */     {
/* 692 */       Class parameterWrapperClazz = getPrimitiveWrapper(parameterType);
/* 693 */       if (parameterWrapperClazz != null) {
/* 694 */         return parameterWrapperClazz.equals(parameterization);
/*     */       }
/*     */     }
/*     */ 
/* 698 */     return false;
/*     */   }
/*     */ 
/*     */   public static Class getPrimitiveWrapper(Class primitiveType)
/*     */   {
/* 710 */     if (Boolean.TYPE.equals(primitiveType))
/* 711 */       return Boolean.class;
/* 712 */     if (Float.TYPE.equals(primitiveType))
/* 713 */       return Float.class;
/* 714 */     if (Long.TYPE.equals(primitiveType))
/* 715 */       return Long.class;
/* 716 */     if (Integer.TYPE.equals(primitiveType))
/* 717 */       return Integer.class;
/* 718 */     if (Short.TYPE.equals(primitiveType))
/* 719 */       return Short.class;
/* 720 */     if (Byte.TYPE.equals(primitiveType))
/* 721 */       return Byte.class;
/* 722 */     if (Double.TYPE.equals(primitiveType))
/* 723 */       return Double.class;
/* 724 */     if (Character.TYPE.equals(primitiveType)) {
/* 725 */       return Character.class;
/*     */     }
/*     */ 
/* 728 */     return null;
/*     */   }
/*     */ 
/*     */   public static Class getPrimitiveType(Class wrapperType)
/*     */   {
/* 741 */     if (Boolean.class.equals(wrapperType))
/* 742 */       return Boolean.TYPE;
/* 743 */     if (Float.class.equals(wrapperType))
/* 744 */       return Float.TYPE;
/* 745 */     if (Long.class.equals(wrapperType))
/* 746 */       return Long.TYPE;
/* 747 */     if (Integer.class.equals(wrapperType))
/* 748 */       return Integer.TYPE;
/* 749 */     if (Short.class.equals(wrapperType))
/* 750 */       return Short.TYPE;
/* 751 */     if (Byte.class.equals(wrapperType))
/* 752 */       return Byte.TYPE;
/* 753 */     if (Double.class.equals(wrapperType))
/* 754 */       return Double.TYPE;
/* 755 */     if (Character.class.equals(wrapperType)) {
/* 756 */       return Character.TYPE;
/*     */     }
/* 758 */     if (log.isDebugEnabled()) {
/* 759 */       log.debug("Not a known primitive wrapper class: " + wrapperType);
/*     */     }
/* 761 */     return null;
/*     */   }
/*     */ 
/*     */   public static Class toNonPrimitiveClass(Class clazz)
/*     */   {
/* 772 */     if (clazz.isPrimitive()) {
/* 773 */       Class primitiveClazz = getPrimitiveWrapper(clazz);
/*     */ 
/* 775 */       if (primitiveClazz != null) {
/* 776 */         return primitiveClazz;
/*     */       }
/* 778 */       return clazz;
/*     */     }
/*     */ 
/* 781 */     return clazz;
/*     */   }
/*     */ 
/*     */   private static class MethodDescriptor
/*     */   {
/*     */     private Class cls;
/*     */     private String methodName;
/*     */     private Class[] paramTypes;
/*     */     private boolean exact;
/*     */     private int hashCode;
/*     */ 
/*     */     public MethodDescriptor(Class cls, String methodName, Class[] paramTypes, boolean exact)
/*     */     {
/* 805 */       if (cls == null) {
/* 806 */         throw new IllegalArgumentException("Class cannot be null");
/*     */       }
/* 808 */       if (methodName == null) {
/* 809 */         throw new IllegalArgumentException("Method Name cannot be null");
/*     */       }
/* 811 */       if (paramTypes == null) {
/* 812 */         paramTypes = MethodUtils.emptyClassArray;
/*     */       }
/*     */ 
/* 815 */       this.cls = cls;
/* 816 */       this.methodName = methodName;
/* 817 */       this.paramTypes = paramTypes;
/* 818 */       this.exact = exact;
/*     */ 
/* 820 */       this.hashCode = methodName.length();
/*     */     }
/*     */ 
/*     */     public boolean equals(Object obj)
/*     */     {
/* 828 */       if (!(obj instanceof MethodDescriptor)) {
/* 829 */         return false;
/*     */       }
/* 831 */       MethodDescriptor md = (MethodDescriptor)obj;
/*     */ 
/* 833 */       return ((this.exact == md.exact) && (this.methodName.equals(md.methodName)) && (this.cls.equals(md.cls)) && (Arrays.equals(this.paramTypes, md.paramTypes)));
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 848 */       return this.hashCode;
/*     */     }
/*     */   }
/*     */ }