/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.Iterator;
/*     */ 
/*     */ public class ResultSetDynaClass extends JDBCDynaClass
/*     */   implements DynaClass
/*     */ {
/*     */   protected ResultSet resultSet;
/*     */ 
/*     */   public ResultSetDynaClass(ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 104 */     this(resultSet, true);
/*     */   }
/*     */ 
/*     */   public ResultSetDynaClass(ResultSet resultSet, boolean lowerCase)
/*     */     throws SQLException
/*     */   {
/* 149 */     this.resultSet = null;
/*     */ 
/* 133 */     if (resultSet == null) {
/* 134 */       throw new NullPointerException();
/*     */     }
/* 136 */     this.resultSet = resultSet;
/* 137 */     this.lowerCase = lowerCase;
/* 138 */     introspect(resultSet);
/*     */   }
/*     */ 
/*     */   public Iterator iterator()
/*     */   {
/* 163 */     return new ResultSetIterator(this);
/*     */   }
/*     */ 
/*     */   ResultSet getResultSet()
/*     */   {
/* 176 */     return this.resultSet;
/*     */   }
/*     */ 
/*     */   protected Class loadClass(String className)
/*     */     throws SQLException
/*     */   {
/*     */     try
/*     */     {
/* 193 */       return super.getClass().getClassLoader().loadClass(className);
/*     */     }
/*     */     catch (Exception e) {
/* 196 */       throw new SQLException("Cannot load column class '" + className + "': " + e);
/*     */     }
/*     */   }
/*     */ }