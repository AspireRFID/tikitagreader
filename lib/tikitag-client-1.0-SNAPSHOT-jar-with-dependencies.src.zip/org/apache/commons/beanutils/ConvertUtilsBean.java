/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.File;
/*     */ import java.lang.reflect.Array;
/*     */ import java.math.BigDecimal;
/*     */ import java.math.BigInteger;
/*     */ import java.net.URL;
/*     */ import java.sql.Date;
/*     */ import java.sql.Time;
/*     */ import java.sql.Timestamp;
/*     */ import org.apache.commons.beanutils.converters.BigDecimalConverter;
/*     */ import org.apache.commons.beanutils.converters.BigIntegerConverter;
/*     */ import org.apache.commons.beanutils.converters.BooleanArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.BooleanConverter;
/*     */ import org.apache.commons.beanutils.converters.ByteArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.ByteConverter;
/*     */ import org.apache.commons.beanutils.converters.CharacterArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.CharacterConverter;
/*     */ import org.apache.commons.beanutils.converters.ClassConverter;
/*     */ import org.apache.commons.beanutils.converters.DoubleArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.DoubleConverter;
/*     */ import org.apache.commons.beanutils.converters.FileConverter;
/*     */ import org.apache.commons.beanutils.converters.FloatArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.FloatConverter;
/*     */ import org.apache.commons.beanutils.converters.IntegerArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.IntegerConverter;
/*     */ import org.apache.commons.beanutils.converters.LongArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.LongConverter;
/*     */ import org.apache.commons.beanutils.converters.ShortArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.ShortConverter;
/*     */ import org.apache.commons.beanutils.converters.SqlDateConverter;
/*     */ import org.apache.commons.beanutils.converters.SqlTimeConverter;
/*     */ import org.apache.commons.beanutils.converters.SqlTimestampConverter;
/*     */ import org.apache.commons.beanutils.converters.StringArrayConverter;
/*     */ import org.apache.commons.beanutils.converters.StringConverter;
/*     */ import org.apache.commons.beanutils.converters.URLConverter;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class ConvertUtilsBean
/*     */ {
/* 125 */   private FastHashMap converters = new FastHashMap();
/*     */ 
/* 130 */   private Log log = LogFactory.getLog(ConvertUtils.class);
/*     */ 
/*     */   /** @deprecated */
/* 151 */   private Boolean defaultBoolean = Boolean.FALSE;
/*     */ 
/*     */   /** @deprecated */
/* 179 */   private Byte defaultByte = new Byte(0);
/*     */ 
/*     */   /** @deprecated */
/* 207 */   private Character defaultCharacter = new Character(' ');
/*     */ 
/*     */   /** @deprecated */
/* 237 */   private Double defaultDouble = new Double(0.0D);
/*     */ 
/*     */   /** @deprecated */
/* 265 */   private Float defaultFloat = new Float(0.0F);
/*     */ 
/*     */   /** @deprecated */
/* 293 */   private Integer defaultInteger = new Integer(0);
/*     */ 
/*     */   /** @deprecated */
/* 321 */   private Long defaultLong = new Long(0L);
/*     */ 
/*     */   /** @deprecated */
/* 349 */   private static Short defaultShort = new Short(0);
/*     */ 
/*     */   protected static ConvertUtilsBean getInstance()
/*     */   {
/* 115 */     return BeanUtilsBean.getInstance().getConvertUtils();
/*     */   }
/*     */ 
/*     */   public ConvertUtilsBean()
/*     */   {
/* 136 */     this.converters.setFast(false);
/* 137 */     deregister();
/* 138 */     this.converters.setFast(true);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public boolean getDefaultBoolean()
/*     */   {
/* 159 */     return this.defaultBoolean.booleanValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultBoolean(boolean newDefaultBoolean)
/*     */   {
/* 168 */     this.defaultBoolean = new Boolean(newDefaultBoolean);
/* 169 */     register(new BooleanConverter(this.defaultBoolean), Boolean.TYPE);
/* 170 */     register(new BooleanConverter(this.defaultBoolean), Boolean.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public byte getDefaultByte()
/*     */   {
/* 187 */     return this.defaultByte.byteValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultByte(byte newDefaultByte)
/*     */   {
/* 196 */     this.defaultByte = new Byte(newDefaultByte);
/* 197 */     register(new ByteConverter(this.defaultByte), Byte.TYPE);
/* 198 */     register(new ByteConverter(this.defaultByte), Byte.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public char getDefaultCharacter()
/*     */   {
/* 215 */     return this.defaultCharacter.charValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultCharacter(char newDefaultCharacter)
/*     */   {
/* 224 */     this.defaultCharacter = new Character(newDefaultCharacter);
/* 225 */     register(new CharacterConverter(this.defaultCharacter), Character.TYPE);
/*     */ 
/* 227 */     register(new CharacterConverter(this.defaultCharacter), Character.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public double getDefaultDouble()
/*     */   {
/* 245 */     return this.defaultDouble.doubleValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultDouble(double newDefaultDouble)
/*     */   {
/* 254 */     this.defaultDouble = new Double(newDefaultDouble);
/* 255 */     register(new DoubleConverter(this.defaultDouble), Double.TYPE);
/* 256 */     register(new DoubleConverter(this.defaultDouble), Double.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public float getDefaultFloat()
/*     */   {
/* 273 */     return this.defaultFloat.floatValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultFloat(float newDefaultFloat)
/*     */   {
/* 282 */     this.defaultFloat = new Float(newDefaultFloat);
/* 283 */     register(new FloatConverter(this.defaultFloat), Float.TYPE);
/* 284 */     register(new FloatConverter(this.defaultFloat), Float.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public int getDefaultInteger()
/*     */   {
/* 301 */     return this.defaultInteger.intValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultInteger(int newDefaultInteger)
/*     */   {
/* 310 */     this.defaultInteger = new Integer(newDefaultInteger);
/* 311 */     register(new IntegerConverter(this.defaultInteger), Integer.TYPE);
/* 312 */     register(new IntegerConverter(this.defaultInteger), Integer.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public long getDefaultLong()
/*     */   {
/* 329 */     return this.defaultLong.longValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultLong(long newDefaultLong)
/*     */   {
/* 338 */     this.defaultLong = new Long(newDefaultLong);
/* 339 */     register(new LongConverter(this.defaultLong), Long.TYPE);
/* 340 */     register(new LongConverter(this.defaultLong), Long.class);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public short getDefaultShort()
/*     */   {
/* 357 */     return defaultShort.shortValue();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void setDefaultShort(short newDefaultShort)
/*     */   {
/* 366 */     defaultShort = new Short(newDefaultShort);
/* 367 */     register(new ShortConverter(defaultShort), Short.TYPE);
/* 368 */     register(new ShortConverter(defaultShort), Short.class);
/*     */   }
/*     */ 
/*     */   public String convert(Object value)
/*     */   {
/* 385 */     if (value == null)
/* 386 */       return ((String)null);
/* 387 */     if (value.getClass().isArray()) {
/* 388 */       if (Array.getLength(value) < 1) {
/* 389 */         return null;
/*     */       }
/* 391 */       value = Array.get(value, 0);
/* 392 */       if (value == null) {
/* 393 */         return ((String)null);
/*     */       }
/* 395 */       converter = lookup(String.class);
/* 396 */       return ((String)converter.convert(String.class, value));
/*     */     }
/*     */ 
/* 399 */     Converter converter = lookup(String.class);
/* 400 */     return ((String)converter.convert(String.class, value));
/*     */   }
/*     */ 
/*     */   public Object convert(String value, Class clazz)
/*     */   {
/* 417 */     if (this.log.isDebugEnabled()) {
/* 418 */       this.log.debug("Convert string '" + value + "' to class '" + clazz.getName() + "'");
/*     */     }
/*     */ 
/* 421 */     Converter converter = lookup(clazz);
/* 422 */     if (converter == null) {
/* 423 */       converter = lookup(String.class);
/*     */     }
/* 425 */     if (this.log.isTraceEnabled()) {
/* 426 */       this.log.trace("  Using converter " + converter);
/*     */     }
/* 428 */     return converter.convert(clazz, value);
/*     */   }
/*     */ 
/*     */   public Object convert(String[] values, Class clazz)
/*     */   {
/* 447 */     Class type = clazz;
/* 448 */     if (clazz.isArray()) {
/* 449 */       type = clazz.getComponentType();
/*     */     }
/* 451 */     if (this.log.isDebugEnabled()) {
/* 452 */       this.log.debug("Convert String[" + values.length + "] to class '" + type.getName() + "[]'");
/*     */     }
/*     */ 
/* 455 */     Converter converter = lookup(type);
/* 456 */     if (converter == null) {
/* 457 */       converter = lookup(String.class);
/*     */     }
/* 459 */     if (this.log.isTraceEnabled()) {
/* 460 */       this.log.trace("  Using converter " + converter);
/*     */     }
/* 462 */     Object array = Array.newInstance(type, values.length);
/* 463 */     for (int i = 0; i < values.length; ++i) {
/* 464 */       Array.set(array, i, converter.convert(type, values[i]));
/*     */     }
/* 466 */     return array;
/*     */   }
/*     */ 
/*     */   public void deregister()
/*     */   {
/* 477 */     boolean[] booleanArray = new boolean[0];
/* 478 */     byte[] byteArray = new byte[0];
/* 479 */     char[] charArray = new char[0];
/* 480 */     double[] doubleArray = new double[0];
/* 481 */     float[] floatArray = new float[0];
/* 482 */     int[] intArray = new int[0];
/* 483 */     long[] longArray = new long[0];
/* 484 */     short[] shortArray = new short[0];
/* 485 */     String[] stringArray = new String[0];
/*     */ 
/* 487 */     this.converters.clear();
/* 488 */     register(BigDecimal.class, new BigDecimalConverter());
/* 489 */     register(BigInteger.class, new BigIntegerConverter());
/* 490 */     register(Boolean.TYPE, new BooleanConverter(this.defaultBoolean));
/* 491 */     register(Boolean.class, new BooleanConverter(this.defaultBoolean));
/* 492 */     register(booleanArray.getClass(), new BooleanArrayConverter(booleanArray));
/*     */ 
/* 494 */     register(Byte.TYPE, new ByteConverter(this.defaultByte));
/* 495 */     register(Byte.class, new ByteConverter(this.defaultByte));
/* 496 */     register(byteArray.getClass(), new ByteArrayConverter(byteArray));
/*     */ 
/* 498 */     register(Character.TYPE, new CharacterConverter(this.defaultCharacter));
/*     */ 
/* 500 */     register(Character.class, new CharacterConverter(this.defaultCharacter));
/*     */ 
/* 502 */     register(charArray.getClass(), new CharacterArrayConverter(charArray));
/*     */ 
/* 504 */     register(Class.class, new ClassConverter());
/* 505 */     register(Double.TYPE, new DoubleConverter(this.defaultDouble));
/* 506 */     register(Double.class, new DoubleConverter(this.defaultDouble));
/* 507 */     register(doubleArray.getClass(), new DoubleArrayConverter(doubleArray));
/*     */ 
/* 509 */     register(Float.TYPE, new FloatConverter(this.defaultFloat));
/* 510 */     register(Float.class, new FloatConverter(this.defaultFloat));
/* 511 */     register(floatArray.getClass(), new FloatArrayConverter(floatArray));
/*     */ 
/* 513 */     register(Integer.TYPE, new IntegerConverter(this.defaultInteger));
/* 514 */     register(Integer.class, new IntegerConverter(this.defaultInteger));
/* 515 */     register(intArray.getClass(), new IntegerArrayConverter(intArray));
/*     */ 
/* 517 */     register(Long.TYPE, new LongConverter(this.defaultLong));
/* 518 */     register(Long.class, new LongConverter(this.defaultLong));
/* 519 */     register(longArray.getClass(), new LongArrayConverter(longArray));
/*     */ 
/* 521 */     register(Short.TYPE, new ShortConverter(defaultShort));
/* 522 */     register(Short.class, new ShortConverter(defaultShort));
/* 523 */     register(shortArray.getClass(), new ShortArrayConverter(shortArray));
/*     */ 
/* 525 */     register(String.class, new StringConverter());
/* 526 */     register(stringArray.getClass(), new StringArrayConverter(stringArray));
/*     */ 
/* 528 */     register(Date.class, new SqlDateConverter());
/* 529 */     register(Time.class, new SqlTimeConverter());
/* 530 */     register(Timestamp.class, new SqlTimestampConverter());
/* 531 */     register(File.class, new FileConverter());
/* 532 */     register(URL.class, new URLConverter());
/*     */   }
/*     */ 
/*     */   private void register(Class clazz, Converter converter)
/*     */   {
/* 538 */     register(converter, clazz);
/*     */   }
/*     */ 
/*     */   public void deregister(Class clazz)
/*     */   {
/* 549 */     this.converters.remove(clazz);
/*     */   }
/*     */ 
/*     */   public Converter lookup(Class clazz)
/*     */   {
/* 563 */     return ((Converter)this.converters.get(clazz));
/*     */   }
/*     */ 
/*     */   public void register(Converter converter, Class clazz)
/*     */   {
/* 578 */     this.converters.put(clazz, converter);
/*     */   }
/*     */ }