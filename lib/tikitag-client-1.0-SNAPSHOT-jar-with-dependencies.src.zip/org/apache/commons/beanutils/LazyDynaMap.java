/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class LazyDynaMap extends LazyDynaBean
/*     */   implements MutableDynaClass
/*     */ {
/*     */   protected String name;
/*     */   protected boolean restricted;
/*     */   protected boolean returnNull;
/*     */ 
/*     */   public LazyDynaMap()
/*     */   {
/*  75 */     this(null, (Map)null);
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(String name)
/*     */   {
/*  84 */     this(name, (Map)null);
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(Map values)
/*     */   {
/*  93 */     this(null, values);
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(String name, Map values)
/*     */   {
/*  66 */     this.returnNull = false;
/*     */ 
/* 103 */     this.name = ((name == null) ? "LazyDynaMap" : name);
/* 104 */     this.jdField_values_of_type_JavaUtilMap = ((values == null) ? newMap() : values);
/* 105 */     this.dynaClass = this;
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(DynaProperty[] properties)
/*     */   {
/* 114 */     this(null, properties);
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(String name, DynaProperty[] properties)
/*     */   {
/* 124 */     this(name, (Map)null);
/* 125 */     if (properties != null)
/* 126 */       for (int i = 0; i < properties.length; ++i)
/* 127 */         add(properties[i]);
/*     */   }
/*     */ 
/*     */   public LazyDynaMap(DynaClass dynaClass)
/*     */   {
/* 138 */     this(dynaClass.getName(), dynaClass.getDynaProperties());
/*     */   }
/*     */ 
/*     */   public void setMap(Map values)
/*     */   {
/* 147 */     this.jdField_values_of_type_JavaUtilMap = values;
/*     */   }
/*     */ 
/*     */   public void set(String name, Object value)
/*     */   {
/* 160 */     if ((isRestricted()) && (!(this.jdField_values_of_type_JavaUtilMap.containsKey(name)))) {
/* 161 */       throw new IllegalArgumentException("Invalid property name '" + name + "' (DynaClass is restricted)");
/*     */     }
/*     */ 
/* 165 */     this.jdField_values_of_type_JavaUtilMap.put(name, value);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 176 */     return this.name;
/*     */   }
/*     */ 
/*     */   public DynaProperty getDynaProperty(String name)
/*     */   {
/* 203 */     if (name == null) {
/* 204 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 208 */     if ((!(this.jdField_values_of_type_JavaUtilMap.containsKey(name))) && (isReturnNull())) {
/* 209 */       return null;
/*     */     }
/*     */ 
/* 212 */     Object value = this.jdField_values_of_type_JavaUtilMap.get(name);
/*     */ 
/* 214 */     if (value == null) {
/* 215 */       return new DynaProperty(name);
/*     */     }
/* 217 */     return new DynaProperty(name, value.getClass());
/*     */   }
/*     */ 
/*     */   public DynaProperty[] getDynaProperties()
/*     */   {
/* 233 */     int i = 0;
/* 234 */     DynaProperty[] properties = new DynaProperty[this.jdField_values_of_type_JavaUtilMap.size()];
/* 235 */     Iterator iterator = this.jdField_values_of_type_JavaUtilMap.keySet().iterator();
/*     */ 
/* 237 */     while (iterator.hasNext()) {
/* 238 */       String name = (String)iterator.next();
/* 239 */       Object value = this.jdField_values_of_type_JavaUtilMap.get(name);
/* 240 */       properties[(i++)] = new DynaProperty(name, (value == null) ? null : value.getClass());
/*     */     }
/*     */ 
/* 243 */     return properties;
/*     */   }
/*     */ 
/*     */   public DynaBean newInstance()
/*     */   {
/* 252 */     return new LazyDynaMap(this);
/*     */   }
/*     */ 
/*     */   public boolean isRestricted()
/*     */   {
/* 264 */     return this.restricted;
/*     */   }
/*     */ 
/*     */   public void setRestricted(boolean restricted)
/*     */   {
/* 273 */     this.restricted = restricted;
/*     */   }
/*     */ 
/*     */   public void add(String name)
/*     */   {
/* 285 */     add(name, null);
/*     */   }
/*     */ 
/*     */   public void add(String name, Class type)
/*     */   {
/* 302 */     if (name == null) {
/* 303 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 306 */     if (isRestricted()) {
/* 307 */       throw new IllegalStateException("DynaClass is currently restricted. No new properties can be added.");
/*     */     }
/* 309 */     Object value = this.jdField_values_of_type_JavaUtilMap.get(name);
/*     */ 
/* 312 */     if (value == null)
/* 313 */       this.jdField_values_of_type_JavaUtilMap.put(name, (type == null) ? null : createProperty(name, type));
/*     */   }
/*     */ 
/*     */   public void add(String name, Class type, boolean readable, boolean writeable)
/*     */   {
/* 340 */     throw new UnsupportedOperationException("readable/writable properties not supported");
/*     */   }
/*     */ 
/*     */   protected void add(DynaProperty property)
/*     */   {
/* 351 */     add(property.getName(), property.getType());
/*     */   }
/*     */ 
/*     */   public void remove(String name)
/*     */   {
/* 369 */     if (name == null) {
/* 370 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 373 */     if (isRestricted()) {
/* 374 */       throw new IllegalStateException("DynaClass is currently restricted. No properties can be removed.");
/*     */     }
/*     */ 
/* 378 */     if (this.jdField_values_of_type_JavaUtilMap.containsKey(name))
/* 379 */       this.jdField_values_of_type_JavaUtilMap.remove(name);
/*     */   }
/*     */ 
/*     */   public boolean isReturnNull()
/*     */   {
/* 393 */     return this.returnNull;
/*     */   }
/*     */ 
/*     */   public void setReturnNull(boolean returnNull)
/*     */   {
/* 402 */     this.returnNull = returnNull;
/*     */   }
/*     */ 
/*     */   protected boolean isDynaProperty(String name)
/*     */   {
/* 420 */     if (name == null) {
/* 421 */       throw new IllegalArgumentException("Property name is missing.");
/*     */     }
/*     */ 
/* 424 */     return this.jdField_values_of_type_JavaUtilMap.containsKey(name);
/*     */   }
/*     */ }