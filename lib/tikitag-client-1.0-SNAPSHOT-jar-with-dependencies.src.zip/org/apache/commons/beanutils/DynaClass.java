package org.apache.commons.beanutils;

public abstract interface DynaClass
{
  public abstract String getName();

  public abstract DynaProperty getDynaProperty(String paramString);

  public abstract DynaProperty[] getDynaProperties();

  public abstract DynaBean newInstance()
    throws IllegalAccessException, InstantiationException;
}