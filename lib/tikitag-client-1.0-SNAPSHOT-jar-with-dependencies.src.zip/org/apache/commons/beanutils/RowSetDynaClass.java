/*     */ package org.apache.commons.beanutils;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RowSetDynaClass extends JDBCDynaClass
/*     */   implements DynaClass, Serializable
/*     */ {
/*     */   protected int limit;
/*     */   protected List rows;
/*     */ 
/*     */   public RowSetDynaClass(ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 104 */     this(resultSet, true, -1);
/*     */   }
/*     */ 
/*     */   public RowSetDynaClass(ResultSet resultSet, int limit)
/*     */     throws SQLException
/*     */   {
/* 126 */     this(resultSet, true, limit);
/*     */   }
/*     */ 
/*     */   public RowSetDynaClass(ResultSet resultSet, boolean lowerCase)
/*     */     throws SQLException
/*     */   {
/* 151 */     this(resultSet, lowerCase, -1);
/*     */   }
/*     */ 
/*     */   public RowSetDynaClass(ResultSet resultSet, boolean lowerCase, int limit)
/*     */     throws SQLException
/*     */   {
/*  78 */     this.limit = -1;
/*     */ 
/*  85 */     this.rows = new ArrayList();
/*     */ 
/* 179 */     if (resultSet == null) {
/* 180 */       throw new NullPointerException();
/*     */     }
/* 182 */     this.lowerCase = lowerCase;
/* 183 */     this.limit = limit;
/* 184 */     introspect(resultSet);
/* 185 */     copy(resultSet);
/*     */   }
/*     */ 
/*     */   public List getRows()
/*     */   {
/* 202 */     return this.rows;
/*     */   }
/*     */ 
/*     */   protected void copy(ResultSet resultSet)
/*     */     throws SQLException
/*     */   {
/* 223 */     int cnt = 0;
/* 224 */     while ((resultSet.next()) && (((this.limit < 0) || (cnt++ < this.limit)))) {
/* 225 */       DynaBean bean = createDynaBean();
/* 226 */       for (int i = 0; i < this.jdField_properties_of_type_ArrayOfOrgApacheCommonsBeanutilsDynaProperty.length; ++i) {
/* 227 */         String name = this.jdField_properties_of_type_ArrayOfOrgApacheCommonsBeanutilsDynaProperty[i].getName();
/* 228 */         bean.set(name, resultSet.getObject(name));
/*     */       }
/* 230 */       this.rows.add(bean);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected DynaBean createDynaBean()
/*     */   {
/* 242 */     return new BasicDynaBean(this);
/*     */   }
/*     */ }