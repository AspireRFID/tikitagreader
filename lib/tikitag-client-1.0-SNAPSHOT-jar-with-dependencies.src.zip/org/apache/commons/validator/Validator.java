/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.HashMap;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ 
/*     */ public class Validator
/*     */   implements Serializable
/*     */ {
/*     */   public static final String BEAN_PARAM = "java.lang.Object";
/*     */   public static final String VALIDATOR_ACTION_PARAM = "org.apache.commons.validator.ValidatorAction";
/*     */   public static final String VALIDATOR_RESULTS_PARAM = "org.apache.commons.validator.ValidatorResults";
/*     */   public static final String FORM_PARAM = "org.apache.commons.validator.Form";
/*     */   public static final String FIELD_PARAM = "org.apache.commons.validator.Field";
/*     */   public static final String VALIDATOR_PARAM = "org.apache.commons.validator.Validator";
/*     */   public static final String LOCALE_PARAM = "java.util.Locale";
/*     */   protected ValidatorResources resources;
/*     */   protected String formName;
/*     */   protected String fieldName;
/*     */   protected Map parameters;
/*     */   protected int page;
/*     */   protected ClassLoader classLoader;
/*     */   protected boolean useContextClassLoader;
/*     */   protected boolean onlyReturnErrors;
/*     */ 
/*     */   public Validator(ValidatorResources resources)
/*     */   {
/* 144 */     this(resources, null);
/*     */   }
/*     */ 
/*     */   public Validator(ValidatorResources resources, String formName)
/*     */   {
/*  92 */     this.resources = null;
/*     */ 
/*  97 */     this.formName = null;
/*     */ 
/* 103 */     this.fieldName = null;
/*     */ 
/* 109 */     this.parameters = new HashMap();
/*     */ 
/* 114 */     this.page = 0;
/*     */ 
/* 122 */     this.classLoader = null;
/*     */ 
/* 128 */     this.useContextClassLoader = false;
/*     */ 
/* 133 */     this.onlyReturnErrors = false;
/*     */ 
/* 157 */     if (resources == null) {
/* 158 */       throw new IllegalArgumentException("Resources cannot be null.");
/*     */     }
/*     */ 
/* 161 */     this.resources = resources;
/* 162 */     this.formName = formName;
/*     */   }
/*     */ 
/*     */   public Validator(ValidatorResources resources, String formName, String fieldName)
/*     */   {
/*  92 */     this.resources = null;
/*     */ 
/*  97 */     this.formName = null;
/*     */ 
/* 103 */     this.fieldName = null;
/*     */ 
/* 109 */     this.parameters = new HashMap();
/*     */ 
/* 114 */     this.page = 0;
/*     */ 
/* 122 */     this.classLoader = null;
/*     */ 
/* 128 */     this.useContextClassLoader = false;
/*     */ 
/* 133 */     this.onlyReturnErrors = false;
/*     */ 
/* 177 */     if (resources == null) {
/* 178 */       throw new IllegalArgumentException("Resources cannot be null.");
/*     */     }
/*     */ 
/* 181 */     this.resources = resources;
/* 182 */     this.formName = formName;
/* 183 */     this.fieldName = fieldName;
/*     */   }
/*     */ 
/*     */   public void setParameter(String parameterClassName, Object parameterValue)
/*     */   {
/* 196 */     this.parameters.put(parameterClassName, parameterValue);
/*     */   }
/*     */ 
/*     */   public Object getParameterValue(String parameterClassName)
/*     */   {
/* 208 */     return this.parameters.get(parameterClassName);
/*     */   }
/*     */ 
/*     */   public String getFormName()
/*     */   {
/* 216 */     return this.formName;
/*     */   }
/*     */ 
/*     */   public void setFormName(String formName)
/*     */   {
/* 224 */     this.formName = formName;
/*     */   }
/*     */ 
/*     */   public void setFieldName(String fieldName)
/*     */   {
/* 234 */     this.fieldName = fieldName;
/*     */   }
/*     */ 
/*     */   public int getPage()
/*     */   {
/* 244 */     return this.page;
/*     */   }
/*     */ 
/*     */   public void setPage(int page)
/*     */   {
/* 254 */     this.page = page;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 267 */     this.formName = null;
/* 268 */     this.fieldName = null;
/* 269 */     this.parameters = new HashMap();
/* 270 */     this.page = 0;
/*     */   }
/*     */ 
/*     */   public boolean getUseContextClassLoader()
/*     */   {
/* 278 */     return this.useContextClassLoader;
/*     */   }
/*     */ 
/*     */   public void setUseContextClassLoader(boolean use)
/*     */   {
/* 291 */     this.useContextClassLoader = use;
/*     */   }
/*     */ 
/*     */   public ClassLoader getClassLoader()
/*     */   {
/* 306 */     if (this.classLoader != null) {
/* 307 */       return this.classLoader;
/*     */     }
/*     */ 
/* 310 */     if (this.useContextClassLoader) {
/* 311 */       ClassLoader contextLoader = Thread.currentThread().getContextClassLoader();
/* 312 */       if (contextLoader != null) {
/* 313 */         return contextLoader;
/*     */       }
/*     */     }
/*     */ 
/* 317 */     return super.getClass().getClassLoader();
/*     */   }
/*     */ 
/*     */   public void setClassLoader(ClassLoader classLoader)
/*     */   {
/* 328 */     this.classLoader = classLoader;
/*     */   }
/*     */ 
/*     */   public ValidatorResults validate()
/*     */     throws ValidatorException
/*     */   {
/* 340 */     Locale locale = (Locale)getParameterValue("java.util.Locale");
/*     */ 
/* 342 */     if (locale == null) {
/* 343 */       locale = Locale.getDefault();
/*     */     }
/*     */ 
/* 346 */     setParameter("org.apache.commons.validator.Validator", this);
/*     */ 
/* 348 */     Form form = this.resources.getForm(locale, this.formName);
/* 349 */     if (form != null) {
/* 350 */       setParameter("org.apache.commons.validator.Form", form);
/* 351 */       return form.validate(this.parameters, this.resources.getValidatorActions(), this.page, this.fieldName);
/*     */     }
/*     */ 
/* 358 */     return new ValidatorResults();
/*     */   }
/*     */ 
/*     */   public boolean getOnlyReturnErrors()
/*     */   {
/* 366 */     return this.onlyReturnErrors;
/*     */   }
/*     */ 
/*     */   public void setOnlyReturnErrors(boolean onlyReturnErrors)
/*     */   {
/* 376 */     this.onlyReturnErrors = onlyReturnErrors;
/*     */   }
/*     */ }