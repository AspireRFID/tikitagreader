/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Arg
/*     */   implements Cloneable, Serializable
/*     */ {
/*  45 */   protected String bundle = null;
/*     */ 
/*  50 */   protected String key = null;
/*     */ 
/*  55 */   protected String name = null;
/*     */ 
/*  62 */   protected int position = -1;
/*     */ 
/*  69 */   protected boolean resource = true;
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/*  77 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {
/*  80 */       throw new RuntimeException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getBundle()
/*     */   {
/*  90 */     return this.bundle;
/*     */   }
/*     */ 
/*     */   public String getKey()
/*     */   {
/*  98 */     return this.key;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/* 106 */     return this.name;
/*     */   }
/*     */ 
/*     */   public int getPosition()
/*     */   {
/* 114 */     return this.position;
/*     */   }
/*     */ 
/*     */   public boolean isResource()
/*     */   {
/* 122 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public void setBundle(String bundle)
/*     */   {
/* 131 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/* 139 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 147 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void setPosition(int position)
/*     */   {
/* 155 */     this.position = position;
/*     */   }
/*     */ 
/*     */   public void setResource(boolean resource)
/*     */   {
/* 163 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 171 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 173 */     results.append("Arg: name=");
/* 174 */     results.append(this.name);
/* 175 */     results.append("  key=");
/* 176 */     results.append(this.key);
/* 177 */     results.append("  position=");
/* 178 */     results.append(this.position);
/* 179 */     results.append("  bundle=");
/* 180 */     results.append(this.bundle);
/* 181 */     results.append("  resource=");
/* 182 */     results.append(this.resource);
/* 183 */     results.append("\n");
/*     */ 
/* 185 */     return results.toString();
/*     */   }
/*     */ }