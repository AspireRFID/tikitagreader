/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ValidatorResults
/*     */   implements Serializable
/*     */ {
/*  37 */   protected Map hResults = new HashMap();
/*     */ 
/*     */   public void merge(ValidatorResults results)
/*     */   {
/*  45 */     this.hResults.putAll(results.hResults);
/*     */   }
/*     */ 
/*     */   public void add(Field field, String validatorName, boolean result)
/*     */   {
/*  56 */     add(field, validatorName, result, null);
/*     */   }
/*     */ 
/*     */   public void add(Field field, String validatorName, boolean result, Object value)
/*     */   {
/*  73 */     ValidatorResult validatorResult = getValidatorResult(field.getKey());
/*     */ 
/*  75 */     if (validatorResult == null) {
/*  76 */       validatorResult = new ValidatorResult(field);
/*  77 */       this.hResults.put(field.getKey(), validatorResult);
/*     */     }
/*     */ 
/*  80 */     validatorResult.add(validatorName, result, value);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  87 */     this.hResults.clear();
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/*  97 */     return this.hResults.isEmpty();
/*     */   }
/*     */ 
/*     */   public ValidatorResult getValidatorResult(String key)
/*     */   {
/* 111 */     return ((ValidatorResult)this.hResults.get(key));
/*     */   }
/*     */ 
/*     */   public Set getPropertyNames()
/*     */   {
/* 120 */     return Collections.unmodifiableSet(this.hResults.keySet());
/*     */   }
/*     */ 
/*     */   public Map getResultValueMap()
/*     */   {
/* 130 */     Map results = new HashMap();
/*     */ 
/* 132 */     for (Iterator i = this.hResults.keySet().iterator(); i.hasNext(); ) {
/* 133 */       String propertyKey = (String)i.next();
/* 134 */       ValidatorResult vr = getValidatorResult(propertyKey);
/*     */ 
/* 136 */       for (Iterator x = vr.getActions(); x.hasNext(); ) {
/* 137 */         String actionKey = (String)x.next();
/* 138 */         Object result = vr.getResult(actionKey);
/*     */ 
/* 140 */         if ((result != null) && (!(result instanceof Boolean))) {
/* 141 */           results.put(propertyKey, result);
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 146 */     return results;
/*     */   }
/*     */ }