/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Var
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   public static final String JSTYPE_INT = "int";
/*     */   public static final String JSTYPE_STRING = "string";
/*     */   public static final String JSTYPE_REGEXP = "regexp";
/*  51 */   private String name = null;
/*     */ 
/*  56 */   private String value = null;
/*     */ 
/*  61 */   private String jsType = null;
/*     */ 
/*  66 */   private boolean resource = false;
/*     */ 
/*  71 */   private String bundle = null;
/*     */ 
/*     */   public Var()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Var(String name, String value, String jsType)
/*     */   {
/*  88 */     this.name = name;
/*  89 */     this.value = value;
/*  90 */     this.jsType = jsType;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  98 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 106 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getValue()
/*     */   {
/* 114 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(String value)
/*     */   {
/* 122 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public boolean isResource()
/*     */   {
/* 131 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public void setResource(boolean resource)
/*     */   {
/* 140 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public String getBundle()
/*     */   {
/* 149 */     return this.bundle;
/*     */   }
/*     */ 
/*     */   public void setBundle(String bundle)
/*     */   {
/* 158 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */   public String getJsType()
/*     */   {
/* 166 */     return this.jsType;
/*     */   }
/*     */ 
/*     */   public void setJsType(String jsType)
/*     */   {
/* 174 */     this.jsType = jsType;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 183 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {
/* 186 */       throw new RuntimeException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 195 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 197 */     results.append("Var: name=");
/* 198 */     results.append(this.name);
/* 199 */     results.append("  value=");
/* 200 */     results.append(this.value);
/* 201 */     results.append("  resource=");
/* 202 */     results.append(this.resource);
/* 203 */     if (this.resource) {
/* 204 */       results.append("  bundle=");
/* 205 */       results.append(this.bundle);
/*     */     }
/* 207 */     results.append("  jsType=");
/* 208 */     results.append(this.jsType);
/* 209 */     results.append("\n");
/*     */ 
/* 211 */     return results.toString();
/*     */   }
/*     */ }