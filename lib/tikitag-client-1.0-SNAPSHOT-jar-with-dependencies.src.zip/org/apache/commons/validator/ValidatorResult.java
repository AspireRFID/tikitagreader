/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ValidatorResult
/*     */   implements Serializable
/*     */ {
/*  37 */   protected Map hAction = new HashMap();
/*     */ 
/*  43 */   protected Field field = null;
/*     */ 
/*     */   public ValidatorResult(Field field)
/*     */   {
/*  51 */     this.field = field;
/*     */   }
/*     */ 
/*     */   public void add(String validatorName, boolean result)
/*     */   {
/*  60 */     add(validatorName, result, null);
/*     */   }
/*     */ 
/*     */   public void add(String validatorName, boolean result, Object value)
/*     */   {
/*  70 */     this.hAction.put(validatorName, new ResultStatus(result, value));
/*     */   }
/*     */ 
/*     */   public boolean containsAction(String validatorName)
/*     */   {
/*  79 */     return this.hAction.containsKey(validatorName);
/*     */   }
/*     */ 
/*     */   public boolean isValid(String validatorName)
/*     */   {
/*  88 */     ResultStatus status = (ResultStatus)this.hAction.get(validatorName);
/*  89 */     return ((status == null) ? false : status.isValid());
/*     */   }
/*     */ 
/*     */   public Object getResult(String validatorName)
/*     */   {
/*  98 */     ResultStatus status = (ResultStatus)this.hAction.get(validatorName);
/*  99 */     return ((status == null) ? null : status.getResult());
/*     */   }
/*     */ 
/*     */   public Iterator getActions()
/*     */   {
/* 107 */     return Collections.unmodifiableMap(this.hAction).keySet().iterator();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public Map getActionMap()
/*     */   {
/* 119 */     return Collections.unmodifiableMap(this.hAction);
/*     */   }
/*     */ 
/*     */   public Field getField()
/*     */   {
/* 127 */     return this.field;
/*     */   }
/*     */ 
/*     */   protected class ResultStatus
/*     */     implements Serializable
/*     */   {
/* 134 */     private boolean valid = false;
/* 135 */     private Object result = null;
/*     */ 
/*     */     public ResultStatus(boolean valid, Object result)
/*     */     {
/* 143 */       this.valid = valid;
/* 144 */       this.result = result;
/*     */     }
/*     */ 
/*     */     public boolean isValid()
/*     */     {
/* 152 */       return this.valid;
/*     */     }
/*     */ 
/*     */     public void setValid(boolean valid)
/*     */     {
/* 160 */       this.valid = valid;
/*     */     }
/*     */ 
/*     */     public Object getResult()
/*     */     {
/* 170 */       return this.result;
/*     */     }
/*     */ 
/*     */     public void setResult(Object result)
/*     */     {
/* 180 */       this.result = result;
/*     */     }
/*     */   }
/*     */ }