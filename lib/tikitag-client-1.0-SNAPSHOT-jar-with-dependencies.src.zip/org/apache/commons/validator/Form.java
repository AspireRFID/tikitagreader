/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ 
/*     */ public class Form
/*     */   implements Serializable
/*     */ {
/*  43 */   protected String name = null;
/*     */ 
/*  50 */   protected List lFields = new ArrayList();
/*     */ 
/*     */   /** @deprecated */
/*  57 */   protected FastHashMap hFields = new FastHashMap();
/*     */ 
/*  64 */   protected String inherit = null;
/*     */ 
/*  70 */   private boolean processed = false;
/*     */ 
/*     */   public String getName()
/*     */   {
/*  78 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  87 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public void addField(Field f)
/*     */   {
/*  96 */     this.lFields.add(f);
/*  97 */     this.hFields.put(f.getKey(), f);
/*     */   }
/*     */ 
/*     */   public List getFields()
/*     */   {
/* 107 */     return Collections.unmodifiableList(this.lFields);
/*     */   }
/*     */ 
/*     */   public Field getField(String fieldName)
/*     */   {
/* 119 */     return ((Field)this.hFields.get(fieldName));
/*     */   }
/*     */ 
/*     */   public boolean containsField(String fieldName)
/*     */   {
/* 130 */     return this.hFields.containsKey(fieldName);
/*     */   }
/*     */ 
/*     */   protected void merge(Form depends)
/*     */   {
/* 143 */     List templFields = new ArrayList();
/* 144 */     Map temphFields = new FastHashMap();
/* 145 */     Iterator dependsIt = depends.getFields().iterator();
/* 146 */     while (dependsIt.hasNext()) {
/* 147 */       Field defaultField = (Field)dependsIt.next();
/* 148 */       if (defaultField != null) {
/* 149 */         String fieldKey = defaultField.getKey();
/* 150 */         if (!(containsField(fieldKey))) {
/* 151 */           templFields.add(defaultField);
/* 152 */           temphFields.put(fieldKey, defaultField);
/*     */         }
/*     */         else {
/* 155 */           Field old = getField(fieldKey);
/* 156 */           this.hFields.remove(fieldKey);
/* 157 */           this.lFields.remove(old);
/* 158 */           templFields.add(old);
/* 159 */           temphFields.put(fieldKey, old);
/*     */         }
/*     */       }
/*     */     }
/* 163 */     this.lFields.addAll(0, templFields);
/* 164 */     this.hFields.putAll(temphFields);
/*     */   }
/*     */ 
/*     */   protected void process(Map globalConstants, Map constants, Map forms)
/*     */   {
/* 176 */     if (isProcessed()) {
/* 177 */       return;
/*     */     }
/*     */ 
/* 180 */     int n = 0;
/* 181 */     if (isExtending()) {
/* 182 */       Form parent = (Form)forms.get(this.inherit);
/* 183 */       if (parent != null) {
/* 184 */         if (!(parent.isProcessed()))
/*     */         {
/* 186 */           parent.process(constants, globalConstants, forms);
/*     */         }
/* 188 */         for (Iterator i = parent.getFields().iterator(); i.hasNext(); ) {
/* 189 */           Field f = (Field)i.next();
/*     */ 
/* 191 */           if (this.hFields.get(f.getKey()) == null) {
/* 192 */             this.lFields.add(n, f);
/* 193 */             this.hFields.put(f.getKey(), f);
/* 194 */             ++n;
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 199 */     this.hFields.setFast(true);
/*     */ 
/* 201 */     for (Iterator i = this.lFields.listIterator(n); i.hasNext(); ) {
/* 202 */       Field f = (Field)i.next();
/* 203 */       f.process(globalConstants, constants);
/*     */     }
/*     */ 
/* 206 */     this.processed = true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 215 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 217 */     results.append("Form: ");
/* 218 */     results.append(this.name);
/* 219 */     results.append("\n");
/*     */ 
/* 221 */     for (Iterator i = this.lFields.iterator(); i.hasNext(); ) {
/* 222 */       results.append("\tField: \n");
/* 223 */       results.append(i.next());
/* 224 */       results.append("\n");
/*     */     }
/*     */ 
/* 227 */     return results.toString();
/*     */   }
/*     */ 
/*     */   ValidatorResults validate(Map params, Map actions, int page)
/*     */     throws ValidatorException
/*     */   {
/* 245 */     return validate(params, actions, page, null);
/*     */   }
/*     */ 
/*     */   ValidatorResults validate(Map params, Map actions, int page, String fieldName)
/*     */     throws ValidatorException
/*     */   {
/* 265 */     ValidatorResults results = new ValidatorResults();
/* 266 */     params.put("org.apache.commons.validator.ValidatorResults", results);
/*     */ 
/* 269 */     if (fieldName != null) {
/* 270 */       Field field = (Field)this.hFields.get(fieldName);
/*     */ 
/* 272 */       if (field == null) {
/* 273 */         throw new ValidatorException("Unknown field " + fieldName + " in form " + getName());
/*     */       }
/* 275 */       params.put("org.apache.commons.validator.Field", field);
/*     */ 
/* 277 */       if (field.getPage() <= page)
/* 278 */         results.merge(field.validate(params, actions));
/*     */     }
/*     */     else {
/* 281 */       Iterator fields = this.lFields.iterator();
/* 282 */       while (fields.hasNext()) {
/* 283 */         Field field = (Field)fields.next();
/*     */ 
/* 285 */         params.put("org.apache.commons.validator.Field", field);
/*     */ 
/* 287 */         if (field.getPage() <= page) {
/* 288 */           results.merge(field.validate(params, actions));
/*     */         }
/*     */       }
/*     */     }
/*     */ 
/* 293 */     return results;
/*     */   }
/*     */ 
/*     */   public boolean isProcessed()
/*     */   {
/* 304 */     return this.processed;
/*     */   }
/*     */ 
/*     */   public String getExtends()
/*     */   {
/* 314 */     return this.inherit;
/*     */   }
/*     */ 
/*     */   public void setExtends(String inherit)
/*     */   {
/* 324 */     this.inherit = inherit;
/*     */   }
/*     */ 
/*     */   public boolean isExtending()
/*     */   {
/* 334 */     return (this.inherit != null);
/*     */   }
/*     */ 
/*     */   protected Map getFieldMap()
/*     */   {
/* 344 */     return this.hFields;
/*     */   }
/*     */ }