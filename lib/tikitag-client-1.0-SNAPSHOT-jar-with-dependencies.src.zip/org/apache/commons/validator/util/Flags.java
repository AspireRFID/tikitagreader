/*     */ package org.apache.commons.validator.util;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Flags
/*     */   implements Serializable
/*     */ {
/*  46 */   private long flags = 0L;
/*     */ 
/*     */   public Flags()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Flags(long flags)
/*     */   {
/*  62 */     this.flags = flags;
/*     */   }
/*     */ 
/*     */   public long getFlags()
/*     */   {
/*  71 */     return this.flags;
/*     */   }
/*     */ 
/*     */   public boolean isOn(long flag)
/*     */   {
/*  83 */     return ((this.flags & flag) > 0L);
/*     */   }
/*     */ 
/*     */   public boolean isOff(long flag)
/*     */   {
/*  95 */     return ((this.flags & flag) == 0L);
/*     */   }
/*     */ 
/*     */   public void turnOn(long flag)
/*     */   {
/* 105 */     this.flags |= flag;
/*     */   }
/*     */ 
/*     */   public void turnOff(long flag)
/*     */   {
/* 115 */     this.flags &= (flag ^ 0xFFFFFFFF);
/*     */   }
/*     */ 
/*     */   public void turnOffAll()
/*     */   {
/* 122 */     this.flags = 0L;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 130 */     this.flags = 0L;
/*     */   }
/*     */ 
/*     */   public void turnOnAll()
/*     */   {
/* 137 */     this.flags = 9223372036854775807L;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 148 */       return super.clone();
/*     */     } catch (CloneNotSupportedException e) {
/* 150 */       throw new RuntimeException("Couldn't clone Flags object.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 162 */     if (!(obj instanceof Flags)) {
/* 163 */       return false;
/*     */     }
/*     */ 
/* 166 */     if (obj == this) {
/* 167 */       return true;
/*     */     }
/*     */ 
/* 170 */     Flags f = (Flags)obj;
/*     */ 
/* 172 */     return (this.flags == f.flags);
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 182 */     return (int)this.flags;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 193 */     StringBuffer bin = new StringBuffer(Long.toBinaryString(this.flags));
/* 194 */     for (int i = 64 - bin.length(); i > 0; --i) {
/* 195 */       bin.insert(0, "0");
/*     */     }
/* 197 */     return bin.toString();
/*     */   }
/*     */ }