/*     */ package org.apache.commons.validator.util;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.validator.Arg;
/*     */ import org.apache.commons.validator.Msg;
/*     */ import org.apache.commons.validator.Var;
/*     */ 
/*     */ public class ValidatorUtils
/*     */ {
/*     */   public static String replace(String value, String key, String replaceValue)
/*     */   {
/*  55 */     if ((value == null) || (key == null) || (replaceValue == null)) {
/*  56 */       return value;
/*     */     }
/*     */ 
/*  59 */     int pos = value.indexOf(key);
/*     */ 
/*  61 */     if (pos < 0) {
/*  62 */       return value;
/*     */     }
/*     */ 
/*  65 */     int length = value.length();
/*  66 */     int start = pos;
/*  67 */     int end = pos + key.length();
/*     */ 
/*  69 */     if (length == key.length()) {
/*  70 */       value = replaceValue;
/*     */     }
/*  72 */     else if (end == length) {
/*  73 */       value = value.substring(0, start) + replaceValue;
/*     */     }
/*     */     else {
/*  76 */       value = value.substring(0, start) + replaceValue + replace(value.substring(end), key, replaceValue);
/*     */     }
/*     */ 
/*  82 */     return value;
/*     */   }
/*     */ 
/*     */   public static String getValueAsString(Object bean, String property)
/*     */   {
/*  99 */     Object value = null;
/*     */     try
/*     */     {
/* 102 */       value = PropertyUtils.getProperty(bean, property);
/*     */     }
/*     */     catch (IllegalAccessException e) {
/* 105 */       Log log = LogFactory.getLog(ValidatorUtils.class);
/* 106 */       log.error(e.getMessage(), e);
/*     */     } catch (InvocationTargetException e) {
/* 108 */       Log log = LogFactory.getLog(ValidatorUtils.class);
/* 109 */       log.error(e.getMessage(), e);
/*     */     } catch (NoSuchMethodException e) {
/* 111 */       Log log = LogFactory.getLog(ValidatorUtils.class);
/* 112 */       log.error(e.getMessage(), e);
/*     */     }
/*     */ 
/* 115 */     if (value == null) {
/* 116 */       return null;
/*     */     }
/*     */ 
/* 119 */     if (value instanceof String[]) {
/* 120 */       return ((((String[])value).length > 0) ? value.toString() : "");
/*     */     }
/* 122 */     if (value instanceof Collection) {
/* 123 */       return ((((Collection)value).isEmpty()) ? "" : value.toString());
/*     */     }
/*     */ 
/* 126 */     return value.toString();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public static FastHashMap copyFastHashMap(FastHashMap map)
/*     */   {
/* 144 */     FastHashMap results = new FastHashMap();
/*     */ 
/* 146 */     Iterator i = map.keySet().iterator();
/* 147 */     while (i.hasNext()) {
/* 148 */       String key = (String)i.next();
/* 149 */       Object value = map.get(key);
/*     */ 
/* 151 */       if (value instanceof Msg)
/* 152 */         results.put(key, ((Msg)value).clone());
/* 153 */       else if (value instanceof Arg)
/* 154 */         results.put(key, ((Arg)value).clone());
/* 155 */       else if (value instanceof Var)
/* 156 */         results.put(key, ((Var)value).clone());
/*     */       else {
/* 158 */         results.put(key, value);
/*     */       }
/*     */     }
/*     */ 
/* 162 */     results.setFast(true);
/* 163 */     return results;
/*     */   }
/*     */ 
/*     */   public static Map copyMap(Map map)
/*     */   {
/* 176 */     Map results = new HashMap();
/*     */ 
/* 178 */     Iterator iter = map.keySet().iterator();
/* 179 */     while (iter.hasNext()) {
/* 180 */       String key = (String)iter.next();
/* 181 */       Object value = map.get(key);
/*     */ 
/* 183 */       if (value instanceof Msg)
/* 184 */         results.put(key, ((Msg)value).clone());
/* 185 */       else if (value instanceof Arg)
/* 186 */         results.put(key, ((Arg)value).clone());
/* 187 */       else if (value instanceof Var)
/* 188 */         results.put(key, ((Var)value).clone());
/*     */       else {
/* 190 */         results.put(key, value);
/*     */       }
/*     */     }
/* 193 */     return results;
/*     */   }
/*     */ }