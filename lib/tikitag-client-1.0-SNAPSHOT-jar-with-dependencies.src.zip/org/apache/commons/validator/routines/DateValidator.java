/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Calendar;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class DateValidator extends AbstractCalendarValidator
/*     */ {
/*  87 */   private static final DateValidator VALIDATOR = new DateValidator();
/*     */ 
/*     */   public static DateValidator getInstance()
/*     */   {
/*  94 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public DateValidator()
/*     */   {
/* 102 */     this(true, 3);
/*     */   }
/*     */ 
/*     */   public DateValidator(boolean strict, int dateStyle)
/*     */   {
/* 114 */     super(strict, dateStyle, -1);
/*     */   }
/*     */ 
/*     */   public Date validate(String value)
/*     */   {
/* 126 */     return ((Date)parse(value, (String)null, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, TimeZone timeZone)
/*     */   {
/* 138 */     return ((Date)parse(value, (String)null, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, String pattern)
/*     */   {
/* 151 */     return ((Date)parse(value, pattern, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, String pattern, TimeZone timeZone)
/*     */   {
/* 165 */     return ((Date)parse(value, pattern, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, Locale locale)
/*     */   {
/* 177 */     return ((Date)parse(value, (String)null, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, Locale locale, TimeZone timeZone)
/*     */   {
/* 190 */     return ((Date)parse(value, (String)null, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, String pattern, Locale locale)
/*     */   {
/* 204 */     return ((Date)parse(value, pattern, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Date validate(String value, String pattern, Locale locale, TimeZone timeZone)
/*     */   {
/* 219 */     return ((Date)parse(value, pattern, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public int compareDates(Date value, Date compare, TimeZone timeZone)
/*     */   {
/* 233 */     Calendar calendarValue = getCalendar(value, timeZone);
/* 234 */     Calendar calendarCompare = getCalendar(compare, timeZone);
/* 235 */     return compare(calendarValue, calendarCompare, 5);
/*     */   }
/*     */ 
/*     */   public int compareWeeks(Date value, Date compare, TimeZone timeZone)
/*     */   {
/* 249 */     Calendar calendarValue = getCalendar(value, timeZone);
/* 250 */     Calendar calendarCompare = getCalendar(compare, timeZone);
/* 251 */     return compare(calendarValue, calendarCompare, 3);
/*     */   }
/*     */ 
/*     */   public int compareMonths(Date value, Date compare, TimeZone timeZone)
/*     */   {
/* 265 */     Calendar calendarValue = getCalendar(value, timeZone);
/* 266 */     Calendar calendarCompare = getCalendar(compare, timeZone);
/* 267 */     return compare(calendarValue, calendarCompare, 2);
/*     */   }
/*     */ 
/*     */   public int compareQuarters(Date value, Date compare, TimeZone timeZone)
/*     */   {
/* 281 */     return compareQuarters(value, compare, timeZone, 1);
/*     */   }
/*     */ 
/*     */   public int compareQuarters(Date value, Date compare, TimeZone timeZone, int monthOfFirstQuarter)
/*     */   {
/* 296 */     Calendar calendarValue = getCalendar(value, timeZone);
/* 297 */     Calendar calendarCompare = getCalendar(compare, timeZone);
/* 298 */     return super.compareQuarters(calendarValue, calendarCompare, monthOfFirstQuarter);
/*     */   }
/*     */ 
/*     */   public int compareYears(Date value, Date compare, TimeZone timeZone)
/*     */   {
/* 312 */     Calendar calendarValue = getCalendar(value, timeZone);
/* 313 */     Calendar calendarCompare = getCalendar(compare, timeZone);
/* 314 */     return compare(calendarValue, calendarCompare, 1);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 325 */     return value;
/*     */   }
/*     */ 
/*     */   private Calendar getCalendar(Date value, TimeZone timeZone)
/*     */   {
/* 336 */     Calendar calendar = null;
/* 337 */     if (timeZone != null)
/* 338 */       calendar = Calendar.getInstance(timeZone);
/*     */     else {
/* 340 */       calendar = Calendar.getInstance();
/*     */     }
/* 342 */     calendar.setTime(value);
/* 343 */     return calendar;
/*     */   }
/*     */ }