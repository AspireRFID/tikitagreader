/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class DoubleValidator extends AbstractNumberValidator
/*     */ {
/*  67 */   private static final DoubleValidator VALIDATOR = new DoubleValidator();
/*     */ 
/*     */   public static DoubleValidator getInstance()
/*     */   {
/*  74 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public DoubleValidator()
/*     */   {
/*  81 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public DoubleValidator(boolean strict, int formatType)
/*     */   {
/* 106 */     super(strict, formatType, true);
/*     */   }
/*     */ 
/*     */   public Double validate(String value)
/*     */   {
/* 118 */     return ((Double)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Double validate(String value, String pattern)
/*     */   {
/* 130 */     return ((Double)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Double validate(String value, Locale locale)
/*     */   {
/* 142 */     return ((Double)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Double validate(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     return ((Double)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(double value, double min, double max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Double value, double min, double max)
/*     */   {
/* 182 */     return isInRange(value.doubleValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(double value, double min)
/*     */   {
/* 194 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Double value, double min)
/*     */   {
/* 206 */     return minValue(value.doubleValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(double value, double max)
/*     */   {
/* 218 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Double value, double max)
/*     */   {
/* 230 */     return maxValue(value.doubleValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 243 */     if (value instanceof Double) {
/* 244 */       return value;
/*     */     }
/* 246 */     return new Double(((Number)value).doubleValue());
/*     */   }
/*     */ }