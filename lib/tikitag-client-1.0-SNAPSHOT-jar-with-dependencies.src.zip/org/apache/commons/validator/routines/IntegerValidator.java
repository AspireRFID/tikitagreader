/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class IntegerValidator extends AbstractNumberValidator
/*     */ {
/*  67 */   private static final IntegerValidator VALIDATOR = new IntegerValidator();
/*     */ 
/*     */   public static IntegerValidator getInstance()
/*     */   {
/*  74 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public IntegerValidator()
/*     */   {
/*  81 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public IntegerValidator(boolean strict, int formatType)
/*     */   {
/* 106 */     super(strict, formatType, false);
/*     */   }
/*     */ 
/*     */   public Integer validate(String value)
/*     */   {
/* 118 */     return ((Integer)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Integer validate(String value, String pattern)
/*     */   {
/* 130 */     return ((Integer)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Integer validate(String value, Locale locale)
/*     */   {
/* 142 */     return ((Integer)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Integer validate(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     return ((Integer)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(int value, int min, int max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Integer value, int min, int max)
/*     */   {
/* 182 */     return isInRange(value.intValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(int value, int min)
/*     */   {
/* 194 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Integer value, int min)
/*     */   {
/* 206 */     return minValue(value.intValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(int value, int max)
/*     */   {
/* 218 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Integer value, int max)
/*     */   {
/* 230 */     return maxValue(value.intValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 244 */     long longValue = ((Number)value).longValue();
/*     */ 
/* 246 */     if ((longValue < -2147483648L) || (longValue > 2147483647L))
/*     */     {
/* 248 */       return null;
/*     */     }
/* 250 */     return new Integer((int)longValue);
/*     */   }
/*     */ }