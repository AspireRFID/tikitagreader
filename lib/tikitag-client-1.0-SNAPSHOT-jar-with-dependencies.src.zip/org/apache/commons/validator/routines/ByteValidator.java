/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class ByteValidator extends AbstractNumberValidator
/*     */ {
/*  67 */   private static final ByteValidator VALIDATOR = new ByteValidator();
/*     */ 
/*     */   public static ByteValidator getInstance()
/*     */   {
/*  74 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public ByteValidator()
/*     */   {
/*  81 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public ByteValidator(boolean strict, int formatType)
/*     */   {
/* 106 */     super(strict, formatType, false);
/*     */   }
/*     */ 
/*     */   public Byte validate(String value)
/*     */   {
/* 118 */     return ((Byte)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Byte validate(String value, String pattern)
/*     */   {
/* 130 */     return ((Byte)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Byte validate(String value, Locale locale)
/*     */   {
/* 142 */     return ((Byte)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Byte validate(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     return ((Byte)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(byte value, byte min, byte max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Byte value, byte min, byte max)
/*     */   {
/* 182 */     return isInRange(value.byteValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(byte value, byte min)
/*     */   {
/* 194 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Byte value, byte min)
/*     */   {
/* 206 */     return minValue(value.byteValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(byte value, byte max)
/*     */   {
/* 218 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Byte value, byte max)
/*     */   {
/* 230 */     return maxValue(value.byteValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 244 */     long longValue = ((Number)value).longValue();
/*     */ 
/* 246 */     if ((longValue < -128L) || (longValue > 127L))
/*     */     {
/* 248 */       return null;
/*     */     }
/* 250 */     return new Byte((byte)(int)longValue);
/*     */   }
/*     */ }