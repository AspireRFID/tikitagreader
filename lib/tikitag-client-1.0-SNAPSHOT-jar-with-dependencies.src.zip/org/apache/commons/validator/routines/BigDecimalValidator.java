/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class BigDecimalValidator extends AbstractNumberValidator
/*     */ {
/*  71 */   private static final BigDecimalValidator VALIDATOR = new BigDecimalValidator();
/*     */ 
/*     */   public static BigDecimalValidator getInstance()
/*     */   {
/*  78 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public BigDecimalValidator()
/*     */   {
/*  85 */     this(true);
/*     */   }
/*     */ 
/*     */   public BigDecimalValidator(boolean strict)
/*     */   {
/*  95 */     this(strict, 0, true);
/*     */   }
/*     */ 
/*     */   protected BigDecimalValidator(boolean strict, int formatType, boolean allowFractions)
/*     */   {
/* 123 */     super(strict, formatType, allowFractions);
/*     */   }
/*     */ 
/*     */   public BigDecimal validate(String value)
/*     */   {
/* 135 */     return ((BigDecimal)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public BigDecimal validate(String value, String pattern)
/*     */   {
/* 148 */     return ((BigDecimal)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public BigDecimal validate(String value, Locale locale)
/*     */   {
/* 160 */     return ((BigDecimal)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public BigDecimal validate(String value, String pattern, Locale locale)
/*     */   {
/* 174 */     return ((BigDecimal)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(BigDecimal value, double min, double max)
/*     */   {
/* 187 */     return ((value.doubleValue() >= min) && (value.doubleValue() <= max));
/*     */   }
/*     */ 
/*     */   public boolean minValue(BigDecimal value, double min)
/*     */   {
/* 199 */     return (value.doubleValue() >= min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(BigDecimal value, double max)
/*     */   {
/* 211 */     return (value.doubleValue() <= max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 223 */     BigDecimal decimal = null;
/* 224 */     if (value instanceof Long)
/* 225 */       decimal = BigDecimal.valueOf(((Long)value).longValue());
/*     */     else {
/* 227 */       decimal = new BigDecimal(value.toString());
/*     */     }
/*     */ 
/* 230 */     int scale = determineScale((NumberFormat)formatter);
/* 231 */     if (scale >= 0) {
/* 232 */       decimal = decimal.setScale(scale, 1);
/*     */     }
/*     */ 
/* 235 */     return decimal;
/*     */   }
/*     */ }