/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.math.BigDecimal;
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ 
/*     */ public class PercentValidator extends BigDecimalValidator
/*     */ {
/*  50 */   private static final PercentValidator VALIDATOR = new PercentValidator();
/*     */   private static final char PERCENT_SYMBOL = 37;
/*  55 */   private static final BigDecimal POINT_ZERO_ONE = new BigDecimal("0.01");
/*     */ 
/*     */   public static BigDecimalValidator getInstance()
/*     */   {
/*  62 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public PercentValidator()
/*     */   {
/*  69 */     this(true);
/*     */   }
/*     */ 
/*     */   public PercentValidator(boolean strict)
/*     */   {
/*  79 */     super(strict, 2, true);
/*     */   }
/*     */ 
/*     */   protected Object parse(String value, Format formatter)
/*     */   {
/*  98 */     BigDecimal parsedValue = (BigDecimal)super.parse(value, formatter);
/*  99 */     if ((parsedValue != null) || (!(formatter instanceof DecimalFormat))) {
/* 100 */       return parsedValue;
/*     */     }
/*     */ 
/* 104 */     DecimalFormat decimalFormat = (DecimalFormat)formatter;
/* 105 */     String pattern = decimalFormat.toPattern();
/* 106 */     if (pattern.indexOf(37) >= 0) {
/* 107 */       StringBuffer buffer = new StringBuffer(pattern.length());
/* 108 */       for (int i = 0; i < pattern.length(); ++i) {
/* 109 */         if (pattern.charAt(i) != '%') {
/* 110 */           buffer.append(pattern.charAt(i));
/*     */         }
/*     */       }
/* 113 */       decimalFormat.applyPattern(buffer.toString());
/* 114 */       parsedValue = (BigDecimal)super.parse(value, decimalFormat);
/*     */ 
/* 117 */       if (parsedValue != null) {
/* 118 */         parsedValue = parsedValue.multiply(POINT_ZERO_ONE);
/*     */       }
/*     */     }
/*     */ 
/* 122 */     return parsedValue;
/*     */   }
/*     */ }