/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class LongValidator extends AbstractNumberValidator
/*     */ {
/*  66 */   private static final LongValidator VALIDATOR = new LongValidator();
/*     */ 
/*     */   public static LongValidator getInstance()
/*     */   {
/*  73 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public LongValidator()
/*     */   {
/*  80 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public LongValidator(boolean strict, int formatType)
/*     */   {
/* 105 */     super(strict, formatType, false);
/*     */   }
/*     */ 
/*     */   public Long validate(String value)
/*     */   {
/* 117 */     return ((Long)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Long validate(String value, String pattern)
/*     */   {
/* 129 */     return ((Long)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Long validate(String value, Locale locale)
/*     */   {
/* 141 */     return ((Long)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Long validate(String value, String pattern, Locale locale)
/*     */   {
/* 155 */     return ((Long)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(long value, long min, long max)
/*     */   {
/* 168 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Long value, long min, long max)
/*     */   {
/* 181 */     return isInRange(value.longValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(long value, long min)
/*     */   {
/* 193 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Long value, long min)
/*     */   {
/* 205 */     return minValue(value.longValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(long value, long max)
/*     */   {
/* 217 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Long value, long max)
/*     */   {
/* 229 */     return maxValue(value.longValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 242 */     if (value instanceof Long) {
/* 243 */       return value;
/*     */     }
/* 245 */     return new Long(((Number)value).longValue());
/*     */   }
/*     */ }