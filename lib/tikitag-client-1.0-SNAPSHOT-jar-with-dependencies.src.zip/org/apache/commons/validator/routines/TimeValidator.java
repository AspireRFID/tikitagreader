/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.Format;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class TimeValidator extends AbstractCalendarValidator
/*     */ {
/*  87 */   private static final TimeValidator VALIDATOR = new TimeValidator();
/*     */ 
/*     */   public static TimeValidator getInstance()
/*     */   {
/*  94 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public TimeValidator()
/*     */   {
/* 102 */     this(true, 3);
/*     */   }
/*     */ 
/*     */   public TimeValidator(boolean strict, int timeStyle)
/*     */   {
/* 114 */     super(strict, -1, timeStyle);
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value)
/*     */   {
/* 126 */     return ((Calendar)parse(value, (String)null, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, TimeZone timeZone)
/*     */   {
/* 138 */     return ((Calendar)parse(value, (String)null, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern)
/*     */   {
/* 150 */     return ((Calendar)parse(value, pattern, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, TimeZone timeZone)
/*     */   {
/* 163 */     return ((Calendar)parse(value, pattern, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, Locale locale)
/*     */   {
/* 175 */     return ((Calendar)parse(value, (String)null, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, Locale locale, TimeZone timeZone)
/*     */   {
/* 188 */     return ((Calendar)parse(value, (String)null, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, Locale locale)
/*     */   {
/* 202 */     return ((Calendar)parse(value, pattern, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, Locale locale, TimeZone timeZone)
/*     */   {
/* 217 */     return ((Calendar)parse(value, pattern, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public int compareTime(Calendar value, Calendar compare)
/*     */   {
/* 230 */     return compareTime(value, compare, 14);
/*     */   }
/*     */ 
/*     */   public int compareSeconds(Calendar value, Calendar compare)
/*     */   {
/* 243 */     return compareTime(value, compare, 13);
/*     */   }
/*     */ 
/*     */   public int compareMinutes(Calendar value, Calendar compare)
/*     */   {
/* 256 */     return compareTime(value, compare, 12);
/*     */   }
/*     */ 
/*     */   public int compareHours(Calendar value, Calendar compare)
/*     */   {
/* 269 */     return compareTime(value, compare, 11);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 280 */     return ((DateFormat)formatter).getCalendar();
/*     */   }
/*     */ }