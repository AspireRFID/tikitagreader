/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.Format;
/*     */ import java.text.ParsePosition;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public abstract class AbstractFormatValidator
/*     */   implements Serializable
/*     */ {
/*  35 */   private boolean strict = true;
/*     */ 
/*     */   public AbstractFormatValidator(boolean strict)
/*     */   {
/*  44 */     this.strict = strict;
/*     */   }
/*     */ 
/*     */   public boolean isStrict()
/*     */   {
/*  65 */     return this.strict;
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value)
/*     */   {
/*  75 */     return isValid(value, (String)null, (Locale)null);
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, String pattern)
/*     */   {
/*  86 */     return isValid(value, pattern, (Locale)null);
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, Locale locale)
/*     */   {
/*  97 */     return isValid(value, (String)null, locale);
/*     */   }
/*     */ 
/*     */   public abstract boolean isValid(String paramString1, String paramString2, Locale paramLocale);
/*     */ 
/*     */   public String format(Object value)
/*     */   {
/* 118 */     return format(value, (String)null, (Locale)null);
/*     */   }
/*     */ 
/*     */   public String format(Object value, String pattern)
/*     */   {
/* 130 */     return format(value, pattern, (Locale)null);
/*     */   }
/*     */ 
/*     */   public String format(Object value, Locale locale)
/*     */   {
/* 142 */     return format(value, (String)null, locale);
/*     */   }
/*     */ 
/*     */   public String format(Object value, String pattern, Locale locale)
/*     */   {
/* 155 */     Format formatter = getFormat(pattern, locale);
/* 156 */     return format(value, formatter);
/*     */   }
/*     */ 
/*     */   protected String format(Object value, Format formatter)
/*     */   {
/* 167 */     return formatter.format(value);
/*     */   }
/*     */ 
/*     */   protected Object parse(String value, Format formatter)
/*     */   {
/* 179 */     ParsePosition pos = new ParsePosition(0);
/* 180 */     Object parsedValue = formatter.parseObject(value, pos);
/* 181 */     if (pos.getErrorIndex() > -1) {
/* 182 */       return null;
/*     */     }
/*     */ 
/* 185 */     if ((isStrict()) && (pos.getIndex() < value.length())) {
/* 186 */       return null;
/*     */     }
/*     */ 
/* 189 */     if (parsedValue != null) {
/* 190 */       parsedValue = processParsedValue(parsedValue, formatter);
/*     */     }
/*     */ 
/* 193 */     return parsedValue;
/*     */   }
/*     */ 
/*     */   protected abstract Object processParsedValue(Object paramObject, Format paramFormat);
/*     */ 
/*     */   protected abstract Format getFormat(String paramString, Locale paramLocale);
/*     */ }