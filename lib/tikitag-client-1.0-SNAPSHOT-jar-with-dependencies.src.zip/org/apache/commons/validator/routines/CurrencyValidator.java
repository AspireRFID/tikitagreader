/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.Format;
/*     */ 
/*     */ public class CurrencyValidator extends BigDecimalValidator
/*     */ {
/*  47 */   private static final CurrencyValidator VALIDATOR = new CurrencyValidator();
/*     */   private static final char CURRENCY_SYMBOL = 164;
/*     */ 
/*     */   public static BigDecimalValidator getInstance()
/*     */   {
/*  57 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public CurrencyValidator()
/*     */   {
/*  64 */     this(true, true);
/*     */   }
/*     */ 
/*     */   public CurrencyValidator(boolean strict, boolean allowFractions)
/*     */   {
/*  76 */     super(strict, 1, allowFractions);
/*     */   }
/*     */ 
/*     */   protected Object parse(String value, Format formatter)
/*     */   {
/*  95 */     Object parsedValue = super.parse(value, formatter);
/*  96 */     if ((parsedValue != null) || (!(formatter instanceof DecimalFormat))) {
/*  97 */       return parsedValue;
/*     */     }
/*     */ 
/* 101 */     DecimalFormat decimalFormat = (DecimalFormat)formatter;
/* 102 */     String pattern = decimalFormat.toPattern();
/* 103 */     if (pattern.indexOf(164) >= 0) {
/* 104 */       StringBuffer buffer = new StringBuffer(pattern.length());
/* 105 */       for (int i = 0; i < pattern.length(); ++i) {
/* 106 */         if (pattern.charAt(i) != 164) {
/* 107 */           buffer.append(pattern.charAt(i));
/*     */         }
/*     */       }
/* 110 */       decimalFormat.applyPattern(buffer.toString());
/* 111 */       parsedValue = super.parse(value, decimalFormat);
/*     */     }
/* 113 */     return parsedValue;
/*     */   }
/*     */ }