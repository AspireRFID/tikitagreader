/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.math.BigInteger;
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class BigIntegerValidator extends AbstractNumberValidator
/*     */ {
/*  68 */   private static final BigIntegerValidator VALIDATOR = new BigIntegerValidator();
/*     */ 
/*     */   public static BigIntegerValidator getInstance()
/*     */   {
/*  75 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public BigIntegerValidator()
/*     */   {
/*  82 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public BigIntegerValidator(boolean strict, int formatType)
/*     */   {
/* 107 */     super(strict, formatType, false);
/*     */   }
/*     */ 
/*     */   public BigInteger validate(String value)
/*     */   {
/* 119 */     return ((BigInteger)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public BigInteger validate(String value, String pattern)
/*     */   {
/* 131 */     return ((BigInteger)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public BigInteger validate(String value, Locale locale)
/*     */   {
/* 143 */     return ((BigInteger)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public BigInteger validate(String value, String pattern, Locale locale)
/*     */   {
/* 157 */     return ((BigInteger)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(BigInteger value, long min, long max)
/*     */   {
/* 170 */     return ((value.longValue() >= min) && (value.longValue() <= max));
/*     */   }
/*     */ 
/*     */   public boolean minValue(BigInteger value, long min)
/*     */   {
/* 182 */     return (value.longValue() >= min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(BigInteger value, long max)
/*     */   {
/* 194 */     return (value.longValue() <= max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 206 */     return BigInteger.valueOf(((Number)value).longValue());
/*     */   }
/*     */ }