/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.DecimalFormat;
/*     */ import java.text.DecimalFormatSymbols;
/*     */ import java.text.Format;
/*     */ import java.text.NumberFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public abstract class AbstractNumberValidator extends AbstractFormatValidator
/*     */ {
/*     */   public static final int STANDARD_FORMAT = 0;
/*     */   public static final int CURRENCY_FORMAT = 1;
/*     */   public static final int PERCENT_FORMAT = 2;
/*     */   private boolean allowFractions;
/*     */   private int formatType;
/*     */ 
/*     */   public AbstractNumberValidator(boolean strict, int formatType, boolean allowFractions)
/*     */   {
/*  60 */     super(strict);
/*  61 */     this.allowFractions = allowFractions;
/*  62 */     this.formatType = formatType;
/*     */   }
/*     */ 
/*     */   public boolean isAllowFractions()
/*     */   {
/*  73 */     return this.allowFractions;
/*     */   }
/*     */ 
/*     */   public int getFormatType()
/*     */   {
/*  83 */     return this.formatType;
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, String pattern, Locale locale)
/*     */   {
/*  96 */     Object parsedValue = parse(value, pattern, locale);
/*  97 */     return (parsedValue != null);
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Number value, Number min, Number max)
/*     */   {
/* 110 */     return ((minValue(value, min)) && (maxValue(value, max)));
/*     */   }
/*     */ 
/*     */   public boolean minValue(Number value, Number min)
/*     */   {
/* 122 */     if (isAllowFractions()) {
/* 123 */       return (value.doubleValue() >= min.doubleValue());
/*     */     }
/* 125 */     return (value.longValue() >= min.longValue());
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Number value, Number max)
/*     */   {
/* 138 */     if (isAllowFractions()) {
/* 139 */       return (value.doubleValue() <= max.doubleValue());
/*     */     }
/* 141 */     return (value.longValue() <= max.longValue());
/*     */   }
/*     */ 
/*     */   protected Object parse(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     value = (value == null) ? null : value.trim();
/* 157 */     if ((value == null) || (value.length() == 0)) {
/* 158 */       return null;
/*     */     }
/* 160 */     Format formatter = getFormat(pattern, locale);
/* 161 */     return parse(value, formatter);
/*     */   }
/*     */ 
/*     */   protected abstract Object processParsedValue(Object paramObject, Format paramFormat);
/*     */ 
/*     */   protected Format getFormat(String pattern, Locale locale)
/*     */   {
/* 187 */     NumberFormat formatter = null;
/* 188 */     boolean usePattern = (pattern != null) && (pattern.length() > 0);
/* 189 */     if (!(usePattern)) {
/* 190 */       formatter = (NumberFormat)getFormat(locale);
/* 191 */     } else if (locale == null) {
/* 192 */       formatter = new DecimalFormat(pattern);
/*     */     } else {
/* 194 */       DecimalFormatSymbols symbols = new DecimalFormatSymbols(locale);
/* 195 */       formatter = new DecimalFormat(pattern, symbols);
/*     */     }
/*     */ 
/* 198 */     if (determineScale(formatter) == 0) {
/* 199 */       formatter.setParseIntegerOnly(true);
/*     */     }
/* 201 */     return formatter;
/*     */   }
/*     */ 
/*     */   protected int determineScale(NumberFormat format)
/*     */   {
/* 212 */     if (!(isStrict())) {
/* 213 */       return -1;
/*     */     }
/* 215 */     if ((!(isAllowFractions())) || (format.isParseIntegerOnly())) {
/* 216 */       return 0;
/*     */     }
/* 218 */     int minimumFraction = format.getMinimumFractionDigits();
/* 219 */     int maximumFraction = format.getMaximumFractionDigits();
/* 220 */     if (minimumFraction != maximumFraction) {
/* 221 */       return -1;
/*     */     }
/* 223 */     int scale = minimumFraction;
/* 224 */     if (format instanceof DecimalFormat) {
/* 225 */       int multiplier = ((DecimalFormat)format).getMultiplier();
/* 226 */       if (multiplier == 100)
/* 227 */         scale += 2;
/* 228 */       else if (multiplier == 1000)
/* 229 */         scale += 3;
/*     */     }
/* 231 */     else if (this.formatType == 2) {
/* 232 */       scale += 2;
/*     */     }
/* 234 */     return scale;
/*     */   }
/*     */ 
/*     */   protected Format getFormat(Locale locale)
/*     */   {
/* 245 */     NumberFormat formatter = null;
/* 246 */     switch (this.formatType)
/*     */     {
/*     */     case 1:
/* 248 */       if (locale == null) {
/* 249 */         formatter = NumberFormat.getCurrencyInstance(); break label86:
/*     */       }
/* 251 */       formatter = NumberFormat.getCurrencyInstance(locale);
/*     */ 
/* 253 */       break;
/*     */     case 2:
/* 255 */       if (locale == null) {
/* 256 */         formatter = NumberFormat.getPercentInstance(); break label86:
/*     */       }
/* 258 */       formatter = NumberFormat.getPercentInstance(locale);
/*     */ 
/* 260 */       break;
/*     */     default:
/* 262 */       if (locale == null) {
/* 263 */         formatter = NumberFormat.getInstance(); break label86:
/*     */       }
/* 265 */       formatter = NumberFormat.getInstance(locale);
/*     */     }
/*     */ 
/* 269 */     label86: return formatter;
/*     */   }
/*     */ }