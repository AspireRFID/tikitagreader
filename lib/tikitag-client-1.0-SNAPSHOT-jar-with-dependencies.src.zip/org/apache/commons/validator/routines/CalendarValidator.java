/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.Format;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public class CalendarValidator extends AbstractCalendarValidator
/*     */ {
/*  90 */   private static final CalendarValidator VALIDATOR = new CalendarValidator();
/*     */ 
/*     */   public static CalendarValidator getInstance()
/*     */   {
/*  97 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public CalendarValidator()
/*     */   {
/* 105 */     this(true, 3);
/*     */   }
/*     */ 
/*     */   public CalendarValidator(boolean strict, int dateStyle)
/*     */   {
/* 117 */     super(strict, dateStyle, -1);
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value)
/*     */   {
/* 129 */     return ((Calendar)parse(value, (String)null, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, TimeZone timeZone)
/*     */   {
/* 142 */     return ((Calendar)parse(value, (String)null, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern)
/*     */   {
/* 154 */     return ((Calendar)parse(value, pattern, (Locale)null, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, TimeZone timeZone)
/*     */   {
/* 167 */     return ((Calendar)parse(value, pattern, (Locale)null, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, Locale locale)
/*     */   {
/* 179 */     return ((Calendar)parse(value, (String)null, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, Locale locale, TimeZone timeZone)
/*     */   {
/* 192 */     return ((Calendar)parse(value, (String)null, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, Locale locale)
/*     */   {
/* 206 */     return ((Calendar)parse(value, pattern, locale, (TimeZone)null));
/*     */   }
/*     */ 
/*     */   public Calendar validate(String value, String pattern, Locale locale, TimeZone timeZone)
/*     */   {
/* 221 */     return ((Calendar)parse(value, pattern, locale, timeZone));
/*     */   }
/*     */ 
/*     */   public static void adjustToTimeZone(Calendar value, TimeZone timeZone)
/*     */   {
/* 231 */     if (value.getTimeZone().hasSameRules(timeZone)) {
/* 232 */       value.setTimeZone(timeZone);
/*     */     } else {
/* 234 */       int year = value.get(1);
/* 235 */       int month = value.get(2);
/* 236 */       int date = value.get(5);
/* 237 */       int hour = value.get(11);
/* 238 */       int minute = value.get(12);
/* 239 */       value.setTimeZone(timeZone);
/* 240 */       value.set(year, month, date, hour, minute);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int compareDates(Calendar value, Calendar compare)
/*     */   {
/* 254 */     return compare(value, compare, 5);
/*     */   }
/*     */ 
/*     */   public int compareWeeks(Calendar value, Calendar compare)
/*     */   {
/* 267 */     return compare(value, compare, 3);
/*     */   }
/*     */ 
/*     */   public int compareMonths(Calendar value, Calendar compare)
/*     */   {
/* 280 */     return compare(value, compare, 2);
/*     */   }
/*     */ 
/*     */   public int compareQuarters(Calendar value, Calendar compare)
/*     */   {
/* 293 */     return compareQuarters(value, compare, 1);
/*     */   }
/*     */ 
/*     */   public int compareQuarters(Calendar value, Calendar compare, int monthOfFirstQuarter)
/*     */   {
/* 307 */     return super.compareQuarters(value, compare, monthOfFirstQuarter);
/*     */   }
/*     */ 
/*     */   public int compareYears(Calendar value, Calendar compare)
/*     */   {
/* 320 */     return compare(value, compare, 1);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 331 */     return ((DateFormat)formatter).getCalendar();
/*     */   }
/*     */ }