/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.DateFormatSymbols;
/*     */ import java.text.Format;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Calendar;
/*     */ import java.util.Locale;
/*     */ import java.util.TimeZone;
/*     */ 
/*     */ public abstract class AbstractCalendarValidator extends AbstractFormatValidator
/*     */ {
/*  38 */   private int dateStyle = -1;
/*     */ 
/*  40 */   private int timeStyle = -1;
/*     */ 
/*     */   public AbstractCalendarValidator(boolean strict, int dateStyle, int timeStyle)
/*     */   {
/*  52 */     super(strict);
/*  53 */     this.dateStyle = dateStyle;
/*  54 */     this.timeStyle = timeStyle;
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, String pattern, Locale locale)
/*     */   {
/*  66 */     Object parsedValue = parse(value, pattern, locale, (TimeZone)null);
/*  67 */     return (parsedValue != null);
/*     */   }
/*     */ 
/*     */   public String format(Object value, TimeZone timeZone)
/*     */   {
/*  80 */     return format(value, (String)null, (Locale)null, timeZone);
/*     */   }
/*     */ 
/*     */   public String format(Object value, String pattern, TimeZone timeZone)
/*     */   {
/*  94 */     return format(value, pattern, (Locale)null, timeZone);
/*     */   }
/*     */ 
/*     */   public String format(Object value, Locale locale, TimeZone timeZone)
/*     */   {
/* 108 */     return format(value, (String)null, locale, timeZone);
/*     */   }
/*     */ 
/*     */   public String format(Object value, String pattern, Locale locale)
/*     */   {
/* 121 */     return format(value, pattern, locale, (TimeZone)null);
/*     */   }
/*     */ 
/*     */   public String format(Object value, String pattern, Locale locale, TimeZone timeZone)
/*     */   {
/* 136 */     DateFormat formatter = (DateFormat)getFormat(pattern, locale);
/* 137 */     if (timeZone != null)
/* 138 */       formatter.setTimeZone(timeZone);
/* 139 */     else if (value instanceof Calendar) {
/* 140 */       formatter.setTimeZone(((Calendar)value).getTimeZone());
/*     */     }
/* 142 */     return format(value, formatter);
/*     */   }
/*     */ 
/*     */   protected String format(Object value, Format formatter)
/*     */   {
/* 153 */     if (value == null)
/* 154 */       return null;
/* 155 */     if (value instanceof Calendar) {
/* 156 */       value = ((Calendar)value).getTime();
/*     */     }
/* 158 */     return formatter.format(value);
/*     */   }
/*     */ 
/*     */   protected Object parse(String value, String pattern, Locale locale, TimeZone timeZone)
/*     */   {
/* 173 */     value = (value == null) ? null : value.trim();
/* 174 */     if ((value == null) || (value.length() == 0)) {
/* 175 */       return null;
/*     */     }
/* 177 */     DateFormat formatter = (DateFormat)getFormat(pattern, locale);
/* 178 */     if (timeZone != null) {
/* 179 */       formatter.setTimeZone(timeZone);
/*     */     }
/* 181 */     return parse(value, formatter);
/*     */   }
/*     */ 
/*     */   protected abstract Object processParsedValue(Object paramObject, Format paramFormat);
/*     */ 
/*     */   protected Format getFormat(String pattern, Locale locale)
/*     */   {
/* 206 */     DateFormat formatter = null;
/* 207 */     boolean usePattern = (pattern != null) && (pattern.length() > 0);
/* 208 */     if (!(usePattern)) {
/* 209 */       formatter = (DateFormat)getFormat(locale);
/* 210 */     } else if (locale == null) {
/* 211 */       formatter = new SimpleDateFormat(pattern);
/*     */     } else {
/* 213 */       DateFormatSymbols symbols = new DateFormatSymbols(locale);
/* 214 */       formatter = new SimpleDateFormat(pattern, symbols);
/*     */     }
/* 216 */     formatter.setLenient(false);
/* 217 */     return formatter;
/*     */   }
/*     */ 
/*     */   protected Format getFormat(Locale locale)
/*     */   {
/* 229 */     DateFormat formatter = null;
/* 230 */     if ((this.dateStyle >= 0) && (this.timeStyle >= 0)) {
/* 231 */       if (locale == null)
/* 232 */         formatter = DateFormat.getDateTimeInstance(this.dateStyle, this.timeStyle);
/*     */       else
/* 234 */         formatter = DateFormat.getDateTimeInstance(this.dateStyle, this.timeStyle, locale);
/*     */     }
/* 236 */     else if (this.timeStyle >= 0) {
/* 237 */       if (locale == null)
/* 238 */         formatter = DateFormat.getTimeInstance(this.timeStyle);
/*     */       else
/* 240 */         formatter = DateFormat.getTimeInstance(this.timeStyle, locale);
/*     */     }
/*     */     else {
/* 243 */       int useDateStyle = (this.dateStyle >= 0) ? this.dateStyle : 3;
/* 244 */       if (locale == null)
/* 245 */         formatter = DateFormat.getDateInstance(useDateStyle);
/*     */       else {
/* 247 */         formatter = DateFormat.getDateInstance(useDateStyle, locale);
/*     */       }
/*     */     }
/* 250 */     formatter.setLenient(false);
/* 251 */     return formatter;
/*     */   }
/*     */ 
/*     */   protected int compare(Calendar value, Calendar compare, int field)
/*     */   {
/* 269 */     int result = 0;
/*     */ 
/* 272 */     result = calculateCompareResult(value, compare, 1);
/* 273 */     if ((result != 0) || (field == 1)) {
/* 274 */       return result;
/*     */     }
/*     */ 
/* 278 */     if (field == 3) {
/* 279 */       return calculateCompareResult(value, compare, 3);
/*     */     }
/*     */ 
/* 283 */     if (field == 6) {
/* 284 */       return calculateCompareResult(value, compare, 6);
/*     */     }
/*     */ 
/* 288 */     result = calculateCompareResult(value, compare, 2);
/* 289 */     if ((result != 0) || (field == 2)) {
/* 290 */       return result;
/*     */     }
/*     */ 
/* 294 */     if (field == 4) {
/* 295 */       return calculateCompareResult(value, compare, 4);
/*     */     }
/*     */ 
/* 299 */     result = calculateCompareResult(value, compare, 5);
/* 300 */     if ((result != 0) || (field == 5) || (field == 5) || (field == 7) || (field == 8))
/*     */     {
/* 304 */       return result;
/*     */     }
/*     */ 
/* 308 */     return compareTime(value, compare, field);
/*     */   }
/*     */ 
/*     */   protected int compareTime(Calendar value, Calendar compare, int field)
/*     */   {
/* 326 */     int result = 0;
/*     */ 
/* 329 */     result = calculateCompareResult(value, compare, 11);
/* 330 */     if ((result != 0) || (field == 10) || (field == 11)) {
/* 331 */       return result;
/*     */     }
/*     */ 
/* 335 */     result = calculateCompareResult(value, compare, 12);
/* 336 */     if ((result != 0) || (field == 12)) {
/* 337 */       return result;
/*     */     }
/*     */ 
/* 341 */     result = calculateCompareResult(value, compare, 13);
/* 342 */     if ((result != 0) || (field == 13)) {
/* 343 */       return result;
/*     */     }
/*     */ 
/* 347 */     if (field == 14) {
/* 348 */       return calculateCompareResult(value, compare, 14);
/*     */     }
/*     */ 
/* 351 */     throw new IllegalArgumentException("Invalid field: " + field);
/*     */   }
/*     */ 
/*     */   protected int compareQuarters(Calendar value, Calendar compare, int monthOfFirstQuarter)
/*     */   {
/* 366 */     int valueQuarter = calculateQuarter(value, monthOfFirstQuarter);
/* 367 */     int compareQuarter = calculateQuarter(compare, monthOfFirstQuarter);
/* 368 */     if (valueQuarter < compareQuarter)
/* 369 */       return -1;
/* 370 */     if (valueQuarter > compareQuarter) {
/* 371 */       return 1;
/*     */     }
/* 373 */     return 0;
/*     */   }
/*     */ 
/*     */   private int calculateQuarter(Calendar calendar, int monthOfFirstQuarter)
/*     */   {
/* 386 */     int year = calendar.get(1);
/*     */ 
/* 388 */     int month = calendar.get(2) + 1;
/* 389 */     int relativeMonth = (month >= monthOfFirstQuarter) ? month - monthOfFirstQuarter : month + 12 - monthOfFirstQuarter;
/*     */ 
/* 392 */     int quarter = relativeMonth / 3 + 1;
/*     */ 
/* 394 */     if (month < monthOfFirstQuarter) {
/* 395 */       --year;
/*     */     }
/* 397 */     return (year * 10 + quarter);
/*     */   }
/*     */ 
/*     */   private int calculateCompareResult(Calendar value, Calendar compare, int field)
/*     */   {
/* 412 */     int difference = value.get(field) - compare.get(field);
/* 413 */     if (difference < 0)
/* 414 */       return -1;
/* 415 */     if (difference > 0) {
/* 416 */       return 1;
/*     */     }
/* 418 */     return 0;
/*     */   }
/*     */ }