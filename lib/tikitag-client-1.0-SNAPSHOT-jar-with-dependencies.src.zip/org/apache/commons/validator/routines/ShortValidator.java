/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class ShortValidator extends AbstractNumberValidator
/*     */ {
/*  67 */   private static final ShortValidator VALIDATOR = new ShortValidator();
/*     */ 
/*     */   public static ShortValidator getInstance()
/*     */   {
/*  74 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public ShortValidator()
/*     */   {
/*  81 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public ShortValidator(boolean strict, int formatType)
/*     */   {
/* 106 */     super(strict, formatType, false);
/*     */   }
/*     */ 
/*     */   public Short validate(String value)
/*     */   {
/* 118 */     return ((Short)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Short validate(String value, String pattern)
/*     */   {
/* 130 */     return ((Short)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Short validate(String value, Locale locale)
/*     */   {
/* 142 */     return ((Short)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Short validate(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     return ((Short)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(short value, short min, short max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Short value, short min, short max)
/*     */   {
/* 182 */     return isInRange(value.shortValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(short value, short min)
/*     */   {
/* 194 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Short value, short min)
/*     */   {
/* 206 */     return minValue(value.shortValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(short value, short max)
/*     */   {
/* 218 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Short value, short max)
/*     */   {
/* 230 */     return maxValue(value.shortValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 244 */     long longValue = ((Number)value).longValue();
/*     */ 
/* 246 */     if ((longValue < -32768L) || (longValue > 32767L))
/*     */     {
/* 248 */       return null;
/*     */     }
/* 250 */     return new Short((short)(int)longValue);
/*     */   }
/*     */ }