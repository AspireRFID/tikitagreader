/*     */ package org.apache.commons.validator.routines;
/*     */ 
/*     */ import java.text.Format;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class FloatValidator extends AbstractNumberValidator
/*     */ {
/*  67 */   private static final FloatValidator VALIDATOR = new FloatValidator();
/*     */ 
/*     */   public static FloatValidator getInstance()
/*     */   {
/*  74 */     return VALIDATOR;
/*     */   }
/*     */ 
/*     */   public FloatValidator()
/*     */   {
/*  81 */     this(true, 0);
/*     */   }
/*     */ 
/*     */   public FloatValidator(boolean strict, int formatType)
/*     */   {
/* 106 */     super(strict, formatType, true);
/*     */   }
/*     */ 
/*     */   public Float validate(String value)
/*     */   {
/* 118 */     return ((Float)parse(value, (String)null, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Float validate(String value, String pattern)
/*     */   {
/* 130 */     return ((Float)parse(value, pattern, (Locale)null));
/*     */   }
/*     */ 
/*     */   public Float validate(String value, Locale locale)
/*     */   {
/* 142 */     return ((Float)parse(value, (String)null, locale));
/*     */   }
/*     */ 
/*     */   public Float validate(String value, String pattern, Locale locale)
/*     */   {
/* 156 */     return ((Float)parse(value, pattern, locale));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(float value, float min, float max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public boolean isInRange(Float value, float min, float max)
/*     */   {
/* 182 */     return isInRange(value.floatValue(), min, max);
/*     */   }
/*     */ 
/*     */   public boolean minValue(float value, float min)
/*     */   {
/* 194 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public boolean minValue(Float value, float min)
/*     */   {
/* 206 */     return minValue(value.floatValue(), min);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(float value, float max)
/*     */   {
/* 218 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public boolean maxValue(Float value, float max)
/*     */   {
/* 230 */     return maxValue(value.floatValue(), max);
/*     */   }
/*     */ 
/*     */   protected Object processParsedValue(Object value, Format formatter)
/*     */   {
/* 244 */     double doubleValue = ((Number)value).doubleValue();
/*     */ 
/* 246 */     if (doubleValue > 0.0D) {
/* 247 */       if (doubleValue < 1.401298464324817E-045D) {
/* 248 */         return null;
/*     */       }
/* 250 */       if (doubleValue <= 3.402823466385289E+038D) break label69;
/* 251 */       return null;
/*     */     }
/* 253 */     if (doubleValue < 0.0D) {
/* 254 */       double posDouble = doubleValue * -1.0D;
/* 255 */       if (posDouble < 1.401298464324817E-045D) {
/* 256 */         return null;
/*     */       }
/* 258 */       if (posDouble > 3.402823466385289E+038D) {
/* 259 */         return null;
/*     */       }
/*     */     }
/*     */ 
/* 263 */     label69: return new Float((float)doubleValue);
/*     */   }
/*     */ }