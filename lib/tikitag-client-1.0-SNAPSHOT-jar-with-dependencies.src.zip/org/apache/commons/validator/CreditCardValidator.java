/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Iterator;
/*     */ import org.apache.commons.validator.util.Flags;
/*     */ 
/*     */ public class CreditCardValidator
/*     */ {
/*     */   public static final int NONE = 0;
/*     */   public static final int AMEX = 1;
/*     */   public static final int VISA = 2;
/*     */   public static final int MASTERCARD = 4;
/*     */   public static final int DISCOVER = 8;
/*     */   private Collection cardTypes;
/*     */ 
/*     */   public CreditCardValidator()
/*     */   {
/*  89 */     this(15);
/*     */   }
/*     */ 
/*     */   public CreditCardValidator(int options)
/*     */   {
/*  83 */     this.cardTypes = new ArrayList();
/*     */ 
/* 101 */     Flags f = new Flags(options);
/* 102 */     if (f.isOn(2L)) {
/* 103 */       this.cardTypes.add(new Visa(null));
/*     */     }
/*     */ 
/* 106 */     if (f.isOn(1L)) {
/* 107 */       this.cardTypes.add(new Amex(null));
/*     */     }
/*     */ 
/* 110 */     if (f.isOn(4L)) {
/* 111 */       this.cardTypes.add(new Mastercard(null));
/*     */     }
/*     */ 
/* 114 */     if (f.isOn(8L))
/* 115 */       this.cardTypes.add(new Discover(null));
/*     */   }
/*     */ 
/*     */   public boolean isValid(String card)
/*     */   {
/* 125 */     if ((card == null) || (card.length() < 13) || (card.length() > 19)) {
/* 126 */       return false;
/*     */     }
/*     */ 
/* 129 */     if (!(luhnCheck(card))) {
/* 130 */       return false;
/*     */     }
/*     */ 
/* 133 */     Iterator types = this.cardTypes.iterator();
/* 134 */     while (types.hasNext()) {
/* 135 */       CreditCardType type = (CreditCardType)types.next();
/* 136 */       if (type.matches(card)) {
/* 137 */         return true;
/*     */       }
/*     */     }
/*     */ 
/* 141 */     return false;
/*     */   }
/*     */ 
/*     */   public void addAllowedCardType(CreditCardType type)
/*     */   {
/* 151 */     this.cardTypes.add(type);
/*     */   }
/*     */ 
/*     */   protected boolean luhnCheck(String cardNumber)
/*     */   {
/* 161 */     int digits = cardNumber.length();
/* 162 */     int oddOrEven = digits & 0x1;
/* 163 */     long sum = 0L;
/* 164 */     for (int count = 0; count < digits; ++count) {
/* 165 */       int digit = 0;
/*     */       try {
/* 167 */         digit = Integer.parseInt(cardNumber.charAt(count) + "");
/*     */       } catch (NumberFormatException e) {
/* 169 */         return false;
/*     */       }
/*     */ 
/* 172 */       if ((count & 0x1 ^ oddOrEven) == 0) {
/* 173 */         digit *= 2;
/* 174 */         if (digit > 9) {
/* 175 */           digit -= 9;
/*     */         }
/*     */       }
/* 178 */       sum += digit;
/*     */     }
/*     */ 
/* 181 */     return (sum != 0L);
/*     */   }
/*     */ 
/*     */   private class Mastercard
/*     */     implements CreditCardValidator.CreditCardType
/*     */   {
/*     */     private static final String PREFIX = "51,52,53,54,55,";
/*     */     private final CreditCardValidator this$0;
/*     */ 
/*     */     private Mastercard()
/*     */     {
/* 234 */       this.this$0 = this$0; }
/*     */ 
/*     */     public boolean matches(String card) {
/* 237 */       String prefix2 = card.substring(0, 2) + ",";
/* 238 */       return (("51,52,53,54,55,".indexOf(prefix2) != -1) && (card.length() == 16));
/*     */     }
/*     */ 
/*     */     Mastercard(CreditCardValidator.1 x1)
/*     */     {
/* 234 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Discover
/*     */     implements CreditCardValidator.CreditCardType
/*     */   {
/*     */     private static final String PREFIX = "6011";
/*     */     private final CreditCardValidator this$0;
/*     */ 
/*     */     private Discover()
/*     */     {
/* 227 */       this.this$0 = this$0; }
/*     */ 
/*     */     public boolean matches(String card) {
/* 230 */       return ((card.substring(0, 4).equals("6011")) && (card.length() == 16));
/*     */     }
/*     */ 
/*     */     Discover(CreditCardValidator.1 x1)
/*     */     {
/* 227 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Amex
/*     */     implements CreditCardValidator.CreditCardType
/*     */   {
/*     */     private static final String PREFIX = "34,37,";
/*     */     private final CreditCardValidator this$0;
/*     */ 
/*     */     private Amex()
/*     */     {
/* 219 */       this.this$0 = this$0; }
/*     */ 
/*     */     public boolean matches(String card) {
/* 222 */       String prefix2 = card.substring(0, 2) + ",";
/* 223 */       return (("34,37,".indexOf(prefix2) != -1) && (card.length() == 15));
/*     */     }
/*     */ 
/*     */     Amex(CreditCardValidator.1 x1)
/*     */     {
/* 219 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Visa
/*     */     implements CreditCardValidator.CreditCardType
/*     */   {
/*     */     private static final String PREFIX = "4";
/*     */     private final CreditCardValidator this$0;
/*     */ 
/*     */     private Visa()
/*     */     {
/* 210 */       this.this$0 = this$0; }
/*     */ 
/*     */     public boolean matches(String card) {
/* 213 */       return ((card.substring(0, 1).equals("4")) && (((card.length() == 13) || (card.length() == 16))));
/*     */     }
/*     */ 
/*     */     Visa(CreditCardValidator.1 x1)
/*     */     {
/* 210 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static abstract interface CreditCardType
/*     */   {
/*     */     public abstract boolean matches(String paramString);
/*     */   }
/*     */ }