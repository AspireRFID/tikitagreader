/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.text.DateFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Locale;
/*     */ 
/*     */ public class DateValidator
/*     */ {
/*  39 */   private static final DateValidator DATE_VALIDATOR = new DateValidator();
/*     */ 
/*     */   public static DateValidator getInstance()
/*     */   {
/*  46 */     return DATE_VALIDATOR;
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, String datePattern, boolean strict)
/*     */   {
/*  70 */     if ((value == null) || (datePattern == null) || (datePattern.length() <= 0))
/*     */     {
/*  74 */       return false;
/*     */     }
/*     */ 
/*  77 */     SimpleDateFormat formatter = new SimpleDateFormat(datePattern);
/*  78 */     formatter.setLenient(false);
/*     */     try
/*     */     {
/*  81 */       formatter.parse(value);
/*     */     } catch (ParseException e) {
/*  83 */       return false;
/*     */     }
/*     */ 
/*  87 */     return ((strict) && (datePattern.length() != value.length()));
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value, Locale locale)
/*     */   {
/* 105 */     if (value == null) {
/* 106 */       return false;
/*     */     }
/*     */ 
/* 109 */     DateFormat formatter = null;
/* 110 */     if (locale != null)
/* 111 */       formatter = DateFormat.getDateInstance(3, locale);
/*     */     else {
/* 113 */       formatter = DateFormat.getDateInstance(3, Locale.getDefault());
/*     */     }
/*     */ 
/* 119 */     formatter.setLenient(false);
/*     */     try
/*     */     {
/* 122 */       formatter.parse(value);
/*     */     } catch (ParseException e) {
/* 124 */       return false;
/*     */     }
/*     */ 
/* 127 */     return true;
/*     */   }
/*     */ }