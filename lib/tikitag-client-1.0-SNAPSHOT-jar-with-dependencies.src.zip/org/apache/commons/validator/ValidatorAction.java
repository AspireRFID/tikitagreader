/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.BufferedReader;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.lang.reflect.Modifier;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.apache.commons.validator.util.ValidatorUtils;
/*     */ 
/*     */ public class ValidatorAction
/*     */   implements Serializable
/*     */ {
/*  51 */   private transient Log log = LogFactory.getLog(ValidatorAction.class);
/*     */ 
/*  56 */   private String name = null;
/*     */ 
/*  62 */   private String classname = null;
/*     */ 
/*  67 */   private Class validationClass = null;
/*     */ 
/*  73 */   private String method = null;
/*     */ 
/*  78 */   private Method validationMethod = null;
/*     */ 
/*  94 */   private String methodParams = "java.lang.Object,org.apache.commons.validator.ValidatorAction,org.apache.commons.validator.Field";
/*     */ 
/* 104 */   private Class[] parameterClasses = null;
/*     */ 
/* 111 */   private String depends = null;
/*     */ 
/* 116 */   private String msg = null;
/*     */ 
/* 122 */   private String jsFunctionName = null;
/*     */ 
/* 128 */   private String jsFunction = null;
/*     */ 
/* 134 */   private String javascript = null;
/*     */ 
/* 141 */   private Object instance = null;
/*     */ 
/* 150 */   private List dependencyList = Collections.synchronizedList(new ArrayList());
/*     */ 
/* 156 */   private List methodParameterList = new ArrayList();
/*     */ 
/*     */   public String getName()
/*     */   {
/* 163 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/* 171 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getClassname()
/*     */   {
/* 179 */     return this.classname;
/*     */   }
/*     */ 
/*     */   public void setClassname(String classname)
/*     */   {
/* 187 */     this.classname = classname;
/*     */   }
/*     */ 
/*     */   public String getMethod()
/*     */   {
/* 195 */     return this.method;
/*     */   }
/*     */ 
/*     */   public void setMethod(String method)
/*     */   {
/* 203 */     this.method = method;
/*     */   }
/*     */ 
/*     */   public String getMethodParams()
/*     */   {
/* 211 */     return this.methodParams;
/*     */   }
/*     */ 
/*     */   public void setMethodParams(String methodParams)
/*     */   {
/* 219 */     this.methodParams = methodParams;
/*     */ 
/* 221 */     this.methodParameterList.clear();
/*     */ 
/* 223 */     StringTokenizer st = new StringTokenizer(methodParams, ",");
/* 224 */     while (st.hasMoreTokens()) {
/* 225 */       String value = st.nextToken().trim();
/*     */ 
/* 227 */       if ((value != null) && (value.length() > 0))
/* 228 */         this.methodParameterList.add(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getDepends()
/*     */   {
/* 239 */     return this.depends;
/*     */   }
/*     */ 
/*     */   public void setDepends(String depends)
/*     */   {
/* 247 */     this.depends = depends;
/*     */ 
/* 249 */     this.dependencyList.clear();
/*     */ 
/* 251 */     StringTokenizer st = new StringTokenizer(depends, ",");
/* 252 */     while (st.hasMoreTokens()) {
/* 253 */       String depend = st.nextToken().trim();
/*     */ 
/* 255 */       if ((depend != null) && (depend.length() > 0))
/* 256 */         this.dependencyList.add(depend);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getMsg()
/*     */   {
/* 266 */     return this.msg;
/*     */   }
/*     */ 
/*     */   public void setMsg(String msg)
/*     */   {
/* 274 */     this.msg = msg;
/*     */   }
/*     */ 
/*     */   public String getJsFunctionName()
/*     */   {
/* 284 */     return this.jsFunctionName;
/*     */   }
/*     */ 
/*     */   public void setJsFunctionName(String jsFunctionName)
/*     */   {
/* 294 */     this.jsFunctionName = jsFunctionName;
/*     */   }
/*     */ 
/*     */   public void setJsFunction(String jsFunction)
/*     */   {
/* 324 */     if (this.javascript != null) {
/* 325 */       throw new IllegalStateException("Cannot call setJsFunction() after calling setJavascript()");
/*     */     }
/*     */ 
/* 328 */     this.jsFunction = jsFunction;
/*     */   }
/*     */ 
/*     */   public String getJavascript()
/*     */   {
/* 337 */     return this.javascript;
/*     */   }
/*     */ 
/*     */   public void setJavascript(String javascript)
/*     */   {
/* 346 */     if (this.jsFunction != null) {
/* 347 */       throw new IllegalStateException("Cannot call setJavascript() after calling setJsFunction()");
/*     */     }
/*     */ 
/* 350 */     this.javascript = javascript;
/*     */   }
/*     */ 
/*     */   protected void init()
/*     */   {
/* 357 */     loadJavascriptFunction();
/*     */   }
/*     */ 
/*     */   protected synchronized void loadJavascriptFunction()
/*     */   {
/* 373 */     if (javascriptAlreadyLoaded()) {
/* 374 */       return;
/*     */     }
/*     */ 
/* 377 */     if (getLog().isTraceEnabled()) {
/* 378 */       getLog().trace("  Loading function begun");
/*     */     }
/*     */ 
/* 381 */     if (this.jsFunction == null) {
/* 382 */       this.jsFunction = generateJsFunction();
/*     */     }
/*     */ 
/* 385 */     String javascriptFileName = formatJavascriptFileName();
/*     */ 
/* 387 */     if (getLog().isTraceEnabled()) {
/* 388 */       getLog().trace("  Loading js function '" + javascriptFileName + "'");
/*     */     }
/*     */ 
/* 391 */     this.javascript = readJavascriptFile(javascriptFileName);
/*     */ 
/* 393 */     if (getLog().isTraceEnabled())
/* 394 */       getLog().trace("  Loading javascript function completed");
/*     */   }
/*     */ 
/*     */   private String readJavascriptFile(String javascriptFileName)
/*     */   {
/* 405 */     ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/* 406 */     if (classLoader == null) {
/* 407 */       classLoader = super.getClass().getClassLoader();
/*     */     }
/*     */ 
/* 410 */     InputStream is = classLoader.getResourceAsStream(javascriptFileName);
/* 411 */     if (is == null) {
/* 412 */       is = super.getClass().getResourceAsStream(javascriptFileName);
/*     */     }
/*     */ 
/* 415 */     if (is == null) {
/* 416 */       getLog().debug("  Unable to read javascript name " + javascriptFileName);
/* 417 */       return null;
/*     */     }
/*     */ 
/* 420 */     StringBuffer buffer = new StringBuffer();
/* 421 */     BufferedReader reader = new BufferedReader(new InputStreamReader(is));
/*     */     try {
/* 423 */       String line = null;
/* 424 */       while ((line = reader.readLine()) != null)
/* 425 */         buffer.append(line + "\n");
/*     */     }
/*     */     catch (IOException e)
/*     */     {
/* 429 */       getLog().error("Error reading javascript file.", e);
/*     */     }
/*     */     finally {
/*     */       try {
/* 433 */         reader.close();
/*     */       } catch (IOException e) {
/* 435 */         getLog().error("Error closing stream to javascript file.", e);
/*     */       }
/*     */     }
/*     */ 
/* 439 */     String function = buffer.toString();
/* 440 */     return ((function.equals("")) ? null : function);
/*     */   }
/*     */ 
/*     */   private String formatJavascriptFileName()
/*     */   {
/* 448 */     String name = this.jsFunction.substring(1);
/*     */ 
/* 450 */     if (!(this.jsFunction.startsWith("/"))) {
/* 451 */       name = this.jsFunction.replace('.', '/') + ".js";
/*     */     }
/*     */ 
/* 454 */     return name;
/*     */   }
/*     */ 
/*     */   private boolean javascriptAlreadyLoaded()
/*     */   {
/* 461 */     return (this.javascript != null);
/*     */   }
/*     */ 
/*     */   private String generateJsFunction()
/*     */   {
/* 468 */     StringBuffer jsName = new StringBuffer("org.apache.commons.validator.javascript");
/*     */ 
/* 471 */     jsName.append(".validate");
/* 472 */     jsName.append(this.name.substring(0, 1).toUpperCase());
/* 473 */     jsName.append(this.name.substring(1, this.name.length()));
/*     */ 
/* 475 */     return jsName.toString();
/*     */   }
/*     */ 
/*     */   public boolean isDependency(String validatorName)
/*     */   {
/* 484 */     return this.dependencyList.contains(validatorName);
/*     */   }
/*     */ 
/*     */   public List getDependencyList()
/*     */   {
/* 493 */     return Collections.unmodifiableList(this.dependencyList);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 501 */     StringBuffer results = new StringBuffer("ValidatorAction: ");
/* 502 */     results.append(this.name);
/* 503 */     results.append("\n");
/*     */ 
/* 505 */     return results.toString();
/*     */   }
/*     */ 
/*     */   boolean executeValidationMethod(Field field, Map params, ValidatorResults results, int pos)
/*     */     throws ValidatorException
/*     */   {
/* 524 */     params.put("org.apache.commons.validator.ValidatorAction", this);
/*     */     try
/*     */     {
/* 527 */       if (this.validationMethod == null) {
/* 528 */         synchronized (this) {
/* 529 */           ClassLoader loader = getClassLoader(params);
/* 530 */           loadValidationClass(loader);
/* 531 */           loadParameterClasses(loader);
/* 532 */           loadValidationMethod();
/*     */         }
/*     */       }
/*     */ 
/* 536 */       Object[] paramValues = getParameterValues(params);
/*     */ 
/* 538 */       if (field.isIndexed()) {
/* 539 */         handleIndexedField(field, pos, paramValues);
/*     */       }
/*     */ 
/* 542 */       Object result = null;
/*     */       try {
/* 544 */         result = this.validationMethod.invoke(getValidationClassInstance(), paramValues);
/*     */       }
/*     */       catch (IllegalArgumentException e)
/*     */       {
/* 550 */         throw new ValidatorException(e.getMessage());
/*     */       } catch (IllegalAccessException e) {
/* 552 */         throw new ValidatorException(e.getMessage());
/*     */       }
/*     */       catch (InvocationTargetException e) {
/* 555 */         if (e.getTargetException() instanceof Exception) {
/* 556 */           throw ((Exception)e.getTargetException());
/*     */         }
/* 558 */         if (e.getTargetException() instanceof Error) {
/* 559 */           throw ((Error)e.getTargetException());
/*     */         }
/*     */       }
/*     */ 
/* 563 */       boolean valid = isValid(result);
/* 564 */       if ((!(valid)) || ((valid) && (!(onlyReturnErrors(params))))) {
/* 565 */         results.add(field, this.name, valid, result);
/*     */       }
/*     */ 
/* 568 */       if (!(valid)) {
/* 569 */         return false;
/*     */       }
/*     */ 
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 575 */       if (e instanceof ValidatorException) {
/* 576 */         throw ((ValidatorException)e);
/*     */       }
/*     */ 
/* 579 */       getLog().error("Unhandled exception thrown during validation: " + e.getMessage(), e);
/*     */ 
/* 583 */       results.add(field, this.name, false);
/* 584 */       return false;
/*     */     }
/*     */ 
/* 587 */     return true;
/*     */   }
/*     */ 
/*     */   private void loadValidationMethod()
/*     */     throws ValidatorException
/*     */   {
/* 595 */     if (this.validationMethod != null) {
/* 596 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 600 */       this.validationMethod = this.validationClass.getMethod(this.method, this.parameterClasses);
/*     */     }
/*     */     catch (NoSuchMethodException e)
/*     */     {
/* 604 */       throw new ValidatorException("No such validation method: " + e.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadValidationClass(ClassLoader loader)
/*     */     throws ValidatorException
/*     */   {
/* 617 */     if (this.validationClass != null) {
/* 618 */       return;
/*     */     }
/*     */     try
/*     */     {
/* 622 */       this.validationClass = loader.loadClass(this.classname);
/*     */     } catch (ClassNotFoundException e) {
/* 624 */       throw new ValidatorException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   private void loadParameterClasses(ClassLoader loader)
/*     */     throws ValidatorException
/*     */   {
/* 638 */     if (this.parameterClasses != null) {
/* 639 */       return;
/*     */     }
/*     */ 
/* 642 */     Class[] parameterClasses = new Class[this.methodParameterList.size()];
/*     */ 
/* 644 */     for (int i = 0; i < this.methodParameterList.size(); ++i) {
/* 645 */       String paramClassName = (String)this.methodParameterList.get(i);
/*     */       try
/*     */       {
/* 648 */         parameterClasses[i] = loader.loadClass(paramClassName);
/*     */       }
/*     */       catch (ClassNotFoundException e) {
/* 651 */         throw new ValidatorException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/* 655 */     this.parameterClasses = parameterClasses;
/*     */   }
/*     */ 
/*     */   private Object[] getParameterValues(Map params)
/*     */   {
/* 668 */     Object[] paramValue = new Object[this.methodParameterList.size()];
/*     */ 
/* 670 */     for (int i = 0; i < this.methodParameterList.size(); ++i) {
/* 671 */       String paramClassName = (String)this.methodParameterList.get(i);
/* 672 */       paramValue[i] = params.get(paramClassName);
/*     */     }
/*     */ 
/* 675 */     return paramValue;
/*     */   }
/*     */ 
/*     */   private Object getValidationClassInstance()
/*     */     throws ValidatorException
/*     */   {
/* 683 */     if (Modifier.isStatic(this.validationMethod.getModifiers())) {
/* 684 */       this.instance = null;
/*     */     }
/* 687 */     else if (this.instance == null) {
/*     */       try {
/* 689 */         this.instance = this.validationClass.newInstance();
/*     */       } catch (InstantiationException e) {
/* 691 */         String msg = "Couldn't create instance of " + this.classname + ".  " + e.getMessage();
/*     */ 
/* 697 */         throw new ValidatorException(msg);
/*     */       }
/*     */       catch (IllegalAccessException e) {
/* 700 */         String msg = "Couldn't create instance of " + this.classname + ".  " + e.getMessage();
/*     */ 
/* 706 */         throw new ValidatorException(msg);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 711 */     return this.instance;
/*     */   }
/*     */ 
/*     */   private void handleIndexedField(Field field, int pos, Object[] paramValues)
/*     */     throws ValidatorException
/*     */   {
/* 724 */     int beanIndex = this.methodParameterList.indexOf("java.lang.Object");
/* 725 */     int fieldIndex = this.methodParameterList.indexOf("org.apache.commons.validator.Field");
/*     */ 
/* 727 */     Object[] indexedList = field.getIndexedProperty(paramValues[beanIndex]);
/*     */ 
/* 730 */     paramValues[beanIndex] = indexedList[pos];
/*     */ 
/* 734 */     Field indexedField = (Field)field.clone();
/* 735 */     indexedField.setKey(ValidatorUtils.replace(indexedField.getKey(), "[]", "[" + pos + "]"));
/*     */ 
/* 741 */     paramValues[fieldIndex] = indexedField;
/*     */   }
/*     */ 
/*     */   private boolean isValid(Object result)
/*     */   {
/* 750 */     if (result instanceof Boolean) {
/* 751 */       Boolean valid = (Boolean)result;
/* 752 */       return valid.booleanValue();
/*     */     }
/* 754 */     return (result != null);
/*     */   }
/*     */ 
/*     */   private ClassLoader getClassLoader(Map params)
/*     */   {
/* 763 */     Validator v = (Validator)params.get("org.apache.commons.validator.Validator");
/* 764 */     return v.getClassLoader();
/*     */   }
/*     */ 
/*     */   private boolean onlyReturnErrors(Map params)
/*     */   {
/* 772 */     Validator v = (Validator)params.get("org.apache.commons.validator.Validator");
/* 773 */     return v.getOnlyReturnErrors();
/*     */   }
/*     */ 
/*     */   private Log getLog()
/*     */   {
/* 787 */     if (this.log == null) {
/* 788 */       this.log = LogFactory.getLog(ValidatorAction.class);
/*     */     }
/* 790 */     return this.log;
/*     */   }
/*     */ }