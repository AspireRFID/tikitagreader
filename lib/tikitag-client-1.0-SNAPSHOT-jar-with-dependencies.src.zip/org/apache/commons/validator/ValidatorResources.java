/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Serializable;
/*     */ import java.net.URL;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.Iterator;
/*     */ import java.util.Locale;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.Rule;
/*     */ import org.apache.commons.digester.xmlrules.DigesterLoader;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class ValidatorResources
/*     */   implements Serializable
/*     */ {
/*     */   private static final String VALIDATOR_RULES = "digester-rules.xml";
/*  65 */   private static final String[] REGISTRATIONS = { "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.0//EN", "/org/apache/commons/validator/resources/validator_1_0.dtd", "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.0.1//EN", "/org/apache/commons/validator/resources/validator_1_0_1.dtd", "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.1//EN", "/org/apache/commons/validator/resources/validator_1_1.dtd", "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.1.3//EN", "/org/apache/commons/validator/resources/validator_1_1_3.dtd", "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.2.0//EN", "/org/apache/commons/validator/resources/validator_1_2_0.dtd", "-//Apache Software Foundation//DTD Commons Validator Rules Configuration 1.3.0//EN", "/org/apache/commons/validator/resources/validator_1_3_0.dtd" };
/*     */   private transient Log log;
/*     */ 
/*     */   /** @deprecated */
/*     */   protected FastHashMap hFormSets;
/*     */ 
/*     */   /** @deprecated */
/*     */   protected FastHashMap hConstants;
/*     */ 
/*     */   /** @deprecated */
/*     */   protected FastHashMap hActions;
/* 106 */   protected static Locale defaultLocale = Locale.getDefault();
/*     */   protected FormSet defaultFormSet;
/*     */   private static final String ARGS_PATTERN = "form-validation/formset/form/field/arg";
/*     */ 
/*     */   public ValidatorResources()
/*     */   {
/*  80 */     this.log = LogFactory.getLog(ValidatorResources.class);
/*     */ 
/*  87 */     this.hFormSets = new FastHashMap();
/*     */ 
/*  94 */     this.hConstants = new FastHashMap();
/*     */ 
/* 101 */     this.hActions = new FastHashMap();
/*     */   }
/*     */ 
/*     */   public ValidatorResources(InputStream in)
/*     */     throws IOException, SAXException
/*     */   {
/* 133 */     this(new InputStream[] { in });
/*     */   }
/*     */ 
/*     */   public ValidatorResources(InputStream[] streams)
/*     */     throws IOException, SAXException
/*     */   {
/*  80 */     this.log = LogFactory.getLog(ValidatorResources.class);
/*     */ 
/*  87 */     this.hFormSets = new FastHashMap();
/*     */ 
/*  94 */     this.hConstants = new FastHashMap();
/*     */ 
/* 101 */     this.hActions = new FastHashMap();
/*     */ 
/* 153 */     Digester digester = initDigester();
/* 154 */     for (int i = 0; i < streams.length; ++i) {
/* 155 */       digester.push(this);
/* 156 */       digester.parse(streams[i]);
/*     */     }
/*     */ 
/* 159 */     process();
/*     */   }
/*     */ 
/*     */   public ValidatorResources(String uri)
/*     */     throws IOException, SAXException
/*     */   {
/* 173 */     this(new String[] { uri });
/*     */   }
/*     */ 
/*     */   public ValidatorResources(String[] uris)
/*     */     throws IOException, SAXException
/*     */   {
/*  80 */     this.log = LogFactory.getLog(ValidatorResources.class);
/*     */ 
/*  87 */     this.hFormSets = new FastHashMap();
/*     */ 
/*  94 */     this.hConstants = new FastHashMap();
/*     */ 
/* 101 */     this.hActions = new FastHashMap();
/*     */ 
/* 192 */     Digester digester = initDigester();
/* 193 */     for (int i = 0; i < uris.length; ++i) {
/* 194 */       digester.push(this);
/* 195 */       digester.parse(uris[i]);
/*     */     }
/*     */ 
/* 198 */     process();
/*     */   }
/*     */ 
/*     */   public ValidatorResources(URL url)
/*     */     throws IOException, SAXException
/*     */   {
/* 214 */     this(new URL[] { url });
/*     */   }
/*     */ 
/*     */   public ValidatorResources(URL[] urls)
/*     */     throws IOException, SAXException
/*     */   {
/*  80 */     this.log = LogFactory.getLog(ValidatorResources.class);
/*     */ 
/*  87 */     this.hFormSets = new FastHashMap();
/*     */ 
/*  94 */     this.hConstants = new FastHashMap();
/*     */ 
/* 101 */     this.hActions = new FastHashMap();
/*     */ 
/* 233 */     Digester digester = initDigester();
/* 234 */     for (int i = 0; i < urls.length; ++i) {
/* 235 */       digester.push(this);
/* 236 */       InputStream stream = null;
/*     */       try {
/* 238 */         stream = urls[i].openStream();
/* 239 */         InputSource source = new InputSource(urls[i].toExternalForm());
/*     */ 
/* 241 */         source.setByteStream(stream);
/* 242 */         digester.parse(source);
/*     */       } finally {
/* 244 */         if (stream != null) {
/*     */           try {
/* 246 */             stream.close();
/*     */           }
/*     */           catch (IOException e)
/*     */           {
/*     */           }
/*     */         }
/*     */       }
/*     */     }
/* 254 */     process();
/*     */   }
/*     */ 
/*     */   private Digester initDigester()
/*     */   {
/* 261 */     URL rulesUrl = super.getClass().getResource("digester-rules.xml");
/* 262 */     if (rulesUrl == null)
/*     */     {
/* 264 */       rulesUrl = ValidatorResources.class.getResource("digester-rules.xml");
/*     */     }
/* 266 */     if (getLog().isDebugEnabled()) {
/* 267 */       getLog().debug("Loading rules from '" + rulesUrl + "'");
/*     */     }
/* 269 */     Digester digester = DigesterLoader.createDigester(rulesUrl);
/* 270 */     digester.setNamespaceAware(true);
/* 271 */     digester.setValidating(true);
/* 272 */     digester.setUseContextClassLoader(true);
/*     */ 
/* 275 */     addOldArgRules(digester);
/*     */ 
/* 278 */     for (int i = 0; i < REGISTRATIONS.length; i += 2) {
/* 279 */       URL url = super.getClass().getResource(REGISTRATIONS[(i + 1)]);
/* 280 */       if (url != null) {
/* 281 */         digester.register(REGISTRATIONS[i], url.toString());
/*     */       }
/*     */     }
/* 284 */     return digester;
/*     */   }
/*     */ 
/*     */   private void addOldArgRules(Digester digester)
/*     */   {
/* 299 */     Rule rule = new Rule()
/*     */     {
/*     */       public void begin(String namespace, String name, Attributes attributes) throws Exception
/*     */       {
/* 303 */         Arg arg = new Arg();
/* 304 */         arg.setKey(attributes.getValue("key"));
/* 305 */         arg.setName(attributes.getValue("name"));
/* 306 */         if ("false".equalsIgnoreCase(attributes.getValue("resource")))
/* 307 */           arg.setResource(false);
/*     */         try
/*     */         {
/* 310 */           arg.setPosition(Integer.parseInt(name.substring(3)));
/*     */         } catch (Exception ex) {
/* 312 */           ValidatorResources.this.getLog().error("Error parsing Arg position: " + name + " " + arg + " " + ex);
/*     */         }
/*     */ 
/* 317 */         ((Field)getDigester().peek(0)).addArg(arg);
/*     */       }
/*     */     };
/* 322 */     digester.addRule("form-validation/formset/form/field/arg0", rule);
/* 323 */     digester.addRule("form-validation/formset/form/field/arg1", rule);
/* 324 */     digester.addRule("form-validation/formset/form/field/arg2", rule);
/* 325 */     digester.addRule("form-validation/formset/form/field/arg3", rule);
/*     */   }
/*     */ 
/*     */   public void addFormSet(FormSet fs)
/*     */   {
/* 337 */     String key = buildKey(fs);
/* 338 */     if (key.length() == 0) {
/* 339 */       if ((getLog().isWarnEnabled()) && (this.defaultFormSet != null))
/*     */       {
/* 341 */         getLog().warn("Overriding default FormSet definition.");
/*     */       }
/* 343 */       this.defaultFormSet = fs;
/*     */     } else {
/* 345 */       FormSet formset = (FormSet)this.hFormSets.get(key);
/* 346 */       if (formset == null) {
/* 347 */         if (getLog().isDebugEnabled())
/* 348 */           getLog().debug("Adding FormSet '" + fs.toString() + "'.");
/*     */       }
/* 350 */       else if (getLog().isWarnEnabled())
/*     */       {
/* 352 */         getLog().warn("Overriding FormSet definition. Duplicate for locale: " + key);
/*     */       }
/*     */ 
/* 356 */       this.hFormSets.put(key, fs);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addConstant(String name, String value)
/*     */   {
/* 366 */     if (getLog().isDebugEnabled()) {
/* 367 */       getLog().debug("Adding Global Constant: " + name + "," + value);
/*     */     }
/*     */ 
/* 370 */     this.hConstants.put(name, value);
/*     */   }
/*     */ 
/*     */   public void addValidatorAction(ValidatorAction va)
/*     */   {
/* 381 */     va.init();
/*     */ 
/* 383 */     this.hActions.put(va.getName(), va);
/*     */ 
/* 385 */     if (getLog().isDebugEnabled())
/* 386 */       getLog().debug("Add ValidatorAction: " + va.getName() + "," + va.getClassname());
/*     */   }
/*     */ 
/*     */   public ValidatorAction getValidatorAction(String key)
/*     */   {
/* 396 */     return ((ValidatorAction)this.hActions.get(key));
/*     */   }
/*     */ 
/*     */   public Map getValidatorActions()
/*     */   {
/* 404 */     return Collections.unmodifiableMap(this.hActions);
/*     */   }
/*     */ 
/*     */   protected String buildKey(FormSet fs)
/*     */   {
/* 414 */     return buildLocale(fs.getLanguage(), fs.getCountry(), fs.getVariant());
/*     */   }
/*     */ 
/*     */   private String buildLocale(String lang, String country, String variant)
/*     */   {
/* 422 */     String key = ((lang != null) && (lang.length() > 0)) ? lang : "";
/* 423 */     key = key + (((country != null) && (country.length() > 0)) ? "_" + country : "");
/* 424 */     key = key + (((variant != null) && (variant.length() > 0)) ? "_" + variant : "");
/* 425 */     return key;
/*     */   }
/*     */ 
/*     */   public Form getForm(Locale locale, String formKey)
/*     */   {
/* 444 */     return getForm(locale.getLanguage(), locale.getCountry(), locale.getVariant(), formKey);
/*     */   }
/*     */ 
/*     */   public Form getForm(String language, String country, String variant, String formKey)
/*     */   {
/*     */     FormSet formSet;
/* 468 */     Form form = null;
/*     */ 
/* 471 */     String key = buildLocale(language, country, variant);
/* 472 */     if (key.length() > 0) {
/* 473 */       FormSet formSet = (FormSet)this.hFormSets.get(key);
/* 474 */       if (formSet != null) {
/* 475 */         form = formSet.getForm(formKey);
/*     */       }
/*     */     }
/* 478 */     String localeKey = key;
/*     */ 
/* 482 */     if (form == null) {
/* 483 */       key = buildLocale(language, country, null);
/* 484 */       if (key.length() > 0) {
/* 485 */         formSet = (FormSet)this.hFormSets.get(key);
/* 486 */         if (formSet != null) {
/* 487 */           form = formSet.getForm(formKey);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 493 */     if (form == null) {
/* 494 */       key = buildLocale(language, null, null);
/* 495 */       if (key.length() > 0) {
/* 496 */         formSet = (FormSet)this.hFormSets.get(key);
/* 497 */         if (formSet != null) {
/* 498 */           form = formSet.getForm(formKey);
/*     */         }
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 504 */     if (form == null) {
/* 505 */       form = this.defaultFormSet.getForm(formKey);
/* 506 */       key = "default";
/*     */     }
/*     */ 
/* 509 */     if (form == null) {
/* 510 */       if (getLog().isWarnEnabled()) {
/* 511 */         getLog().warn("Form '" + formKey + "' not found for locale '" + localeKey + "'");
/*     */       }
/*     */ 
/*     */     }
/* 515 */     else if (getLog().isDebugEnabled()) {
/* 516 */       getLog().debug("Form '" + formKey + "' found in formset '" + key + "' for locale '" + localeKey + "'");
/*     */     }
/*     */ 
/* 521 */     return form;
/*     */   }
/*     */ 
/*     */   public void process()
/*     */   {
/* 534 */     this.hFormSets.setFast(true);
/* 535 */     this.hConstants.setFast(true);
/* 536 */     this.hActions.setFast(true);
/*     */ 
/* 538 */     processForms();
/*     */   }
/*     */ 
/*     */   private void processForms()
/*     */   {
/*     */     FormSet fs;
/* 547 */     if (this.defaultFormSet == null)
/*     */     {
/* 549 */       this.defaultFormSet = new FormSet();
/*     */     }
/* 551 */     this.defaultFormSet.process(this.hConstants);
/*     */ 
/* 553 */     for (Iterator i = this.hFormSets.keySet().iterator(); i.hasNext(); ) {
/* 554 */       String key = (String)i.next();
/* 555 */       fs = (FormSet)this.hFormSets.get(key);
/* 556 */       fs.merge(getParent(fs));
/*     */     }
/*     */ 
/* 560 */     for (Iterator i = this.hFormSets.values().iterator(); i.hasNext(); ) {
/* 561 */       fs = (FormSet)i.next();
/* 562 */       if (!(fs.isProcessed()))
/* 563 */         fs.process(this.hConstants);
/*     */     }
/*     */   }
/*     */ 
/*     */   private FormSet getParent(FormSet fs)
/*     */   {
/* 580 */     FormSet parent = null;
/* 581 */     if (fs.getType() == 2) {
/* 582 */       parent = this.defaultFormSet;
/* 583 */     } else if (fs.getType() == 3) {
/* 584 */       parent = (FormSet)this.hFormSets.get(buildLocale(fs.getLanguage(), null, null));
/*     */ 
/* 586 */       if (parent == null)
/* 587 */         parent = this.defaultFormSet;
/*     */     }
/* 589 */     else if (fs.getType() == 4) {
/* 590 */       parent = (FormSet)this.hFormSets.get(buildLocale(fs.getLanguage(), fs.getCountry(), null));
/*     */ 
/* 592 */       if (parent == null) {
/* 593 */         parent = (FormSet)this.hFormSets.get(buildLocale(fs.getLanguage(), null, null));
/*     */ 
/* 595 */         if (parent == null) {
/* 596 */           parent = this.defaultFormSet;
/*     */         }
/*     */       }
/*     */     }
/* 600 */     return parent;
/*     */   }
/*     */ 
/*     */   FormSet getFormSet(String language, String country, String variant)
/*     */   {
/* 614 */     String key = buildLocale(language, country, variant);
/*     */ 
/* 616 */     if (key.length() == 0) {
/* 617 */       return this.defaultFormSet;
/*     */     }
/*     */ 
/* 620 */     return ((FormSet)this.hFormSets.get(key));
/*     */   }
/*     */ 
/*     */   protected Map getFormSets()
/*     */   {
/* 629 */     return this.hFormSets;
/*     */   }
/*     */ 
/*     */   protected Map getConstants()
/*     */   {
/* 638 */     return this.hConstants;
/*     */   }
/*     */ 
/*     */   protected Map getActions()
/*     */   {
/* 647 */     return this.hActions;
/*     */   }
/*     */ 
/*     */   private Log getLog()
/*     */   {
/* 661 */     if (this.log == null) {
/* 662 */       this.log = LogFactory.getLog(ValidatorResources.class);
/*     */     }
/* 664 */     return this.log;
/*     */   }
/*     */ }