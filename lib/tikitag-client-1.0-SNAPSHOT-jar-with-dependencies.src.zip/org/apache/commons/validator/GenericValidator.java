/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Locale;
/*     */ import org.apache.oro.text.perl.Perl5Util;
/*     */ 
/*     */ public class GenericValidator
/*     */   implements Serializable
/*     */ {
/*  34 */   private static final UrlValidator URL_VALIDATOR = new UrlValidator();
/*     */ 
/*  39 */   private static final CreditCardValidator CREDIT_CARD_VALIDATOR = new CreditCardValidator();
/*     */ 
/*     */   public static boolean isBlankOrNull(String value)
/*     */   {
/*  50 */     return ((value == null) || (value.trim().length() == 0));
/*     */   }
/*     */ 
/*     */   public static boolean matchRegexp(String value, String regexp)
/*     */   {
/*  61 */     if ((regexp == null) || (regexp.length() <= 0)) {
/*  62 */       return false;
/*     */     }
/*     */ 
/*  65 */     Perl5Util matcher = new Perl5Util();
/*  66 */     return matcher.match("/" + regexp + "/", value);
/*     */   }
/*     */ 
/*     */   public static boolean isByte(String value)
/*     */   {
/*  76 */     return (GenericTypeValidator.formatByte(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isShort(String value)
/*     */   {
/*  86 */     return (GenericTypeValidator.formatShort(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isInt(String value)
/*     */   {
/*  96 */     return (GenericTypeValidator.formatInt(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isLong(String value)
/*     */   {
/* 106 */     return (GenericTypeValidator.formatLong(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isFloat(String value)
/*     */   {
/* 116 */     return (GenericTypeValidator.formatFloat(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isDouble(String value)
/*     */   {
/* 126 */     return (GenericTypeValidator.formatDouble(value) != null);
/*     */   }
/*     */ 
/*     */   public static boolean isDate(String value, Locale locale)
/*     */   {
/* 140 */     return DateValidator.getInstance().isValid(value, locale);
/*     */   }
/*     */ 
/*     */   public static boolean isDate(String value, String datePattern, boolean strict)
/*     */   {
/* 156 */     return DateValidator.getInstance().isValid(value, datePattern, strict);
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(byte value, byte min, byte max)
/*     */   {
/* 169 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(int value, int min, int max)
/*     */   {
/* 182 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(float value, float min, float max)
/*     */   {
/* 195 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(short value, short min, short max)
/*     */   {
/* 208 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(long value, long min, long max)
/*     */   {
/* 221 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isInRange(double value, double min, double max)
/*     */   {
/* 234 */     return ((value >= min) && (value <= max));
/*     */   }
/*     */ 
/*     */   public static boolean isCreditCard(String value)
/*     */   {
/* 243 */     return CREDIT_CARD_VALIDATOR.isValid(value);
/*     */   }
/*     */ 
/*     */   public static boolean isEmail(String value)
/*     */   {
/* 253 */     return EmailValidator.getInstance().isValid(value);
/*     */   }
/*     */ 
/*     */   public static boolean isUrl(String value)
/*     */   {
/* 265 */     return URL_VALIDATOR.isValid(value);
/*     */   }
/*     */ 
/*     */   public static boolean maxLength(String value, int max)
/*     */   {
/* 276 */     return (value.length() <= max);
/*     */   }
/*     */ 
/*     */   public static boolean maxLength(String value, int max, int lineEndLength)
/*     */   {
/* 288 */     int adjustAmount = adjustForLineEnding(value, lineEndLength);
/* 289 */     return (value.length() + adjustAmount <= max);
/*     */   }
/*     */ 
/*     */   public static boolean minLength(String value, int min)
/*     */   {
/* 300 */     return (value.length() >= min);
/*     */   }
/*     */ 
/*     */   public static boolean minLength(String value, int min, int lineEndLength)
/*     */   {
/* 312 */     int adjustAmount = adjustForLineEnding(value, lineEndLength);
/* 313 */     return (value.length() + adjustAmount >= min);
/*     */   }
/*     */ 
/*     */   private static int adjustForLineEnding(String value, int lineEndLength)
/*     */   {
/* 326 */     int nCount = 0;
/* 327 */     int rCount = 0;
/* 328 */     for (int i = 0; i < value.length(); ++i) {
/* 329 */       if (value.charAt(i) == '\n') {
/* 330 */         ++nCount;
/*     */       }
/* 332 */       if (value.charAt(i) == '\r') {
/* 333 */         ++rCount;
/*     */       }
/*     */     }
/* 336 */     return (nCount * lineEndLength - (rCount + nCount));
/*     */   }
/*     */ 
/*     */   public static boolean minValue(int value, int min)
/*     */   {
/* 349 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public static boolean minValue(long value, long min)
/*     */   {
/* 360 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public static boolean minValue(double value, double min)
/*     */   {
/* 371 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public static boolean minValue(float value, float min)
/*     */   {
/* 382 */     return (value >= min);
/*     */   }
/*     */ 
/*     */   public static boolean maxValue(int value, int max)
/*     */   {
/* 393 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public static boolean maxValue(long value, long max)
/*     */   {
/* 404 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public static boolean maxValue(double value, double max)
/*     */   {
/* 415 */     return (value <= max);
/*     */   }
/*     */ 
/*     */   public static boolean maxValue(float value, float max)
/*     */   {
/* 426 */     return (value <= max);
/*     */   }
/*     */ }