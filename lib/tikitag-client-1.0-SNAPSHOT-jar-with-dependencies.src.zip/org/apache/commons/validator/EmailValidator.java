/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import org.apache.oro.text.perl.Perl5Util;
/*     */ 
/*     */ public class EmailValidator
/*     */ {
/*     */   private static final String SPECIAL_CHARS = "\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177";
/*     */   private static final String VALID_CHARS = "[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]";
/*     */   private static final String QUOTED_USER = "(\"[^\"]*\")";
/*     */   private static final String ATOM = "[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+";
/*     */   private static final String WORD = "(([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]|')+|(\"[^\"]*\"))";
/*     */   private static final String LEGAL_ASCII_PATTERN = "/^[\\000-\\177]+$/";
/*     */   private static final String EMAIL_PATTERN = "/^(.+)@(.+)$/";
/*     */   private static final String IP_DOMAIN_PATTERN = "/^\\[(\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})\\]$/";
/*     */   private static final String TLD_PATTERN = "/^([a-zA-Z]+)$/";
/*     */   private static final String USER_PATTERN = "/^\\s*(([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]|')+|(\"[^\"]*\"))(\\.(([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]|')+|(\"[^\"]*\")))*$/";
/*     */   private static final String DOMAIN_PATTERN = "/^[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+(\\.[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+)*\\s*$/";
/*     */   private static final String ATOM_PATTERN = "/([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+)/";
/*  61 */   private static final EmailValidator EMAIL_VALIDATOR = new EmailValidator();
/*     */ 
/*     */   public static EmailValidator getInstance()
/*     */   {
/*  68 */     return EMAIL_VALIDATOR;
/*     */   }
/*     */ 
/*     */   public boolean isValid(String email)
/*     */   {
/*  86 */     if (email == null) {
/*  87 */       return false;
/*     */     }
/*     */ 
/*  90 */     Perl5Util matchAsciiPat = new Perl5Util();
/*  91 */     if (!(matchAsciiPat.match("/^[\\000-\\177]+$/", email))) {
/*  92 */       return false;
/*     */     }
/*     */ 
/*  95 */     email = stripComments(email);
/*     */ 
/*  98 */     Perl5Util emailMatcher = new Perl5Util();
/*  99 */     if (!(emailMatcher.match("/^(.+)@(.+)$/", email))) {
/* 100 */       return false;
/*     */     }
/*     */ 
/* 103 */     if (email.endsWith(".")) {
/* 104 */       return false;
/*     */     }
/*     */ 
/* 107 */     if (!(isValidUser(emailMatcher.group(1)))) {
/* 108 */       return false;
/*     */     }
/*     */ 
/* 112 */     return (!(isValidDomain(emailMatcher.group(2))));
/*     */   }
/*     */ 
/*     */   protected boolean isValidDomain(String domain)
/*     */   {
/* 124 */     boolean symbolic = false;
/* 125 */     Perl5Util ipAddressMatcher = new Perl5Util();
/*     */ 
/* 127 */     if (ipAddressMatcher.match("/^\\[(\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})\\]$/", domain))
/*     */     {
/* 129 */       return (!(isValidIpAddress(ipAddressMatcher)));
/*     */     }
/*     */ 
/* 135 */     Perl5Util domainMatcher = new Perl5Util();
/* 136 */     symbolic = domainMatcher.match("/^[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+(\\.[^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+)*\\s*$/", domain);
/*     */ 
/* 139 */     if (symbolic) {
/* 140 */       if (isValidSymbolicDomain(domain)) break label66;
/* 141 */       return false;
/*     */     }
/*     */ 
/* 144 */     return false;
/*     */ 
/* 147 */     label66: return true;
/*     */   }
/*     */ 
/*     */   protected boolean isValidUser(String user)
/*     */   {
/* 156 */     Perl5Util userMatcher = new Perl5Util();
/* 157 */     return userMatcher.match("/^\\s*(([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]|')+|(\"[^\"]*\"))(\\.(([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]|')+|(\"[^\"]*\")))*$/", user);
/*     */   }
/*     */ 
/*     */   protected boolean isValidIpAddress(Perl5Util ipAddressMatcher)
/*     */   {
/* 166 */     for (int i = 1; i <= 4; ++i) {
/* 167 */       String ipSegment = ipAddressMatcher.group(i);
/* 168 */       if ((ipSegment == null) || (ipSegment.length() <= 0)) {
/* 169 */         return false;
/*     */       }
/*     */ 
/* 172 */       int iIpSegment = 0;
/*     */       try
/*     */       {
/* 175 */         iIpSegment = Integer.parseInt(ipSegment);
/*     */       } catch (NumberFormatException e) {
/* 177 */         return false;
/*     */       }
/*     */ 
/* 180 */       if (iIpSegment > 255) {
/* 181 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 185 */     return true;
/*     */   }
/*     */ 
/*     */   protected boolean isValidSymbolicDomain(String domain)
/*     */   {
/* 194 */     String[] domainSegment = new String[10];
/* 195 */     boolean match = true;
/* 196 */     int i = 0;
/* 197 */     Perl5Util atomMatcher = new Perl5Util();
/* 198 */     while (match) {
/* 199 */       match = atomMatcher.match("/([^\\s\\000-\\037\\(\\)<>@,;:'\\\\\\\"\\.\\[\\]\\177]+)/", domain);
/* 200 */       if (match) {
/* 201 */         domainSegment[i] = atomMatcher.group(1);
/* 202 */         int l = domainSegment[i].length() + 1;
/* 203 */         domain = (l >= domain.length()) ? "" : domain.substring(l);
/*     */ 
/* 208 */         ++i;
/*     */       }
/*     */     }
/*     */ 
/* 212 */     int len = i;
/*     */ 
/* 215 */     if (len < 2) {
/* 216 */       return false;
/*     */     }
/*     */ 
/* 221 */     String tld = domainSegment[(len - 1)];
/* 222 */     if (tld.length() > 1) {
/* 223 */       Perl5Util matchTldPat = new Perl5Util();
/* 224 */       if (!(matchTldPat.match("/^([a-zA-Z]+)$/", tld)))
/* 225 */         return false;
/*     */     }
/*     */     else {
/* 228 */       return false;
/*     */     }
/*     */ 
/* 231 */     return true;
/*     */   }
/*     */ 
/*     */   protected String stripComments(String emailStr)
/*     */   {
/* 242 */     String input = emailStr;
/* 243 */     String result = emailStr;
/* 244 */     String commentPat = "s/^((?:[^\"\\\\]|\\\\.)*(?:\"(?:[^\"\\\\]|\\\\.)*\"(?:[^\"\\\\]|I111\\\\.)*)*)\\((?:[^()\\\\]|\\\\.)*\\)/$1 /osx";
/* 245 */     Perl5Util commentMatcher = new Perl5Util();
/* 246 */     result = commentMatcher.substitute(commentPat, input);
/*     */ 
/* 248 */     while (!(result.equals(input))) {
/* 249 */       input = result;
/* 250 */       result = commentMatcher.substitute(commentPat, input);
/*     */     }
/* 252 */     return result;
/*     */   }
/*     */ }