/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.collections.FastHashMap;
/*     */ import org.apache.commons.validator.util.ValidatorUtils;
/*     */ 
/*     */ public class Field
/*     */   implements Cloneable, Serializable
/*     */ {
/*     */   private static final String DEFAULT_ARG = "org.apache.commons.validator.Field.DEFAULT";
/*     */   public static final String TOKEN_INDEXED = "[]";
/*     */   protected static final String TOKEN_START = "${";
/*     */   protected static final String TOKEN_END = "}";
/*     */   protected static final String TOKEN_VAR = "var:";
/*  79 */   protected String property = null;
/*     */ 
/*  84 */   protected String indexedProperty = null;
/*     */ 
/*  89 */   protected String indexedListProperty = null;
/*     */ 
/*  94 */   protected String key = null;
/*     */ 
/*  99 */   protected String depends = null;
/*     */ 
/* 104 */   protected int page = 0;
/*     */ 
/* 109 */   protected int fieldOrder = 0;
/*     */ 
/* 117 */   private List dependencyList = Collections.synchronizedList(new ArrayList());
/*     */ 
/*     */   /** @deprecated */
/* 122 */   protected FastHashMap hVars = new FastHashMap();
/*     */ 
/*     */   /** @deprecated */
/* 127 */   protected FastHashMap hMsgs = new FastHashMap();
/*     */ 
/* 135 */   protected Map[] args = new Map[0];
/*     */ 
/*     */   public int getPage()
/*     */   {
/* 143 */     return this.page;
/*     */   }
/*     */ 
/*     */   public void setPage(int page)
/*     */   {
/* 152 */     this.page = page;
/*     */   }
/*     */ 
/*     */   public int getFieldOrder()
/*     */   {
/* 160 */     return this.fieldOrder;
/*     */   }
/*     */ 
/*     */   public void setFieldOrder(int fieldOrder)
/*     */   {
/* 168 */     this.fieldOrder = fieldOrder;
/*     */   }
/*     */ 
/*     */   public String getProperty()
/*     */   {
/* 176 */     return this.property;
/*     */   }
/*     */ 
/*     */   public void setProperty(String property)
/*     */   {
/* 184 */     this.property = property;
/*     */   }
/*     */ 
/*     */   public String getIndexedProperty()
/*     */   {
/* 194 */     return this.indexedProperty;
/*     */   }
/*     */ 
/*     */   public void setIndexedProperty(String indexedProperty)
/*     */   {
/* 202 */     this.indexedProperty = indexedProperty;
/*     */   }
/*     */ 
/*     */   public String getIndexedListProperty()
/*     */   {
/* 214 */     return this.indexedListProperty;
/*     */   }
/*     */ 
/*     */   public void setIndexedListProperty(String indexedListProperty)
/*     */   {
/* 222 */     this.indexedListProperty = indexedListProperty;
/*     */   }
/*     */ 
/*     */   public String getDepends()
/*     */   {
/* 230 */     return this.depends;
/*     */   }
/*     */ 
/*     */   public void setDepends(String depends)
/*     */   {
/* 238 */     this.depends = depends;
/*     */ 
/* 240 */     this.dependencyList.clear();
/*     */ 
/* 242 */     StringTokenizer st = new StringTokenizer(depends, ",");
/* 243 */     while (st.hasMoreTokens()) {
/* 244 */       String depend = st.nextToken().trim();
/*     */ 
/* 246 */       if ((depend != null) && (depend.length() > 0))
/* 247 */         this.dependencyList.add(depend);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addMsg(Msg msg)
/*     */   {
/* 257 */     this.hMsgs.put(msg.getName(), msg);
/*     */   }
/*     */ 
/*     */   public String getMsg(String key)
/*     */   {
/* 266 */     Msg msg = getMessage(key);
/* 267 */     return ((msg == null) ? null : msg.getKey());
/*     */   }
/*     */ 
/*     */   public Msg getMessage(String key)
/*     */   {
/* 277 */     return ((Msg)this.hMsgs.get(key));
/*     */   }
/*     */ 
/*     */   public Map getMessages()
/*     */   {
/* 287 */     return Collections.unmodifiableMap(this.hMsgs);
/*     */   }
/*     */ 
/*     */   public void addArg(Arg arg)
/*     */   {
/* 297 */     if ((arg == null) || (arg.getKey() == null) || (arg.getKey().length() == 0)) {
/* 298 */       return;
/*     */     }
/*     */ 
/* 301 */     determineArgPosition(arg);
/* 302 */     ensureArgsCapacity(arg);
/*     */ 
/* 304 */     Map argMap = this.args[arg.getPosition()];
/* 305 */     if (argMap == null) {
/* 306 */       argMap = new HashMap();
/* 307 */       this.args[arg.getPosition()] = argMap;
/*     */     }
/*     */ 
/* 310 */     if (arg.getName() == null)
/* 311 */       argMap.put("org.apache.commons.validator.Field.DEFAULT", arg);
/*     */     else
/* 313 */       argMap.put(arg.getName(), arg);
/*     */   }
/*     */ 
/*     */   private void determineArgPosition(Arg arg)
/*     */   {
/* 323 */     int position = arg.getPosition();
/*     */ 
/* 326 */     if (position >= 0) {
/* 327 */       return;
/*     */     }
/*     */ 
/* 331 */     if ((this.args == null) || (this.args.length == 0)) {
/* 332 */       arg.setPosition(0);
/* 333 */       return;
/*     */     }
/*     */ 
/* 338 */     String key = (arg.getName() == null) ? "org.apache.commons.validator.Field.DEFAULT" : arg.getName();
/* 339 */     int lastPosition = -1;
/* 340 */     int lastDefault = -1;
/* 341 */     for (int i = 0; i < this.args.length; ++i) {
/* 342 */       if ((this.args[i] != null) && (this.args[i].containsKey(key))) {
/* 343 */         lastPosition = i;
/*     */       }
/* 345 */       if ((this.args[i] != null) && (this.args[i].containsKey("org.apache.commons.validator.Field.DEFAULT"))) {
/* 346 */         lastDefault = i;
/*     */       }
/*     */     }
/*     */ 
/* 350 */     if (lastPosition < 0) {
/* 351 */       lastPosition = lastDefault;
/*     */     }
/*     */ 
/* 355 */     arg.setPosition(++lastPosition);
/*     */   }
/*     */ 
/*     */   private void ensureArgsCapacity(Arg arg)
/*     */   {
/* 366 */     if (arg.getPosition() >= this.args.length) {
/* 367 */       Map[] newArgs = new Map[arg.getPosition() + 1];
/* 368 */       System.arraycopy(this.args, 0, newArgs, 0, this.args.length);
/* 369 */       this.args = newArgs;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Arg getArg(int position)
/*     */   {
/* 380 */     return getArg("org.apache.commons.validator.Field.DEFAULT", position);
/*     */   }
/*     */ 
/*     */   public Arg getArg(String key, int position)
/*     */   {
/* 394 */     if ((position >= this.args.length) || (this.args[position] == null)) {
/* 395 */       return null;
/*     */     }
/*     */ 
/* 398 */     Arg arg = (Arg)this.args[position].get(key);
/*     */ 
/* 402 */     if ((arg == null) && (key.equals("org.apache.commons.validator.Field.DEFAULT"))) {
/* 403 */       return null;
/*     */     }
/*     */ 
/* 406 */     return ((arg == null) ? getArg(position) : arg);
/*     */   }
/*     */ 
/*     */   public Arg[] getArgs(String key)
/*     */   {
/* 417 */     Arg[] args = new Arg[this.args.length];
/*     */ 
/* 419 */     for (int i = 0; i < this.args.length; ++i) {
/* 420 */       args[i] = getArg(key, i);
/*     */     }
/*     */ 
/* 423 */     return args;
/*     */   }
/*     */ 
/*     */   public void addVar(Var v)
/*     */   {
/* 431 */     this.hVars.put(v.getName(), v);
/*     */   }
/*     */ 
/*     */   public void addVar(String name, String value, String jsType)
/*     */   {
/* 442 */     addVar(new Var(name, value, jsType));
/*     */   }
/*     */ 
/*     */   public Var getVar(String mainKey)
/*     */   {
/* 451 */     return ((Var)this.hVars.get(mainKey));
/*     */   }
/*     */ 
/*     */   public String getVarValue(String mainKey)
/*     */   {
/* 460 */     String value = null;
/*     */ 
/* 462 */     Object o = this.hVars.get(mainKey);
/* 463 */     if ((o != null) && (o instanceof Var)) {
/* 464 */       Var v = (Var)o;
/* 465 */       value = v.getValue();
/*     */     }
/*     */ 
/* 468 */     return value;
/*     */   }
/*     */ 
/*     */   public Map getVars()
/*     */   {
/* 477 */     return Collections.unmodifiableMap(this.hVars);
/*     */   }
/*     */ 
/*     */   public String getKey()
/*     */   {
/* 485 */     if (this.key == null) {
/* 486 */       generateKey();
/*     */     }
/*     */ 
/* 489 */     return this.key;
/*     */   }
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/* 498 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public boolean isIndexed()
/*     */   {
/* 508 */     return ((this.indexedListProperty != null) && (this.indexedListProperty.length() > 0));
/*     */   }
/*     */ 
/*     */   public void generateKey()
/*     */   {
/* 515 */     if (isIndexed())
/* 516 */       this.key = this.indexedListProperty + "[]" + "." + this.property;
/*     */     else
/* 518 */       this.key = this.property;
/*     */   }
/*     */ 
/*     */   void process(Map globalConstants, Map constants)
/*     */   {
/* 527 */     this.hMsgs.setFast(false);
/* 528 */     this.hVars.setFast(true);
/*     */ 
/* 530 */     generateKey();
/*     */ 
/* 533 */     for (Iterator i = constants.keySet().iterator(); i.hasNext(); ) {
/* 534 */       String key = (String)i.next();
/* 535 */       String key2 = "${" + key + "}";
/* 536 */       String replaceValue = (String)constants.get(key);
/*     */ 
/* 538 */       this.property = ValidatorUtils.replace(this.property, key2, replaceValue);
/*     */ 
/* 540 */       processVars(key2, replaceValue);
/*     */ 
/* 542 */       processMessageComponents(key2, replaceValue);
/*     */     }
/*     */ 
/* 546 */     for (Iterator i = globalConstants.keySet().iterator(); i.hasNext(); ) {
/* 547 */       String key = (String)i.next();
/* 548 */       String key2 = "${" + key + "}";
/* 549 */       String replaceValue = (String)globalConstants.get(key);
/*     */ 
/* 551 */       this.property = ValidatorUtils.replace(this.property, key2, replaceValue);
/*     */ 
/* 553 */       processVars(key2, replaceValue);
/*     */ 
/* 555 */       processMessageComponents(key2, replaceValue);
/*     */     }
/*     */ 
/* 559 */     for (Iterator i = this.hVars.keySet().iterator(); i.hasNext(); ) {
/* 560 */       String key = (String)i.next();
/* 561 */       String key2 = "${var:" + key + "}";
/* 562 */       Var var = getVar(key);
/* 563 */       String replaceValue = var.getValue();
/*     */ 
/* 565 */       processMessageComponents(key2, replaceValue);
/*     */     }
/*     */ 
/* 568 */     this.hMsgs.setFast(true);
/*     */   }
/*     */ 
/*     */   private void processVars(String key, String replaceValue)
/*     */   {
/* 575 */     Iterator i = this.hVars.keySet().iterator();
/* 576 */     while (i.hasNext()) {
/* 577 */       String varKey = (String)i.next();
/* 578 */       Var var = getVar(varKey);
/*     */ 
/* 580 */       var.setValue(ValidatorUtils.replace(var.getValue(), key, replaceValue));
/*     */     }
/*     */   }
/*     */ 
/*     */   private void processMessageComponents(String key, String replaceValue)
/*     */   {
/* 589 */     String varKey = "${var:";
/*     */ 
/* 591 */     if ((key != null) && (!(key.startsWith(varKey)))) {
/* 592 */       for (Iterator i = this.hMsgs.values().iterator(); i.hasNext(); ) {
/* 593 */         Msg msg = (Msg)i.next();
/* 594 */         msg.setKey(ValidatorUtils.replace(msg.getKey(), key, replaceValue));
/*     */       }
/*     */     }
/*     */ 
/* 598 */     processArg(key, replaceValue);
/*     */   }
/*     */ 
/*     */   private void processArg(String key, String replaceValue)
/*     */   {
/* 606 */     for (int i = 0; i < this.args.length; ++i)
/*     */     {
/* 608 */       Map argMap = this.args[i];
/* 609 */       if (argMap == null) {
/*     */         continue;
/*     */       }
/*     */ 
/* 613 */       Iterator iter = argMap.values().iterator();
/* 614 */       while (iter.hasNext()) {
/* 615 */         Arg arg = (Arg)iter.next();
/*     */ 
/* 617 */         if (arg != null)
/* 618 */           arg.setKey(ValidatorUtils.replace(arg.getKey(), key, replaceValue));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isDependency(String validatorName)
/*     */   {
/* 631 */     return this.dependencyList.contains(validatorName);
/*     */   }
/*     */ 
/*     */   public List getDependencyList()
/*     */   {
/* 640 */     return Collections.unmodifiableList(this.dependencyList);
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 648 */     Field field = null;
/*     */     try {
/* 650 */       field = (Field)super.clone();
/*     */     } catch (CloneNotSupportedException e) {
/* 652 */       throw new RuntimeException(e.toString());
/*     */     }
/*     */ 
/* 655 */     field.args = new Map[this.args.length];
/* 656 */     for (int i = 0; i < this.args.length; ++i) {
/* 657 */       if (this.args[i] == null) {
/*     */         continue;
/*     */       }
/*     */ 
/* 661 */       Map argMap = new HashMap(this.args[i]);
/* 662 */       Iterator iter = argMap.keySet().iterator();
/* 663 */       while (iter.hasNext()) {
/* 664 */         String validatorName = (String)iter.next();
/* 665 */         Arg arg = (Arg)argMap.get(validatorName);
/* 666 */         argMap.put(validatorName, arg.clone());
/*     */       }
/* 668 */       field.args[i] = argMap;
/*     */     }
/*     */ 
/* 671 */     field.hVars = ValidatorUtils.copyFastHashMap(this.hVars);
/* 672 */     field.hMsgs = ValidatorUtils.copyFastHashMap(this.hMsgs);
/*     */ 
/* 674 */     return field;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 682 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 684 */     results.append("\t\tkey = " + this.key + "\n");
/* 685 */     results.append("\t\tproperty = " + this.property + "\n");
/* 686 */     results.append("\t\tindexedProperty = " + this.indexedProperty + "\n");
/* 687 */     results.append("\t\tindexedListProperty = " + this.indexedListProperty + "\n");
/* 688 */     results.append("\t\tdepends = " + this.depends + "\n");
/* 689 */     results.append("\t\tpage = " + this.page + "\n");
/* 690 */     results.append("\t\tfieldOrder = " + this.fieldOrder + "\n");
/*     */ 
/* 692 */     if (this.hVars != null) {
/* 693 */       results.append("\t\tVars:\n");
/* 694 */       for (Iterator i = this.hVars.keySet().iterator(); i.hasNext(); ) {
/* 695 */         Object key = i.next();
/* 696 */         results.append("\t\t\t");
/* 697 */         results.append(key);
/* 698 */         results.append("=");
/* 699 */         results.append(this.hVars.get(key));
/* 700 */         results.append("\n");
/*     */       }
/*     */     }
/*     */ 
/* 704 */     return results.toString();
/*     */   }
/*     */ 
/*     */   Object[] getIndexedProperty(Object bean)
/*     */     throws ValidatorException
/*     */   {
/* 715 */     Object indexedProperty = null;
/*     */     try
/*     */     {
/* 718 */       indexedProperty = PropertyUtils.getProperty(bean, getIndexedListProperty());
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 722 */       throw new ValidatorException(e.getMessage());
/*     */     } catch (InvocationTargetException e) {
/* 724 */       throw new ValidatorException(e.getMessage());
/*     */     } catch (NoSuchMethodException e) {
/* 726 */       throw new ValidatorException(e.getMessage());
/*     */     }
/*     */ 
/* 729 */     if (indexedProperty instanceof Collection) {
/* 730 */       return ((Collection)indexedProperty).toArray();
/*     */     }
/* 732 */     if (indexedProperty.getClass().isArray()) {
/* 733 */       return ((Object[])indexedProperty);
/*     */     }
/*     */ 
/* 736 */     throw new ValidatorException(getKey() + " is not indexed");
/*     */   }
/*     */ 
/*     */   private int getIndexedPropertySize(Object bean)
/*     */     throws ValidatorException
/*     */   {
/* 748 */     Object indexedProperty = null;
/*     */     try
/*     */     {
/* 751 */       indexedProperty = PropertyUtils.getProperty(bean, getIndexedListProperty());
/*     */     }
/*     */     catch (IllegalAccessException e)
/*     */     {
/* 755 */       throw new ValidatorException(e.getMessage());
/*     */     } catch (InvocationTargetException e) {
/* 757 */       throw new ValidatorException(e.getMessage());
/*     */     } catch (NoSuchMethodException e) {
/* 759 */       throw new ValidatorException(e.getMessage());
/*     */     }
/*     */ 
/* 762 */     if (indexedProperty == null)
/* 763 */       return 0;
/* 764 */     if (indexedProperty instanceof Collection)
/* 765 */       return ((Collection)indexedProperty).size();
/* 766 */     if (indexedProperty.getClass().isArray()) {
/* 767 */       return ((Object[])indexedProperty).length;
/*     */     }
/* 769 */     throw new ValidatorException(getKey() + " is not indexed");
/*     */   }
/*     */ 
/*     */   private boolean validateForRule(ValidatorAction va, ValidatorResults results, Map actions, Map params, int pos)
/*     */     throws ValidatorException
/*     */   {
/* 787 */     ValidatorResult result = results.getValidatorResult(getKey());
/* 788 */     if ((result != null) && (result.containsAction(va.getName()))) {
/* 789 */       return result.isValid(va.getName());
/*     */     }
/*     */ 
/* 792 */     if (!(runDependentValidators(va, results, actions, params, pos))) {
/* 793 */       return false;
/*     */     }
/*     */ 
/* 796 */     return va.executeValidationMethod(this, params, results, pos);
/*     */   }
/*     */ 
/*     */   private boolean runDependentValidators(ValidatorAction va, ValidatorResults results, Map actions, Map params, int pos)
/*     */     throws ValidatorException
/*     */   {
/* 817 */     List dependentValidators = va.getDependencyList();
/*     */ 
/* 819 */     if (dependentValidators.isEmpty()) {
/* 820 */       return true;
/*     */     }
/*     */ 
/* 823 */     Iterator iter = dependentValidators.iterator();
/* 824 */     while (iter.hasNext()) {
/* 825 */       String depend = (String)iter.next();
/*     */ 
/* 827 */       ValidatorAction action = (ValidatorAction)actions.get(depend);
/* 828 */       if (action == null) {
/* 829 */         handleMissingAction(depend);
/*     */       }
/*     */ 
/* 832 */       if (!(validateForRule(action, results, actions, params, pos))) {
/* 833 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 837 */     return true;
/*     */   }
/*     */ 
/*     */   public ValidatorResults validate(Map params, Map actions)
/*     */     throws ValidatorException
/*     */   {
/* 854 */     if (getDepends() == null) {
/* 855 */       return new ValidatorResults();
/*     */     }
/*     */ 
/* 858 */     ValidatorResults allResults = new ValidatorResults();
/*     */ 
/* 860 */     Object bean = params.get("java.lang.Object");
/* 861 */     int numberOfFieldsToValidate = (isIndexed()) ? getIndexedPropertySize(bean) : 1;
/*     */ 
/* 864 */     for (int fieldNumber = 0; fieldNumber < numberOfFieldsToValidate; ++fieldNumber)
/*     */     {
/* 866 */       Iterator dependencies = this.dependencyList.iterator();
/* 867 */       ValidatorResults results = new ValidatorResults();
/* 868 */       while (dependencies.hasNext()) {
/* 869 */         String depend = (String)dependencies.next();
/*     */ 
/* 871 */         ValidatorAction action = (ValidatorAction)actions.get(depend);
/* 872 */         if (action == null) {
/* 873 */           handleMissingAction(depend);
/*     */         }
/*     */ 
/* 876 */         boolean good = validateForRule(action, results, actions, params, fieldNumber);
/*     */ 
/* 879 */         if (!(good)) {
/* 880 */           allResults.merge(results);
/* 881 */           return allResults;
/*     */         }
/*     */       }
/* 884 */       allResults.merge(results);
/*     */     }
/*     */ 
/* 887 */     return allResults;
/*     */   }
/*     */ 
/*     */   private void handleMissingAction(String name)
/*     */     throws ValidatorException
/*     */   {
/* 897 */     throw new ValidatorException("No ValidatorAction named " + name + " found for field " + getProperty());
/*     */   }
/*     */ 
/*     */   protected Map getMsgMap()
/*     */   {
/* 907 */     return this.hMsgs;
/*     */   }
/*     */ 
/*     */   protected Map getVarMap()
/*     */   {
/* 916 */     return this.hVars;
/*     */   }
/*     */ }