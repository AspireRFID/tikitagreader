/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.validator.util.Flags;
/*     */ import org.apache.oro.text.perl.Perl5Util;
/*     */ 
/*     */ public class UrlValidator
/*     */   implements Serializable
/*     */ {
/*     */   public static final int ALLOW_ALL_SCHEMES = 1;
/*     */   public static final int ALLOW_2_SLASHES = 2;
/*     */   public static final int NO_FRAGMENTS = 4;
/*     */   private static final String ALPHA_CHARS = "a-zA-Z";
/*     */   private static final String ALPHA_NUMERIC_CHARS = "a-zA-Z\\d";
/*     */   private static final String SPECIAL_CHARS = ";/@&=,.?:+$";
/*     */   private static final String VALID_CHARS = "[^\\s;/@&=,.?:+$]";
/*     */   private static final String SCHEME_CHARS = "a-zA-Z";
/*     */   private static final String AUTHORITY_CHARS = "a-zA-Z\\d\\-\\.";
/*     */   private static final String ATOM = "[^\\s;/@&=,.?:+$]+";
/*     */   private static final String URL_PATTERN = "/^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?/";
/*     */   private static final int PARSE_URL_SCHEME = 2;
/*     */   private static final int PARSE_URL_AUTHORITY = 4;
/*     */   private static final int PARSE_URL_PATH = 5;
/*     */   private static final int PARSE_URL_QUERY = 7;
/*     */   private static final int PARSE_URL_FRAGMENT = 9;
/*     */   private static final String SCHEME_PATTERN = "/^[a-zA-Z]/";
/*     */   private static final String AUTHORITY_PATTERN = "/^([a-zA-Z\\d\\-\\.]*)(:\\d*)?(.*)?/";
/*     */   private static final int PARSE_AUTHORITY_HOST_IP = 1;
/*     */   private static final int PARSE_AUTHORITY_PORT = 2;
/*     */   private static final int PARSE_AUTHORITY_EXTRA = 3;
/*     */   private static final String PATH_PATTERN = "/^(/[-\\w:@&?=+,.!/~*'%$_;]*)?$/";
/*     */   private static final String QUERY_PATTERN = "/^(.*)$/";
/*     */   private static final String LEGAL_ASCII_PATTERN = "/^[\\000-\\177]+$/";
/*     */   private static final String IP_V4_DOMAIN_PATTERN = "/^(\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})$/";
/*     */   private static final String DOMAIN_PATTERN = "/^[^\\s;/@&=,.?:+$]+(\\.[^\\s;/@&=,.?:+$]+)*$/";
/*     */   private static final String PORT_PATTERN = "/^:(\\d{1,5})$/";
/*     */   private static final String ATOM_PATTERN = "/([^\\s;/@&=,.?:+$]+)/";
/*     */   private static final String ALPHA_PATTERN = "/^[a-zA-Z]/";
/*     */   private Flags options;
/*     */   private Set allowedSchemes;
/*     */   protected String[] defaultSchemes;
/*     */ 
/*     */   public UrlValidator()
/*     */   {
/* 184 */     this(null);
/*     */   }
/*     */ 
/*     */   public UrlValidator(String[] schemes)
/*     */   {
/* 196 */     this(schemes, 0);
/*     */   }
/*     */ 
/*     */   public UrlValidator(int options)
/*     */   {
/* 206 */     this(null, options);
/*     */   }
/*     */ 
/*     */   public UrlValidator(String[] schemes, int options)
/*     */   {
/* 168 */     this.options = null;
/*     */ 
/* 173 */     this.allowedSchemes = new HashSet();
/*     */ 
/* 178 */     this.defaultSchemes = new String[] { "http", "https", "ftp" };
/*     */ 
/* 217 */     this.options = new Flags(options);
/*     */ 
/* 219 */     if (this.options.isOn(1L)) {
/* 220 */       return;
/*     */     }
/*     */ 
/* 223 */     if (schemes == null) {
/* 224 */       schemes = this.defaultSchemes;
/*     */     }
/*     */ 
/* 227 */     this.allowedSchemes.addAll(Arrays.asList(schemes));
/*     */   }
/*     */ 
/*     */   public boolean isValid(String value)
/*     */   {
/* 238 */     if (value == null) {
/* 239 */       return false;
/*     */     }
/*     */ 
/* 242 */     Perl5Util matchUrlPat = new Perl5Util();
/* 243 */     Perl5Util matchAsciiPat = new Perl5Util();
/*     */ 
/* 245 */     if (!(matchAsciiPat.match("/^[\\000-\\177]+$/", value))) {
/* 246 */       return false;
/*     */     }
/*     */ 
/* 250 */     if (!(matchUrlPat.match("/^(([^:/?#]+):)?(//([^/?#]*))?([^?#]*)(\\?([^#]*))?(#(.*))?/", value))) {
/* 251 */       return false;
/*     */     }
/*     */ 
/* 254 */     if (!(isValidScheme(matchUrlPat.group(2)))) {
/* 255 */       return false;
/*     */     }
/*     */ 
/* 258 */     if (!(isValidAuthority(matchUrlPat.group(4)))) {
/* 259 */       return false;
/*     */     }
/*     */ 
/* 262 */     if (!(isValidPath(matchUrlPat.group(5)))) {
/* 263 */       return false;
/*     */     }
/*     */ 
/* 266 */     if (!(isValidQuery(matchUrlPat.group(7)))) {
/* 267 */       return false;
/*     */     }
/*     */ 
/* 271 */     return (!(isValidFragment(matchUrlPat.group(9))));
/*     */   }
/*     */ 
/*     */   protected boolean isValidScheme(String scheme)
/*     */   {
/* 286 */     if (scheme == null) {
/* 287 */       return false;
/*     */     }
/*     */ 
/* 290 */     Perl5Util schemeMatcher = new Perl5Util();
/* 291 */     if (!(schemeMatcher.match("/^[a-zA-Z]/", scheme))) {
/* 292 */       return false;
/*     */     }
/*     */ 
/* 298 */     return ((this.options.isOff(1L)) && 
/* 297 */       (!(this.allowedSchemes.contains(scheme))));
/*     */   }
/*     */ 
/*     */   protected boolean isValidAuthority(String authority)
/*     */   {
/* 312 */     if (authority == null) {
/* 313 */       return false;
/*     */     }
/*     */ 
/* 316 */     Perl5Util authorityMatcher = new Perl5Util();
/* 317 */     Perl5Util matchIPV4Pat = new Perl5Util();
/*     */ 
/* 319 */     if (!(authorityMatcher.match("/^([a-zA-Z\\d\\-\\.]*)(:\\d*)?(.*)?/", authority))) {
/* 320 */       return false;
/*     */     }
/*     */ 
/* 323 */     boolean ipV4Address = false;
/* 324 */     boolean hostname = false;
/*     */ 
/* 326 */     String hostIP = authorityMatcher.group(1);
/* 327 */     ipV4Address = matchIPV4Pat.match("/^(\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})[.](\\d{1,3})$/", hostIP);
/*     */ 
/* 329 */     if (ipV4Address)
/*     */     {
/* 331 */       for (int i = 1; i <= 4; ++i) {
/* 332 */         String ipSegment = matchIPV4Pat.group(i);
/* 333 */         if ((ipSegment == null) || (ipSegment.length() <= 0)) {
/* 334 */           return false;
/*     */         }
/*     */         try
/*     */         {
/* 338 */           if (Integer.parseInt(ipSegment) > 255)
/* 339 */             return false;
/*     */         }
/*     */         catch (NumberFormatException e) {
/* 342 */           return false;
/*     */         }
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 348 */       Perl5Util domainMatcher = new Perl5Util();
/* 349 */       hostname = domainMatcher.match("/^[^\\s;/@&=,.?:+$]+(\\.[^\\s;/@&=,.?:+$]+)*$/", hostIP);
/*     */     }
/*     */ 
/* 353 */     if (hostname)
/*     */     {
/* 356 */       char[] chars = hostIP.toCharArray();
/* 357 */       int size = 1;
/* 358 */       for (int i = 0; i < chars.length; ++i) {
/* 359 */         if (chars[i] == '.') {
/* 360 */           ++size;
/*     */         }
/*     */       }
/* 363 */       String[] domainSegment = new String[size];
/* 364 */       boolean match = true;
/* 365 */       int segmentCount = 0;
/* 366 */       int segmentLength = 0;
/* 367 */       Perl5Util atomMatcher = new Perl5Util();
/*     */ 
/* 369 */       while (match) {
/* 370 */         match = atomMatcher.match("/([^\\s;/@&=,.?:+$]+)/", hostIP);
/* 371 */         if (match) {
/* 372 */           domainSegment[segmentCount] = atomMatcher.group(1);
/* 373 */           segmentLength = domainSegment[segmentCount].length() + 1;
/* 374 */           hostIP = (segmentLength >= hostIP.length()) ? "" : hostIP.substring(segmentLength);
/*     */ 
/* 379 */           ++segmentCount;
/*     */         }
/*     */       }
/* 382 */       String topLevel = domainSegment[(segmentCount - 1)];
/* 383 */       if ((topLevel.length() < 2) || (topLevel.length() > 4)) {
/* 384 */         return false;
/*     */       }
/*     */ 
/* 388 */       Perl5Util alphaMatcher = new Perl5Util();
/* 389 */       if (!(alphaMatcher.match("/^[a-zA-Z]/", topLevel.substring(0, 1)))) {
/* 390 */         return false;
/*     */       }
/*     */ 
/* 394 */       if (segmentCount < 2) {
/* 395 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 399 */     if ((!(hostname)) && (!(ipV4Address))) {
/* 400 */       return false;
/*     */     }
/*     */ 
/* 403 */     String port = authorityMatcher.group(2);
/* 404 */     if (port != null) {
/* 405 */       Perl5Util portMatcher = new Perl5Util();
/* 406 */       if (!(portMatcher.match("/^:(\\d{1,5})$/", port))) {
/* 407 */         return false;
/*     */       }
/*     */     }
/*     */ 
/* 411 */     String extra = authorityMatcher.group(3);
/*     */ 
/* 413 */     return (!(GenericValidator.isBlankOrNull(extra)));
/*     */   }
/*     */ 
/*     */   protected boolean isValidPath(String path)
/*     */   {
/* 425 */     if (path == null) {
/* 426 */       return false;
/*     */     }
/*     */ 
/* 429 */     Perl5Util pathMatcher = new Perl5Util();
/*     */ 
/* 431 */     if (!(pathMatcher.match("/^(/[-\\w:@&?=+,.!/~*'%$_;]*)?$/", path))) {
/* 432 */       return false;
/*     */     }
/*     */ 
/* 435 */     int slash2Count = countToken("//", path);
/* 436 */     if ((this.options.isOff(2L)) && (slash2Count > 0)) {
/* 437 */       return false;
/*     */     }
/*     */ 
/* 440 */     int slashCount = countToken("/", path);
/* 441 */     int dot2Count = countToken("..", path);
/*     */ 
/* 444 */     return ((dot2Count > 0) && 
/* 443 */       (slashCount - slash2Count - 1 <= dot2Count));
/*     */   }
/*     */ 
/*     */   protected boolean isValidQuery(String query)
/*     */   {
/* 457 */     if (query == null) {
/* 458 */       return true;
/*     */     }
/*     */ 
/* 461 */     Perl5Util queryMatcher = new Perl5Util();
/* 462 */     return queryMatcher.match("/^(.*)$/", query);
/*     */   }
/*     */ 
/*     */   protected boolean isValidFragment(String fragment)
/*     */   {
/* 471 */     if (fragment == null) {
/* 472 */       return true;
/*     */     }
/*     */ 
/* 475 */     return this.options.isOff(4L);
/*     */   }
/*     */ 
/*     */   protected int countToken(String token, String target)
/*     */   {
/* 485 */     int tokenIndex = 0;
/* 486 */     int count = 0;
/* 487 */     while (tokenIndex != -1) {
/* 488 */       tokenIndex = target.indexOf(token, tokenIndex);
/* 489 */       if (tokenIndex > -1) {
/* 490 */         ++tokenIndex;
/* 491 */         ++count;
/*     */       }
/*     */     }
/* 494 */     return count;
/*     */   }
/*     */ }