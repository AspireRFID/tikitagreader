/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.text.DateFormat;
/*     */ import java.text.NumberFormat;
/*     */ import java.text.ParseException;
/*     */ import java.text.ParsePosition;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.Locale;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class GenericTypeValidator
/*     */   implements Serializable
/*     */ {
/*     */   public static Byte formatByte(String value)
/*     */   {
/*  45 */     if (value == null) {
/*  46 */       return null;
/*     */     }
/*     */     try
/*     */     {
/*  50 */       return new Byte(value); } catch (NumberFormatException e) {
/*     */     }
/*  52 */     return null;
/*     */   }
/*     */ 
/*     */   public static Byte formatByte(String value, Locale locale)
/*     */   {
/*  66 */     Byte result = null;
/*     */ 
/*  68 */     if (value != null) {
/*  69 */       NumberFormat formatter = null;
/*  70 */       if (locale != null)
/*  71 */         formatter = NumberFormat.getNumberInstance(locale);
/*     */       else {
/*  73 */         formatter = NumberFormat.getNumberInstance(Locale.getDefault());
/*     */       }
/*  75 */       formatter.setParseIntegerOnly(true);
/*  76 */       ParsePosition pos = new ParsePosition(0);
/*  77 */       Number num = formatter.parse(value, pos);
/*     */ 
/*  80 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/*  81 */         (num.doubleValue() >= -128.0D) && (num.doubleValue() <= 127.0D))
/*     */       {
/*  83 */         result = new Byte(num.byteValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/*  88 */     return result;
/*     */   }
/*     */ 
/*     */   public static Short formatShort(String value)
/*     */   {
/*  98 */     if (value == null) {
/*  99 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 103 */       return new Short(value); } catch (NumberFormatException e) {
/*     */     }
/* 105 */     return null;
/*     */   }
/*     */ 
/*     */   public static Short formatShort(String value, Locale locale)
/*     */   {
/* 119 */     Short result = null;
/*     */ 
/* 121 */     if (value != null) {
/* 122 */       NumberFormat formatter = null;
/* 123 */       if (locale != null)
/* 124 */         formatter = NumberFormat.getNumberInstance(locale);
/*     */       else {
/* 126 */         formatter = NumberFormat.getNumberInstance(Locale.getDefault());
/*     */       }
/* 128 */       formatter.setParseIntegerOnly(true);
/* 129 */       ParsePosition pos = new ParsePosition(0);
/* 130 */       Number num = formatter.parse(value, pos);
/*     */ 
/* 133 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/* 134 */         (num.doubleValue() >= -32768.0D) && (num.doubleValue() <= 32767.0D))
/*     */       {
/* 136 */         result = new Short(num.shortValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 141 */     return result;
/*     */   }
/*     */ 
/*     */   public static Integer formatInt(String value)
/*     */   {
/* 151 */     if (value == null) {
/* 152 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 156 */       return new Integer(value); } catch (NumberFormatException e) {
/*     */     }
/* 158 */     return null;
/*     */   }
/*     */ 
/*     */   public static Integer formatInt(String value, Locale locale)
/*     */   {
/* 172 */     Integer result = null;
/*     */ 
/* 174 */     if (value != null) {
/* 175 */       NumberFormat formatter = null;
/* 176 */       if (locale != null)
/* 177 */         formatter = NumberFormat.getNumberInstance(locale);
/*     */       else {
/* 179 */         formatter = NumberFormat.getNumberInstance(Locale.getDefault());
/*     */       }
/* 181 */       formatter.setParseIntegerOnly(true);
/* 182 */       ParsePosition pos = new ParsePosition(0);
/* 183 */       Number num = formatter.parse(value, pos);
/*     */ 
/* 186 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/* 187 */         (num.doubleValue() >= -2147483648.0D) && (num.doubleValue() <= 2147483647.0D))
/*     */       {
/* 189 */         result = new Integer(num.intValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public static Long formatLong(String value)
/*     */   {
/* 204 */     if (value == null) {
/* 205 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 209 */       return new Long(value); } catch (NumberFormatException e) {
/*     */     }
/* 211 */     return null;
/*     */   }
/*     */ 
/*     */   public static Long formatLong(String value, Locale locale)
/*     */   {
/* 225 */     Long result = null;
/*     */ 
/* 227 */     if (value != null) {
/* 228 */       NumberFormat formatter = null;
/* 229 */       if (locale != null)
/* 230 */         formatter = NumberFormat.getNumberInstance(locale);
/*     */       else {
/* 232 */         formatter = NumberFormat.getNumberInstance(Locale.getDefault());
/*     */       }
/* 234 */       formatter.setParseIntegerOnly(true);
/* 235 */       ParsePosition pos = new ParsePosition(0);
/* 236 */       Number num = formatter.parse(value, pos);
/*     */ 
/* 239 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/* 240 */         (num.doubleValue() >= -9.223372036854776E+018D) && (num.doubleValue() <= 9.223372036854776E+018D))
/*     */       {
/* 242 */         result = new Long(num.longValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 247 */     return result;
/*     */   }
/*     */ 
/*     */   public static Float formatFloat(String value)
/*     */   {
/* 257 */     if (value == null) {
/* 258 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 262 */       return new Float(value); } catch (NumberFormatException e) {
/*     */     }
/* 264 */     return null;
/*     */   }
/*     */ 
/*     */   public static Float formatFloat(String value, Locale locale)
/*     */   {
/* 278 */     Float result = null;
/*     */ 
/* 280 */     if (value != null) {
/* 281 */       NumberFormat formatter = null;
/* 282 */       if (locale != null)
/* 283 */         formatter = NumberFormat.getInstance(locale);
/*     */       else {
/* 285 */         formatter = NumberFormat.getInstance(Locale.getDefault());
/*     */       }
/* 287 */       ParsePosition pos = new ParsePosition(0);
/* 288 */       Number num = formatter.parse(value, pos);
/*     */ 
/* 291 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/* 292 */         (num.doubleValue() >= -3.402823466385289E+038D) && (num.doubleValue() <= 3.402823466385289E+038D))
/*     */       {
/* 294 */         result = new Float(num.floatValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 299 */     return result;
/*     */   }
/*     */ 
/*     */   public static Double formatDouble(String value)
/*     */   {
/* 309 */     if (value == null) {
/* 310 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 314 */       return new Double(value); } catch (NumberFormatException e) {
/*     */     }
/* 316 */     return null;
/*     */   }
/*     */ 
/*     */   public static Double formatDouble(String value, Locale locale)
/*     */   {
/* 330 */     Double result = null;
/*     */ 
/* 332 */     if (value != null) {
/* 333 */       NumberFormat formatter = null;
/* 334 */       if (locale != null)
/* 335 */         formatter = NumberFormat.getInstance(locale);
/*     */       else {
/* 337 */         formatter = NumberFormat.getInstance(Locale.getDefault());
/*     */       }
/* 339 */       ParsePosition pos = new ParsePosition(0);
/* 340 */       Number num = formatter.parse(value, pos);
/*     */ 
/* 343 */       if ((pos.getErrorIndex() == -1) && (pos.getIndex() == value.length()) && 
/* 344 */         (num.doubleValue() >= -1.797693134862316E+308D) && (num.doubleValue() <= 1.7976931348623157E+308D))
/*     */       {
/* 346 */         result = new Double(num.doubleValue());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 351 */     return result;
/*     */   }
/*     */ 
/*     */   public static Date formatDate(String value, Locale locale)
/*     */   {
/* 367 */     Date date = null;
/*     */ 
/* 369 */     if (value == null) {
/* 370 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 374 */       DateFormat formatter = null;
/* 375 */       if (locale != null) {
/* 376 */         formatter = DateFormat.getDateInstance(3, locale);
/*     */       }
/*     */       else {
/* 379 */         formatter = DateFormat.getDateInstance(3, Locale.getDefault());
/*     */       }
/*     */ 
/* 385 */       formatter.setLenient(false);
/*     */ 
/* 387 */       date = formatter.parse(value);
/*     */     }
/*     */     catch (ParseException e) {
/* 390 */       Log log = LogFactory.getLog(GenericTypeValidator.class);
/* 391 */       if (log.isDebugEnabled()) {
/* 392 */         log.debug("Date parse failed value=[" + value + "], " + "locale=[" + locale + "] " + e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 397 */     return date;
/*     */   }
/*     */ 
/*     */   public static Date formatDate(String value, String datePattern, boolean strict)
/*     */   {
/* 415 */     Date date = null;
/*     */ 
/* 417 */     if ((value == null) || (datePattern == null) || (datePattern.length() == 0))
/*     */     {
/* 420 */       return null;
/*     */     }
/*     */     try
/*     */     {
/* 424 */       SimpleDateFormat formatter = new SimpleDateFormat(datePattern);
/* 425 */       formatter.setLenient(false);
/*     */ 
/* 427 */       date = formatter.parse(value);
/*     */ 
/* 429 */       if ((strict) && 
/* 430 */         (datePattern.length() != value.length())) {
/* 431 */         date = null;
/*     */       }
/*     */     }
/*     */     catch (ParseException e)
/*     */     {
/* 436 */       Log log = LogFactory.getLog(GenericTypeValidator.class);
/* 437 */       if (log.isDebugEnabled()) {
/* 438 */         log.debug("Date parse failed value=[" + value + "], " + "pattern=[" + datePattern + "], " + "strict=[" + strict + "] " + e);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 444 */     return date;
/*     */   }
/*     */ 
/*     */   public static Long formatCreditCard(String value)
/*     */   {
/* 458 */     return ((GenericValidator.isCreditCard(value)) ? new Long(value) : null);
/*     */   }
/*     */ }