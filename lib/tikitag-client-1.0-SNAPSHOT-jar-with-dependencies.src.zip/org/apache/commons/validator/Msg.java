/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ 
/*     */ public class Msg
/*     */   implements Cloneable, Serializable
/*     */ {
/*  36 */   protected String bundle = null;
/*     */ 
/*  41 */   protected String key = null;
/*     */ 
/*  46 */   protected String name = null;
/*     */ 
/*  54 */   protected boolean resource = true;
/*     */ 
/*     */   public String getBundle()
/*     */   {
/*  62 */     return this.bundle;
/*     */   }
/*     */ 
/*     */   public void setBundle(String bundle)
/*     */   {
/*  71 */     this.bundle = bundle;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  79 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name)
/*     */   {
/*  87 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getKey()
/*     */   {
/*  95 */     return this.key;
/*     */   }
/*     */ 
/*     */   public void setKey(String key)
/*     */   {
/* 103 */     this.key = key;
/*     */   }
/*     */ 
/*     */   public boolean isResource()
/*     */   {
/* 112 */     return this.resource;
/*     */   }
/*     */ 
/*     */   public void setResource(boolean resource)
/*     */   {
/* 121 */     this.resource = resource;
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/*     */     try
/*     */     {
/* 130 */       return super.clone();
/*     */     }
/*     */     catch (CloneNotSupportedException e) {
/* 133 */       throw new RuntimeException(e.toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 142 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 144 */     results.append("Msg: name=");
/* 145 */     results.append(this.name);
/* 146 */     results.append("  key=");
/* 147 */     results.append(this.key);
/* 148 */     results.append("  resource=");
/* 149 */     results.append(this.resource);
/* 150 */     results.append("  bundle=");
/* 151 */     results.append(this.bundle);
/* 152 */     results.append("\n");
/*     */ 
/* 154 */     return results.toString();
/*     */   }
/*     */ }