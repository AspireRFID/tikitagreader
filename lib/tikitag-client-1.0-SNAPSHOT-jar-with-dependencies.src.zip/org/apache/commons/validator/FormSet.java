/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class FormSet
/*     */   implements Serializable
/*     */ {
/*  37 */   private transient Log log = LogFactory.getLog(FormSet.class);
/*     */ 
/*  43 */   private boolean processed = false;
/*     */ 
/*  46 */   private String language = null;
/*     */ 
/*  49 */   private String country = null;
/*     */ 
/*  52 */   private String variant = null;
/*     */ 
/*  58 */   private Map forms = new HashMap();
/*     */ 
/*  64 */   private Map constants = new HashMap();
/*     */   protected static final int GLOBAL_FORMSET = 1;
/*     */   protected static final int LANGUAGE_FORMSET = 2;
/*     */   protected static final int COUNTRY_FORMSET = 3;
/*     */   protected static final int VARIANT_FORMSET = 4;
/*     */   private boolean merged;
/*     */ 
/*     */   protected boolean isMerged()
/*     */   {
/* 101 */     return this.merged;
/*     */   }
/*     */ 
/*     */   protected int getType()
/*     */   {
/* 115 */     if (getVariant() != null) {
/* 116 */       if ((getLanguage() == null) || (getCountry() == null)) {
/* 117 */         throw new NullPointerException("When variant is specified, country and language must be specified.");
/*     */       }
/*     */ 
/* 120 */       return 4;
/*     */     }
/* 122 */     if (getCountry() != null) {
/* 123 */       if (getLanguage() == null) {
/* 124 */         throw new NullPointerException("When country is specified, language must be specified.");
/*     */       }
/*     */ 
/* 127 */       return 3;
/*     */     }
/* 129 */     if (getLanguage() != null) {
/* 130 */       return 2;
/*     */     }
/*     */ 
/* 133 */     return 1;
/*     */   }
/*     */ 
/*     */   protected void merge(FormSet depends)
/*     */   {
/* 147 */     if (depends != null) {
/* 148 */       Map pForms = getForms();
/* 149 */       Map dForms = depends.getForms();
/* 150 */       for (Iterator it = dForms.keySet().iterator(); it.hasNext(); ) {
/* 151 */         Object key = it.next();
/* 152 */         Form pForm = (Form)pForms.get(key);
/* 153 */         if (pForm != null)
/*     */         {
/* 155 */           pForm.merge((Form)dForms.get(key));
/*     */         }
/*     */         else {
/* 158 */           addForm((Form)dForms.get(key));
/*     */         }
/*     */       }
/*     */     }
/* 162 */     this.merged = true;
/*     */   }
/*     */ 
/*     */   public boolean isProcessed()
/*     */   {
/* 172 */     return this.processed;
/*     */   }
/*     */ 
/*     */   public String getLanguage()
/*     */   {
/* 181 */     return this.language;
/*     */   }
/*     */ 
/*     */   public void setLanguage(String language)
/*     */   {
/* 190 */     this.language = language;
/*     */   }
/*     */ 
/*     */   public String getCountry()
/*     */   {
/* 199 */     return this.country;
/*     */   }
/*     */ 
/*     */   public void setCountry(String country)
/*     */   {
/* 208 */     this.country = country;
/*     */   }
/*     */ 
/*     */   public String getVariant()
/*     */   {
/* 217 */     return this.variant;
/*     */   }
/*     */ 
/*     */   public void setVariant(String variant)
/*     */   {
/* 226 */     this.variant = variant;
/*     */   }
/*     */ 
/*     */   public void addConstant(String name, String value)
/*     */   {
/* 237 */     if (this.constants.containsKey(name)) {
/* 238 */       getLog().error("Constant '" + name + "' already exists in FormSet[" + displayKey() + "] - ignoring.");
/*     */     }
/*     */     else
/*     */     {
/* 242 */       this.constants.put(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addForm(Form f)
/*     */   {
/* 254 */     String formName = f.getName();
/* 255 */     if (this.forms.containsKey(formName)) {
/* 256 */       getLog().error("Form '" + formName + "' already exists in FormSet[" + displayKey() + "] - ignoring.");
/*     */     }
/*     */     else
/*     */     {
/* 260 */       this.forms.put(f.getName(), f);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Form getForm(String formName)
/*     */   {
/* 272 */     return ((Form)this.forms.get(formName));
/*     */   }
/*     */ 
/*     */   public Map getForms()
/*     */   {
/* 282 */     return Collections.unmodifiableMap(this.forms);
/*     */   }
/*     */ 
/*     */   synchronized void process(Map globalConstants)
/*     */   {
/* 291 */     for (Iterator i = this.forms.values().iterator(); i.hasNext(); ) {
/* 292 */       Form f = (Form)i.next();
/* 293 */       f.process(globalConstants, this.constants, this.forms);
/*     */     }
/*     */ 
/* 296 */     this.processed = true;
/*     */   }
/*     */ 
/*     */   public String displayKey()
/*     */   {
/* 305 */     StringBuffer results = new StringBuffer();
/* 306 */     if ((this.language != null) && (this.language.length() > 0)) {
/* 307 */       results.append("language=");
/* 308 */       results.append(this.language);
/*     */     }
/* 310 */     if ((this.country != null) && (this.country.length() > 0)) {
/* 311 */       if (results.length() > 0) {
/* 312 */         results.append(", ");
/*     */       }
/* 314 */       results.append("country=");
/* 315 */       results.append(this.country);
/*     */     }
/* 317 */     if ((this.variant != null) && (this.variant.length() > 0)) {
/* 318 */       if (results.length() > 0) {
/* 319 */         results.append(", ");
/*     */       }
/* 321 */       results.append("variant=");
/* 322 */       results.append(this.variant);
/*     */     }
/* 324 */     if (results.length() == 0) {
/* 325 */       results.append("default");
/*     */     }
/*     */ 
/* 328 */     return results.toString();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 337 */     StringBuffer results = new StringBuffer();
/*     */ 
/* 339 */     results.append("FormSet: language=");
/* 340 */     results.append(this.language);
/* 341 */     results.append("  country=");
/* 342 */     results.append(this.country);
/* 343 */     results.append("  variant=");
/* 344 */     results.append(this.variant);
/* 345 */     results.append("\n");
/*     */ 
/* 347 */     for (Iterator i = getForms().values().iterator(); i.hasNext(); ) {
/* 348 */       results.append("   ");
/* 349 */       results.append(i.next());
/* 350 */       results.append("\n");
/*     */     }
/*     */ 
/* 353 */     return results.toString();
/*     */   }
/*     */ 
/*     */   private Log getLog()
/*     */   {
/* 367 */     if (this.log == null) {
/* 368 */       this.log = LogFactory.getLog(FormSet.class);
/*     */     }
/* 370 */     return this.log;
/*     */   }
/*     */ }