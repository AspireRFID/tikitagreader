/*     */ package org.apache.commons.validator;
/*     */ 
/*     */ import org.apache.commons.digester.AbstractObjectCreationFactory;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class FormSetFactory extends AbstractObjectCreationFactory
/*     */ {
/*  33 */   private transient Log log = LogFactory.getLog(FormSetFactory.class);
/*     */ 
/*     */   public Object createObject(Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  45 */     ValidatorResources resources = (ValidatorResources)this.digester.peek(0);
/*     */ 
/*  47 */     String language = attributes.getValue("language");
/*  48 */     String country = attributes.getValue("country");
/*  49 */     String variant = attributes.getValue("variant");
/*     */ 
/*  51 */     return createFormSet(resources, language, country, variant);
/*     */   }
/*     */ 
/*     */   private FormSet createFormSet(ValidatorResources resources, String language, String country, String variant)
/*     */     throws Exception
/*     */   {
/*  72 */     FormSet formSet = resources.getFormSet(language, country, variant);
/*  73 */     if (formSet != null) {
/*  74 */       if (getLog().isDebugEnabled()) {
/*  75 */         getLog().debug("FormSet[" + formSet.displayKey() + "] found - merging.");
/*     */       }
/*  77 */       return formSet;
/*     */     }
/*     */ 
/*  81 */     formSet = new FormSet();
/*  82 */     formSet.setLanguage(language);
/*  83 */     formSet.setCountry(country);
/*  84 */     formSet.setVariant(variant);
/*     */ 
/*  87 */     resources.addFormSet(formSet);
/*     */ 
/*  89 */     if (getLog().isDebugEnabled()) {
/*  90 */       getLog().debug("FormSet[" + formSet.displayKey() + "] created.");
/*     */     }
/*     */ 
/*  93 */     return formSet;
/*     */   }
/*     */ 
/*     */   private Log getLog()
/*     */   {
/* 108 */     if (this.log == null) {
/* 109 */       this.log = LogFactory.getLog(FormSetFactory.class);
/*     */     }
/* 111 */     return this.log;
/*     */   }
/*     */ }