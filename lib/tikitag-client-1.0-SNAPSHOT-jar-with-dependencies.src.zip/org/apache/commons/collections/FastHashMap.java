/*     */ package org.apache.commons.collections;
/*     */ 
/*     */ import java.util.Collection;
/*     */ import java.util.ConcurrentModificationException;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Map.Entry;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class FastHashMap extends HashMap
/*     */ {
/*  71 */   protected HashMap map = null;
/*     */ 
/*  76 */   protected boolean fast = false;
/*     */ 
/*     */   public FastHashMap()
/*     */   {
/*  86 */     this.map = new HashMap();
/*     */   }
/*     */ 
/*     */   public FastHashMap(int capacity)
/*     */   {
/*  96 */     this.map = new HashMap(capacity);
/*     */   }
/*     */ 
/*     */   public FastHashMap(int capacity, float factor)
/*     */   {
/* 107 */     this.map = new HashMap(capacity, factor);
/*     */   }
/*     */ 
/*     */   public FastHashMap(Map map)
/*     */   {
/* 117 */     this.map = new HashMap(map);
/*     */   }
/*     */ 
/*     */   public boolean getFast()
/*     */   {
/* 130 */     return this.fast;
/*     */   }
/*     */ 
/*     */   public void setFast(boolean fast)
/*     */   {
/* 139 */     this.fast = fast;
/*     */   }
/*     */ 
/*     */   public Object get(Object key)
/*     */   {
/* 158 */     if (this.fast) {
/* 159 */       return this.map.get(key);
/*     */     }
/* 161 */     synchronized (this.map) {
/* 162 */       return this.map.get(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int size()
/*     */   {
/* 173 */     if (this.fast) {
/* 174 */       return this.map.size();
/*     */     }
/* 176 */     synchronized (this.map) {
/* 177 */       return this.map.size();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isEmpty()
/*     */   {
/* 188 */     if (this.fast) {
/* 189 */       return this.map.isEmpty();
/*     */     }
/* 191 */     synchronized (this.map) {
/* 192 */       return this.map.isEmpty();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsKey(Object key)
/*     */   {
/* 205 */     if (this.fast) {
/* 206 */       return this.map.containsKey(key);
/*     */     }
/* 208 */     synchronized (this.map) {
/* 209 */       return this.map.containsKey(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean containsValue(Object value)
/*     */   {
/* 222 */     if (this.fast) {
/* 223 */       return this.map.containsValue(value);
/*     */     }
/* 225 */     synchronized (this.map) {
/* 226 */       return this.map.containsValue(value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object put(Object key, Object value)
/*     */   {
/* 247 */     if (this.fast) {
/* 248 */       synchronized (this) {
/* 249 */         HashMap temp = (HashMap)this.map.clone();
/* 250 */         Object result = temp.put(key, value);
/* 251 */         this.map = temp;
/* 252 */         return result;
/*     */       }
/*     */     }
/* 255 */     synchronized (this.map) {
/* 256 */       return this.map.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void putAll(Map in)
/*     */   {
/* 268 */     if (this.fast)
/* 269 */       synchronized (this) {
/* 270 */         HashMap temp = (HashMap)this.map.clone();
/* 271 */         temp.putAll(in);
/* 272 */         this.map = temp;
/*     */       }
/*     */     else
/* 275 */       synchronized (this.map) {
/* 276 */         this.map.putAll(in);
/*     */       }
/*     */   }
/*     */ 
/*     */   public Object remove(Object key)
/*     */   {
/* 289 */     if (this.fast) {
/* 290 */       synchronized (this) {
/* 291 */         HashMap temp = (HashMap)this.map.clone();
/* 292 */         Object result = temp.remove(key);
/* 293 */         this.map = temp;
/* 294 */         return result;
/*     */       }
/*     */     }
/* 297 */     synchronized (this.map) {
/* 298 */       return this.map.remove(key);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 307 */     if (this.fast)
/* 308 */       synchronized (this) {
/* 309 */         this.map = new HashMap();
/*     */       }
/*     */     else
/* 312 */       synchronized (this.map) {
/* 313 */         this.map.clear();
/*     */       }
/*     */   }
/*     */ 
/*     */   public boolean equals(Object o)
/*     */   {
/* 332 */     if (o == this)
/* 333 */       return true;
/* 334 */     if (!(o instanceof Map)) {
/* 335 */       return false;
/*     */     }
/* 337 */     Map mo = (Map)o;
/*     */ 
/* 340 */     if (this.fast) {
/* 341 */       if (mo.size() != this.map.size()) {
/* 342 */         return false;
/*     */       }
/* 344 */       Iterator i = this.map.entrySet().iterator();
/* 345 */       while (i.hasNext()) {
/* 346 */         Map.Entry e = (Map.Entry)i.next();
/* 347 */         Object key = e.getKey();
/* 348 */         Object value = e.getValue();
/* 349 */         if (value == null) {
/* 350 */           if ((mo.get(key) == null) && (mo.containsKey(key))) break label144;
/* 351 */           return false;
/*     */         }
/*     */ 
/* 354 */         label144: if (!(value.equals(mo.get(key)))) {
/* 355 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 359 */       return true;
/*     */     }
/*     */ 
/* 362 */     synchronized (this.map) {
/* 363 */       if (mo.size() != this.map.size()) {
/* 364 */         return false;
/*     */       }
/* 366 */       Iterator i = this.map.entrySet().iterator();
/* 367 */       while (i.hasNext()) {
/* 368 */         Map.Entry e = (Map.Entry)i.next();
/* 369 */         Object key = e.getKey();
/* 370 */         Object value = e.getValue();
/* 371 */         if (value == null) {
/* 372 */           if ((mo.get(key) == null) && (mo.containsKey(key))) break label281;
/* 373 */           return false;
/*     */         }
/*     */ 
/* 376 */         label281: if (!(value.equals(mo.get(key)))) {
/* 377 */           return false;
/*     */         }
/*     */       }
/*     */ 
/* 381 */       return true;
/*     */     }
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 394 */     if (this.fast) {
/* 395 */       int h = 0;
/* 396 */       Iterator i = this.map.entrySet().iterator();
/* 397 */       while (i.hasNext()) {
/* 398 */         h += i.next().hashCode();
/*     */       }
/* 400 */       return h;
/*     */     }
/* 402 */     synchronized (this.map) {
/* 403 */       int h = 0;
/* 404 */       Iterator i = this.map.entrySet().iterator();
/* 405 */       while (i.hasNext()) {
/* 406 */         h += i.next().hashCode();
/*     */       }
/* 408 */       return h;
/*     */     }
/*     */   }
/*     */ 
/*     */   public Object clone()
/*     */   {
/* 420 */     FastHashMap results = null;
/* 421 */     if (this.fast)
/* 422 */       results = new FastHashMap(this.map);
/*     */     else {
/* 424 */       synchronized (this.map) {
/* 425 */         results = new FastHashMap(this.map);
/*     */       }
/*     */     }
/* 428 */     results.setFast(getFast());
/* 429 */     return results;
/*     */   }
/*     */ 
/*     */   public Set entrySet()
/*     */   {
/* 440 */     return new EntrySet(null);
/*     */   }
/*     */ 
/*     */   public Set keySet()
/*     */   {
/* 447 */     return new KeySet(null);
/*     */   }
/*     */ 
/*     */   public Collection values()
/*     */   {
/* 454 */     return new Values(null);
/*     */   }
/*     */ 
/*     */   private class EntrySet extends FastHashMap.CollectionView
/*     */     implements Set
/*     */   {
/*     */     private final FastHashMap this$0;
/*     */ 
/*     */     private EntrySet()
/*     */     {
/* 703 */       super(???); this.this$0 = ???; }
/*     */ 
/*     */     protected Collection get(Map map) {
/* 706 */       return map.entrySet();
/*     */     }
/*     */ 
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 710 */       return entry;
/*     */     }
/*     */ 
/*     */     EntrySet(FastHashMap.1 x1)
/*     */     {
/* 703 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class Values extends FastHashMap.CollectionView
/*     */   {
/*     */     private final FastHashMap this$0;
/*     */ 
/*     */     private Values()
/*     */     {
/* 689 */       super(???); this.this$0 = ???; }
/*     */ 
/*     */     protected Collection get(Map map) {
/* 692 */       return map.values();
/*     */     }
/*     */ 
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 696 */       return entry.getValue();
/*     */     }
/*     */ 
/*     */     Values(FastHashMap.1 x1)
/*     */     {
/* 689 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class KeySet extends FastHashMap.CollectionView
/*     */     implements Set
/*     */   {
/*     */     private final FastHashMap this$0;
/*     */ 
/*     */     private KeySet()
/*     */     {
/* 674 */       super(???); this.this$0 = ???; }
/*     */ 
/*     */     protected Collection get(Map map) {
/* 677 */       return map.keySet();
/*     */     }
/*     */ 
/*     */     protected Object iteratorNext(Map.Entry entry) {
/* 681 */       return entry.getKey();
/*     */     }
/*     */ 
/*     */     KeySet(FastHashMap.1 x1)
/*     */     {
/* 674 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private abstract class CollectionView
/*     */     implements Collection
/*     */   {
/*     */     protected abstract Collection get(Map paramMap);
/*     */ 
/*     */     protected abstract Object iteratorNext(Map.Entry paramEntry);
/*     */ 
/*     */     public void clear()
/*     */     {
/* 473 */       if (FastHashMap.this.fast)
/* 474 */         synchronized (FastHashMap.this) {
/* 475 */           FastHashMap.this.map = new HashMap();
/*     */         }
/*     */       else
/* 478 */         synchronized (FastHashMap.this.map) {
/* 479 */           get(FastHashMap.this.map).clear();
/*     */         }
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o)
/*     */     {
/* 485 */       if (FastHashMap.this.fast) {
/* 486 */         synchronized (FastHashMap.this) {
/* 487 */           HashMap temp = (HashMap)FastHashMap.this.map.clone();
/* 488 */           boolean r = get(temp).remove(o);
/* 489 */           FastHashMap.this.map = temp;
/* 490 */           return r;
/*     */         }
/*     */       }
/* 493 */       synchronized (FastHashMap.this.map) {
/* 494 */         return get(FastHashMap.this.map).remove(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection o)
/*     */     {
/* 500 */       if (FastHashMap.this.fast) {
/* 501 */         synchronized (FastHashMap.this) {
/* 502 */           HashMap temp = (HashMap)FastHashMap.this.map.clone();
/* 503 */           boolean r = get(temp).removeAll(o);
/* 504 */           FastHashMap.this.map = temp;
/* 505 */           return r;
/*     */         }
/*     */       }
/* 508 */       synchronized (FastHashMap.this.map) {
/* 509 */         return get(FastHashMap.this.map).removeAll(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection o)
/*     */     {
/* 515 */       if (FastHashMap.this.fast) {
/* 516 */         synchronized (FastHashMap.this) {
/* 517 */           HashMap temp = (HashMap)FastHashMap.this.map.clone();
/* 518 */           boolean r = get(temp).retainAll(o);
/* 519 */           FastHashMap.this.map = temp;
/* 520 */           return r;
/*     */         }
/*     */       }
/* 523 */       synchronized (FastHashMap.this.map) {
/* 524 */         return get(FastHashMap.this.map).retainAll(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 530 */       if (FastHashMap.this.fast) {
/* 531 */         return get(FastHashMap.this.map).size();
/*     */       }
/* 533 */       synchronized (FastHashMap.this.map) {
/* 534 */         return get(FastHashMap.this.map).size();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 541 */       if (FastHashMap.this.fast) {
/* 542 */         return get(FastHashMap.this.map).isEmpty();
/*     */       }
/* 544 */       synchronized (FastHashMap.this.map) {
/* 545 */         return get(FastHashMap.this.map).isEmpty();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 551 */       if (FastHashMap.this.fast) {
/* 552 */         return get(FastHashMap.this.map).contains(o);
/*     */       }
/* 554 */       synchronized (FastHashMap.this.map) {
/* 555 */         return get(FastHashMap.this.map).contains(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection o)
/*     */     {
/* 561 */       if (FastHashMap.this.fast) {
/* 562 */         return get(FastHashMap.this.map).containsAll(o);
/*     */       }
/* 564 */       synchronized (FastHashMap.this.map) {
/* 565 */         return get(FastHashMap.this.map).containsAll(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Object[] toArray(Object[] o)
/*     */     {
/* 571 */       if (FastHashMap.this.fast) {
/* 572 */         return get(FastHashMap.this.map).toArray(o);
/*     */       }
/* 574 */       synchronized (FastHashMap.this.map) {
/* 575 */         return get(FastHashMap.this.map).toArray(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 581 */       if (FastHashMap.this.fast) {
/* 582 */         return get(FastHashMap.this.map).toArray();
/*     */       }
/* 584 */       synchronized (FastHashMap.this.map) {
/* 585 */         return get(FastHashMap.this.map).toArray();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean equals(Object o)
/*     */     {
/* 592 */       if (o == this) return true;
/* 593 */       if (FastHashMap.this.fast) {
/* 594 */         return get(FastHashMap.this.map).equals(o);
/*     */       }
/* 596 */       synchronized (FastHashMap.this.map) {
/* 597 */         return get(FastHashMap.this.map).equals(o);
/*     */       }
/*     */     }
/*     */ 
/*     */     public int hashCode()
/*     */     {
/* 603 */       if (FastHashMap.this.fast) {
/* 604 */         return get(FastHashMap.this.map).hashCode();
/*     */       }
/* 606 */       synchronized (FastHashMap.this.map) {
/* 607 */         return get(FastHashMap.this.map).hashCode();
/*     */       }
/*     */     }
/*     */ 
/*     */     public boolean add(Object o)
/*     */     {
/* 613 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection c) {
/* 617 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public Iterator iterator() {
/* 621 */       return new CollectionViewIterator();
/*     */     }
/*     */ 
/*     */     private class CollectionViewIterator implements Iterator
/*     */     {
/*     */       private Map expected;
/* 627 */       private Map.Entry lastReturned = null;
/*     */       private Iterator iterator;
/*     */ 
/*     */       public CollectionViewIterator() {
/* 631 */         this.expected = FastHashMap.this.map;
/* 632 */         this.iterator = this.expected.entrySet().iterator();
/*     */       }
/*     */ 
/*     */       public boolean hasNext() {
/* 636 */         if (this.expected != FastHashMap.this.map) {
/* 637 */           throw new ConcurrentModificationException();
/*     */         }
/* 639 */         return this.iterator.hasNext();
/*     */       }
/*     */ 
/*     */       public Object next() {
/* 643 */         if (this.expected != FastHashMap.this.map) {
/* 644 */           throw new ConcurrentModificationException();
/*     */         }
/* 646 */         this.lastReturned = ((Map.Entry)this.iterator.next());
/* 647 */         return FastHashMap.CollectionView.this.iteratorNext(this.lastReturned);
/*     */       }
/*     */ 
/*     */       public void remove() {
/* 651 */         if (this.lastReturned == null) {
/* 652 */           throw new IllegalStateException();
/*     */         }
/* 654 */         if (FastHashMap.this.fast) {
/* 655 */           synchronized (FastHashMap.this) {
/* 656 */             if (this.expected != FastHashMap.this.map) {
/* 657 */               throw new ConcurrentModificationException();
/*     */             }
/* 659 */             FastHashMap.this.remove(this.lastReturned.getKey());
/* 660 */             this.lastReturned = null;
/* 661 */             this.expected = FastHashMap.this.map;
/*     */           }
/*     */         } else {
/* 664 */           this.iterator.remove();
/* 665 */           this.lastReturned = null;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }