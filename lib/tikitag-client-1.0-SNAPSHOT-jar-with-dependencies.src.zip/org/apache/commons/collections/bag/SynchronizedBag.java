/*     */ package org.apache.commons.collections.bag;
/*     */ 
/*     */ import java.util.Set;
/*     */ import org.apache.commons.collections.Bag;
/*     */ import org.apache.commons.collections.collection.SynchronizedCollection;
/*     */ import org.apache.commons.collections.set.SynchronizedSet;
/*     */ 
/*     */ public class SynchronizedBag extends SynchronizedCollection
/*     */   implements Bag
/*     */ {
/*     */   private static final long serialVersionUID = 8084674570753837109L;
/*     */ 
/*     */   public static Bag decorate(Bag bag)
/*     */   {
/*  53 */     return new SynchronizedBag(bag);
/*     */   }
/*     */ 
/*     */   protected SynchronizedBag(Bag bag)
/*     */   {
/*  64 */     super(bag);
/*     */   }
/*     */ 
/*     */   protected SynchronizedBag(Bag bag, Object lock)
/*     */   {
/*  75 */     super(bag, lock);
/*     */   }
/*     */ 
/*     */   protected Bag getBag()
/*     */   {
/*  84 */     return ((Bag)this.collection);
/*     */   }
/*     */ 
/*     */   public boolean add(Object object, int count)
/*     */   {
/*  89 */     synchronized (this.lock) {
/*  90 */       return getBag().add(object, count);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean remove(Object object, int count) {
/*  95 */     synchronized (this.lock) {
/*  96 */       return getBag().remove(object, count);
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set uniqueSet() {
/* 101 */     synchronized (this.lock) {
/* 102 */       Set set = getBag().uniqueSet();
/* 103 */       return new SynchronizedBagSet(set, this.lock);
/*     */     }
/*     */   }
/*     */ 
/*     */   public int getCount(Object object) {
/* 108 */     synchronized (this.lock) {
/* 109 */       return getBag().getCount(object);
/*     */     }
/*     */   }
/*     */ 
/*     */   class SynchronizedBagSet extends SynchronizedSet
/*     */   {
/*     */     SynchronizedBagSet(Set paramSet, Object paramObject)
/*     */     {
/* 124 */       super(paramSet, lock);
/*     */     }
/*     */   }
/*     */ }