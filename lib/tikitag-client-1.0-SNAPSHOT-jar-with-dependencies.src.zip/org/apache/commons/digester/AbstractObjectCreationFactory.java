/*    */ package org.apache.commons.digester;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ public abstract class AbstractObjectCreationFactory
/*    */   implements ObjectCreationFactory
/*    */ {
/*    */   protected Digester digester;
/*    */ 
/*    */   public AbstractObjectCreationFactory()
/*    */   {
/* 37 */     this.digester = null;
/*    */   }
/*    */ 
/*    */   public abstract Object createObject(Attributes paramAttributes)
/*    */     throws Exception;
/*    */ 
/*    */   public Digester getDigester()
/*    */   {
/* 60 */     return this.digester;
/*    */   }
/*    */ 
/*    */   public void setDigester(Digester digester)
/*    */   {
/* 73 */     this.digester = digester;
/*    */   }
/*    */ }