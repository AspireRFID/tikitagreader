/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class RegexRules extends AbstractRulesImpl
/*     */ {
/*  40 */   private ArrayList registeredRules = new ArrayList();
/*     */   private RegexMatcher matcher;
/*     */ 
/*     */   public RegexRules(RegexMatcher matcher)
/*     */   {
/*  53 */     setRegexMatcher(matcher);
/*     */   }
/*     */ 
/*     */   public RegexMatcher getRegexMatcher()
/*     */   {
/*  62 */     return this.matcher;
/*     */   }
/*     */ 
/*     */   public void setRegexMatcher(RegexMatcher matcher)
/*     */   {
/*  72 */     if (matcher == null) {
/*  73 */       throw new IllegalArgumentException("RegexMatcher must not be null.");
/*     */     }
/*  75 */     this.matcher = matcher;
/*     */   }
/*     */ 
/*     */   protected void registerRule(String pattern, Rule rule)
/*     */   {
/*  87 */     this.registeredRules.add(new RegisteredRule(pattern, rule));
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  94 */     this.registeredRules.clear();
/*     */   }
/*     */ 
/*     */   public List match(String namespaceURI, String pattern)
/*     */   {
/* 116 */     ArrayList rules = new ArrayList(this.registeredRules.size());
/* 117 */     Iterator it = this.registeredRules.iterator();
/* 118 */     while (it.hasNext()) {
/* 119 */       RegisteredRule next = (RegisteredRule)it.next();
/* 120 */       if (this.matcher.match(pattern, next.pattern)) {
/* 121 */         rules.add(next.rule);
/*     */       }
/*     */     }
/* 124 */     return rules;
/*     */   }
/*     */ 
/*     */   public List rules()
/*     */   {
/* 136 */     ArrayList rules = new ArrayList(this.registeredRules.size());
/* 137 */     Iterator it = this.registeredRules.iterator();
/* 138 */     while (it.hasNext()) {
/* 139 */       rules.add(((RegisteredRule)it.next()).rule);
/*     */     }
/* 141 */     return rules;
/*     */   }
/*     */ 
/*     */   private class RegisteredRule
/*     */   {
/*     */     String pattern;
/*     */     Rule rule;
/*     */ 
/*     */     RegisteredRule(String pattern, Rule rule) {
/* 150 */       this.pattern = pattern;
/* 151 */       this.rule = rule;
/*     */     }
/*     */   }
/*     */ }