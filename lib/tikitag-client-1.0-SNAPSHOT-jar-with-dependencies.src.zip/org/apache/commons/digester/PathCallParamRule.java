/*    */ package org.apache.commons.digester;
/*    */ 
/*    */ import org.xml.sax.Attributes;
/*    */ 
/*    */ public class PathCallParamRule extends Rule
/*    */ {
/* 54 */   protected int paramIndex = 0;
/*    */ 
/*    */   public PathCallParamRule(int paramIndex)
/*    */   {
/* 45 */     this.paramIndex = paramIndex;
/*    */   }
/*    */ 
/*    */   public void begin(String namespace, String name, Attributes attributes)
/*    */     throws Exception
/*    */   {
/* 72 */     String param = getDigester().getMatch();
/*    */ 
/* 74 */     if (param != null) {
/* 75 */       Object[] parameters = (Object[])this.digester.peekParams();
/* 76 */       parameters[this.paramIndex] = param;
/*    */     }
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 86 */     StringBuffer sb = new StringBuffer("PathCallParamRule[");
/* 87 */     sb.append("paramIndex=");
/* 88 */     sb.append(this.paramIndex);
/* 89 */     sb.append("]");
/* 90 */     return sb.toString();
/*    */   }
/*    */ }