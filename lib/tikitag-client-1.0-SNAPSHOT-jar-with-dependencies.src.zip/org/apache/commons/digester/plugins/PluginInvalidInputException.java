/*    */ package org.apache.commons.digester.plugins;
/*    */ 
/*    */ public class PluginInvalidInputException extends PluginException
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public PluginInvalidInputException(Throwable cause)
/*    */   {
/* 33 */     this(cause.getMessage());
/* 34 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public PluginInvalidInputException(String msg)
/*    */   {
/* 41 */     super(msg);
/*    */ 
/* 27 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public PluginInvalidInputException(String msg, Throwable cause)
/*    */   {
/* 49 */     this(msg);
/* 50 */     this.cause = cause;
/*    */   }
/*    */ }