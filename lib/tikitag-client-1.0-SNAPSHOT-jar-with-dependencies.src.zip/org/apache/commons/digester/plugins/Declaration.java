/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class Declaration
/*     */ {
/*     */   private Class pluginClass;
/*     */   private String pluginClassName;
/*     */   private String id;
/*  45 */   private Properties properties = new Properties();
/*     */ 
/*  48 */   private boolean initialized = false;
/*     */ 
/*  54 */   private RuleLoader ruleLoader = null;
/*     */ 
/*     */   public Declaration(String pluginClassName)
/*     */   {
/*  66 */     this.pluginClassName = pluginClassName;
/*     */   }
/*     */ 
/*     */   public Declaration(Class pluginClass)
/*     */   {
/*  73 */     this.pluginClass = pluginClass;
/*  74 */     this.pluginClassName = pluginClass.getName();
/*     */   }
/*     */ 
/*     */   public Declaration(Class pluginClass, RuleLoader ruleLoader)
/*     */   {
/*  83 */     this.pluginClass = pluginClass;
/*  84 */     this.pluginClassName = pluginClass.getName();
/*  85 */     this.ruleLoader = ruleLoader;
/*     */   }
/*     */ 
/*     */   public void setId(String id)
/*     */   {
/*  98 */     this.id = id;
/*     */   }
/*     */ 
/*     */   public String getId()
/*     */   {
/* 108 */     return this.id;
/*     */   }
/*     */ 
/*     */   public void setProperties(Properties p)
/*     */   {
/* 125 */     this.properties.putAll(p);
/*     */   }
/*     */ 
/*     */   public Class getPluginClass()
/*     */   {
/* 134 */     return this.pluginClass;
/*     */   }
/*     */ 
/*     */   public void init(Digester digester, PluginManager pm)
/*     */     throws PluginException
/*     */   {
/* 144 */     Log log = digester.getLogger();
/* 145 */     boolean debug = log.isDebugEnabled();
/* 146 */     if (debug) {
/* 147 */       log.debug("init being called!");
/*     */     }
/*     */ 
/* 150 */     if (this.initialized) {
/* 151 */       throw new PluginAssertionFailure("Init called multiple times.");
/*     */     }
/*     */ 
/* 154 */     if ((this.pluginClass == null) && (this.pluginClassName != null)) {
/*     */       try
/*     */       {
/* 157 */         this.pluginClass = digester.getClassLoader().loadClass(this.pluginClassName);
/*     */       }
/*     */       catch (ClassNotFoundException cnfe) {
/* 160 */         throw new PluginException("Unable to load class " + this.pluginClassName, cnfe);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 165 */     if (this.ruleLoader == null)
/*     */     {
/* 168 */       log.debug("Searching for ruleloader...");
/* 169 */       this.ruleLoader = pm.findLoader(digester, this.id, this.pluginClass, this.properties);
/*     */     } else {
/* 171 */       log.debug("This declaration has an explicit ruleLoader.");
/*     */     }
/*     */ 
/* 174 */     if (debug) {
/* 175 */       if (this.ruleLoader == null) {
/* 176 */         log.debug("No ruleLoader found for plugin declaration id [" + this.id + "]" + ", class [" + this.pluginClass.getClass().getName() + "].");
/*     */       }
/*     */       else
/*     */       {
/* 181 */         log.debug("RuleLoader of type [" + this.ruleLoader.getClass().getName() + "] associated with plugin declaration" + " id [" + this.id + "]" + ", class [" + this.pluginClass.getClass().getName() + "].");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 189 */     this.initialized = true;
/*     */   }
/*     */ 
/*     */   public void configure(Digester digester, String pattern)
/*     */     throws PluginException
/*     */   {
/* 203 */     Log log = digester.getLogger();
/* 204 */     boolean debug = log.isDebugEnabled();
/* 205 */     if (debug) {
/* 206 */       log.debug("configure being called!");
/*     */     }
/*     */ 
/* 209 */     if (!(this.initialized)) {
/* 210 */       throw new PluginAssertionFailure("Not initialized.");
/*     */     }
/*     */ 
/* 213 */     if (this.ruleLoader != null)
/* 214 */       this.ruleLoader.addRules(digester, pattern);
/*     */   }
/*     */ }