/*    */ package org.apache.commons.digester.plugins;
/*    */ 
/*    */ public class PluginException extends Exception
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public PluginException(Throwable cause)
/*    */   {
/* 35 */     this(cause.getMessage());
/* 36 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public PluginException(String msg)
/*    */   {
/* 43 */     super(msg);
/*    */ 
/* 29 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public PluginException(String msg, Throwable cause)
/*    */   {
/* 51 */     this(msg);
/* 52 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public Throwable getCause()
/*    */   {
/* 59 */     return this.cause;
/*    */   }
/*    */ }