/*    */ package org.apache.commons.digester.plugins;
/*    */ 
/*    */ public class PluginConfigurationException extends RuntimeException
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public PluginConfigurationException(Throwable cause)
/*    */   {
/* 37 */     this(cause.getMessage());
/* 38 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public PluginConfigurationException(String msg)
/*    */   {
/* 45 */     super(msg);
/*    */ 
/* 31 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public PluginConfigurationException(String msg, Throwable cause)
/*    */   {
/* 53 */     this(msg);
/* 54 */     this.cause = cause;
/*    */   }
/*    */ }