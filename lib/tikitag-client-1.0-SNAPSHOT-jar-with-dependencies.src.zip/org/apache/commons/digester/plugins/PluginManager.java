/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class PluginManager
/*     */ {
/*  41 */   private HashMap declarationsByClass = new HashMap();
/*     */ 
/*  44 */   private HashMap declarationsById = new HashMap();
/*     */   private PluginManager parent;
/*     */   private PluginContext pluginContext;
/*     */ 
/*     */   public PluginManager(PluginContext r)
/*     */   {
/*  59 */     this.pluginContext = r;
/*     */   }
/*     */ 
/*     */   public PluginManager(PluginManager parent)
/*     */   {
/*  73 */     this.parent = parent;
/*  74 */     this.pluginContext = parent.pluginContext;
/*     */   }
/*     */ 
/*     */   public void addDeclaration(Declaration decl)
/*     */   {
/*  89 */     Log log = LogUtils.getLogger(null);
/*  90 */     boolean debug = log.isDebugEnabled();
/*     */ 
/*  92 */     Class pluginClass = decl.getPluginClass();
/*  93 */     String id = decl.getId();
/*     */ 
/*  95 */     this.declarationsByClass.put(pluginClass.getName(), decl);
/*     */ 
/*  97 */     if (id != null) {
/*  98 */       this.declarationsById.put(id, decl);
/*  99 */       if (debug)
/* 100 */         log.debug("Indexing plugin-id [" + id + "]" + " -> class [" + pluginClass.getName() + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   public Declaration getDeclarationByClass(String className)
/*     */   {
/* 112 */     Declaration decl = (Declaration)this.declarationsByClass.get(className);
/*     */ 
/* 115 */     if ((decl == null) && (this.parent != null)) {
/* 116 */       decl = this.parent.getDeclarationByClass(className);
/*     */     }
/*     */ 
/* 119 */     return decl;
/*     */   }
/*     */ 
/*     */   public Declaration getDeclarationById(String id)
/*     */   {
/* 130 */     Declaration decl = (Declaration)this.declarationsById.get(id);
/*     */ 
/* 132 */     if ((decl == null) && (this.parent != null)) {
/* 133 */       decl = this.parent.getDeclarationById(id);
/*     */     }
/*     */ 
/* 136 */     return decl;
/*     */   }
/*     */ 
/*     */   public RuleLoader findLoader(Digester digester, String id, Class pluginClass, Properties props)
/*     */     throws PluginException
/*     */   {
/* 154 */     Log log = LogUtils.getLogger(digester);
/* 155 */     boolean debug = log.isDebugEnabled();
/* 156 */     log.debug("scanning ruleFinders to locate loader..");
/*     */ 
/* 158 */     List ruleFinders = this.pluginContext.getRuleFinders();
/* 159 */     RuleLoader ruleLoader = null;
/*     */     try {
/* 161 */       Iterator i = ruleFinders.iterator(); break label109:
/*     */       do
/*     */       {
/* 164 */         RuleFinder finder = (RuleFinder)i.next();
/* 165 */         if (debug) {
/* 166 */           log.debug("checking finder of type " + finder.getClass().getName());
/*     */         }
/* 168 */         ruleLoader = finder.findLoader(digester, pluginClass, props);
/*     */ 
/* 162 */         label109: if (!(i.hasNext())) break;  }
/* 162 */       while (ruleLoader == null);
/*     */     }
/*     */     catch (PluginException e)
/*     */     {
/* 172 */       throw new PluginException("Unable to locate plugin rules for plugin with id [" + id + "]" + ", and class [" + pluginClass.getName() + "]" + ":" + e.getMessage(), e.getCause());
/*     */     }
/*     */ 
/* 178 */     log.debug("scanned ruleFinders.");
/*     */ 
/* 180 */     return ruleLoader;
/*     */   }
/*     */ }