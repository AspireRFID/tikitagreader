/*    */ package org.apache.commons.digester.plugins;
/*    */ 
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.apache.commons.logging.impl.NoOpLog;
/*    */ 
/*    */ class LogUtils
/*    */ {
/*    */   static Log getLogger(Digester digester)
/*    */   {
/* 66 */     if (digester == null) {
/* 67 */       return new NoOpLog();
/*    */     }
/*    */ 
/* 70 */     return digester.getLogger();
/*    */   }
/*    */ }