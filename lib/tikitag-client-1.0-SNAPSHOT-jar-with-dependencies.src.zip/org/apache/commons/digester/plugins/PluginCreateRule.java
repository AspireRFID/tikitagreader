/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.Rule;
/*     */ import org.apache.commons.digester.Rules;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class PluginCreateRule extends Rule
/*     */   implements InitializableRule
/*     */ {
/*  40 */   private String pluginClassAttrNs = null;
/*  41 */   private String pluginClassAttr = null;
/*     */ 
/*  44 */   private String pluginIdAttrNs = null;
/*  45 */   private String pluginIdAttr = null;
/*     */   private String pattern;
/*  54 */   private Class baseClass = null;
/*     */   private Declaration defaultPlugin;
/*     */   private PluginConfigurationException initException;
/*     */ 
/*     */   public PluginCreateRule(Class baseClass)
/*     */   {
/*  81 */     this.baseClass = baseClass;
/*     */   }
/*     */ 
/*     */   public PluginCreateRule(Class baseClass, Class dfltPluginClass)
/*     */   {
/*  96 */     this.baseClass = baseClass;
/*  97 */     if (dfltPluginClass != null)
/*  98 */       this.defaultPlugin = new Declaration(dfltPluginClass);
/*     */   }
/*     */ 
/*     */   public PluginCreateRule(Class baseClass, Class dfltPluginClass, RuleLoader dfltPluginRuleLoader)
/*     */   {
/* 118 */     this.baseClass = baseClass;
/* 119 */     if (dfltPluginClass != null)
/* 120 */       this.defaultPlugin = new Declaration(dfltPluginClass, dfltPluginRuleLoader);
/*     */   }
/*     */ 
/*     */   public void setPluginClassAttribute(String namespaceUri, String attrName)
/*     */   {
/* 134 */     this.pluginClassAttrNs = namespaceUri;
/* 135 */     this.pluginClassAttr = attrName;
/*     */   }
/*     */ 
/*     */   public void setPluginIdAttribute(String namespaceUri, String attrName)
/*     */   {
/* 145 */     this.pluginIdAttrNs = namespaceUri;
/* 146 */     this.pluginIdAttr = attrName;
/*     */   }
/*     */ 
/*     */   public void postRegisterInit(String matchPattern)
/*     */     throws PluginConfigurationException
/*     */   {
/* 162 */     Log log = LogUtils.getLogger(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester);
/* 163 */     boolean debug = log.isDebugEnabled();
/* 164 */     if (debug) {
/* 165 */       log.debug("PluginCreateRule.postRegisterInit: rule registered for pattern [" + matchPattern + "]");
/*     */     }
/*     */ 
/* 169 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester == null)
/*     */     {
/* 174 */       this.initException = new PluginConfigurationException("Invalid invocation of postRegisterInit: digester not set.");
/*     */ 
/* 177 */       throw this.initException;
/*     */     }
/*     */ 
/* 180 */     if (this.pattern != null)
/*     */     {
/* 188 */       this.initException = new PluginConfigurationException("A single PluginCreateRule instance has been mapped to multiple patterns; this is not supported.");
/*     */ 
/* 191 */       throw this.initException;
/*     */     }
/*     */ 
/* 194 */     if (matchPattern.indexOf(42) != -1)
/*     */     {
/* 206 */       this.initException = new PluginConfigurationException("A PluginCreateRule instance has been mapped to pattern [" + matchPattern + "]." + " This pattern includes a wildcard character." + " This is not supported by the plugin architecture.");
/*     */ 
/* 211 */       throw this.initException;
/*     */     }
/*     */ 
/* 214 */     if (this.baseClass == null) {
/* 215 */       this.baseClass = Object.class;
/*     */     }
/*     */ 
/* 218 */     PluginRules rules = (PluginRules)this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getRules();
/* 219 */     PluginManager pm = rules.getPluginManager();
/*     */ 
/* 222 */     if (this.defaultPlugin != null) {
/* 223 */       if (!(this.baseClass.isAssignableFrom(this.defaultPlugin.getPluginClass()))) {
/* 224 */         this.initException = new PluginConfigurationException("Default class [" + this.defaultPlugin.getPluginClass().getName() + "] does not inherit from [" + this.baseClass.getName() + "].");
/*     */ 
/* 229 */         throw this.initException;
/*     */       }
/*     */       try
/*     */       {
/* 233 */         this.defaultPlugin.init(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester, pm);
/*     */       }
/*     */       catch (PluginException pwe)
/*     */       {
/* 237 */         throw new PluginConfigurationException(pwe.getMessage(), pwe.getCause());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 243 */     this.pattern = matchPattern;
/*     */ 
/* 245 */     if (this.pluginClassAttr == null)
/*     */     {
/* 248 */       this.pluginClassAttrNs = rules.getPluginClassAttrNs();
/* 249 */       this.pluginClassAttr = rules.getPluginClassAttr();
/*     */ 
/* 251 */       if (debug) {
/* 252 */         log.debug("init: pluginClassAttr set to per-digester values [ns=" + this.pluginClassAttrNs + ", name=" + this.pluginClassAttr + "]");
/*     */       }
/*     */ 
/*     */     }
/* 258 */     else if (debug) {
/* 259 */       log.debug("init: pluginClassAttr set to rule-specific values [ns=" + this.pluginClassAttrNs + ", name=" + this.pluginClassAttr + "]");
/*     */     }
/*     */ 
/* 266 */     if (this.pluginIdAttr == null)
/*     */     {
/* 269 */       this.pluginIdAttrNs = rules.getPluginIdAttrNs();
/* 270 */       this.pluginIdAttr = rules.getPluginIdAttr();
/*     */ 
/* 272 */       if (debug) {
/* 273 */         log.debug("init: pluginIdAttr set to per-digester values [ns=" + this.pluginIdAttrNs + ", name=" + this.pluginIdAttr + "]");
/*     */       }
/*     */ 
/*     */     }
/* 279 */     else if (debug) {
/* 280 */       log.debug("init: pluginIdAttr set to rule-specific values [ns=" + this.pluginIdAttrNs + ", name=" + this.pluginIdAttr + "]");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*     */     String pluginClassName;
/*     */     String pluginId;
/* 309 */     Log log = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getLogger();
/* 310 */     boolean debug = log.isDebugEnabled();
/* 311 */     if (debug) {
/* 312 */       log.debug("PluginCreateRule.begin: pattern=[" + this.pattern + "]" + " match=[" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch() + "]");
/*     */     }
/*     */ 
/* 316 */     if (this.initException != null)
/*     */     {
/* 319 */       throw this.initException;
/*     */     }
/*     */ 
/* 322 */     String path = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch();
/*     */ 
/* 329 */     PluginRules oldRules = (PluginRules)this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getRules();
/* 330 */     PluginRules newRules = new PluginRules(path, oldRules);
/* 331 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.setRules(newRules);
/*     */ 
/* 334 */     PluginManager pluginManager = newRules.getPluginManager();
/* 335 */     Declaration currDeclaration = null;
/*     */ 
/* 337 */     if (debug) {
/* 338 */       log.debug("PluginCreateRule.begin: installing new plugin: oldrules=" + oldRules.toString() + ", newrules=" + newRules.toString());
/*     */     }
/*     */ 
/* 344 */     if (this.pluginClassAttrNs == null)
/*     */     {
/* 352 */       pluginClassName = attributes.getValue(this.pluginClassAttr);
/*     */     }
/*     */     else pluginClassName = attributes.getValue(this.pluginClassAttrNs, this.pluginClassAttr);
/*     */ 
/* 359 */     if (this.pluginIdAttrNs == null)
/* 360 */       pluginId = attributes.getValue(this.pluginIdAttr);
/*     */     else {
/* 362 */       pluginId = attributes.getValue(this.pluginIdAttrNs, this.pluginIdAttr);
/*     */     }
/*     */ 
/* 366 */     if (pluginClassName != null)
/*     */     {
/* 373 */       currDeclaration = pluginManager.getDeclarationByClass(pluginClassName);
/*     */ 
/* 376 */       if (currDeclaration == null) {
/* 377 */         currDeclaration = new Declaration(pluginClassName);
/*     */         try {
/* 379 */           currDeclaration.init(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester, pluginManager);
/*     */         } catch (PluginException pwe) {
/* 381 */           throw new PluginInvalidInputException(pwe.getMessage(), pwe.getCause());
/*     */         }
/*     */ 
/* 384 */         pluginManager.addDeclaration(currDeclaration); }
/*     */     } else {
/* 386 */       if (pluginId != null) {
/* 387 */         currDeclaration = pluginManager.getDeclarationById(pluginId);
/*     */ 
/* 389 */         if (currDeclaration != null) break label438;
/* 390 */         throw new PluginInvalidInputException("Plugin id [" + pluginId + "] is not defined.");
/*     */       }
/*     */ 
/* 393 */       if (this.defaultPlugin != null)
/* 394 */         currDeclaration = this.defaultPlugin;
/*     */       else {
/* 396 */         throw new PluginInvalidInputException("No plugin class specified for element " + this.pattern);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 402 */     label438: currDeclaration.configure(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester, this.pattern);
/*     */ 
/* 405 */     Class pluginClass = currDeclaration.getPluginClass();
/*     */ 
/* 407 */     Object instance = pluginClass.newInstance();
/* 408 */     getDigester().push(instance);
/* 409 */     if (debug) {
/* 410 */       log.debug("PluginCreateRule.begin: pattern=[" + this.pattern + "]" + " match=[" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch() + "]" + " pushed instance of plugin [" + pluginClass.getName() + "]");
/*     */     }
/*     */ 
/* 419 */     List rules = newRules.getDecoratedRules().match(namespace, path);
/* 420 */     fireBeginMethods(rules, namespace, name, attributes);
/*     */   }
/*     */ 
/*     */   public void body(String namespace, String name, String text)
/*     */     throws Exception
/*     */   {
/* 444 */     String path = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch();
/* 445 */     PluginRules newRules = (PluginRules)this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getRules();
/* 446 */     List rules = newRules.getDecoratedRules().match(namespace, path);
/* 447 */     fireBodyMethods(rules, namespace, name, text);
/*     */   }
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/* 466 */     String path = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch();
/* 467 */     PluginRules newRules = (PluginRules)this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getRules();
/* 468 */     List rules = newRules.getDecoratedRules().match(namespace, path);
/* 469 */     fireEndMethods(rules, namespace, name);
/*     */ 
/* 473 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.setRules(newRules.getParent());
/*     */ 
/* 477 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.pop();
/*     */   }
/*     */ 
/*     */   public String getPattern()
/*     */   {
/* 493 */     return this.pattern;
/*     */   }
/*     */ 
/*     */   public void fireBeginMethods(List rules, String namespace, String name, Attributes list)
/*     */     throws Exception
/*     */   {
/* 507 */     if ((rules != null) && (rules.size() > 0)) {
/* 508 */       Log log = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getLogger();
/* 509 */       boolean debug = log.isDebugEnabled();
/* 510 */       for (int i = 0; i < rules.size(); ++i)
/*     */         try {
/* 512 */           Rule rule = (Rule)rules.get(i);
/* 513 */           if (debug) {
/* 514 */             log.debug("  Fire begin() for " + rule);
/*     */           }
/* 516 */           rule.begin(namespace, name, list);
/*     */         } catch (Exception e) {
/* 518 */           throw this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.createSAXException(e);
/*     */         } catch (Error e) {
/* 520 */           throw e;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   private void fireBodyMethods(List rules, String namespaceURI, String name, String text)
/*     */     throws Exception
/*     */   {
/* 536 */     if ((rules != null) && (rules.size() > 0)) {
/* 537 */       Log log = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getLogger();
/* 538 */       boolean debug = log.isDebugEnabled();
/* 539 */       for (int i = 0; i < rules.size(); ++i)
/*     */         try {
/* 541 */           Rule rule = (Rule)rules.get(i);
/* 542 */           if (debug) {
/* 543 */             log.debug("  Fire body() for " + rule);
/*     */           }
/* 545 */           rule.body(namespaceURI, name, text);
/*     */         } catch (Exception e) {
/* 547 */           throw this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.createSAXException(e);
/*     */         } catch (Error e) {
/* 549 */           throw e;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void fireEndMethods(List rules, String namespaceURI, String name)
/*     */     throws Exception
/*     */   {
/* 566 */     if (rules != null) {
/* 567 */       Log log = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getLogger();
/* 568 */       boolean debug = log.isDebugEnabled();
/* 569 */       for (int i = 0; i < rules.size(); ++i) {
/* 570 */         int j = rules.size() - i - 1;
/*     */         try {
/* 572 */           Rule rule = (Rule)rules.get(j);
/* 573 */           if (debug) {
/* 574 */             log.debug("  Fire end() for " + rule);
/*     */           }
/* 576 */           rule.end(namespaceURI, name);
/*     */         } catch (Exception e) {
/* 578 */           throw this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.createSAXException(e);
/*     */         } catch (Error e) {
/* 580 */           throw e;
/*     */         }
/*     */       }
/*     */     }
/*     */   }
/*     */ }