/*    */ package org.apache.commons.digester.plugins;
/*    */ 
/*    */ public class PluginAssertionFailure extends RuntimeException
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public PluginAssertionFailure(Throwable cause)
/*    */   {
/* 55 */     this(cause.getMessage());
/* 56 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public PluginAssertionFailure(String msg)
/*    */   {
/* 63 */     super(msg);
/*    */ 
/* 49 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public PluginAssertionFailure(String msg, Throwable cause)
/*    */   {
/* 71 */     this(msg);
/* 72 */     this.cause = cause;
/*    */   }
/*    */ }