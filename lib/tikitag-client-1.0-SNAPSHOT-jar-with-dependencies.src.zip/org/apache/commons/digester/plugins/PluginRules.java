/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.List;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.Rule;
/*     */ import org.apache.commons.digester.Rules;
/*     */ import org.apache.commons.digester.RulesBase;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class PluginRules
/*     */   implements Rules
/*     */ {
/*     */   protected Digester digester;
/*     */   private Rules decoratedRules;
/*     */   private PluginManager pluginManager;
/*     */   private String mountPoint;
/*     */   private PluginRules parent;
/*     */   private PluginContext pluginContext;
/*     */ 
/*     */   public PluginRules()
/*     */   {
/* 102 */     this(new RulesBase());
/*     */   }
/*     */ 
/*     */   public PluginRules(Rules decoratedRules)
/*     */   {
/*  64 */     this.digester = null;
/*     */ 
/*  80 */     this.mountPoint = null;
/*     */ 
/*  86 */     this.parent = null;
/*     */ 
/*  92 */     this.pluginContext = null;
/*     */ 
/* 110 */     this.decoratedRules = decoratedRules;
/*     */ 
/* 112 */     this.pluginContext = new PluginContext();
/* 113 */     this.pluginManager = new PluginManager(this.pluginContext);
/*     */   }
/*     */ 
/*     */   PluginRules(String mountPoint, PluginRules parent)
/*     */   {
/*  64 */     this.digester = null;
/*     */ 
/*  80 */     this.mountPoint = null;
/*     */ 
/*  86 */     this.parent = null;
/*     */ 
/*  92 */     this.pluginContext = null;
/*     */ 
/* 134 */     this.decoratedRules = new RulesBase();
/* 135 */     this.pluginContext = parent.pluginContext;
/* 136 */     this.pluginManager = new PluginManager(parent.pluginManager);
/*     */ 
/* 138 */     this.mountPoint = mountPoint;
/* 139 */     this.parent = parent;
/*     */   }
/*     */ 
/*     */   public Rules getParent()
/*     */   {
/* 148 */     return this.parent;
/*     */   }
/*     */ 
/*     */   public Digester getDigester()
/*     */   {
/* 155 */     return this.digester;
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/* 164 */     this.digester = digester;
/* 165 */     this.decoratedRules.setDigester(digester);
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/* 173 */     return this.decoratedRules.getNamespaceURI();
/*     */   }
/*     */ 
/*     */   public void setNamespaceURI(String namespaceURI)
/*     */   {
/* 185 */     this.decoratedRules.setNamespaceURI(namespaceURI);
/*     */   }
/*     */ 
/*     */   public PluginManager getPluginManager()
/*     */   {
/* 194 */     return this.pluginManager;
/*     */   }
/*     */ 
/*     */   public List getRuleFinders()
/*     */   {
/* 201 */     return this.pluginContext.getRuleFinders();
/*     */   }
/*     */ 
/*     */   public void setRuleFinders(List ruleFinders)
/*     */   {
/* 208 */     this.pluginContext.setRuleFinders(ruleFinders);
/*     */   }
/*     */ 
/*     */   Rules getDecoratedRules()
/*     */   {
/* 219 */     return this.decoratedRules;
/*     */   }
/*     */ 
/*     */   public List rules()
/*     */   {
/* 232 */     return this.decoratedRules.rules();
/*     */   }
/*     */ 
/*     */   public void add(String pattern, Rule rule)
/*     */   {
/* 244 */     Log log = LogUtils.getLogger(this.digester);
/* 245 */     boolean debug = log.isDebugEnabled();
/*     */ 
/* 247 */     if (debug) {
/* 248 */       log.debug("add entry: mapping pattern [" + pattern + "]" + " to rule of type [" + rule.getClass().getName() + "]");
/*     */     }
/*     */ 
/* 253 */     if (pattern.startsWith("/"))
/*     */     {
/* 255 */       pattern = pattern.substring(1);
/*     */     }
/*     */ 
/* 258 */     if ((this.mountPoint != null) && 
/* 259 */       (!(pattern.equals(this.mountPoint))) && (!(pattern.startsWith(this.mountPoint + "/"))))
/*     */     {
/* 268 */       log.warn("An attempt was made to add a rule with a pattern thatis not at or below the mountpoint of the current PluginRules object. Rule pattern: " + pattern + ", mountpoint: " + this.mountPoint + ", rule type: " + rule.getClass().getName());
/*     */ 
/* 275 */       return;
/*     */     }
/*     */ 
/* 279 */     this.decoratedRules.add(pattern, rule);
/*     */ 
/* 281 */     if (rule instanceof InitializableRule) {
/*     */       try {
/* 283 */         ((InitializableRule)rule).postRegisterInit(pattern);
/*     */       }
/*     */       catch (PluginConfigurationException e)
/*     */       {
/* 290 */         if (debug) {
/* 291 */           log.debug("Rule initialisation failed", e);
/*     */         }
/*     */ 
/* 294 */         return;
/*     */       }
/*     */     }
/*     */ 
/* 298 */     if (debug)
/* 299 */       log.debug("add exit: mapped pattern [" + pattern + "]" + " to rule of type [" + rule.getClass().getName() + "]");
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 308 */     this.decoratedRules.clear();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public List match(String path)
/*     */   {
/* 323 */     return match(null, path);
/*     */   }
/*     */ 
/*     */   public List match(String namespaceURI, String path)
/*     */   {
/*     */     List matches;
/* 338 */     Log log = LogUtils.getLogger(this.digester);
/* 339 */     boolean debug = log.isDebugEnabled();
/*     */ 
/* 341 */     if (debug) {
/* 342 */       log.debug("Matching path [" + path + "] on rules object " + super.toString());
/*     */     }
/*     */ 
/* 348 */     if ((this.mountPoint != null) && (path.length() <= this.mountPoint.length()))
/*     */     {
/* 350 */       if (debug) {
/* 351 */         log.debug("Path [" + path + "] delegated to parent.");
/*     */       }
/*     */ 
/* 355 */       matches = this.parent.match(namespaceURI, path);
/*     */     }
/*     */     else
/*     */     {
/* 363 */       matches = this.decoratedRules.match(namespaceURI, path);
/*     */     }
/*     */ 
/* 366 */     return matches;
/*     */   }
/*     */ 
/*     */   public void setPluginClassAttribute(String namespaceUri, String attrName)
/*     */   {
/* 372 */     this.pluginContext.setPluginClassAttribute(namespaceUri, attrName);
/*     */   }
/*     */ 
/*     */   public void setPluginIdAttribute(String namespaceUri, String attrName)
/*     */   {
/* 378 */     this.pluginContext.setPluginIdAttribute(namespaceUri, attrName);
/*     */   }
/*     */ 
/*     */   public String getPluginClassAttrNs()
/*     */   {
/* 383 */     return this.pluginContext.getPluginClassAttrNs();
/*     */   }
/*     */ 
/*     */   public String getPluginClassAttr()
/*     */   {
/* 388 */     return this.pluginContext.getPluginClassAttr();
/*     */   }
/*     */ 
/*     */   public String getPluginIdAttrNs()
/*     */   {
/* 393 */     return this.pluginContext.getPluginIdAttrNs();
/*     */   }
/*     */ 
/*     */   public String getPluginIdAttr()
/*     */   {
/* 398 */     return this.pluginContext.getPluginIdAttr();
/*     */   }
/*     */ }