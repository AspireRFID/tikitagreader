/*    */ package org.apache.commons.digester.plugins.strategies;
/*    */ 
/*    */ import java.io.FileInputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.digester.plugins.PluginException;
/*    */ import org.apache.commons.digester.plugins.RuleFinder;
/*    */ import org.apache.commons.digester.plugins.RuleLoader;
/*    */ 
/*    */ public class FinderFromFile extends RuleFinder
/*    */ {
/* 44 */   public static String DFLT_FILENAME_ATTR = "file";
/*    */   private String filenameAttr;
/*    */ 
/*    */   public FinderFromFile()
/*    */   {
/* 51 */     this(DFLT_FILENAME_ATTR);
/*    */   }
/*    */ 
/*    */   public FinderFromFile(String filenameAttr)
/*    */   {
/* 56 */     this.filenameAttr = filenameAttr;
/*    */   }
/*    */ 
/*    */   public RuleLoader findLoader(Digester d, Class pluginClass, Properties p)
/*    */     throws PluginException
/*    */   {
/* 72 */     String rulesFileName = p.getProperty(this.filenameAttr);
/* 73 */     if (rulesFileName == null)
/*    */     {
/* 76 */       return null;
/*    */     }
/*    */ 
/* 79 */     InputStream is = null;
/*    */     try {
/* 81 */       is = new FileInputStream(rulesFileName);
/*    */     } catch (IOException ioe) {
/* 83 */       throw new PluginException("Unable to process file [" + rulesFileName + "]", ioe);
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 88 */       RuleLoader loader = new LoaderFromStream(is);
/* 89 */       return loader;
/*    */     } catch (Exception e) {
/* 91 */       throw new PluginException("Unable to load xmlrules from file [" + rulesFileName + "]", e);
/*    */     }
/*    */     finally
/*    */     {
/*    */       try {
/* 96 */         is.close();
/*    */       } catch (IOException ioe) {
/* 98 */         throw new PluginException("Unable to close stream for file [" + rulesFileName + "]", ioe);
/*    */       }
/*    */     }
/*    */   }
/*    */ }