/*    */ package org.apache.commons.digester.plugins.strategies;
/*    */ 
/*    */ import java.io.ByteArrayInputStream;
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.digester.plugins.PluginException;
/*    */ import org.apache.commons.digester.plugins.RuleLoader;
/*    */ import org.apache.commons.digester.xmlrules.FromXmlRuleSet;
/*    */ import org.apache.commons.logging.Log;
/*    */ import org.xml.sax.InputSource;
/*    */ 
/*    */ public class LoaderFromStream extends RuleLoader
/*    */ {
/*    */   private byte[] input;
/*    */   private FromXmlRuleSet ruleSet;
/*    */ 
/*    */   public LoaderFromStream(InputStream s)
/*    */     throws Exception
/*    */   {
/* 47 */     load(s);
/*    */   }
/*    */ 
/*    */   private void load(InputStream s)
/*    */     throws IOException
/*    */   {
/* 58 */     ByteArrayOutputStream baos = new ByteArrayOutputStream();
/* 59 */     byte[] buf = new byte[256];
/*    */     while (true) {
/* 61 */       int i = s.read(buf);
/* 62 */       if (i == -1)
/*    */         break;
/* 64 */       baos.write(buf, 0, i);
/*    */     }
/* 66 */     this.input = baos.toByteArray();
/*    */   }
/*    */ 
/*    */   public void addRules(Digester d, String path)
/*    */     throws PluginException
/*    */   {
/* 74 */     Log log = d.getLogger();
/* 75 */     boolean debug = log.isDebugEnabled();
/* 76 */     if (debug) {
/* 77 */       log.debug("LoaderFromStream: loading rules for plugin at path [" + path + "]");
/*    */     }
/*    */ 
/* 88 */     InputSource source = new InputSource(new ByteArrayInputStream(this.input));
/* 89 */     FromXmlRuleSet ruleSet = new FromXmlRuleSet(source);
/* 90 */     ruleSet.addRuleInstances(d, path);
/*    */   }
/*    */ }