/*    */ package org.apache.commons.digester.plugins.strategies;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.digester.plugins.PluginException;
/*    */ import org.apache.commons.digester.plugins.RuleFinder;
/*    */ import org.apache.commons.digester.plugins.RuleLoader;
/*    */ 
/*    */ public class FinderFromDfltClass extends RuleFinder
/*    */ {
/* 34 */   public static String DFLT_RULECLASS_SUFFIX = "RuleInfo";
/* 35 */   public static String DFLT_METHOD_NAME = "addRules";
/*    */   private String rulesClassSuffix;
/*    */   private String methodName;
/*    */ 
/*    */   public FinderFromDfltClass()
/*    */   {
/* 42 */     this(DFLT_RULECLASS_SUFFIX, DFLT_METHOD_NAME);
/*    */   }
/*    */ 
/*    */   public FinderFromDfltClass(String rulesClassSuffix, String methodName)
/*    */   {
/* 54 */     this.rulesClassSuffix = rulesClassSuffix;
/* 55 */     this.methodName = methodName;
/*    */   }
/*    */ 
/*    */   public RuleLoader findLoader(Digester digester, Class pluginClass, Properties p)
/*    */     throws PluginException
/*    */   {
/* 74 */     String rulesClassName = pluginClass.getName() + this.rulesClassSuffix;
/*    */ 
/* 76 */     Class rulesClass = null;
/*    */     try {
/* 78 */       rulesClass = digester.getClassLoader().loadClass(rulesClassName);
/*    */     }
/*    */     catch (ClassNotFoundException cnfe)
/*    */     {
/*    */     }
/* 83 */     if (rulesClass == null)
/*    */     {
/* 85 */       return null;
/*    */     }
/*    */ 
/* 88 */     if (this.methodName == null) {
/* 89 */       this.methodName = DFLT_METHOD_NAME;
/*    */     }
/*    */ 
/* 92 */     return new LoaderFromClass(rulesClass, this.methodName);
/*    */   }
/*    */ }