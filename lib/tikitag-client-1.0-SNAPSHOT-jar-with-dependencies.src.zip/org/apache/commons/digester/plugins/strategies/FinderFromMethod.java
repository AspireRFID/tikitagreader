/*    */ package org.apache.commons.digester.plugins.strategies;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.digester.plugins.PluginException;
/*    */ import org.apache.commons.digester.plugins.RuleFinder;
/*    */ import org.apache.commons.digester.plugins.RuleLoader;
/*    */ 
/*    */ public class FinderFromMethod extends RuleFinder
/*    */ {
/* 38 */   public static String DFLT_METHOD_ATTR = "method";
/*    */   private String methodAttr;
/*    */ 
/*    */   public FinderFromMethod()
/*    */   {
/* 45 */     this(DFLT_METHOD_ATTR);
/*    */   }
/*    */ 
/*    */   public FinderFromMethod(String methodAttr)
/*    */   {
/* 50 */     this.methodAttr = methodAttr;
/*    */   }
/*    */ 
/*    */   public RuleLoader findLoader(Digester d, Class pluginClass, Properties p)
/*    */     throws PluginException
/*    */   {
/* 68 */     String methodName = p.getProperty(this.methodAttr);
/* 69 */     if (methodName == null)
/*    */     {
/* 72 */       return null;
/*    */     }
/*    */ 
/* 75 */     return new LoaderFromClass(pluginClass, methodName);
/*    */   }
/*    */ }