/*     */ package org.apache.commons.digester.plugins.strategies;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.plugins.PluginException;
/*     */ import org.apache.commons.digester.plugins.RuleFinder;
/*     */ import org.apache.commons.digester.plugins.RuleLoader;
/*     */ 
/*     */ public class FinderFromResource extends RuleFinder
/*     */ {
/*  41 */   public static String DFLT_RESOURCE_ATTR = "resource";
/*     */   private String resourceAttr;
/*     */ 
/*     */   public FinderFromResource()
/*     */   {
/*  48 */     this(DFLT_RESOURCE_ATTR);
/*     */   }
/*     */ 
/*     */   public FinderFromResource(String resourceAttr)
/*     */   {
/*  53 */     this.resourceAttr = resourceAttr;
/*     */   }
/*     */ 
/*     */   public RuleLoader findLoader(Digester d, Class pluginClass, Properties p)
/*     */     throws PluginException
/*     */   {
/*  69 */     String resourceName = p.getProperty(this.resourceAttr);
/*  70 */     if (resourceName == null)
/*     */     {
/*  73 */       return null;
/*     */     }
/*     */ 
/*  76 */     InputStream is = pluginClass.getClassLoader().getResourceAsStream(resourceName);
/*     */ 
/*  80 */     if (is == null) {
/*  81 */       throw new PluginException("Resource " + resourceName + " not found.");
/*     */     }
/*     */ 
/*  85 */     return loadRules(d, pluginClass, is, resourceName);
/*     */   }
/*     */ 
/*     */   public static RuleLoader loadRules(Digester d, Class pluginClass, InputStream is, String resourceName)
/*     */     throws PluginException
/*     */   {
/*     */     try
/*     */     {
/* 104 */       RuleLoader loader = new LoaderFromStream(is);
/* 105 */       return loader;
/*     */     } catch (Exception e) {
/* 107 */       throw new PluginException("Unable to load xmlrules from resource [" + resourceName + "]", e);
/*     */     }
/*     */     finally
/*     */     {
/*     */       try {
/* 112 */         is.close();
/*     */       } catch (IOException ioe) {
/* 114 */         throw new PluginException("Unable to close stream for resource [" + resourceName + "]", ioe);
/*     */       }
/*     */     }
/*     */   }
/*     */ }