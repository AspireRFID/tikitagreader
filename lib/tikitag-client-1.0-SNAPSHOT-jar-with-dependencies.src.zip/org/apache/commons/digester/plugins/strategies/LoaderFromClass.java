/*    */ package org.apache.commons.digester.plugins.strategies;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import org.apache.commons.beanutils.MethodUtils;
/*    */ import org.apache.commons.digester.Digester;
/*    */ import org.apache.commons.digester.plugins.PluginException;
/*    */ import org.apache.commons.digester.plugins.RuleLoader;
/*    */ import org.apache.commons.logging.Log;
/*    */ 
/*    */ public class LoaderFromClass extends RuleLoader
/*    */ {
/*    */   private Class rulesClass;
/*    */   private Method rulesMethod;
/*    */ 
/*    */   public LoaderFromClass(Class rulesClass, Method rulesMethod)
/*    */   {
/* 42 */     this.rulesClass = rulesClass;
/* 43 */     this.rulesMethod = rulesMethod;
/*    */   }
/*    */ 
/*    */   public LoaderFromClass(Class rulesClass, String methodName)
/*    */     throws PluginException
/*    */   {
/* 50 */     Method method = locateMethod(rulesClass, methodName);
/*    */ 
/* 52 */     if (method == null) {
/* 53 */       throw new PluginException("rule class " + rulesClass.getName() + " does not have method " + methodName + " or that method has an invalid signature.");
/*    */     }
/*    */ 
/* 59 */     this.rulesClass = rulesClass;
/* 60 */     this.rulesMethod = method;
/*    */   }
/*    */ 
/*    */   public void addRules(Digester d, String path)
/*    */     throws PluginException
/*    */   {
/*    */     Object none;
/* 67 */     Log log = d.getLogger();
/* 68 */     boolean debug = log.isDebugEnabled();
/* 69 */     if (debug) {
/* 70 */       log.debug("LoaderFromClass loading rules for plugin at path [" + path + "]");
/*    */     }
/*    */ 
/*    */     try
/*    */     {
/* 76 */       Object[] params = { d, path };
/* 77 */       none = this.rulesMethod.invoke(null, params);
/*    */     } catch (Exception e) {
/* 79 */       throw new PluginException("Unable to invoke rules method " + this.rulesMethod + " on rules class " + this.rulesClass, e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static Method locateMethod(Class rulesClass, String methodName)
/*    */     throws PluginException
/*    */   {
/* 95 */     Class[] paramSpec = { Digester.class, String.class };
/* 96 */     Method rulesMethod = MethodUtils.getAccessibleMethod(rulesClass, methodName, paramSpec);
/*    */ 
/* 99 */     return rulesMethod;
/*    */   }
/*    */ }