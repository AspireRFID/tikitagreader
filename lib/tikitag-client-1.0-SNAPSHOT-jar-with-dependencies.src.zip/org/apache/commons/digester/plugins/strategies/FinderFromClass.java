/*     */ package org.apache.commons.digester.plugins.strategies;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.plugins.PluginException;
/*     */ import org.apache.commons.digester.plugins.RuleFinder;
/*     */ import org.apache.commons.digester.plugins.RuleLoader;
/*     */ 
/*     */ public class FinderFromClass extends RuleFinder
/*     */ {
/*  34 */   public static String DFLT_RULECLASS_ATTR = "ruleclass";
/*  35 */   public static String DFLT_METHOD_ATTR = "method";
/*  36 */   public static String DFLT_METHOD_NAME = "addRules";
/*     */   private String ruleClassAttr;
/*     */   private String methodAttr;
/*     */   private String dfltMethodName;
/*     */ 
/*     */   public FinderFromClass()
/*     */   {
/*  46 */     this(DFLT_RULECLASS_ATTR, DFLT_METHOD_ATTR, DFLT_METHOD_NAME);
/*     */   }
/*     */ 
/*     */   public FinderFromClass(String ruleClassAttr, String methodAttr, String dfltMethodName)
/*     */   {
/*  60 */     this.ruleClassAttr = ruleClassAttr;
/*  61 */     this.methodAttr = methodAttr;
/*  62 */     this.dfltMethodName = dfltMethodName;
/*     */   }
/*     */ 
/*     */   public RuleLoader findLoader(Digester digester, Class pluginClass, Properties p)
/*     */     throws PluginException
/*     */   {
/*     */     Class ruleClass;
/*  95 */     String ruleClassName = p.getProperty(this.ruleClassAttr);
/*  96 */     if (ruleClassName == null)
/*     */     {
/*  99 */       return null;
/*     */     }
/*     */ 
/* 103 */     String methodName = null;
/* 104 */     if (this.methodAttr != null) {
/* 105 */       methodName = p.getProperty(this.methodAttr);
/*     */     }
/* 107 */     if (methodName == null) {
/* 108 */       methodName = this.dfltMethodName;
/*     */     }
/* 110 */     if (methodName == null) {
/* 111 */       methodName = DFLT_METHOD_NAME;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 117 */       ruleClass = digester.getClassLoader().loadClass(ruleClassName);
/*     */     }
/*     */     catch (ClassNotFoundException cnfe) {
/* 120 */       throw new PluginException("Unable to load class " + ruleClassName, cnfe);
/*     */     }
/*     */ 
/* 124 */     return new LoaderFromClass(ruleClass, methodName);
/*     */   }
/*     */ }