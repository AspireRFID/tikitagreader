package org.apache.commons.digester.plugins;

public abstract interface InitializableRule
{
  public abstract void postRegisterInit(String paramString)
    throws PluginConfigurationException;
}