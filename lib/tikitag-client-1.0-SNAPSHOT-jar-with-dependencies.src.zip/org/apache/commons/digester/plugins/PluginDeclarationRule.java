/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.Properties;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.Rule;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class PluginDeclarationRule extends Rule
/*     */ {
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  70 */     int nAttrs = attributes.getLength();
/*  71 */     Properties props = new Properties();
/*  72 */     for (int i = 0; i < nAttrs; ++i) {
/*  73 */       String key = attributes.getLocalName(i);
/*  74 */       if ((key == null) || (key.length() == 0)) {
/*  75 */         key = attributes.getQName(i);
/*     */       }
/*  77 */       String value = attributes.getValue(i);
/*  78 */       props.setProperty(key, value);
/*     */     }
/*     */     try
/*     */     {
/*  82 */       declarePlugin(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester, props);
/*     */     } catch (PluginInvalidInputException ex) {
/*  84 */       throw new PluginInvalidInputException("Error on element [" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch() + "]: " + ex.getMessage());
/*     */     }
/*     */   }
/*     */ 
/*     */   public static void declarePlugin(Digester digester, Properties props)
/*     */     throws PluginException
/*     */   {
/*  93 */     Log log = digester.getLogger();
/*  94 */     boolean debug = log.isDebugEnabled();
/*     */ 
/*  96 */     String id = props.getProperty("id");
/*  97 */     String pluginClassName = props.getProperty("class");
/*     */ 
/*  99 */     if (id == null) {
/* 100 */       throw new PluginInvalidInputException("mandatory attribute id not present on plugin declaration");
/*     */     }
/*     */ 
/* 104 */     if (pluginClassName == null) {
/* 105 */       throw new PluginInvalidInputException("mandatory attribute class not present on plugin declaration");
/*     */     }
/*     */ 
/* 109 */     Declaration newDecl = new Declaration(pluginClassName);
/* 110 */     newDecl.setId(id);
/* 111 */     newDecl.setProperties(props);
/*     */ 
/* 113 */     PluginRules rc = (PluginRules)digester.getRules();
/* 114 */     PluginManager pm = rc.getPluginManager();
/*     */ 
/* 116 */     newDecl.init(digester, pm);
/* 117 */     pm.addDeclaration(newDecl);
/*     */   }
/*     */ }