/*     */ package org.apache.commons.digester.plugins;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromClass;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromDfltClass;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromDfltMethod;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromDfltResource;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromFile;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromMethod;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderFromResource;
/*     */ import org.apache.commons.digester.plugins.strategies.FinderSetProperties;
/*     */ 
/*     */ public class PluginContext
/*     */ {
/*  49 */   public final String DFLT_PLUGIN_CLASS_ATTR_NS = null;
/*  50 */   public final String DFLT_PLUGIN_CLASS_ATTR = "plugin-class";
/*     */ 
/*  54 */   public final String DFLT_PLUGIN_ID_ATTR_NS = null;
/*  55 */   public final String DFLT_PLUGIN_ID_ATTR = "plugin-id";
/*     */ 
/*  58 */   private String pluginClassAttrNs = this.DFLT_PLUGIN_CLASS_ATTR_NS;
/*     */ 
/*  61 */   private String pluginClassAttr = "plugin-class";
/*     */ 
/*  64 */   private String pluginIdAttrNs = this.DFLT_PLUGIN_ID_ATTR_NS;
/*     */ 
/*  67 */   private String pluginIdAttr = "plugin-id";
/*     */   private List ruleFinders;
/*     */ 
/*     */   public List getRuleFinders()
/*     */   {
/*  93 */     if (this.ruleFinders == null)
/*     */     {
/*  97 */       this.ruleFinders = new LinkedList();
/*  98 */       this.ruleFinders.add(new FinderFromFile());
/*  99 */       this.ruleFinders.add(new FinderFromResource());
/* 100 */       this.ruleFinders.add(new FinderFromClass());
/* 101 */       this.ruleFinders.add(new FinderFromMethod());
/* 102 */       this.ruleFinders.add(new FinderFromDfltMethod());
/* 103 */       this.ruleFinders.add(new FinderFromDfltClass());
/* 104 */       this.ruleFinders.add(new FinderFromDfltResource());
/* 105 */       this.ruleFinders.add(new FinderFromDfltResource(".xml"));
/* 106 */       this.ruleFinders.add(new FinderSetProperties());
/*     */     }
/* 108 */     return this.ruleFinders;
/*     */   }
/*     */ 
/*     */   public void setRuleFinders(List ruleFinders)
/*     */   {
/* 122 */     this.ruleFinders = ruleFinders;
/*     */   }
/*     */ 
/*     */   public void setPluginClassAttribute(String namespaceUri, String attrName)
/*     */   {
/* 160 */     this.pluginClassAttrNs = namespaceUri;
/* 161 */     this.pluginClassAttr = attrName;
/*     */   }
/*     */ 
/*     */   public void setPluginIdAttribute(String namespaceUri, String attrName)
/*     */   {
/* 199 */     this.pluginIdAttrNs = namespaceUri;
/* 200 */     this.pluginIdAttr = attrName;
/*     */   }
/*     */ 
/*     */   public String getPluginClassAttrNs()
/*     */   {
/* 210 */     return this.pluginClassAttrNs;
/*     */   }
/*     */ 
/*     */   public String getPluginClassAttr()
/*     */   {
/* 220 */     return this.pluginClassAttr;
/*     */   }
/*     */ 
/*     */   public String getPluginIdAttrNs()
/*     */   {
/* 230 */     return this.pluginIdAttrNs;
/*     */   }
/*     */ 
/*     */   public String getPluginIdAttr()
/*     */   {
/* 240 */     return this.pluginIdAttr;
/*     */   }
/*     */ }