package org.apache.commons.digester.plugins;

import org.apache.commons.digester.Digester;

public abstract class RuleLoader
{
  public abstract void addRules(Digester paramDigester, String paramString)
    throws PluginException;
}