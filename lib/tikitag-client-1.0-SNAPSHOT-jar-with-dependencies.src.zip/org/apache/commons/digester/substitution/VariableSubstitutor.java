/*     */ package org.apache.commons.digester.substitution;
/*     */ 
/*     */ import org.apache.commons.digester.Substitutor;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class VariableSubstitutor extends Substitutor
/*     */ {
/*     */   private VariableExpander attributesExpander;
/*     */   private VariableAttributes variableAttributes;
/*     */   private VariableExpander bodyTextExpander;
/*     */ 
/*     */   public VariableSubstitutor(VariableExpander expander)
/*     */   {
/*  61 */     this(expander, expander);
/*     */   }
/*     */ 
/*     */   public VariableSubstitutor(VariableExpander attributesExpander, VariableExpander bodyTextExpander)
/*     */   {
/*  72 */     this.attributesExpander = attributesExpander;
/*  73 */     this.bodyTextExpander = bodyTextExpander;
/*  74 */     this.variableAttributes = new VariableAttributes();
/*     */   }
/*     */ 
/*     */   public Attributes substitute(Attributes attributes)
/*     */   {
/*  82 */     Attributes results = attributes;
/*  83 */     if (this.attributesExpander != null) {
/*  84 */       this.variableAttributes.init(attributes, this.attributesExpander);
/*  85 */       results = this.variableAttributes;
/*     */     }
/*  87 */     return results;
/*     */   }
/*     */ 
/*     */   public String substitute(String bodyText)
/*     */   {
/*  99 */     String result = bodyText;
/* 100 */     if (this.bodyTextExpander != null) {
/* 101 */       result = this.bodyTextExpander.expand(bodyText);
/*     */     }
/* 103 */     return result;
/*     */   }
/*     */ }