package org.apache.commons.digester.substitution;

public abstract interface VariableExpander
{
  public abstract String expand(String paramString);
}