/*    */ package org.apache.commons.digester.substitution;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Map;
/*    */ 
/*    */ public class MultiVariableExpander
/*    */   implements VariableExpander
/*    */ {
/* 30 */   private int nEntries = 0;
/* 31 */   private ArrayList markers = new ArrayList(2);
/* 32 */   private ArrayList sources = new ArrayList(2);
/*    */ 
/*    */   public void addSource(String marker, Map source)
/*    */   {
/* 38 */     this.nEntries += 1;
/* 39 */     this.markers.add(marker);
/* 40 */     this.sources.add(source);
/*    */   }
/*    */ 
/*    */   public String expand(String param)
/*    */   {
/* 51 */     for (int i = 0; i < this.nEntries; ++i) {
/* 52 */       param = expand(param, (String)this.markers.get(i), (Map)this.sources.get(i));
/*    */     }
/*    */ 
/* 57 */     return param;
/*    */   }
/*    */ 
/*    */   public String expand(String str, String marker, Map source)
/*    */   {
/* 76 */     String startMark = marker + "{";
/* 77 */     int markLen = startMark.length();
/*    */ 
/* 79 */     int index = 0;
/*    */     while (true)
/*    */     {
/* 82 */       index = str.indexOf(startMark, index);
/* 83 */       if (index == -1)
/*    */       {
/* 85 */         return str;
/*    */       }
/*    */ 
/* 88 */       int startIndex = index + markLen;
/* 89 */       if (startIndex > str.length())
/*    */       {
/* 91 */         throw new IllegalArgumentException("var expression starts at end of string");
/*    */       }
/*    */ 
/* 95 */       int endIndex = str.indexOf("}", index + markLen);
/* 96 */       if (endIndex == -1)
/*    */       {
/* 98 */         throw new IllegalArgumentException("var expression starts but does not end");
/*    */       }
/*    */ 
/* 102 */       String key = str.substring(index + markLen, endIndex);
/* 103 */       Object value = source.get(key);
/* 104 */       if (value == null) {
/* 105 */         throw new IllegalArgumentException("parameter [" + key + "] is not defined.");
/*    */       }
/*    */ 
/* 108 */       String varValue = value.toString();
/*    */ 
/* 110 */       str = str.substring(0, index) + varValue + str.substring(endIndex + 1);
/* 111 */       index += varValue.length();
/*    */     }
/*    */   }
/*    */ }