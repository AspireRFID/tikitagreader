package org.apache.commons.digester;

import org.xml.sax.Attributes;

public abstract interface ObjectCreationFactory
{
  public abstract Object createObject(Attributes paramAttributes)
    throws Exception;

  public abstract Digester getDigester();

  public abstract void setDigester(Digester paramDigester);
}