/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ 
/*     */ public class SimpleRegexMatcher extends RegexMatcher
/*     */ {
/*  41 */   private static final Log baseLog = LogFactory.getLog(SimpleRegexMatcher.class);
/*     */   private Log log;
/*     */ 
/*     */   public SimpleRegexMatcher()
/*     */   {
/*  44 */     this.log = baseLog;
/*     */   }
/*     */ 
/*     */   public Log getLog()
/*     */   {
/*  52 */     return this.log;
/*     */   }
/*     */ 
/*     */   public void setLog(Log log)
/*     */   {
/*  59 */     this.log = log;
/*     */   }
/*     */ 
/*     */   public boolean match(String basePattern, String regexPattern)
/*     */   {
/*  74 */     if ((basePattern == null) || (regexPattern == null)) {
/*  75 */       return false;
/*     */     }
/*  77 */     return match(basePattern, regexPattern, 0, 0);
/*     */   }
/*     */ 
/*     */   private boolean match(String basePattern, String regexPattern, int baseAt, int regexAt)
/*     */   {
/*  87 */     if (this.log.isTraceEnabled()) {
/*  88 */       this.log.trace("Base: " + basePattern);
/*  89 */       this.log.trace("Regex: " + regexPattern);
/*  90 */       this.log.trace("Base@" + baseAt);
/*  91 */       this.log.trace("Regex@" + regexAt);
/*     */     }
/*     */ 
/*  95 */     if (regexAt >= regexPattern.length())
/*     */     {
/*  99 */       return (baseAt < basePattern.length());
/*     */     }
/*     */ 
/* 105 */     if (baseAt >= basePattern.length())
/*     */     {
/* 107 */       return false;
/*     */     }
/*     */ 
/* 112 */     char regexCurrent = regexPattern.charAt(regexAt);
/* 113 */     switch (regexCurrent)
/*     */     {
/*     */     case '*':
/* 117 */       if (++regexAt >= regexPattern.length())
/*     */       {
/* 119 */         return true;
/*     */       }
/*     */ 
/* 123 */       char nextRegex = regexPattern.charAt(regexAt);
/* 124 */       if (this.log.isTraceEnabled()) {
/* 125 */         this.log.trace("Searching for next '" + nextRegex + "' char");
/*     */       }
/* 127 */       int nextMatch = basePattern.indexOf(nextRegex, baseAt);
/* 128 */       while (nextMatch != -1) {
/* 129 */         if (this.log.isTraceEnabled()) {
/* 130 */           this.log.trace("Trying '*' match@" + nextMatch);
/*     */         }
/* 132 */         if (match(basePattern, regexPattern, nextMatch, regexAt)) {
/* 133 */           return true;
/*     */         }
/* 135 */         nextMatch = basePattern.indexOf(nextRegex, nextMatch + 1);
/*     */       }
/* 137 */       this.log.trace("No matches found.");
/* 138 */       return false;
/*     */     case '?':
/* 142 */       return match(basePattern, regexPattern, ++baseAt, ++regexAt);
/*     */     }
/*     */ 
/* 145 */     if (this.log.isTraceEnabled()) {
/* 146 */       this.log.trace("Camparing " + regexCurrent + " to " + basePattern.charAt(baseAt));
/*     */     }
/* 148 */     if (regexCurrent == basePattern.charAt(baseAt))
/*     */     {
/* 150 */       return match(basePattern, regexPattern, ++baseAt, ++regexAt);
/*     */     }
/* 152 */     return false;
/*     */   }
/*     */ }