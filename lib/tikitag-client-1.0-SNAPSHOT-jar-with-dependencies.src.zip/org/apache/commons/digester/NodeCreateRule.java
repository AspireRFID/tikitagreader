/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import javax.xml.parsers.DocumentBuilder;
/*     */ import javax.xml.parsers.DocumentBuilderFactory;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import org.w3c.dom.Attr;
/*     */ import org.w3c.dom.DOMException;
/*     */ import org.w3c.dom.Document;
/*     */ import org.w3c.dom.Element;
/*     */ import org.w3c.dom.Node;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.ContentHandler;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.XMLReader;
/*     */ import org.xml.sax.helpers.DefaultHandler;
/*     */ 
/*     */ public class NodeCreateRule extends Rule
/*     */ {
/*     */   private DocumentBuilder documentBuilder;
/*     */   private int nodeType;
/*     */ 
/*     */   public NodeCreateRule()
/*     */     throws ParserConfigurationException
/*     */   {
/* 286 */     this(1);
/*     */   }
/*     */ 
/*     */   public NodeCreateRule(DocumentBuilder documentBuilder)
/*     */   {
/* 301 */     this(1, documentBuilder);
/*     */   }
/*     */ 
/*     */   public NodeCreateRule(int nodeType)
/*     */     throws ParserConfigurationException
/*     */   {
/* 319 */     this(nodeType, DocumentBuilderFactory.newInstance().newDocumentBuilder());
/*     */   }
/*     */ 
/*     */   public NodeCreateRule(int nodeType, DocumentBuilder documentBuilder)
/*     */   {
/* 358 */     this.documentBuilder = null;
/*     */ 
/* 368 */     this.nodeType = 1;
/*     */ 
/* 341 */     if ((nodeType != 11) && (nodeType != 1))
/*     */     {
/* 343 */       throw new IllegalArgumentException("Can only create nodes of type DocumentFragment and Element");
/*     */     }
/*     */ 
/* 346 */     this.nodeType = nodeType;
/* 347 */     this.documentBuilder = documentBuilder;
/*     */   }
/*     */ 
/*     */   public void begin(String namespaceURI, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 389 */     XMLReader xmlReader = getDigester().getXMLReader();
/* 390 */     Document doc = this.documentBuilder.newDocument();
/* 391 */     NodeBuilder builder = null;
/* 392 */     if (this.nodeType == 1)
/*     */     {
/*     */       int i;
/* 393 */       Element element = null;
/* 394 */       if (getDigester().getNamespaceAware()) {
/* 395 */         element = doc.createElementNS(namespaceURI, name);
/*     */ 
/* 397 */         for (i = 0; i < attributes.getLength(); ++i) {
/* 398 */           element.setAttributeNS(attributes.getURI(i), attributes.getLocalName(i), attributes.getValue(i));
/*     */         }
/*     */       }
/*     */       else
/*     */       {
/* 403 */         element = doc.createElement(name);
/* 404 */         for (i = 0; i < attributes.getLength(); ++i) {
/* 405 */           element.setAttribute(attributes.getQName(i), attributes.getValue(i));
/*     */         }
/*     */       }
/*     */ 
/* 409 */       builder = new NodeBuilder(doc, element);
/*     */     } else {
/* 411 */       builder = new NodeBuilder(doc, doc.createDocumentFragment());
/*     */     }
/* 413 */     xmlReader.setContentHandler(builder);
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/* 423 */     Object top = this.digester.pop();
/*     */   }
/*     */ 
/*     */   private class NodeBuilder extends DefaultHandler
/*     */   {
/* 126 */     protected ContentHandler oldContentHandler = null;
/*     */ 
/* 133 */     protected int depth = 0;
/*     */ 
/* 139 */     protected Document doc = null;
/*     */ 
/* 145 */     protected Node root = null;
/*     */ 
/* 151 */     protected Node top = null;
/*     */ 
/*     */     public NodeBuilder(Document doc, Node root)
/*     */       throws ParserConfigurationException, SAXException
/*     */     {
/* 110 */       this.doc = doc;
/* 111 */       this.root = root;
/* 112 */       this.top = root;
/*     */ 
/* 114 */       this.oldContentHandler = NodeCreateRule.this.digester.getXMLReader().getContentHandler();
/*     */     }
/*     */ 
/*     */     public void characters(char[] ch, int start, int length)
/*     */       throws SAXException
/*     */     {
/*     */       try
/*     */       {
/* 169 */         String str = new String(ch, start, length);
/* 170 */         if (str.trim().length() > 0)
/* 171 */           this.top.appendChild(this.doc.createTextNode(str));
/*     */       }
/*     */       catch (DOMException e) {
/* 174 */         throw new SAXException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void endElement(String namespaceURI, String localName, String qName)
/*     */       throws SAXException
/*     */     {
/*     */       try
/*     */       {
/* 193 */         if (this.depth == 0) {
/* 194 */           NodeCreateRule.this.getDigester().getXMLReader().setContentHandler(this.oldContentHandler);
/*     */ 
/* 196 */           NodeCreateRule.this.getDigester().push(this.root);
/* 197 */           NodeCreateRule.this.getDigester().endElement(namespaceURI, localName, qName);
/*     */         }
/*     */ 
/* 200 */         this.top = this.top.getParentNode();
/* 201 */         this.depth -= 1;
/*     */       } catch (DOMException e) {
/* 203 */         throw new SAXException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void processingInstruction(String target, String data)
/*     */       throws SAXException
/*     */     {
/*     */       try
/*     */       {
/* 223 */         this.top.appendChild(this.doc.createProcessingInstruction(target, data));
/*     */       } catch (DOMException e) {
/* 225 */         throw new SAXException(e.getMessage());
/*     */       }
/*     */     }
/*     */ 
/*     */     public void startElement(String namespaceURI, String localName, String qName, Attributes atts)
/*     */       throws SAXException
/*     */     {
/*     */       try
/*     */       {
/* 246 */         Node previousTop = this.top;
/* 247 */         if ((localName == null) || (localName.length() == 0))
/* 248 */           this.top = this.doc.createElement(qName);
/*     */         else {
/* 250 */           this.top = this.doc.createElementNS(namespaceURI, localName);
/*     */         }
/* 252 */         for (int i = 0; i < atts.getLength(); ++i) {
/* 253 */           Attr attr = null;
/* 254 */           if ((atts.getLocalName(i) == null) || (atts.getLocalName(i).length() == 0))
/*     */           {
/* 256 */             attr = this.doc.createAttribute(atts.getQName(i));
/* 257 */             attr.setNodeValue(atts.getValue(i));
/* 258 */             ((Element)this.top).setAttributeNode(attr);
/*     */           } else {
/* 260 */             attr = this.doc.createAttributeNS(atts.getURI(i), atts.getLocalName(i));
/*     */ 
/* 262 */             attr.setNodeValue(atts.getValue(i));
/* 263 */             ((Element)this.top).setAttributeNodeNS(attr);
/*     */           }
/*     */         }
/* 266 */         previousTop.appendChild(this.top);
/* 267 */         this.depth += 1;
/*     */       } catch (DOMException e) {
/* 269 */         throw new SAXException(e.getMessage());
/*     */       }
/*     */     }
/*     */   }
/*     */ }