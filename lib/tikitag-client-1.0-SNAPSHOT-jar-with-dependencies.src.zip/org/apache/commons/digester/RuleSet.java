package org.apache.commons.digester;

public abstract interface RuleSet
{
  public abstract String getNamespaceURI();

  public abstract void addRuleInstances(Digester paramDigester);
}