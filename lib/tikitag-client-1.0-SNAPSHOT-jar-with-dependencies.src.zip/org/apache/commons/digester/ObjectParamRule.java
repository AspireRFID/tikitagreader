/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class ObjectParamRule extends Rule
/*     */ {
/*     */   protected String attributeName;
/*     */   protected int paramIndex;
/*     */   protected Object param;
/*     */ 
/*     */   public ObjectParamRule(int paramIndex, Object param)
/*     */   {
/*  49 */     this(paramIndex, null, param);
/*     */   }
/*     */ 
/*     */   public ObjectParamRule(int paramIndex, String attributeName, Object param)
/*     */   {
/*  73 */     this.attributeName = null;
/*     */ 
/*  78 */     this.paramIndex = 0;
/*     */ 
/*  83 */     this.param = null;
/*     */ 
/*  62 */     this.paramIndex = paramIndex;
/*  63 */     this.attributeName = attributeName;
/*  64 */     this.param = param;
/*     */   }
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*  95 */     Object anAttribute = null;
/*  96 */     Object[] parameters = (Object[])this.digester.peekParams();
/*     */ 
/*  98 */     if (this.attributeName != null) {
/*  99 */       anAttribute = attributes.getValue(this.attributeName);
/* 100 */       if (anAttribute != null) {
/* 101 */         parameters[this.paramIndex] = this.param;
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 106 */       parameters[this.paramIndex] = this.param;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 114 */     StringBuffer sb = new StringBuffer("ObjectParamRule[");
/* 115 */     sb.append("paramIndex=");
/* 116 */     sb.append(this.paramIndex);
/* 117 */     sb.append(", attributeName=");
/* 118 */     sb.append(this.attributeName);
/* 119 */     sb.append(", param=");
/* 120 */     sb.append(this.param);
/* 121 */     sb.append("]");
/* 122 */     return sb.toString();
/*     */   }
/*     */ }