/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.HashMap;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class SetPropertiesRule extends Rule
/*     */ {
/*     */   private String[] attributeNames;
/*     */   private String[] propertyNames;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetPropertiesRule(Digester digester)
/*     */   {
/*     */   }
/*     */ 
/*     */   public SetPropertiesRule()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SetPropertiesRule(String attributeName, String propertyName)
/*     */   {
/*  80 */     this.attributeNames = new String[1];
/*  81 */     this.attributeNames[0] = attributeName;
/*  82 */     this.propertyNames = new String[1];
/*  83 */     this.propertyNames[0] = propertyName;
/*     */   }
/*     */ 
/*     */   public SetPropertiesRule(String[] attributeNames, String[] propertyNames)
/*     */   {
/* 125 */     this.attributeNames = new String[attributeNames.length];
/* 126 */     int i = 0; for (int size = attributeNames.length; i < size; ++i) {
/* 127 */       this.attributeNames[i] = attributeNames[i];
/*     */     }
/*     */ 
/* 130 */     this.propertyNames = new String[propertyNames.length];
/* 131 */     int i = 0; for (int size = propertyNames.length; i < size; ++i)
/* 132 */       this.propertyNames[i] = propertyNames[i];
/*     */   }
/*     */ 
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 159 */     HashMap values = new HashMap();
/*     */ 
/* 162 */     int attNamesLength = 0;
/* 163 */     if (this.attributeNames != null) {
/* 164 */       attNamesLength = this.attributeNames.length;
/*     */     }
/* 166 */     int propNamesLength = 0;
/* 167 */     if (this.propertyNames != null) {
/* 168 */       propNamesLength = this.propertyNames.length;
/*     */     }
/*     */ 
/* 172 */     for (int i = 0; i < attributes.getLength(); ++i) {
/* 173 */       String name = attributes.getLocalName(i);
/* 174 */       if ("".equals(name)) {
/* 175 */         name = attributes.getQName(i);
/*     */       }
/* 177 */       String value = attributes.getValue(i);
/*     */ 
/* 180 */       for (int n = 0; n < attNamesLength; ++n) {
/* 181 */         if (name.equals(this.attributeNames[n])) {
/* 182 */           if (n < propNamesLength)
/*     */           {
/* 184 */             name = this.propertyNames[n]; break;
/*     */           }
/*     */ 
/* 189 */           name = null;
/*     */ 
/* 191 */           break;
/*     */         }
/*     */       }
/*     */ 
/* 195 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 196 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Setting property '" + name + "' to '" + value + "'");
/*     */       }
/*     */ 
/* 200 */       if (name != null) {
/* 201 */         values.put(name, value);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 206 */     Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek();
/* 207 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 208 */       if (top != null) {
/* 209 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set " + top.getClass().getName() + " properties");
/*     */       }
/*     */       else
/*     */       {
/* 213 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set NULL properties");
/*     */       }
/*     */     }
/*     */ 
/* 217 */     BeanUtils.populate(top, values);
/*     */   }
/*     */ 
/*     */   public void addAlias(String attributeName, String propertyName)
/*     */   {
/* 232 */     if (this.attributeNames == null)
/*     */     {
/* 234 */       this.attributeNames = new String[1];
/* 235 */       this.attributeNames[0] = attributeName;
/* 236 */       this.propertyNames = new String[1];
/* 237 */       this.propertyNames[0] = propertyName;
/*     */     }
/*     */     else {
/* 240 */       int length = this.attributeNames.length;
/* 241 */       String[] tempAttributes = new String[length + 1];
/* 242 */       for (int i = 0; i < length; ++i) {
/* 243 */         tempAttributes[i] = this.attributeNames[i];
/*     */       }
/* 245 */       tempAttributes[length] = attributeName;
/*     */ 
/* 247 */       String[] tempProperties = new String[length + 1];
/* 248 */       for (int i = 0; (i < length) && (i < this.propertyNames.length); ++i) {
/* 249 */         tempProperties[i] = this.propertyNames[i];
/*     */       }
/* 251 */       tempProperties[length] = propertyName;
/*     */ 
/* 253 */       this.propertyNames = tempProperties;
/* 254 */       this.attributeNames = tempAttributes;
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 264 */     StringBuffer sb = new StringBuffer("SetPropertiesRule[");
/* 265 */     sb.append("]");
/* 266 */     return sb.toString();
/*     */   }
/*     */ }