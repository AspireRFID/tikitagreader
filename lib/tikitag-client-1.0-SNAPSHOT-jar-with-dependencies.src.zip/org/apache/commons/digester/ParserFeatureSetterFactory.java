/*    */ package org.apache.commons.digester;
/*    */ 
/*    */ import java.util.Properties;
/*    */ import javax.xml.parsers.ParserConfigurationException;
/*    */ import javax.xml.parsers.SAXParser;
/*    */ import org.apache.commons.digester.parser.GenericParser;
/*    */ import org.apache.commons.digester.parser.XercesParser;
/*    */ import org.xml.sax.SAXException;
/*    */ import org.xml.sax.SAXNotRecognizedException;
/*    */ import org.xml.sax.SAXNotSupportedException;
/*    */ 
/*    */ public class ParserFeatureSetterFactory
/*    */ {
/*    */   private static boolean isXercesUsed;
/*    */ 
/*    */   public static SAXParser newSAXParser(Properties properties)
/*    */     throws ParserConfigurationException, SAXException, SAXNotRecognizedException, SAXNotSupportedException
/*    */   {
/* 72 */     if (isXercesUsed) {
/* 73 */       return XercesParser.newSAXParser(properties);
/*    */     }
/* 75 */     return GenericParser.newSAXParser(properties);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/*    */     try
/*    */     {
/* 52 */       Class versionClass = Class.forName("org.apache.xerces.impl.Version");
/*    */ 
/* 54 */       isXercesUsed = true;
/*    */     } catch (Exception ex) {
/* 56 */       isXercesUsed = false;
/*    */     }
/*    */   }
/*    */ }