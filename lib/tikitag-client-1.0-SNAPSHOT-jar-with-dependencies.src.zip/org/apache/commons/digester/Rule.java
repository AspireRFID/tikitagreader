/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public abstract class Rule
/*     */ {
/*  62 */   protected Digester digester = null;
/*     */ 
/*  68 */   protected String namespaceURI = null;
/*     */ 
/*     */   /** @deprecated */
/*     */   public Rule(Digester digester)
/*     */   {
/*  45 */     setDigester(digester);
/*     */   }
/*     */ 
/*     */   public Rule()
/*     */   {
/*     */   }
/*     */ 
/*     */   public Digester getDigester()
/*     */   {
/*  79 */     return this.digester;
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/*  88 */     this.digester = digester;
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/*  97 */     return this.namespaceURI;
/*     */   }
/*     */ 
/*     */   public void setNamespaceURI(String namespaceURI)
/*     */   {
/* 110 */     this.namespaceURI = namespaceURI;
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 152 */     begin(attributes);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void body(String text)
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void body(String namespace, String name, String text)
/*     */     throws Exception
/*     */   {
/* 192 */     body(text);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/* 228 */     end();
/*     */   }
/*     */ 
/*     */   public void finish()
/*     */     throws Exception
/*     */   {
/*     */   }
/*     */ }