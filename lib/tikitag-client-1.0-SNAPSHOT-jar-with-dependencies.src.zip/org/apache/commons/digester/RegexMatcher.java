package org.apache.commons.digester;

public abstract class RegexMatcher
{
  public abstract boolean match(String paramString1, String paramString2);
}