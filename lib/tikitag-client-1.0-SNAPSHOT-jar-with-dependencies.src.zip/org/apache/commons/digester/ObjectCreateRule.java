/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class ObjectCreateRule extends Rule
/*     */ {
/*     */   protected String attributeName;
/*     */   protected String className;
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectCreateRule(Digester digester, String className)
/*     */   {
/*  48 */     this(className);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectCreateRule(Digester digester, Class clazz)
/*     */   {
/*  64 */     this(clazz);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectCreateRule(Digester digester, String className, String attributeName)
/*     */   {
/*  84 */     this(className, attributeName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public ObjectCreateRule(Digester digester, String attributeName, Class clazz)
/*     */   {
/* 105 */     this(attributeName, clazz);
/*     */   }
/*     */ 
/*     */   public ObjectCreateRule(String className)
/*     */   {
/* 116 */     this(className, (String)null);
/*     */   }
/*     */ 
/*     */   public ObjectCreateRule(Class clazz)
/*     */   {
/* 128 */     this(clazz.getName(), (String)null);
/*     */   }
/*     */ 
/*     */   public ObjectCreateRule(String className, String attributeName)
/*     */   {
/* 171 */     this.attributeName = null;
/*     */ 
/* 177 */     this.className = null;
/*     */ 
/* 144 */     this.className = className;
/* 145 */     this.attributeName = attributeName;
/*     */   }
/*     */ 
/*     */   public ObjectCreateRule(String attributeName, Class clazz)
/*     */   {
/* 161 */     this(clazz.getName(), attributeName);
/*     */   }
/*     */ 
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 191 */     String realClassName = this.className;
/* 192 */     if (this.attributeName != null) {
/* 193 */       String value = attributes.getValue(this.attributeName);
/* 194 */       if (value != null) {
/* 195 */         realClassName = value;
/*     */       }
/*     */     }
/* 198 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 199 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[ObjectCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "}New " + realClassName);
/*     */     }
/*     */ 
/* 204 */     Class clazz = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getClassLoader().loadClass(realClassName);
/* 205 */     Object instance = clazz.newInstance();
/* 206 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.push(instance);
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/* 216 */     Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.pop();
/* 217 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled())
/* 218 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[ObjectCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Pop " + top.getClass().getName());
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 230 */     StringBuffer sb = new StringBuffer("ObjectCreateRule[");
/* 231 */     sb.append("className=");
/* 232 */     sb.append(this.className);
/* 233 */     sb.append(", attributeName=");
/* 234 */     sb.append(this.attributeName);
/* 235 */     sb.append("]");
/* 236 */     return sb.toString();
/*     */   }
/*     */ }