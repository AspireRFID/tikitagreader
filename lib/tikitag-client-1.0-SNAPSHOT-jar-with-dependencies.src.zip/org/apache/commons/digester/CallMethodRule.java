/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.beanutils.ConvertUtils;
/*     */ import org.apache.commons.beanutils.MethodUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class CallMethodRule extends Rule
/*     */ {
/*     */   protected String bodyText;
/*     */   private int targetOffset;
/*     */   protected String methodName;
/*     */   protected int paramCount;
/*     */   protected Class[] paramTypes;
/*     */   private String[] paramClassNames;
/*     */   protected boolean useExactMatch;
/*     */ 
/*     */   /** @deprecated */
/*     */   public CallMethodRule(Digester digester, String methodName, int paramCount)
/*     */   {
/*  86 */     this(methodName, paramCount);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public CallMethodRule(Digester digester, String methodName, int paramCount, String[] paramTypes)
/*     */   {
/* 109 */     this(methodName, paramCount, paramTypes);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public CallMethodRule(Digester digester, String methodName, int paramCount, Class[] paramTypes)
/*     */   {
/* 133 */     this(methodName, paramCount, paramTypes);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(String methodName, int paramCount)
/*     */   {
/* 147 */     this(0, methodName, paramCount);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(int targetOffset, String methodName, int paramCount)
/*     */   {
/* 348 */     this.bodyText = null;
/*     */ 
/* 356 */     this.targetOffset = 0;
/*     */ 
/* 361 */     this.methodName = null;
/*     */ 
/* 369 */     this.paramCount = 0;
/*     */ 
/* 375 */     this.paramTypes = null;
/*     */ 
/* 381 */     this.paramClassNames = null;
/*     */ 
/* 386 */     this.useExactMatch = false;
/*     */ 
/* 166 */     this.targetOffset = targetOffset;
/* 167 */     this.methodName = methodName;
/* 168 */     this.paramCount = paramCount;
/* 169 */     if (paramCount == 0) {
/* 170 */       this.paramTypes = new Class[] { String.class };
/*     */     } else {
/* 172 */       this.paramTypes = new Class[paramCount];
/* 173 */       for (int i = 0; i < this.paramTypes.length; ++i)
/* 174 */         this.paramTypes[i] = String.class;
/*     */     }
/*     */   }
/*     */ 
/*     */   public CallMethodRule(String methodName)
/*     */   {
/* 188 */     this(0, methodName, 0, (Class[])null);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(int targetOffset, String methodName)
/*     */   {
/* 205 */     this(targetOffset, methodName, 0, (Class[])null);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(String methodName, int paramCount, String[] paramTypes)
/*     */   {
/* 229 */     this(0, methodName, paramCount, paramTypes);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(int targetOffset, String methodName, int paramCount, String[] paramTypes)
/*     */   {
/* 348 */     this.bodyText = null;
/*     */ 
/* 356 */     this.targetOffset = 0;
/*     */ 
/* 361 */     this.methodName = null;
/*     */ 
/* 369 */     this.paramCount = 0;
/*     */ 
/* 375 */     this.paramTypes = null;
/*     */ 
/* 381 */     this.paramClassNames = null;
/*     */ 
/* 386 */     this.useExactMatch = false;
/*     */ 
/* 256 */     this.targetOffset = targetOffset;
/* 257 */     this.methodName = methodName;
/* 258 */     this.paramCount = paramCount;
/* 259 */     if (paramTypes == null) {
/* 260 */       this.paramTypes = new Class[paramCount];
/* 261 */       for (i = 0; i < this.paramTypes.length; ++i) {
/* 262 */         this.paramTypes[i] = "abc".getClass();
/*     */       }
/*     */     }
/*     */     else
/*     */     {
/* 267 */       this.paramClassNames = new String[paramTypes.length];
/* 268 */       for (i = 0; i < this.paramClassNames.length; ++i)
/* 269 */         this.paramClassNames[i] = paramTypes[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   public CallMethodRule(String methodName, int paramCount, Class[] paramTypes)
/*     */   {
/* 296 */     this(0, methodName, paramCount, paramTypes);
/*     */   }
/*     */ 
/*     */   public CallMethodRule(int targetOffset, String methodName, int paramCount, Class[] paramTypes)
/*     */   {
/* 348 */     this.bodyText = null;
/*     */ 
/* 356 */     this.targetOffset = 0;
/*     */ 
/* 361 */     this.methodName = null;
/*     */ 
/* 369 */     this.paramCount = 0;
/*     */ 
/* 375 */     this.paramTypes = null;
/*     */ 
/* 381 */     this.paramClassNames = null;
/*     */ 
/* 386 */     this.useExactMatch = false;
/*     */ 
/* 324 */     this.targetOffset = targetOffset;
/* 325 */     this.methodName = methodName;
/* 326 */     this.paramCount = paramCount;
/* 327 */     if (paramTypes == null) {
/* 328 */       this.paramTypes = new Class[paramCount];
/* 329 */       for (i = 0; i < this.paramTypes.length; ++i)
/* 330 */         this.paramTypes[i] = "abc".getClass();
/*     */     }
/*     */     else {
/* 333 */       this.paramTypes = new Class[paramTypes.length];
/* 334 */       for (i = 0; i < this.paramTypes.length; ++i)
/* 335 */         this.paramTypes[i] = paramTypes[i];
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean getUseExactMatch()
/*     */   {
/* 395 */     return this.useExactMatch;
/*     */   }
/*     */ 
/*     */   public void setUseExactMatch(boolean useExactMatch)
/*     */   {
/* 404 */     this.useExactMatch = useExactMatch;
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/* 414 */     super.setDigester(digester);
/*     */ 
/* 416 */     if (this.paramClassNames != null) {
/* 417 */       this.paramTypes = new Class[this.paramClassNames.length];
/* 418 */       for (int i = 0; i < this.paramClassNames.length; ++i)
/*     */         try {
/* 420 */           this.paramTypes[i] = digester.getClassLoader().loadClass(this.paramClassNames[i]);
/*     */         }
/*     */         catch (ClassNotFoundException e)
/*     */         {
/* 424 */           digester.getLogger().error("(CallMethodRule) Cannot load class " + this.paramClassNames[i], e);
/* 425 */           this.paramTypes[i] = null;
/*     */         }
/*     */     }
/*     */   }
/*     */ 
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 439 */     if (this.paramCount > 0) {
/* 440 */       Object[] parameters = new Object[this.paramCount];
/* 441 */       for (int i = 0; i < parameters.length; ++i) {
/* 442 */         parameters[i] = null;
/*     */       }
/* 444 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.pushParams(parameters);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void body(String bodyText)
/*     */     throws Exception
/*     */   {
/* 457 */     if (this.paramCount == 0)
/* 458 */       this.bodyText = bodyText.trim();
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/*     */     label170: Object target;
/*     */     StringBuffer sb;
/* 470 */     Object[] parameters = null;
/* 471 */     if (this.paramCount > 0)
/*     */     {
/* 473 */       parameters = (Object[])this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.popParams();
/*     */ 
/* 475 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isTraceEnabled()) {
/* 476 */         int i = 0; for (int size = parameters.length; i < size; ++i) {
/* 477 */           this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.trace("[CallMethodRule](" + i + ")" + parameters[i]);
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 485 */       if ((this.paramCount != 1) || (parameters[0] != null)) break label170;
/* 486 */       return;
/*     */     }
/*     */ 
/* 489 */     if ((this.paramTypes != null) && (this.paramTypes.length != 0))
/*     */     {
/* 495 */       if (this.bodyText == null) {
/* 496 */         return;
/*     */       }
/*     */ 
/* 499 */       parameters = new Object[1];
/* 500 */       parameters[0] = this.bodyText;
/* 501 */       if (this.paramTypes.length == 0) {
/* 502 */         this.paramTypes = new Class[1];
/* 503 */         this.paramTypes[0] = "abc".getClass();
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 511 */     Object[] paramValues = new Object[this.paramTypes.length];
/* 512 */     for (int i = 0; i < this.paramTypes.length; ++i)
/*     */     {
/* 515 */       if ((parameters[i] == null) || ((parameters[i] instanceof String) && (!(String.class.isAssignableFrom(this.paramTypes[i])))))
/*     */       {
/* 520 */         paramValues[i] = ConvertUtils.convert((String)parameters[i], this.paramTypes[i]);
/*     */       }
/*     */       else {
/* 523 */         paramValues[i] = parameters[i];
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 529 */     if (this.targetOffset >= 0)
/* 530 */       target = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(this.targetOffset);
/*     */     else {
/* 532 */       target = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getCount() + this.targetOffset);
/*     */     }
/*     */ 
/* 535 */     if (target == null) {
/* 536 */       sb = new StringBuffer();
/* 537 */       sb.append("[CallMethodRule]{");
/* 538 */       sb.append(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match);
/* 539 */       sb.append("} Call target is null (");
/* 540 */       sb.append("targetOffset=");
/* 541 */       sb.append(this.targetOffset);
/* 542 */       sb.append(",stackdepth=");
/* 543 */       sb.append(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getCount());
/* 544 */       sb.append(")");
/* 545 */       throw new SAXException(sb.toString());
/*     */     }
/*     */ 
/* 549 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 550 */       sb = new StringBuffer("[CallMethodRule]{");
/* 551 */       sb.append(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match);
/* 552 */       sb.append("} Call ");
/* 553 */       sb.append(target.getClass().getName());
/* 554 */       sb.append(".");
/* 555 */       sb.append(this.methodName);
/* 556 */       sb.append("(");
/* 557 */       for (int i = 0; i < paramValues.length; ++i) {
/* 558 */         if (i > 0) {
/* 559 */           sb.append(",");
/*     */         }
/* 561 */         if (paramValues[i] == null)
/* 562 */           sb.append("null");
/*     */         else {
/* 564 */           sb.append(paramValues[i].toString());
/*     */         }
/* 566 */         sb.append("/");
/* 567 */         if (this.paramTypes[i] == null)
/* 568 */           sb.append("null");
/*     */         else {
/* 570 */           sb.append(this.paramTypes[i].getName());
/*     */         }
/*     */       }
/* 573 */       sb.append(")");
/* 574 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug(sb.toString());
/*     */     }
/*     */ 
/* 577 */     Object result = null;
/* 578 */     if (this.useExactMatch)
/*     */     {
/* 580 */       result = MethodUtils.invokeExactMethod(target, this.methodName, paramValues, this.paramTypes);
/*     */     }
/*     */     else
/*     */     {
/* 585 */       result = MethodUtils.invokeMethod(target, this.methodName, paramValues, this.paramTypes);
/*     */     }
/*     */ 
/* 589 */     processMethodCallResult(result);
/*     */   }
/*     */ 
/*     */   public void finish()
/*     */     throws Exception
/*     */   {
/* 598 */     this.bodyText = null;
/*     */   }
/*     */ 
/*     */   protected void processMethodCallResult(Object result)
/*     */   {
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 617 */     StringBuffer sb = new StringBuffer("CallMethodRule[");
/* 618 */     sb.append("methodName=");
/* 619 */     sb.append(this.methodName);
/* 620 */     sb.append(", paramCount=");
/* 621 */     sb.append(this.paramCount);
/* 622 */     sb.append(", paramTypes={");
/* 623 */     if (this.paramTypes != null) {
/* 624 */       for (int i = 0; i < this.paramTypes.length; ++i) {
/* 625 */         if (i > 0) {
/* 626 */           sb.append(", ");
/*     */         }
/* 628 */         sb.append(this.paramTypes[i].getName());
/*     */       }
/*     */     }
/* 631 */     sb.append("}");
/* 632 */     sb.append("]");
/* 633 */     return sb.toString();
/*     */   }
/*     */ }