/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.collections.ArrayStack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class FactoryCreateRule extends Rule
/*     */ {
/*     */   private boolean ignoreCreateExceptions;
/*     */   private ArrayStack exceptionIgnoredStack;
/*     */   protected String attributeName;
/*     */   protected String className;
/*     */   protected ObjectCreationFactory creationFactory;
/*     */ 
/*     */   /** @deprecated */
/*     */   public FactoryCreateRule(Digester digester, String className)
/*     */   {
/*  62 */     this(className);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public FactoryCreateRule(Digester digester, Class clazz)
/*     */   {
/*  80 */     this(clazz);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public FactoryCreateRule(Digester digester, String className, String attributeName)
/*     */   {
/* 102 */     this(className, attributeName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public FactoryCreateRule(Digester digester, Class clazz, String attributeName)
/*     */   {
/* 124 */     this(clazz, attributeName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public FactoryCreateRule(Digester digester, ObjectCreationFactory creationFactory)
/*     */   {
/* 142 */     this(creationFactory);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(String className)
/*     */   {
/* 157 */     this(className, false);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(Class clazz)
/*     */   {
/* 173 */     this(clazz, false);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(String className, String attributeName)
/*     */   {
/* 192 */     this(className, attributeName, false);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(Class clazz, String attributeName)
/*     */   {
/* 211 */     this(clazz, attributeName, false);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(ObjectCreationFactory creationFactory)
/*     */   {
/* 226 */     this(creationFactory, false);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(String className, boolean ignoreCreateExceptions)
/*     */   {
/* 242 */     this(className, null, ignoreCreateExceptions);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(Class clazz, boolean ignoreCreateExceptions)
/*     */   {
/* 259 */     this(clazz, null, ignoreCreateExceptions);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(String className, String attributeName, boolean ignoreCreateExceptions)
/*     */   {
/* 332 */     this.attributeName = null;
/*     */ 
/* 339 */     this.className = null;
/*     */ 
/* 347 */     this.creationFactory = null;
/*     */ 
/* 281 */     this.className = className;
/* 282 */     this.attributeName = attributeName;
/* 283 */     this.ignoreCreateExceptions = ignoreCreateExceptions;
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(Class clazz, String attributeName, boolean ignoreCreateExceptions)
/*     */   {
/* 305 */     this(clazz.getName(), attributeName, ignoreCreateExceptions);
/*     */   }
/*     */ 
/*     */   public FactoryCreateRule(ObjectCreationFactory creationFactory, boolean ignoreCreateExceptions)
/*     */   {
/* 332 */     this.attributeName = null;
/*     */ 
/* 339 */     this.className = null;
/*     */ 
/* 347 */     this.creationFactory = null;
/*     */ 
/* 322 */     this.creationFactory = creationFactory;
/* 323 */     this.ignoreCreateExceptions = ignoreCreateExceptions;
/*     */   }
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/*     */     Object instance;
/* 360 */     if (this.ignoreCreateExceptions)
/*     */     {
/* 362 */       if (this.exceptionIgnoredStack == null) {
/* 363 */         this.exceptionIgnoredStack = new ArrayStack();
/*     */       }
/*     */       try
/*     */       {
/* 367 */         instance = getFactory(attributes).createObject(attributes);
/*     */ 
/* 369 */         if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 370 */           this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[FactoryCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} New " + instance.getClass().getName());
/*     */         }
/*     */ 
/* 373 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.push(instance);
/* 374 */         this.exceptionIgnoredStack.push(Boolean.FALSE);
/*     */       }
/*     */       catch (Exception e)
/*     */       {
/* 378 */         if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isInfoEnabled()) {
/* 379 */           this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.info("[FactoryCreateRule] Create exception ignored: " + ((e.getMessage() == null) ? e.getClass().getName() : e.getMessage()));
/*     */ 
/* 381 */           if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 382 */             this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[FactoryCreateRule] Ignored exception:", e);
/*     */           }
/*     */         }
/* 385 */         this.exceptionIgnoredStack.push(Boolean.TRUE);
/*     */       }
/*     */     }
/*     */     else {
/* 389 */       instance = getFactory(attributes).createObject(attributes);
/*     */ 
/* 391 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 392 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[FactoryCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} New " + instance.getClass().getName());
/*     */       }
/*     */ 
/* 395 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.push(instance);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/* 407 */     if ((this.ignoreCreateExceptions) && (this.exceptionIgnoredStack != null) && (!(this.exceptionIgnoredStack.empty())) && 
/* 412 */       (((Boolean)this.exceptionIgnoredStack.pop()).booleanValue()))
/*     */     {
/* 415 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isTraceEnabled()) {
/* 416 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.trace("[FactoryCreateRule] No creation so no push so no pop");
/*     */       }
/* 418 */       return;
/*     */     }
/*     */ 
/* 422 */     Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.pop();
/* 423 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled())
/* 424 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[FactoryCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Pop " + top.getClass().getName());
/*     */   }
/*     */ 
/*     */   public void finish()
/*     */     throws Exception
/*     */   {
/* 436 */     if (this.attributeName != null)
/* 437 */       this.creationFactory = null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 448 */     StringBuffer sb = new StringBuffer("FactoryCreateRule[");
/* 449 */     sb.append("className=");
/* 450 */     sb.append(this.className);
/* 451 */     sb.append(", attributeName=");
/* 452 */     sb.append(this.attributeName);
/* 453 */     if (this.creationFactory != null) {
/* 454 */       sb.append(", creationFactory=");
/* 455 */       sb.append(this.creationFactory);
/*     */     }
/* 457 */     sb.append("]");
/* 458 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   protected ObjectCreationFactory getFactory(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 477 */     if (this.creationFactory == null) {
/* 478 */       String realClassName = this.className;
/* 479 */       if (this.attributeName != null) {
/* 480 */         String value = attributes.getValue(this.attributeName);
/* 481 */         if (value != null) {
/* 482 */           realClassName = value;
/*     */         }
/*     */       }
/* 485 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 486 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[FactoryCreateRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} New factory " + realClassName);
/*     */       }
/*     */ 
/* 489 */       Class clazz = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getClassLoader().loadClass(realClassName);
/* 490 */       this.creationFactory = ((ObjectCreationFactory)clazz.newInstance());
/*     */ 
/* 492 */       this.creationFactory.setDigester(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester);
/*     */     }
/* 494 */     return this.creationFactory;
/*     */   }
/*     */ }