/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class SetNestedPropertiesRule extends Rule
/*     */ {
/*     */   private static final String PROP_IGNORE = "ignore-me";
/*  95 */   private Log log = null;
/*     */ 
/*  97 */   private AnyChildRule anyChildRule = new AnyChildRule(null);
/*  98 */   private AnyChildRules newRules = new AnyChildRules(this.anyChildRule);
/*  99 */   private Rules oldRules = null;
/*     */ 
/* 101 */   private boolean trimData = true;
/* 102 */   private boolean allowUnknownChildElements = false;
/*     */ 
/* 104 */   private HashMap elementNames = new HashMap();
/*     */ 
/*     */   public SetNestedPropertiesRule()
/*     */   {
/*     */   }
/*     */ 
/*     */   public SetNestedPropertiesRule(String elementName, String propertyName)
/*     */   {
/* 126 */     this.elementNames.put(elementName, propertyName);
/*     */   }
/*     */ 
/*     */   public SetNestedPropertiesRule(String[] elementNames, String[] propertyNames)
/*     */   {
/* 167 */     int i = 0; for (int size = elementNames.length; i < size; ++i) {
/* 168 */       String propName = null;
/* 169 */       if (i < propertyNames.length) {
/* 170 */         propName = propertyNames[i];
/*     */       }
/*     */ 
/* 173 */       if (propName == null) {
/* 174 */         this.elementNames.put(elementNames[i], "ignore-me");
/*     */       }
/*     */       else
/* 177 */         this.elementNames.put(elementNames[i], propName);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/* 186 */     super.setDigester(digester);
/* 187 */     this.log = digester.getLogger();
/* 188 */     this.anyChildRule.setDigester(digester);
/*     */   }
/*     */ 
/*     */   public void setTrimData(boolean trimData)
/*     */   {
/* 197 */     this.trimData = trimData;
/*     */   }
/*     */ 
/*     */   public boolean getTrimData()
/*     */   {
/* 202 */     return this.trimData;
/*     */   }
/*     */ 
/*     */   public void setAllowUnknownChildElements(boolean allowUnknownChildElements)
/*     */   {
/* 211 */     this.allowUnknownChildElements = allowUnknownChildElements;
/*     */   }
/*     */ 
/*     */   public boolean getAllowUnknownChildElements()
/*     */   {
/* 216 */     return this.allowUnknownChildElements;
/*     */   }
/*     */ 
/*     */   public void begin(String namespace, String name, Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 228 */     this.oldRules = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getRules();
/* 229 */     this.newRules.init(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getMatch() + "/", this.oldRules);
/* 230 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.setRules(this.newRules);
/*     */   }
/*     */ 
/*     */   public void body(String bodyText)
/*     */     throws Exception
/*     */   {
/* 239 */     this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.setRules(this.oldRules);
/*     */   }
/*     */ 
/*     */   public void addAlias(String elementName, String propertyName)
/*     */   {
/* 247 */     if (propertyName == null) {
/* 248 */       this.elementNames.put(elementName, "ignore-me");
/*     */     }
/*     */     else
/* 251 */       this.elementNames.put(elementName, propertyName);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 260 */     return "SetNestedPropertiesRule";
/*     */   }
/*     */ 
/*     */   private class AnyChildRule extends Rule
/*     */   {
/*     */     private String currChildNamespaceURI;
/*     */     private String currChildElementName;
/*     */     private final SetNestedPropertiesRule this$0;
/*     */ 
/*     */     private AnyChildRule()
/*     */     {
/* 332 */       this.this$0 = this$0;
/* 333 */       this.currChildNamespaceURI = null;
/* 334 */       this.currChildElementName = null;
/*     */     }
/*     */ 
/*     */     public void begin(String namespaceURI, String name, Attributes attributes) throws Exception
/*     */     {
/* 339 */       this.currChildNamespaceURI = namespaceURI;
/* 340 */       this.currChildElementName = name;
/*     */     }
/*     */ 
/*     */     public void body(String value) throws Exception {
/* 344 */       boolean debug = this.this$0.log.isDebugEnabled();
/*     */ 
/* 346 */       String propName = (String)this.this$0.elementNames.get(this.currChildElementName);
/* 347 */       if (propName == "ignore-me")
/*     */       {
/* 349 */         return;
/*     */       }
/* 351 */       if (propName == null) {
/* 352 */         propName = this.currChildElementName;
/*     */       }
/*     */ 
/* 355 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 356 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetNestedPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Setting property '" + propName + "' to '" + value + "'");
/*     */       }
/*     */ 
/* 362 */       Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek();
/* 363 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 364 */         if (top != null) {
/* 365 */           this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetNestedPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set " + top.getClass().getName() + " properties");
/*     */         }
/*     */         else
/*     */         {
/* 369 */           this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetPropertiesRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set NULL properties");
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 374 */       if (this.this$0.trimData) {
/* 375 */         value = value.trim();
/*     */       }
/*     */ 
/* 378 */       if (!(this.this$0.allowUnknownChildElements))
/*     */       {
/* 381 */         if (top instanceof DynaBean) {
/* 382 */           DynaProperty desc = ((DynaBean)top).getDynaClass().getDynaProperty(propName);
/*     */ 
/* 384 */           if (desc == null)
/* 385 */             throw new NoSuchMethodException("Bean has no property named " + propName);
/*     */         }
/*     */         else
/*     */         {
/* 389 */           PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(top, propName);
/*     */ 
/* 391 */           if (desc == null) {
/* 392 */             throw new NoSuchMethodException("Bean has no property named " + propName);
/*     */           }
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 398 */       BeanUtils.setProperty(top, propName, value);
/*     */     }
/*     */ 
/*     */     public void end(String namespace, String name) throws Exception {
/* 402 */       this.currChildElementName = null;
/*     */     }
/*     */ 
/*     */     AnyChildRule(SetNestedPropertiesRule.1 x1)
/*     */     {
/* 332 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class AnyChildRules
/*     */     implements Rules
/*     */   {
/* 267 */     private String matchPrefix = null;
/* 268 */     private Rules decoratedRules = null;
/*     */ 
/* 270 */     private ArrayList rules = new ArrayList(1);
/*     */     private SetNestedPropertiesRule.AnyChildRule rule;
/*     */ 
/*     */     public AnyChildRules(SetNestedPropertiesRule.AnyChildRule rule)
/*     */     {
/* 274 */       this.rule = rule;
/* 275 */       this.rules.add(rule); }
/*     */ 
/*     */     public Digester getDigester() {
/* 278 */       return null; } 
/*     */     public void setDigester(Digester digester) {  }
/*     */ 
/*     */     public String getNamespaceURI() { return null; }
/*     */ 
/*     */     public void setNamespaceURI(String namespaceURI) { }
/*     */ 
/*     */     public void add(String pattern, Rule rule) {  }
/*     */ 
/*     */     public void clear() {  }
/*     */ 
/*     */     public List match(String matchPath) { return match(null, matchPath);
/*     */     }
/*     */ 
/*     */     public List match(String namespaceURI, String matchPath) {
/* 290 */       List match = this.decoratedRules.match(namespaceURI, matchPath);
/*     */ 
/* 292 */       if ((matchPath.startsWith(this.matchPrefix)) && (matchPath.indexOf(47, this.matchPrefix.length()) == -1))
/*     */       {
/* 303 */         if ((match == null) || (match.size() == 0)) {
/* 304 */           return this.rules;
/*     */         }
/*     */ 
/* 309 */         LinkedList newMatch = new LinkedList(match);
/*     */ 
/* 311 */         newMatch.addLast(this.rule);
/* 312 */         return newMatch;
/*     */       }
/*     */ 
/* 316 */       return match;
/*     */     }
/*     */ 
/*     */     public List rules()
/*     */     {
/* 322 */       throw new RuntimeException("AnyChildRules.rules not implemented.");
/*     */     }
/*     */ 
/*     */     public void init(String prefix, Rules rules)
/*     */     {
/* 327 */       this.matchPrefix = prefix;
/* 328 */       this.decoratedRules = rules;
/*     */     }
/*     */   }
/*     */ }