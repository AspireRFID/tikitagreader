package org.apache.commons.digester;

import java.util.List;

public abstract interface Rules
{
  public abstract Digester getDigester();

  public abstract void setDigester(Digester paramDigester);

  public abstract String getNamespaceURI();

  public abstract void setNamespaceURI(String paramString);

  public abstract void add(String paramString, Rule paramRule);

  public abstract void clear();

  /** @deprecated */
  public abstract List match(String paramString);

  public abstract List match(String paramString1, String paramString2);

  public abstract List rules();
}