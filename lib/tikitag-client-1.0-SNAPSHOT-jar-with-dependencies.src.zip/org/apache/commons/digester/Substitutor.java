package org.apache.commons.digester;

import org.xml.sax.Attributes;

public abstract class Substitutor
{
  public abstract Attributes substitute(Attributes paramAttributes);

  public abstract String substitute(String paramString);
}