/*      */ package org.apache.commons.digester;
/*      */ 
/*      */ import java.io.File;
/*      */ import java.io.FileInputStream;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ import java.io.Reader;
/*      */ import java.lang.reflect.InvocationTargetException;
/*      */ import java.util.EmptyStackException;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Map;
/*      */ import java.util.Properties;
/*      */ import javax.xml.parsers.ParserConfigurationException;
/*      */ import javax.xml.parsers.SAXParser;
/*      */ import javax.xml.parsers.SAXParserFactory;
/*      */ import org.apache.commons.collections.ArrayStack;
/*      */ import org.apache.commons.logging.Log;
/*      */ import org.apache.commons.logging.LogFactory;
/*      */ import org.xml.sax.Attributes;
/*      */ import org.xml.sax.EntityResolver;
/*      */ import org.xml.sax.ErrorHandler;
/*      */ import org.xml.sax.InputSource;
/*      */ import org.xml.sax.Locator;
/*      */ import org.xml.sax.SAXException;
/*      */ import org.xml.sax.SAXNotRecognizedException;
/*      */ import org.xml.sax.SAXNotSupportedException;
/*      */ import org.xml.sax.SAXParseException;
/*      */ import org.xml.sax.XMLReader;
/*      */ import org.xml.sax.helpers.DefaultHandler;
/*      */ 
/*      */ public class Digester extends DefaultHandler
/*      */ {
/*  131 */   protected StringBuffer bodyText = new StringBuffer();
/*      */ 
/*  137 */   protected ArrayStack bodyTexts = new ArrayStack();
/*      */ 
/*  150 */   protected ArrayStack matches = new ArrayStack(10);
/*      */ 
/*  158 */   protected ClassLoader classLoader = null;
/*      */ 
/*  164 */   protected boolean configured = false;
/*      */   protected EntityResolver entityResolver;
/*  176 */   protected HashMap entityValidator = new HashMap();
/*      */ 
/*  183 */   protected ErrorHandler errorHandler = null;
/*      */ 
/*  189 */   protected SAXParserFactory factory = null;
/*      */ 
/*      */   /** @deprecated */
/*  194 */   protected String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
/*      */ 
/*  201 */   protected Locator locator = null;
/*      */ 
/*  207 */   protected String match = "";
/*      */ 
/*  213 */   protected boolean namespaceAware = false;
/*      */ 
/*  224 */   protected HashMap namespaces = new HashMap();
/*      */ 
/*  231 */   protected ArrayStack params = new ArrayStack();
/*      */ 
/*  237 */   protected SAXParser parser = null;
/*      */ 
/*  244 */   protected String publicId = null;
/*      */ 
/*  250 */   protected XMLReader reader = null;
/*      */ 
/*  257 */   protected Object root = null;
/*      */ 
/*  266 */   protected Rules rules = null;
/*      */ 
/*  272 */   protected String schemaLanguage = "http://www.w3.org/2001/XMLSchema";
/*      */ 
/*  278 */   protected String schemaLocation = null;
/*      */ 
/*  284 */   protected ArrayStack stack = new ArrayStack();
/*      */ 
/*  291 */   protected boolean useContextClassLoader = false;
/*      */ 
/*  297 */   protected boolean validating = false;
/*      */ 
/*  303 */   protected Log log = LogFactory.getLog("org.apache.commons.digester.Digester");
/*      */ 
/*  310 */   protected Log saxLog = LogFactory.getLog("org.apache.commons.digester.Digester.sax");
/*      */   protected static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";
/*      */   protected Substitutor substitutor;
/*  327 */   private HashMap stacksByName = new HashMap();
/*      */ 
/*      */   public Digester()
/*      */   {
/*      */   }
/*      */ 
/*      */   public Digester(SAXParser parser)
/*      */   {
/*  104 */     this.parser = parser;
/*      */   }
/*      */ 
/*      */   public Digester(XMLReader reader)
/*      */   {
/*  120 */     this.reader = reader;
/*      */   }
/*      */ 
/*      */   public String findNamespaceURI(String prefix)
/*      */   {
/*  340 */     ArrayStack stack = (ArrayStack)this.namespaces.get(prefix);
/*  341 */     if (stack == null)
/*  342 */       return null;
/*      */     try
/*      */     {
/*  345 */       return ((String)stack.peek()); } catch (EmptyStackException e) {
/*      */     }
/*  347 */     return null;
/*      */   }
/*      */ 
/*      */   public ClassLoader getClassLoader()
/*      */   {
/*  365 */     if (this.classLoader != null) {
/*  366 */       return this.classLoader;
/*      */     }
/*  368 */     if (this.useContextClassLoader) {
/*  369 */       ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
/*      */ 
/*  371 */       if (classLoader != null) {
/*  372 */         return classLoader;
/*      */       }
/*      */     }
/*  375 */     return super.getClass().getClassLoader();
/*      */   }
/*      */ 
/*      */   public void setClassLoader(ClassLoader classLoader)
/*      */   {
/*  389 */     this.classLoader = classLoader;
/*      */   }
/*      */ 
/*      */   public int getCount()
/*      */   {
/*  399 */     return this.stack.size();
/*      */   }
/*      */ 
/*      */   public String getCurrentElementName()
/*      */   {
/*  409 */     String elementName = this.match;
/*  410 */     int lastSlash = elementName.lastIndexOf(47);
/*  411 */     if (lastSlash >= 0) {
/*  412 */       elementName = elementName.substring(lastSlash + 1);
/*      */     }
/*  414 */     return elementName;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public int getDebug()
/*      */   {
/*  428 */     return 0;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void setDebug(int debug)
/*      */   {
/*      */   }
/*      */ 
/*      */   public ErrorHandler getErrorHandler()
/*      */   {
/*  455 */     return this.errorHandler;
/*      */   }
/*      */ 
/*      */   public void setErrorHandler(ErrorHandler errorHandler)
/*      */   {
/*  467 */     this.errorHandler = errorHandler;
/*      */   }
/*      */ 
/*      */   public SAXParserFactory getFactory()
/*      */   {
/*  477 */     if (this.factory == null) {
/*  478 */       this.factory = SAXParserFactory.newInstance();
/*  479 */       this.factory.setNamespaceAware(this.namespaceAware);
/*  480 */       this.factory.setValidating(this.validating);
/*      */     }
/*  482 */     return this.factory;
/*      */   }
/*      */ 
/*      */   public boolean getFeature(String feature)
/*      */     throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  507 */     return getFactory().getFeature(feature);
/*      */   }
/*      */ 
/*      */   public void setFeature(String feature, boolean value)
/*      */     throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  536 */     getFactory().setFeature(feature, value);
/*      */   }
/*      */ 
/*      */   public Log getLogger()
/*      */   {
/*  546 */     return this.log;
/*      */   }
/*      */ 
/*      */   public void setLogger(Log log)
/*      */   {
/*  556 */     this.log = log;
/*      */   }
/*      */ 
/*      */   public Log getSAXLogger()
/*      */   {
/*  568 */     return this.saxLog;
/*      */   }
/*      */ 
/*      */   public void setSAXLogger(Log saxLog)
/*      */   {
/*  581 */     this.saxLog = saxLog;
/*      */   }
/*      */ 
/*      */   public String getMatch()
/*      */   {
/*  589 */     return this.match;
/*      */   }
/*      */ 
/*      */   public boolean getNamespaceAware()
/*      */   {
/*  599 */     return this.namespaceAware;
/*      */   }
/*      */ 
/*      */   public void setNamespaceAware(boolean namespaceAware)
/*      */   {
/*  611 */     this.namespaceAware = namespaceAware;
/*      */   }
/*      */ 
/*      */   public void setPublicId(String publicId)
/*      */   {
/*  621 */     this.publicId = publicId;
/*      */   }
/*      */ 
/*      */   public String getPublicId()
/*      */   {
/*  631 */     return this.publicId;
/*      */   }
/*      */ 
/*      */   public String getRuleNamespaceURI()
/*      */   {
/*  642 */     return getRules().getNamespaceURI();
/*      */   }
/*      */ 
/*      */   public void setRuleNamespaceURI(String ruleNamespaceURI)
/*      */   {
/*  657 */     getRules().setNamespaceURI(ruleNamespaceURI);
/*      */   }
/*      */ 
/*      */   public SAXParser getParser()
/*      */   {
/*  669 */     if (this.parser != null) {
/*  670 */       return this.parser;
/*      */     }
/*      */ 
/*      */     try
/*      */     {
/*  675 */       if (this.validating) {
/*  676 */         Properties properties = new Properties();
/*  677 */         properties.put("SAXParserFactory", getFactory());
/*  678 */         if (this.schemaLocation != null) {
/*  679 */           properties.put("schemaLocation", this.schemaLocation);
/*  680 */           properties.put("schemaLanguage", this.schemaLanguage);
/*      */         }
/*  682 */         this.parser = ParserFeatureSetterFactory.newSAXParser(properties); } else {
/*  683 */         this.parser = getFactory().newSAXParser();
/*      */       }
/*      */     } catch (Exception e) {
/*  686 */       this.log.error("Digester.getParser: ", e);
/*  687 */       return null;
/*      */     }
/*      */ 
/*  690 */     return this.parser;
/*      */   }
/*      */ 
/*      */   public Object getProperty(String property)
/*      */     throws SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  712 */     return getParser().getProperty(property);
/*      */   }
/*      */ 
/*      */   public void setProperty(String property, Object value)
/*      */     throws SAXNotRecognizedException, SAXNotSupportedException
/*      */   {
/*  735 */     getParser().setProperty(property, value);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public XMLReader getReader()
/*      */   {
/*      */     try
/*      */     {
/*  750 */       return getXMLReader();
/*      */     } catch (SAXException e) {
/*  752 */       this.log.error("Cannot get XMLReader", e); }
/*  753 */     return null;
/*      */   }
/*      */ 
/*      */   public Rules getRules()
/*      */   {
/*  766 */     if (this.rules == null) {
/*  767 */       this.rules = new RulesBase();
/*  768 */       this.rules.setDigester(this);
/*      */     }
/*  770 */     return this.rules;
/*      */   }
/*      */ 
/*      */   public void setRules(Rules rules)
/*      */   {
/*  783 */     this.rules = rules;
/*  784 */     this.rules.setDigester(this);
/*      */   }
/*      */ 
/*      */   public String getSchema()
/*      */   {
/*  794 */     return this.schemaLocation;
/*      */   }
/*      */ 
/*      */   public void setSchema(String schemaLocation)
/*      */   {
/*  806 */     this.schemaLocation = schemaLocation;
/*      */   }
/*      */ 
/*      */   public String getSchemaLanguage()
/*      */   {
/*  816 */     return this.schemaLanguage;
/*      */   }
/*      */ 
/*      */   public void setSchemaLanguage(String schemaLanguage)
/*      */   {
/*  828 */     this.schemaLanguage = schemaLanguage;
/*      */   }
/*      */ 
/*      */   public boolean getUseContextClassLoader()
/*      */   {
/*  838 */     return this.useContextClassLoader;
/*      */   }
/*      */ 
/*      */   public void setUseContextClassLoader(boolean use)
/*      */   {
/*  854 */     this.useContextClassLoader = use;
/*      */   }
/*      */ 
/*      */   public boolean getValidating()
/*      */   {
/*  864 */     return this.validating;
/*      */   }
/*      */ 
/*      */   public void setValidating(boolean validating)
/*      */   {
/*  877 */     this.validating = validating;
/*      */   }
/*      */ 
/*      */   public XMLReader getXMLReader()
/*      */     throws SAXException
/*      */   {
/*  890 */     if (this.reader == null) {
/*  891 */       this.reader = getParser().getXMLReader();
/*      */     }
/*      */ 
/*  894 */     this.reader.setDTDHandler(this);
/*  895 */     this.reader.setContentHandler(this);
/*      */ 
/*  897 */     if (this.entityResolver == null)
/*  898 */       this.reader.setEntityResolver(this);
/*      */     else {
/*  900 */       this.reader.setEntityResolver(this.entityResolver);
/*      */     }
/*      */ 
/*  903 */     this.reader.setErrorHandler(this);
/*  904 */     return this.reader;
/*      */   }
/*      */ 
/*      */   public Substitutor getSubstitutor()
/*      */   {
/*  912 */     return this.substitutor;
/*      */   }
/*      */ 
/*      */   public void setSubstitutor(Substitutor substitutor)
/*      */   {
/*  921 */     this.substitutor = substitutor;
/*      */   }
/*      */ 
/*      */   public void characters(char[] buffer, int start, int length)
/*      */     throws SAXException
/*      */   {
/*  940 */     if (this.saxLog.isDebugEnabled()) {
/*  941 */       this.saxLog.debug("characters(" + new String(buffer, start, length) + ")");
/*      */     }
/*      */ 
/*  944 */     this.bodyText.append(buffer, start, length);
/*      */   }
/*      */ 
/*      */   public void endDocument()
/*      */     throws SAXException
/*      */   {
/*  956 */     if (this.saxLog.isDebugEnabled()) {
/*  957 */       if (getCount() > 1) {
/*  958 */         this.saxLog.debug("endDocument():  " + getCount() + " elements left");
/*      */       }
/*      */       else {
/*  961 */         this.saxLog.debug("endDocument()");
/*      */       }
/*      */     }
/*      */ 
/*  965 */     while (getCount() > 1) {
/*  966 */       pop();
/*      */     }
/*      */ 
/*  970 */     Iterator rules = getRules().rules().iterator();
/*  971 */     while (rules.hasNext()) {
/*  972 */       Rule rule = (Rule)rules.next();
/*      */       try {
/*  974 */         rule.finish();
/*      */       } catch (Exception e) {
/*  976 */         this.log.error("Finish event threw exception", e);
/*  977 */         throw createSAXException(e);
/*      */       } catch (Error e) {
/*  979 */         this.log.error("Finish event threw error", e);
/*  980 */         throw e;
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/*  985 */     clear();
/*      */   }
/*      */ 
/*      */   public void endElement(String namespaceURI, String localName, String qName)
/*      */     throws SAXException
/*      */   {
/* 1005 */     boolean debug = this.log.isDebugEnabled();
/*      */ 
/* 1007 */     if (debug) {
/* 1008 */       if (this.saxLog.isDebugEnabled()) {
/* 1009 */         this.saxLog.debug("endElement(" + namespaceURI + "," + localName + "," + qName + ")");
/*      */       }
/*      */ 
/* 1012 */       this.log.debug("  match='" + this.match + "'");
/* 1013 */       this.log.debug("  bodyText='" + this.bodyText + "'");
/*      */     }
/*      */ 
/* 1018 */     String name = localName;
/* 1019 */     if ((name == null) || (name.length() < 1)) {
/* 1020 */       name = qName;
/*      */     }
/*      */ 
/* 1024 */     List rules = (List)this.matches.pop();
/* 1025 */     if ((rules != null) && (rules.size() > 0)) {
/* 1026 */       String bodyText = this.bodyText.toString();
/* 1027 */       Substitutor substitutor = getSubstitutor();
/* 1028 */       if (substitutor != null) {
/* 1029 */         bodyText = substitutor.substitute(bodyText);
/*      */       }
/* 1031 */       for (int i = 0; i < rules.size(); ++i) {
/*      */         try {
/* 1033 */           Rule rule = (Rule)rules.get(i);
/* 1034 */           if (debug) {
/* 1035 */             this.log.debug("  Fire body() for " + rule);
/*      */           }
/* 1037 */           rule.body(namespaceURI, name, bodyText);
/*      */         } catch (Exception e) {
/* 1039 */           this.log.error("Body event threw exception", e);
/* 1040 */           throw createSAXException(e);
/*      */         } catch (Error e) {
/* 1042 */           this.log.error("Body event threw error", e);
/* 1043 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/* 1047 */     else if (debug) {
/* 1048 */       this.log.debug("  No rules found matching '" + this.match + "'.");
/*      */     }
/*      */ 
/* 1053 */     this.bodyText = ((StringBuffer)this.bodyTexts.pop());
/* 1054 */     if (debug) {
/* 1055 */       this.log.debug("  Popping body text '" + this.bodyText.toString() + "'");
/*      */     }
/*      */ 
/* 1059 */     if (rules != null) {
/* 1060 */       for (int i = 0; i < rules.size(); ++i) {
/* 1061 */         int j = rules.size() - i - 1;
/*      */         try {
/* 1063 */           Rule rule = (Rule)rules.get(j);
/* 1064 */           if (debug) {
/* 1065 */             this.log.debug("  Fire end() for " + rule);
/*      */           }
/* 1067 */           rule.end(namespaceURI, name);
/*      */         } catch (Exception e) {
/* 1069 */           this.log.error("End event threw exception", e);
/* 1070 */           throw createSAXException(e);
/*      */         } catch (Error e) {
/* 1072 */           this.log.error("End event threw error", e);
/* 1073 */           throw e;
/*      */         }
/*      */       }
/*      */ 
/*      */     }
/*      */ 
/* 1079 */     int slash = this.match.lastIndexOf(47);
/* 1080 */     if (slash >= 0)
/* 1081 */       this.match = this.match.substring(0, slash);
/*      */     else
/* 1083 */       this.match = "";
/*      */   }
/*      */ 
/*      */   public void endPrefixMapping(String prefix)
/*      */     throws SAXException
/*      */   {
/* 1098 */     if (this.saxLog.isDebugEnabled()) {
/* 1099 */       this.saxLog.debug("endPrefixMapping(" + prefix + ")");
/*      */     }
/*      */ 
/* 1103 */     ArrayStack stack = (ArrayStack)this.namespaces.get(prefix);
/* 1104 */     if (stack == null)
/* 1105 */       return;
/*      */     try
/*      */     {
/* 1108 */       stack.pop();
/* 1109 */       if (stack.empty())
/* 1110 */         this.namespaces.remove(prefix);
/*      */     } catch (EmptyStackException e) {
/* 1112 */       throw createSAXException("endPrefixMapping popped too many times");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void ignorableWhitespace(char[] buffer, int start, int len)
/*      */     throws SAXException
/*      */   {
/* 1131 */     if (this.saxLog.isDebugEnabled())
/* 1132 */       this.saxLog.debug("ignorableWhitespace(" + new String(buffer, start, len) + ")");
/*      */   }
/*      */ 
/*      */   public void processingInstruction(String target, String data)
/*      */     throws SAXException
/*      */   {
/* 1152 */     if (this.saxLog.isDebugEnabled())
/* 1153 */       this.saxLog.debug("processingInstruction('" + target + "','" + data + "')");
/*      */   }
/*      */ 
/*      */   public Locator getDocumentLocator()
/*      */   {
/* 1168 */     return this.locator;
/*      */   }
/*      */ 
/*      */   public void setDocumentLocator(Locator locator)
/*      */   {
/* 1179 */     if (this.saxLog.isDebugEnabled()) {
/* 1180 */       this.saxLog.debug("setDocumentLocator(" + locator + ")");
/*      */     }
/*      */ 
/* 1183 */     this.locator = locator;
/*      */   }
/*      */ 
/*      */   public void skippedEntity(String name)
/*      */     throws SAXException
/*      */   {
/* 1197 */     if (this.saxLog.isDebugEnabled())
/* 1198 */       this.saxLog.debug("skippedEntity(" + name + ")");
/*      */   }
/*      */ 
/*      */   public void startDocument()
/*      */     throws SAXException
/*      */   {
/* 1213 */     if (this.saxLog.isDebugEnabled()) {
/* 1214 */       this.saxLog.debug("startDocument()");
/*      */     }
/*      */ 
/* 1220 */     configure();
/*      */   }
/*      */ 
/*      */   public void startElement(String namespaceURI, String localName, String qName, Attributes list)
/*      */     throws SAXException
/*      */   {
/* 1240 */     boolean debug = this.log.isDebugEnabled();
/*      */ 
/* 1242 */     if (this.saxLog.isDebugEnabled()) {
/* 1243 */       this.saxLog.debug("startElement(" + namespaceURI + "," + localName + "," + qName + ")");
/*      */     }
/*      */ 
/* 1248 */     this.bodyTexts.push(this.bodyText);
/* 1249 */     if (debug) {
/* 1250 */       this.log.debug("  Pushing body text '" + this.bodyText.toString() + "'");
/*      */     }
/* 1252 */     this.bodyText = new StringBuffer();
/*      */ 
/* 1256 */     String name = localName;
/* 1257 */     if ((name == null) || (name.length() < 1)) {
/* 1258 */       name = qName;
/*      */     }
/*      */ 
/* 1262 */     StringBuffer sb = new StringBuffer(this.match);
/* 1263 */     if (this.match.length() > 0) {
/* 1264 */       sb.append('/');
/*      */     }
/* 1266 */     sb.append(name);
/* 1267 */     this.match = sb.toString();
/* 1268 */     if (debug) {
/* 1269 */       this.log.debug("  New match='" + this.match + "'");
/*      */     }
/*      */ 
/* 1273 */     List rules = getRules().match(namespaceURI, this.match);
/* 1274 */     this.matches.push(rules);
/* 1275 */     if ((rules != null) && (rules.size() > 0)) {
/* 1276 */       Substitutor substitutor = getSubstitutor();
/* 1277 */       if (substitutor != null) {
/* 1278 */         list = substitutor.substitute(list);
/*      */       }
/* 1280 */       for (int i = 0; i < rules.size(); ++i) {
/*      */         try {
/* 1282 */           Rule rule = (Rule)rules.get(i);
/* 1283 */           if (debug) {
/* 1284 */             this.log.debug("  Fire begin() for " + rule);
/*      */           }
/* 1286 */           rule.begin(namespaceURI, name, list);
/*      */         } catch (Exception e) {
/* 1288 */           this.log.error("Begin event threw exception", e);
/* 1289 */           throw createSAXException(e);
/*      */         } catch (Error e) {
/* 1291 */           this.log.error("Begin event threw error", e);
/* 1292 */           throw e;
/*      */         }
/*      */       }
/*      */     }
/* 1296 */     else if (debug) {
/* 1297 */       this.log.debug("  No rules found matching '" + this.match + "'.");
/*      */     }
/*      */   }
/*      */ 
/*      */   public void startPrefixMapping(String prefix, String namespaceURI)
/*      */     throws SAXException
/*      */   {
/* 1315 */     if (this.saxLog.isDebugEnabled()) {
/* 1316 */       this.saxLog.debug("startPrefixMapping(" + prefix + "," + namespaceURI + ")");
/*      */     }
/*      */ 
/* 1320 */     ArrayStack stack = (ArrayStack)this.namespaces.get(prefix);
/* 1321 */     if (stack == null) {
/* 1322 */       stack = new ArrayStack();
/* 1323 */       this.namespaces.put(prefix, stack);
/*      */     }
/* 1325 */     stack.push(namespaceURI);
/*      */   }
/*      */ 
/*      */   public void notationDecl(String name, String publicId, String systemId)
/*      */   {
/* 1342 */     if (this.saxLog.isDebugEnabled())
/* 1343 */       this.saxLog.debug("notationDecl(" + name + "," + publicId + "," + systemId + ")");
/*      */   }
/*      */ 
/*      */   public void unparsedEntityDecl(String name, String publicId, String systemId, String notation)
/*      */   {
/* 1361 */     if (this.saxLog.isDebugEnabled())
/* 1362 */       this.saxLog.debug("unparsedEntityDecl(" + name + "," + publicId + "," + systemId + "," + notation + ")");
/*      */   }
/*      */ 
/*      */   public void setEntityResolver(EntityResolver entityResolver)
/*      */   {
/* 1378 */     this.entityResolver = entityResolver;
/*      */   }
/*      */ 
/*      */   public EntityResolver getEntityResolver()
/*      */   {
/* 1387 */     return this.entityResolver;
/*      */   }
/*      */ 
/*      */   public InputSource resolveEntity(String publicId, String systemId)
/*      */     throws SAXException
/*      */   {
/* 1402 */     if (this.saxLog.isDebugEnabled()) {
/* 1403 */       this.saxLog.debug("resolveEntity('" + publicId + "', '" + systemId + "')");
/*      */     }
/*      */ 
/* 1406 */     if (publicId != null) {
/* 1407 */       this.publicId = publicId;
/*      */     }
/*      */ 
/* 1410 */     String entityURL = null;
/* 1411 */     if (publicId != null) {
/* 1412 */       entityURL = (String)this.entityValidator.get(publicId);
/*      */     }
/*      */ 
/* 1416 */     if ((this.schemaLocation != null) && (entityURL == null) && (systemId != null)) {
/* 1417 */       entityURL = (String)this.entityValidator.get(systemId);
/*      */     }
/*      */ 
/* 1420 */     if (entityURL == null) {
/* 1421 */       if (systemId == null)
/*      */       {
/* 1423 */         if (this.log.isDebugEnabled()) {
/* 1424 */           this.log.debug(" Cannot resolve entity: '" + entityURL + "'");
/*      */         }
/* 1426 */         return null;
/*      */       }
/*      */ 
/* 1430 */       if (this.log.isDebugEnabled()) {
/* 1431 */         this.log.debug(" Trying to resolve using system ID '" + systemId + "'");
/*      */       }
/* 1433 */       entityURL = systemId;
/*      */     }
/*      */ 
/* 1438 */     if (this.log.isDebugEnabled()) {
/* 1439 */       this.log.debug(" Resolving to alternate DTD '" + entityURL + "'");
/*      */     }
/*      */     try
/*      */     {
/* 1443 */       return new InputSource(entityURL);
/*      */     } catch (Exception e) {
/* 1445 */       throw createSAXException(e);
/*      */     }
/*      */   }
/*      */ 
/*      */   public void error(SAXParseException exception)
/*      */     throws SAXException
/*      */   {
/* 1463 */     this.log.error("Parse Error at line " + exception.getLineNumber() + " column " + exception.getColumnNumber() + ": " + exception.getMessage(), exception);
/*      */ 
/* 1466 */     if (this.errorHandler != null)
/* 1467 */       this.errorHandler.error(exception);
/*      */   }
/*      */ 
/*      */   public void fatalError(SAXParseException exception)
/*      */     throws SAXException
/*      */   {
/* 1483 */     this.log.error("Parse Fatal Error at line " + exception.getLineNumber() + " column " + exception.getColumnNumber() + ": " + exception.getMessage(), exception);
/*      */ 
/* 1486 */     if (this.errorHandler != null)
/* 1487 */       this.errorHandler.fatalError(exception);
/*      */   }
/*      */ 
/*      */   public void warning(SAXParseException exception)
/*      */     throws SAXException
/*      */   {
/* 1502 */     if (this.errorHandler != null) {
/* 1503 */       this.log.warn("Parse Warning Error at line " + exception.getLineNumber() + " column " + exception.getColumnNumber() + ": " + exception.getMessage(), exception);
/*      */ 
/* 1507 */       this.errorHandler.warning(exception);
/*      */     }
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void log(String message)
/*      */   {
/* 1524 */     this.log.info(message);
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   public void log(String message, Throwable exception)
/*      */   {
/* 1537 */     this.log.error(message, exception);
/*      */   }
/*      */ 
/*      */   public Object parse(File file)
/*      */     throws IOException, SAXException
/*      */   {
/* 1553 */     configure();
/* 1554 */     InputSource input = new InputSource(new FileInputStream(file));
/* 1555 */     input.setSystemId("file://" + file.getAbsolutePath());
/* 1556 */     getXMLReader().parse(input);
/* 1557 */     return this.root;
/*      */   }
/*      */ 
/*      */   public Object parse(InputSource input)
/*      */     throws IOException, SAXException
/*      */   {
/* 1571 */     configure();
/* 1572 */     getXMLReader().parse(input);
/* 1573 */     return this.root;
/*      */   }
/*      */ 
/*      */   public Object parse(InputStream input)
/*      */     throws IOException, SAXException
/*      */   {
/* 1589 */     configure();
/* 1590 */     InputSource is = new InputSource(input);
/* 1591 */     getXMLReader().parse(is);
/* 1592 */     return this.root;
/*      */   }
/*      */ 
/*      */   public Object parse(Reader reader)
/*      */     throws IOException, SAXException
/*      */   {
/* 1608 */     configure();
/* 1609 */     InputSource is = new InputSource(reader);
/* 1610 */     getXMLReader().parse(is);
/* 1611 */     return this.root;
/*      */   }
/*      */ 
/*      */   public Object parse(String uri)
/*      */     throws IOException, SAXException
/*      */   {
/* 1627 */     configure();
/* 1628 */     InputSource is = new InputSource(uri);
/* 1629 */     getXMLReader().parse(is);
/* 1630 */     return this.root;
/*      */   }
/*      */ 
/*      */   public void register(String publicId, String entityURL)
/*      */   {
/* 1658 */     if (this.log.isDebugEnabled()) {
/* 1659 */       this.log.debug("register('" + publicId + "', '" + entityURL + "'");
/*      */     }
/* 1661 */     this.entityValidator.put(publicId, entityURL);
/*      */   }
/*      */ 
/*      */   public void addRule(String pattern, Rule rule)
/*      */   {
/* 1678 */     rule.setDigester(this);
/* 1679 */     getRules().add(pattern, rule);
/*      */   }
/*      */ 
/*      */   public void addRuleSet(RuleSet ruleSet)
/*      */   {
/* 1691 */     String oldNamespaceURI = getRuleNamespaceURI();
/* 1692 */     String newNamespaceURI = ruleSet.getNamespaceURI();
/* 1693 */     if (this.log.isDebugEnabled()) {
/* 1694 */       if (newNamespaceURI == null)
/* 1695 */         this.log.debug("addRuleSet() with no namespace URI");
/*      */       else {
/* 1697 */         this.log.debug("addRuleSet() with namespace URI " + newNamespaceURI);
/*      */       }
/*      */     }
/* 1700 */     setRuleNamespaceURI(newNamespaceURI);
/* 1701 */     ruleSet.addRuleInstances(this);
/* 1702 */     setRuleNamespaceURI(oldNamespaceURI);
/*      */   }
/*      */ 
/*      */   public void addBeanPropertySetter(String pattern)
/*      */   {
/* 1715 */     addRule(pattern, new BeanPropertySetterRule());
/*      */   }
/*      */ 
/*      */   public void addBeanPropertySetter(String pattern, String propertyName)
/*      */   {
/* 1731 */     addRule(pattern, new BeanPropertySetterRule(propertyName));
/*      */   }
/*      */ 
/*      */   public void addCallMethod(String pattern, String methodName)
/*      */   {
/* 1745 */     addRule(pattern, new CallMethodRule(methodName));
/*      */   }
/*      */ 
/*      */   public void addCallMethod(String pattern, String methodName, int paramCount)
/*      */   {
/* 1763 */     addRule(pattern, new CallMethodRule(methodName, paramCount));
/*      */   }
/*      */ 
/*      */   public void addCallMethod(String pattern, String methodName, int paramCount, String[] paramTypes)
/*      */   {
/* 1790 */     addRule(pattern, new CallMethodRule(methodName, paramCount, paramTypes));
/*      */   }
/*      */ 
/*      */   public void addCallMethod(String pattern, String methodName, int paramCount, Class[] paramTypes)
/*      */   {
/* 1819 */     addRule(pattern, new CallMethodRule(methodName, paramCount, paramTypes));
/*      */   }
/*      */ 
/*      */   public void addCallParam(String pattern, int paramIndex)
/*      */   {
/* 1838 */     addRule(pattern, new CallParamRule(paramIndex));
/*      */   }
/*      */ 
/*      */   public void addCallParam(String pattern, int paramIndex, String attributeName)
/*      */   {
/* 1857 */     addRule(pattern, new CallParamRule(paramIndex, attributeName));
/*      */   }
/*      */ 
/*      */   public void addCallParam(String pattern, int paramIndex, boolean fromStack)
/*      */   {
/* 1874 */     addRule(pattern, new CallParamRule(paramIndex, fromStack));
/*      */   }
/*      */ 
/*      */   public void addCallParam(String pattern, int paramIndex, int stackIndex)
/*      */   {
/* 1890 */     addRule(pattern, new CallParamRule(paramIndex, stackIndex));
/*      */   }
/*      */ 
/*      */   public void addCallParamPath(String pattern, int paramIndex)
/*      */   {
/* 1905 */     addRule(pattern, new PathCallParamRule(paramIndex));
/*      */   }
/*      */ 
/*      */   public void addObjectParam(String pattern, int paramIndex, Object paramObj)
/*      */   {
/* 1931 */     addRule(pattern, new ObjectParamRule(paramIndex, paramObj));
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, String className)
/*      */   {
/* 1946 */     addFactoryCreate(pattern, className, false);
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, Class clazz)
/*      */   {
/* 1961 */     addFactoryCreate(pattern, clazz, false);
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, String className, String attributeName)
/*      */   {
/* 1979 */     addFactoryCreate(pattern, className, attributeName, false);
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, Class clazz, String attributeName)
/*      */   {
/* 1997 */     addFactoryCreate(pattern, clazz, attributeName, false);
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, ObjectCreationFactory creationFactory)
/*      */   {
/* 2014 */     addFactoryCreate(pattern, creationFactory, false);
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, String className, boolean ignoreCreateExceptions)
/*      */   {
/* 2032 */     addRule(pattern, new FactoryCreateRule(className, ignoreCreateExceptions));
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, Class clazz, boolean ignoreCreateExceptions)
/*      */   {
/* 2053 */     addRule(pattern, new FactoryCreateRule(clazz, ignoreCreateExceptions));
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, String className, String attributeName, boolean ignoreCreateExceptions)
/*      */   {
/* 2077 */     addRule(pattern, new FactoryCreateRule(className, attributeName, ignoreCreateExceptions));
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, Class clazz, String attributeName, boolean ignoreCreateExceptions)
/*      */   {
/* 2101 */     addRule(pattern, new FactoryCreateRule(clazz, attributeName, ignoreCreateExceptions));
/*      */   }
/*      */ 
/*      */   public void addFactoryCreate(String pattern, ObjectCreationFactory creationFactory, boolean ignoreCreateExceptions)
/*      */   {
/* 2122 */     creationFactory.setDigester(this);
/* 2123 */     addRule(pattern, new FactoryCreateRule(creationFactory, ignoreCreateExceptions));
/*      */   }
/*      */ 
/*      */   public void addObjectCreate(String pattern, String className)
/*      */   {
/* 2137 */     addRule(pattern, new ObjectCreateRule(className));
/*      */   }
/*      */ 
/*      */   public void addObjectCreate(String pattern, Class clazz)
/*      */   {
/* 2152 */     addRule(pattern, new ObjectCreateRule(clazz));
/*      */   }
/*      */ 
/*      */   public void addObjectCreate(String pattern, String className, String attributeName)
/*      */   {
/* 2170 */     addRule(pattern, new ObjectCreateRule(className, attributeName));
/*      */   }
/*      */ 
/*      */   public void addObjectCreate(String pattern, String attributeName, Class clazz)
/*      */   {
/* 2189 */     addRule(pattern, new ObjectCreateRule(attributeName, clazz));
/*      */   }
/*      */ 
/*      */   public void addSetNestedProperties(String pattern)
/*      */   {
/* 2203 */     addRule(pattern, new SetNestedPropertiesRule());
/*      */   }
/*      */ 
/*      */   public void addSetNestedProperties(String pattern, String elementName, String propertyName)
/*      */   {
/* 2217 */     addRule(pattern, new SetNestedPropertiesRule(elementName, propertyName));
/*      */   }
/*      */ 
/*      */   public void addSetNestedProperties(String pattern, String[] elementNames, String[] propertyNames)
/*      */   {
/* 2231 */     addRule(pattern, new SetNestedPropertiesRule(elementNames, propertyNames));
/*      */   }
/*      */ 
/*      */   public void addSetNext(String pattern, String methodName)
/*      */   {
/* 2244 */     addRule(pattern, new SetNextRule(methodName));
/*      */   }
/*      */ 
/*      */   public void addSetNext(String pattern, String methodName, String paramType)
/*      */   {
/* 2264 */     addRule(pattern, new SetNextRule(methodName, paramType));
/*      */   }
/*      */ 
/*      */   public void addSetRoot(String pattern, String methodName)
/*      */   {
/* 2279 */     addRule(pattern, new SetRootRule(methodName));
/*      */   }
/*      */ 
/*      */   public void addSetRoot(String pattern, String methodName, String paramType)
/*      */   {
/* 2296 */     addRule(pattern, new SetRootRule(methodName, paramType));
/*      */   }
/*      */ 
/*      */   public void addSetProperties(String pattern)
/*      */   {
/* 2309 */     addRule(pattern, new SetPropertiesRule());
/*      */   }
/*      */ 
/*      */   public void addSetProperties(String pattern, String attributeName, String propertyName)
/*      */   {
/* 2328 */     addRule(pattern, new SetPropertiesRule(attributeName, propertyName));
/*      */   }
/*      */ 
/*      */   public void addSetProperties(String pattern, String[] attributeNames, String[] propertyNames)
/*      */   {
/* 2347 */     addRule(pattern, new SetPropertiesRule(attributeNames, propertyNames));
/*      */   }
/*      */ 
/*      */   public void addSetProperty(String pattern, String name, String value)
/*      */   {
/* 2363 */     addRule(pattern, new SetPropertyRule(name, value));
/*      */   }
/*      */ 
/*      */   public void addSetTop(String pattern, String methodName)
/*      */   {
/* 2378 */     addRule(pattern, new SetTopRule(methodName));
/*      */   }
/*      */ 
/*      */   public void addSetTop(String pattern, String methodName, String paramType)
/*      */   {
/* 2398 */     addRule(pattern, new SetTopRule(methodName, paramType));
/*      */   }
/*      */ 
/*      */   public void clear()
/*      */   {
/* 2417 */     this.match = "";
/* 2418 */     this.bodyTexts.clear();
/* 2419 */     this.params.clear();
/* 2420 */     this.publicId = null;
/* 2421 */     this.stack.clear();
/*      */   }
/*      */ 
/*      */   public Object peek()
/*      */   {
/*      */     try
/*      */     {
/* 2432 */       return this.stack.peek();
/*      */     } catch (EmptyStackException e) {
/* 2434 */       this.log.warn("Empty stack (returning null)"); }
/* 2435 */     return null;
/*      */   }
/*      */ 
/*      */   public Object peek(int n)
/*      */   {
/*      */     try
/*      */     {
/* 2452 */       return this.stack.peek(n);
/*      */     } catch (EmptyStackException e) {
/* 2454 */       this.log.warn("Empty stack (returning null)"); }
/* 2455 */     return null;
/*      */   }
/*      */ 
/*      */   public Object pop()
/*      */   {
/*      */     try
/*      */     {
/* 2468 */       return this.stack.pop();
/*      */     } catch (EmptyStackException e) {
/* 2470 */       this.log.warn("Empty stack (returning null)"); }
/* 2471 */     return null;
/*      */   }
/*      */ 
/*      */   public void push(Object object)
/*      */   {
/* 2484 */     if (this.stack.size() == 0) {
/* 2485 */       this.root = object;
/*      */     }
/* 2487 */     this.stack.push(object);
/*      */   }
/*      */ 
/*      */   public void push(String stackName, Object value)
/*      */   {
/* 2501 */     ArrayStack namedStack = (ArrayStack)this.stacksByName.get(stackName);
/* 2502 */     if (namedStack == null) {
/* 2503 */       namedStack = new ArrayStack();
/* 2504 */       this.stacksByName.put(stackName, namedStack);
/*      */     }
/* 2506 */     namedStack.push(value);
/*      */   }
/*      */ 
/*      */   public Object pop(String stackName)
/*      */   {
/* 2523 */     Object result = null;
/* 2524 */     ArrayStack namedStack = (ArrayStack)this.stacksByName.get(stackName);
/* 2525 */     if (namedStack == null) {
/* 2526 */       if (this.log.isDebugEnabled()) {
/* 2527 */         this.log.debug("Stack '" + stackName + "' is empty");
/*      */       }
/* 2529 */       throw new EmptyStackException();
/*      */     }
/*      */ 
/* 2533 */     result = namedStack.pop();
/*      */ 
/* 2535 */     return result;
/*      */   }
/*      */ 
/*      */   public Object peek(String stackName)
/*      */   {
/* 2553 */     Object result = null;
/* 2554 */     ArrayStack namedStack = (ArrayStack)this.stacksByName.get(stackName);
/* 2555 */     if (namedStack == null) {
/* 2556 */       if (this.log.isDebugEnabled()) {
/* 2557 */         this.log.debug("Stack '" + stackName + "' is empty");
/*      */       }
/* 2559 */       throw new EmptyStackException();
/*      */     }
/*      */ 
/* 2563 */     result = namedStack.peek();
/*      */ 
/* 2565 */     return result;
/*      */   }
/*      */ 
/*      */   public boolean isEmpty(String stackName)
/*      */   {
/* 2579 */     boolean result = true;
/* 2580 */     ArrayStack namedStack = (ArrayStack)this.stacksByName.get(stackName);
/* 2581 */     if (namedStack != null) {
/* 2582 */       result = namedStack.isEmpty();
/*      */     }
/* 2584 */     return result;
/*      */   }
/*      */ 
/*      */   public Object getRoot()
/*      */   {
/* 2596 */     return this.root;
/*      */   }
/*      */ 
/*      */   protected void configure()
/*      */   {
/* 2623 */     if (this.configured) {
/* 2624 */       return;
/*      */     }
/*      */ 
/* 2628 */     initialize();
/*      */ 
/* 2632 */     this.configured = true;
/*      */   }
/*      */ 
/*      */   protected void initialize()
/*      */   {
/*      */   }
/*      */ 
/*      */   Map getRegistrations()
/*      */   {
/* 2669 */     return this.entityValidator;
/*      */   }
/*      */ 
/*      */   /** @deprecated */
/*      */   List getRules(String match)
/*      */   {
/* 2689 */     return getRules().match(match);
/*      */   }
/*      */ 
/*      */   public Object peekParams()
/*      */   {
/*      */     try
/*      */     {
/* 2704 */       return this.params.peek();
/*      */     } catch (EmptyStackException e) {
/* 2706 */       this.log.warn("Empty stack (returning null)"); }
/* 2707 */     return null;
/*      */   }
/*      */ 
/*      */   public Object peekParams(int n)
/*      */   {
/*      */     try
/*      */     {
/* 2727 */       return this.params.peek(n);
/*      */     } catch (EmptyStackException e) {
/* 2729 */       this.log.warn("Empty stack (returning null)"); }
/* 2730 */     return null;
/*      */   }
/*      */ 
/*      */   public Object popParams()
/*      */   {
/*      */     try
/*      */     {
/* 2746 */       if (this.log.isTraceEnabled()) {
/* 2747 */         this.log.trace("Popping params");
/*      */       }
/* 2749 */       return this.params.pop();
/*      */     } catch (EmptyStackException e) {
/* 2751 */       this.log.warn("Empty stack (returning null)"); }
/* 2752 */     return null;
/*      */   }
/*      */ 
/*      */   public void pushParams(Object object)
/*      */   {
/* 2767 */     if (this.log.isTraceEnabled()) {
/* 2768 */       this.log.trace("Pushing params");
/*      */     }
/* 2770 */     this.params.push(object);
/*      */   }
/*      */ 
/*      */   public SAXException createSAXException(String message, Exception e)
/*      */   {
/* 2781 */     if ((e != null) && (e instanceof InvocationTargetException))
/*      */     {
/* 2783 */       Throwable t = ((InvocationTargetException)e).getTargetException();
/* 2784 */       if ((t != null) && (t instanceof Exception)) {
/* 2785 */         e = (Exception)t;
/*      */       }
/*      */     }
/* 2788 */     if (this.locator != null) {
/* 2789 */       String error = "Error at (" + this.locator.getLineNumber() + ", " + this.locator.getColumnNumber() + ": " + message;
/*      */ 
/* 2791 */       if (e != null) {
/* 2792 */         return new SAXParseException(error, this.locator, e);
/*      */       }
/* 2794 */       return new SAXParseException(error, this.locator);
/*      */     }
/*      */ 
/* 2797 */     this.log.error("No Locator!");
/* 2798 */     if (e != null) {
/* 2799 */       return new SAXException(message, e);
/*      */     }
/* 2801 */     return new SAXException(message);
/*      */   }
/*      */ 
/*      */   public SAXException createSAXException(Exception e)
/*      */   {
/* 2812 */     if (e instanceof InvocationTargetException) {
/* 2813 */       Throwable t = ((InvocationTargetException)e).getTargetException();
/* 2814 */       if ((t != null) && (t instanceof Exception)) {
/* 2815 */         e = (Exception)t;
/*      */       }
/*      */     }
/* 2818 */     return createSAXException(e.getMessage(), e);
/*      */   }
/*      */ 
/*      */   public SAXException createSAXException(String message)
/*      */   {
/* 2828 */     return createSAXException(message, null);
/*      */   }
/*      */ }