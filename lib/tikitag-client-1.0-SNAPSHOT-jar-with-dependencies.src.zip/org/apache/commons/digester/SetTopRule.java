/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.beanutils.MethodUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class SetTopRule extends Rule
/*     */ {
/*     */   protected String methodName;
/*     */   protected String paramType;
/*     */   protected boolean useExactMatch;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetTopRule(Digester digester, String methodName)
/*     */   {
/*  54 */     this(methodName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetTopRule(Digester digester, String methodName, String paramType)
/*     */   {
/*  75 */     this(methodName, paramType);
/*     */   }
/*     */ 
/*     */   public SetTopRule(String methodName)
/*     */   {
/*  88 */     this(methodName, null);
/*     */   }
/*     */ 
/*     */   public SetTopRule(String methodName, String paramType)
/*     */   {
/* 117 */     this.methodName = null;
/*     */ 
/* 123 */     this.paramType = null;
/*     */ 
/* 128 */     this.useExactMatch = false;
/*     */ 
/* 105 */     this.methodName = methodName;
/* 106 */     this.paramType = paramType;
/*     */   }
/*     */ 
/*     */   public boolean isExactMatch()
/*     */   {
/* 155 */     return this.useExactMatch;
/*     */   }
/*     */ 
/*     */   public void setExactMatch(boolean useExactMatch)
/*     */   {
/* 168 */     this.useExactMatch = useExactMatch;
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/* 177 */     Object child = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(0);
/* 178 */     Object parent = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(1);
/*     */ 
/* 180 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 181 */       if (child == null) {
/* 182 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetTopRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call [NULL CHILD]." + this.methodName + "(" + parent + ")");
/*     */       }
/*     */       else
/*     */       {
/* 186 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetTopRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call " + child.getClass().getName() + "." + this.methodName + "(" + parent + ")");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 193 */     Class[] paramTypes = new Class[1];
/* 194 */     if (this.paramType != null) {
/* 195 */       paramTypes[0] = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getClassLoader().loadClass(this.paramType);
/*     */     }
/*     */     else {
/* 198 */       paramTypes[0] = parent.getClass();
/*     */     }
/*     */ 
/* 201 */     if (this.useExactMatch)
/*     */     {
/* 203 */       MethodUtils.invokeExactMethod(child, this.methodName, new Object[] { parent }, paramTypes);
/*     */     }
/*     */     else
/*     */     {
/* 208 */       MethodUtils.invokeMethod(child, this.methodName, new Object[] { parent }, paramTypes);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 220 */     StringBuffer sb = new StringBuffer("SetTopRule[");
/* 221 */     sb.append("methodName=");
/* 222 */     sb.append(this.methodName);
/* 223 */     sb.append(", paramType=");
/* 224 */     sb.append(this.paramType);
/* 225 */     sb.append("]");
/* 226 */     return sb.toString();
/*     */   }
/*     */ }