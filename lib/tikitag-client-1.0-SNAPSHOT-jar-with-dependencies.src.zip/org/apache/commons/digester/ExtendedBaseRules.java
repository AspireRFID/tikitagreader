/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.Comparator;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class ExtendedBaseRules extends RulesBase
/*     */ {
/*     */   private int counter;
/*     */   private Map order;
/*     */ 
/*     */   public ExtendedBaseRules()
/*     */   {
/* 140 */     this.counter = 0;
/*     */ 
/* 150 */     this.order = new HashMap();
/*     */   }
/*     */ 
/*     */   public void add(String pattern, Rule rule)
/*     */   {
/* 163 */     super.add(pattern, rule);
/* 164 */     this.counter += 1;
/* 165 */     this.order.put(rule, new Integer(this.counter));
/*     */   }
/*     */ 
/*     */   public List match(String namespace, String pattern)
/*     */   {
/* 181 */     String parentPattern = "";
/* 182 */     int lastIndex = pattern.lastIndexOf(47);
/*     */ 
/* 184 */     boolean hasParent = true;
/* 185 */     if (lastIndex == -1)
/*     */     {
/* 187 */       hasParent = false;
/*     */     }
/*     */     else
/*     */     {
/* 191 */       parentPattern = pattern.substring(0, lastIndex);
/*     */     }
/*     */ 
/* 197 */     List universalList = new ArrayList(this.counter);
/*     */ 
/* 201 */     List tempList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get("!*");
/* 202 */     if (tempList != null) {
/* 203 */       universalList.addAll(tempList);
/*     */     }
/*     */ 
/* 208 */     tempList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get("!" + parentPattern + "/?");
/* 209 */     if (tempList != null) {
/* 210 */       universalList.addAll(tempList);
/*     */     }
/*     */ 
/* 217 */     boolean ignoreBasicMatches = false;
/*     */ 
/* 221 */     List rulesList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get(pattern);
/* 222 */     if (rulesList != null)
/*     */     {
/* 225 */       ignoreBasicMatches = true;
/*     */     }
/* 230 */     else if (hasParent)
/*     */     {
/* 232 */       rulesList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get(parentPattern + "/?");
/* 233 */       if (rulesList != null)
/*     */       {
/* 236 */         ignoreBasicMatches = true;
/*     */       }
/*     */       else
/*     */       {
/* 241 */         rulesList = findExactAncesterMatch(pattern);
/* 242 */         if (rulesList != null)
/*     */         {
/* 245 */           ignoreBasicMatches = true;
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 257 */     String longKey = "";
/* 258 */     int longKeyLength = 0;
/*     */ 
/* 260 */     Iterator keys = this.jdField_cache_of_type_JavaUtilHashMap.keySet().iterator();
/* 261 */     while (keys.hasNext()) {
/* 262 */       String key = (String)keys.next();
/*     */ 
/* 266 */       boolean isUniversal = key.startsWith("!");
/* 267 */       if (isUniversal)
/*     */       {
/* 269 */         key = key.substring(1, key.length());
/*     */       }
/*     */ 
/* 274 */       boolean wildcardMatchStart = key.startsWith("*/");
/* 275 */       boolean wildcardMatchEnd = key.endsWith("/*");
/* 276 */       if ((!(wildcardMatchStart)) && (((!(isUniversal)) || (!(wildcardMatchEnd)))))
/*     */         continue;
/* 278 */       boolean parentMatched = false;
/* 279 */       boolean basicMatched = false;
/* 280 */       boolean ancesterMatched = false;
/*     */ 
/* 282 */       boolean parentMatchEnd = key.endsWith("/?");
/* 283 */       if (parentMatchEnd)
/*     */       {
/* 285 */         parentMatched = parentMatch(key, pattern, parentPattern);
/*     */       }
/* 287 */       else if (wildcardMatchEnd)
/*     */       {
/* 289 */         if (wildcardMatchStart) {
/* 290 */           String patternBody = key.substring(2, key.length() - 2);
/* 291 */           if (pattern.endsWith(patternBody))
/* 292 */             ancesterMatched = true;
/*     */           else
/* 294 */             ancesterMatched = pattern.indexOf(patternBody + "/") > -1;
/*     */         }
/*     */         else {
/* 297 */           String bodyPattern = key.substring(0, key.length() - 2);
/* 298 */           if (pattern.startsWith(bodyPattern))
/*     */           {
/* 300 */             if (pattern.length() == bodyPattern.length())
/*     */             {
/* 302 */               ancesterMatched = true;
/*     */             }
/*     */             else ancesterMatched = pattern.charAt(bodyPattern.length()) == '/';
/*     */           }
/*     */           else {
/* 307 */             ancesterMatched = false;
/*     */           }
/*     */         }
/*     */       }
/*     */       else {
/* 312 */         basicMatched = basicMatch(key, pattern);
/*     */       }
/*     */ 
/* 315 */       if ((parentMatched) || (basicMatched) || (ancesterMatched)) {
/* 316 */         if (isUniversal)
/*     */         {
/* 319 */           tempList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get("!" + key);
/* 320 */           if (tempList != null)
/* 321 */             universalList.addAll(tempList);
/*     */         }
/*     */         else
/*     */         {
/* 325 */           if (ignoreBasicMatches)
/*     */           {
/*     */             continue;
/*     */           }
/*     */ 
/* 332 */           int keyLength = key.length();
/* 333 */           if (wildcardMatchStart) {
/* 334 */             --keyLength;
/*     */           }
/* 336 */           if (wildcardMatchEnd)
/* 337 */             --keyLength;
/* 338 */           else if (parentMatchEnd) {
/* 339 */             --keyLength;
/*     */           }
/*     */ 
/* 342 */           if (keyLength > longKeyLength) {
/* 343 */             rulesList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get(key);
/* 344 */             longKey = key;
/* 345 */             longKeyLength = keyLength;
/*     */           }
/*     */ 
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 356 */     if (rulesList == null) {
/* 357 */       rulesList = (List)this.jdField_cache_of_type_JavaUtilHashMap.get("*");
/*     */     }
/*     */ 
/* 361 */     if (rulesList != null) {
/* 362 */       universalList.addAll(rulesList);
/*     */     }
/*     */ 
/* 367 */     if (namespace != null)
/*     */     {
/* 369 */       Iterator it = universalList.iterator();
/* 370 */       while (it.hasNext()) {
/* 371 */         Rule rule = (Rule)it.next();
/* 372 */         String ns_uri = rule.getNamespaceURI();
/* 373 */         if ((ns_uri != null) && (!(ns_uri.equals(namespace)))) {
/* 374 */           it.remove();
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 382 */     Collections.sort(universalList, new Comparator()
/*     */     {
/*     */       public int compare(Object o1, Object o2)
/*     */         throws ClassCastException
/*     */       {
/* 388 */         Integer i1 = (Integer)ExtendedBaseRules.this.order.get(o1);
/* 389 */         Integer i2 = (Integer)ExtendedBaseRules.this.order.get(o2);
/*     */ 
/* 392 */         if (i1 == null) {
/* 393 */           if (i2 == null)
/*     */           {
/* 395 */             return 0;
/*     */           }
/*     */ 
/* 399 */           return -1;
/*     */         }
/*     */ 
/* 402 */         if (i2 == null) {
/* 403 */           return 1;
/*     */         }
/*     */ 
/* 406 */         return (i1.intValue() - i2.intValue());
/*     */       }
/*     */     });
/* 410 */     return universalList;
/*     */   }
/*     */ 
/*     */   private boolean parentMatch(String key, String pattern, String parentPattern)
/*     */   {
/* 417 */     return parentPattern.endsWith(key.substring(1, key.length() - 2));
/*     */   }
/*     */ 
/*     */   private boolean basicMatch(String key, String pattern)
/*     */   {
/* 425 */     return ((pattern.equals(key.substring(2))) || (pattern.endsWith(key.substring(1))));
/*     */   }
/*     */ 
/*     */   private List findExactAncesterMatch(String parentPattern)
/*     */   {
/* 433 */     List matchingRules = null;
/* 434 */     int lastIndex = parentPattern.length();
/* 435 */     while (lastIndex-- > 0) {
/* 436 */       lastIndex = parentPattern.lastIndexOf(47, lastIndex);
/* 437 */       if (lastIndex > 0) {
/* 438 */         matchingRules = (List)this.jdField_cache_of_type_JavaUtilHashMap.get(parentPattern.substring(0, lastIndex) + "/*");
/* 439 */         if (matchingRules != null) {
/* 440 */           return matchingRules;
/*     */         }
/*     */       }
/*     */     }
/* 444 */     return null;
/*     */   }
/*     */ }