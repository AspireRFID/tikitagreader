/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.collections.ArrayStack;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class CallParamRule extends Rule
/*     */ {
/*     */   protected String attributeName;
/*     */   protected int paramIndex;
/*     */   protected boolean fromStack;
/*     */   protected int stackIndex;
/*     */   protected ArrayStack bodyTextStack;
/*     */ 
/*     */   /** @deprecated */
/*     */   public CallParamRule(Digester digester, int paramIndex)
/*     */   {
/*  62 */     this(paramIndex);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public CallParamRule(Digester digester, int paramIndex, String attributeName)
/*     */   {
/*  81 */     this(paramIndex, attributeName);
/*     */   }
/*     */ 
/*     */   public CallParamRule(int paramIndex)
/*     */   {
/*  93 */     this(paramIndex, null);
/*     */   }
/*     */ 
/*     */   public CallParamRule(int paramIndex, String attributeName)
/*     */   {
/* 148 */     this.attributeName = null;
/*     */ 
/* 154 */     this.paramIndex = 0;
/*     */ 
/* 160 */     this.fromStack = false;
/*     */ 
/* 165 */     this.stackIndex = 0;
/*     */ 
/* 108 */     this.paramIndex = paramIndex;
/* 109 */     this.attributeName = attributeName;
/*     */   }
/*     */ 
/*     */   public CallParamRule(int paramIndex, boolean fromStack)
/*     */   {
/* 148 */     this.attributeName = null;
/*     */ 
/* 154 */     this.paramIndex = 0;
/*     */ 
/* 160 */     this.fromStack = false;
/*     */ 
/* 165 */     this.stackIndex = 0;
/*     */ 
/* 122 */     this.paramIndex = paramIndex;
/* 123 */     this.fromStack = fromStack;
/*     */   }
/*     */ 
/*     */   public CallParamRule(int paramIndex, int stackIndex)
/*     */   {
/* 148 */     this.attributeName = null;
/*     */ 
/* 154 */     this.paramIndex = 0;
/*     */ 
/* 160 */     this.fromStack = false;
/*     */ 
/* 165 */     this.stackIndex = 0;
/*     */ 
/* 137 */     this.paramIndex = paramIndex;
/* 138 */     this.fromStack = true;
/* 139 */     this.stackIndex = stackIndex;
/*     */   }
/*     */ 
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 183 */     Object param = null;
/*     */ 
/* 185 */     if (this.attributeName != null)
/*     */     {
/* 187 */       param = attributes.getValue(this.attributeName);
/*     */     }
/* 189 */     else if (this.fromStack)
/*     */     {
/* 191 */       param = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(this.stackIndex);
/*     */ 
/* 193 */       if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled())
/*     */       {
/* 195 */         StringBuffer sb = new StringBuffer("[CallParamRule]{");
/* 196 */         sb.append(this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match);
/* 197 */         sb.append("} Save from stack; from stack?").append(this.fromStack);
/* 198 */         sb.append("; object=").append(param);
/* 199 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug(sb.toString());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 209 */     if (param != null) {
/* 210 */       Object[] parameters = (Object[])this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peekParams();
/* 211 */       parameters[this.paramIndex] = param;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void body(String bodyText)
/*     */     throws Exception
/*     */   {
/* 223 */     if ((this.attributeName != null) || (this.fromStack)) {
/*     */       return;
/*     */     }
/*     */ 
/* 227 */     if (this.bodyTextStack == null) {
/* 228 */       this.bodyTextStack = new ArrayStack();
/*     */     }
/* 230 */     this.bodyTextStack.push(bodyText.trim());
/*     */   }
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */   {
/* 239 */     if ((this.bodyTextStack == null) || (this.bodyTextStack.empty()))
/*     */       return;
/* 241 */     Object[] parameters = (Object[])this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peekParams();
/* 242 */     parameters[this.paramIndex] = this.bodyTextStack.pop();
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 251 */     StringBuffer sb = new StringBuffer("CallParamRule[");
/* 252 */     sb.append("paramIndex=");
/* 253 */     sb.append(this.paramIndex);
/* 254 */     sb.append(", attributeName=");
/* 255 */     sb.append(this.attributeName);
/* 256 */     sb.append(", from stack=");
/* 257 */     sb.append(this.fromStack);
/* 258 */     sb.append("]");
/* 259 */     return sb.toString();
/*     */   }
/*     */ }