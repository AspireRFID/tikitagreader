/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.beanutils.MethodUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class SetNextRule extends Rule
/*     */ {
/*     */   protected String methodName;
/*     */   protected String paramType;
/*     */   protected boolean useExactMatch;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetNextRule(Digester digester, String methodName)
/*     */   {
/*  55 */     this(methodName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetNextRule(Digester digester, String methodName, String paramType)
/*     */   {
/*  76 */     this(methodName, paramType);
/*     */   }
/*     */ 
/*     */   public SetNextRule(String methodName)
/*     */   {
/*  89 */     this(methodName, null);
/*     */   }
/*     */ 
/*     */   public SetNextRule(String methodName, String paramType)
/*     */   {
/* 118 */     this.methodName = null;
/*     */ 
/* 124 */     this.paramType = null;
/*     */ 
/* 129 */     this.useExactMatch = false;
/*     */ 
/* 106 */     this.methodName = methodName;
/* 107 */     this.paramType = paramType;
/*     */   }
/*     */ 
/*     */   public boolean isExactMatch()
/*     */   {
/* 156 */     return this.useExactMatch;
/*     */   }
/*     */ 
/*     */   public void setExactMatch(boolean useExactMatch)
/*     */   {
/* 169 */     this.useExactMatch = useExactMatch;
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/* 178 */     Object child = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(0);
/* 179 */     Object parent = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(1);
/* 180 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 181 */       if (parent == null) {
/* 182 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetNextRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call [NULL PARENT]." + this.methodName + "(" + child + ")");
/*     */       }
/*     */       else
/*     */       {
/* 186 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetNextRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call " + parent.getClass().getName() + "." + this.methodName + "(" + child + ")");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 193 */     Class[] paramTypes = new Class[1];
/* 194 */     if (this.paramType != null) {
/* 195 */       paramTypes[0] = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getClassLoader().loadClass(this.paramType);
/*     */     }
/*     */     else {
/* 198 */       paramTypes[0] = child.getClass();
/*     */     }
/*     */ 
/* 201 */     if (this.useExactMatch)
/*     */     {
/* 203 */       MethodUtils.invokeExactMethod(parent, this.methodName, new Object[] { child }, paramTypes);
/*     */     }
/*     */     else
/*     */     {
/* 208 */       MethodUtils.invokeMethod(parent, this.methodName, new Object[] { child }, paramTypes);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 220 */     StringBuffer sb = new StringBuffer("SetNextRule[");
/* 221 */     sb.append("methodName=");
/* 222 */     sb.append(this.methodName);
/* 223 */     sb.append(", paramType=");
/* 224 */     sb.append(this.paramType);
/* 225 */     sb.append("]");
/* 226 */     return sb.toString();
/*     */   }
/*     */ }