/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class BeanPropertySetterRule extends Rule
/*     */ {
/*     */   protected String propertyName;
/*     */   protected String bodyText;
/*     */ 
/*     */   /** @deprecated */
/*     */   public BeanPropertySetterRule(Digester digester, String propertyName)
/*     */   {
/*  60 */     this(propertyName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public BeanPropertySetterRule(Digester digester)
/*     */   {
/*     */   }
/*     */ 
/*     */   public BeanPropertySetterRule(String propertyName)
/*     */   {
/* 110 */     this.propertyName = null;
/*     */ 
/* 116 */     this.bodyText = null;
/*     */ 
/*  88 */     this.propertyName = propertyName;
/*     */   }
/*     */ 
/*     */   public BeanPropertySetterRule()
/*     */   {
/* 100 */     this((String)null);
/*     */   }
/*     */ 
/*     */   public void body(String namespace, String name, String text)
/*     */     throws Exception
/*     */   {
/* 136 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 137 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[BeanPropertySetterRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Called with text '" + text + "'");
/*     */     }
/*     */ 
/* 141 */     this.bodyText = text.trim();
/*     */   }
/*     */ 
/*     */   public void end(String namespace, String name)
/*     */     throws Exception
/*     */   {
/* 160 */     String property = this.propertyName;
/*     */ 
/* 162 */     if (property == null)
/*     */     {
/* 165 */       property = name;
/*     */     }
/*     */ 
/* 169 */     Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek();
/*     */ 
/* 172 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 173 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[BeanPropertySetterRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set " + top.getClass().getName() + " property " + property + " with text " + this.bodyText);
/*     */     }
/*     */ 
/* 180 */     if (top instanceof DynaBean) {
/* 181 */       DynaProperty desc = ((DynaBean)top).getDynaClass().getDynaProperty(property);
/*     */ 
/* 183 */       if (desc == null)
/* 184 */         throw new NoSuchMethodException("Bean has no property named " + property);
/*     */     }
/*     */     else
/*     */     {
/* 188 */       PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(top, property);
/*     */ 
/* 190 */       if (desc == null) {
/* 191 */         throw new NoSuchMethodException("Bean has no property named " + property);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 197 */     BeanUtils.setProperty(top, property, this.bodyText);
/*     */   }
/*     */ 
/*     */   public void finish()
/*     */     throws Exception
/*     */   {
/* 207 */     this.bodyText = null;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 217 */     StringBuffer sb = new StringBuffer("BeanPropertySetterRule[");
/* 218 */     sb.append("propertyName=");
/* 219 */     sb.append(this.propertyName);
/* 220 */     sb.append("]");
/* 221 */     return sb.toString();
/*     */   }
/*     */ }