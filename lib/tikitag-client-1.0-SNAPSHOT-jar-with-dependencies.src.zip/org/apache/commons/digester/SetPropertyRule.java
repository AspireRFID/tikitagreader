/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.beans.PropertyDescriptor;
/*     */ import org.apache.commons.beanutils.BeanUtils;
/*     */ import org.apache.commons.beanutils.DynaBean;
/*     */ import org.apache.commons.beanutils.DynaClass;
/*     */ import org.apache.commons.beanutils.DynaProperty;
/*     */ import org.apache.commons.beanutils.PropertyUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.xml.sax.Attributes;
/*     */ 
/*     */ public class SetPropertyRule extends Rule
/*     */ {
/*     */   protected String name;
/*     */   protected String value;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetPropertyRule(Digester digester, String name, String value)
/*     */   {
/*  57 */     this(name, value);
/*     */   }
/*     */ 
/*     */   public SetPropertyRule(String name, String value)
/*     */   {
/*  83 */     this.name = null;
/*     */ 
/*  89 */     this.value = null;
/*     */ 
/*  72 */     this.name = name;
/*  73 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public void begin(Attributes attributes)
/*     */     throws Exception
/*     */   {
/* 106 */     String actualName = null;
/* 107 */     String actualValue = null;
/* 108 */     for (int i = 0; i < attributes.getLength(); ++i) {
/* 109 */       String name = attributes.getLocalName(i);
/* 110 */       if ("".equals(name)) {
/* 111 */         name = attributes.getQName(i);
/*     */       }
/* 113 */       String value = attributes.getValue(i);
/* 114 */       if (name.equals(this.name))
/* 115 */         actualName = value;
/* 116 */       else if (name.equals(this.value)) {
/* 117 */         actualValue = value;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 122 */     Object top = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek();
/*     */ 
/* 125 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 126 */       this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetPropertyRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Set " + top.getClass().getName() + " property " + actualName + " to " + actualValue);
/*     */     }
/*     */ 
/* 133 */     if (top instanceof DynaBean) {
/* 134 */       DynaProperty desc = ((DynaBean)top).getDynaClass().getDynaProperty(actualName);
/*     */ 
/* 136 */       if (desc == null)
/* 137 */         throw new NoSuchMethodException("Bean has no property named " + actualName);
/*     */     }
/*     */     else
/*     */     {
/* 141 */       PropertyDescriptor desc = PropertyUtils.getPropertyDescriptor(top, actualName);
/*     */ 
/* 143 */       if (desc == null) {
/* 144 */         throw new NoSuchMethodException("Bean has no property named " + actualName);
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 150 */     BeanUtils.setProperty(top, actualName, actualValue);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 160 */     StringBuffer sb = new StringBuffer("SetPropertyRule[");
/* 161 */     sb.append("name=");
/* 162 */     sb.append(this.name);
/* 163 */     sb.append(", value=");
/* 164 */     sb.append(this.value);
/* 165 */     sb.append("]");
/* 166 */     return sb.toString();
/*     */   }
/*     */ }