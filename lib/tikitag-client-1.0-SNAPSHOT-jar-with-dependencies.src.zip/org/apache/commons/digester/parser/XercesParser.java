/*     */ package org.apache.commons.digester.parser;
/*     */ 
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.Properties;
/*     */ import javax.xml.parsers.ParserConfigurationException;
/*     */ import javax.xml.parsers.SAXParser;
/*     */ import javax.xml.parsers.SAXParserFactory;
/*     */ import org.apache.commons.logging.Log;
/*     */ import org.apache.commons.logging.LogFactory;
/*     */ import org.xml.sax.SAXException;
/*     */ import org.xml.sax.SAXNotRecognizedException;
/*     */ import org.xml.sax.SAXNotSupportedException;
/*     */ 
/*     */ public class XercesParser
/*     */ {
/*  48 */   protected static Log log = LogFactory.getLog("org.apache.commons.digester.Digester.sax");
/*     */   private static final String JAXP_SCHEMA_SOURCE = "http://java.sun.com/xml/jaxp/properties/schemaSource";
/*  62 */   protected static String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
/*     */ 
/*  69 */   protected static String XERCES_DYNAMIC = "http://apache.org/xml/features/validation/dynamic";
/*     */ 
/*  76 */   protected static String XERCES_SCHEMA = "http://apache.org/xml/features/validation/schema";
/*     */   protected static float version;
/*  89 */   protected static String versionNumber = null;
/*     */ 
/*     */   private static String getXercesVersion()
/*     */   {
/*  98 */     String versionNumber = "1.0";
/*     */     try
/*     */     {
/* 101 */       Class versionClass = Class.forName("org.apache.xerces.impl.Version");
/*     */ 
/* 104 */       Method method = versionClass.getMethod("getVersion", null);
/*     */ 
/* 106 */       String version = (String)method.invoke(null, null);
/* 107 */       versionNumber = version.substring("Xerces-J".length(), version.lastIndexOf("."));
/*     */     }
/*     */     catch (Exception ex)
/*     */     {
/*     */     }
/* 112 */     return versionNumber;
/*     */   }
/*     */ 
/*     */   public static SAXParser newSAXParser(Properties properties)
/*     */     throws ParserConfigurationException, SAXException, SAXNotSupportedException
/*     */   {
/* 127 */     SAXParserFactory factory = (SAXParserFactory)properties.get("SAXParserFactory");
/*     */ 
/* 130 */     if (versionNumber == null) {
/* 131 */       versionNumber = getXercesVersion();
/* 132 */       version = new Float(versionNumber).floatValue();
/*     */     }
/*     */ 
/* 136 */     if (version > 2.1D)
/*     */     {
/* 138 */       configureXerces(factory);
/* 139 */       return factory.newSAXParser();
/*     */     }
/* 141 */     SAXParser parser = factory.newSAXParser();
/* 142 */     configureOldXerces(parser, properties);
/* 143 */     return parser;
/*     */   }
/*     */ 
/*     */   private static void configureOldXerces(SAXParser parser, Properties properties)
/*     */     throws ParserConfigurationException, SAXNotSupportedException
/*     */   {
/* 159 */     String schemaLocation = (String)properties.get("schemaLocation");
/* 160 */     String schemaLanguage = (String)properties.get("schemaLanguage");
/*     */     try
/*     */     {
/* 163 */       if (schemaLocation != null) {
/* 164 */         parser.setProperty(JAXP_SCHEMA_LANGUAGE, schemaLanguage);
/* 165 */         parser.setProperty("http://java.sun.com/xml/jaxp/properties/schemaSource", schemaLocation);
/*     */       }
/*     */     } catch (SAXNotRecognizedException e) {
/* 168 */       log.info(parser.getClass().getName() + ": " + e.getMessage() + " not supported.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private static void configureXerces(SAXParserFactory factory)
/*     */     throws ParserConfigurationException, SAXNotRecognizedException, SAXNotSupportedException
/*     */   {
/* 185 */     factory.setFeature(XERCES_DYNAMIC, true);
/* 186 */     factory.setFeature(XERCES_SCHEMA, true);
/*     */   }
/*     */ }