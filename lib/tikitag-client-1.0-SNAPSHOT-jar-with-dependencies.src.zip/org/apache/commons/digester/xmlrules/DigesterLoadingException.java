/*    */ package org.apache.commons.digester.xmlrules;
/*    */ 
/*    */ public class DigesterLoadingException extends Exception
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public DigesterLoadingException(String msg)
/*    */   {
/* 36 */     super(msg);
/*    */ 
/* 30 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public DigesterLoadingException(Throwable cause)
/*    */   {
/* 43 */     this(cause.getMessage());
/* 44 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public DigesterLoadingException(String msg, Throwable cause)
/*    */   {
/* 52 */     this(msg);
/* 53 */     this.cause = cause;
/*    */   }
/*    */ }