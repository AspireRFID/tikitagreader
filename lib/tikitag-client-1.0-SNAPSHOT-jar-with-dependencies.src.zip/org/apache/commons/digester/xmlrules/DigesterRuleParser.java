/*     */ package org.apache.commons.digester.xmlrules;
/*     */ 
/*     */ import java.io.FileNotFoundException;
/*     */ import java.io.IOException;
/*     */ import java.net.URL;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.StringTokenizer;
/*     */ import org.apache.commons.beanutils.ConvertUtils;
/*     */ import org.apache.commons.collections.ArrayStack;
/*     */ import org.apache.commons.digester.AbstractObjectCreationFactory;
/*     */ import org.apache.commons.digester.BeanPropertySetterRule;
/*     */ import org.apache.commons.digester.CallMethodRule;
/*     */ import org.apache.commons.digester.CallParamRule;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.FactoryCreateRule;
/*     */ import org.apache.commons.digester.ObjectCreateRule;
/*     */ import org.apache.commons.digester.ObjectParamRule;
/*     */ import org.apache.commons.digester.Rule;
/*     */ import org.apache.commons.digester.RuleSetBase;
/*     */ import org.apache.commons.digester.Rules;
/*     */ import org.apache.commons.digester.SetNextRule;
/*     */ import org.apache.commons.digester.SetPropertiesRule;
/*     */ import org.apache.commons.digester.SetPropertyRule;
/*     */ import org.apache.commons.digester.SetRootRule;
/*     */ import org.apache.commons.digester.SetTopRule;
/*     */ import org.xml.sax.Attributes;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class DigesterRuleParser extends RuleSetBase
/*     */ {
/*     */   public static final String DIGESTER_PUBLIC_ID = "-//Jakarta Apache //DTD digester-rules XML V1.0//EN";
/*     */   private String digesterDtdUrl;
/*     */   protected Digester targetDigester;
/*     */   protected String basePath;
/*     */   protected PatternStack patternStack;
/*     */   private Set includedFiles;
/*     */ 
/*     */   public DigesterRuleParser()
/*     */   {
/*  79 */     this.basePath = "";
/*     */ 
/* 112 */     this.includedFiles = new HashSet();
/*     */ 
/* 119 */     this.patternStack = new PatternStack();
/*     */   }
/*     */ 
/*     */   public DigesterRuleParser(Digester targetDigester)
/*     */   {
/*  79 */     this.basePath = "";
/*     */ 
/* 112 */     this.includedFiles = new HashSet();
/*     */ 
/* 128 */     this.targetDigester = targetDigester;
/* 129 */     this.patternStack = new PatternStack();
/*     */   }
/*     */ 
/*     */   private DigesterRuleParser(Digester targetDigester, PatternStack stack, Set includedFiles)
/*     */   {
/*  79 */     this.basePath = "";
/*     */ 
/* 112 */     this.includedFiles = new HashSet();
/*     */ 
/* 144 */     this.targetDigester = targetDigester;
/* 145 */     this.patternStack = stack;
/* 146 */     this.includedFiles = includedFiles;
/*     */   }
/*     */ 
/*     */   public void setTarget(Digester d)
/*     */   {
/* 154 */     this.targetDigester = d;
/*     */   }
/*     */ 
/*     */   public void setBasePath(String path)
/*     */   {
/* 165 */     if (path == null) {
/* 166 */       this.basePath = "";
/*     */     }
/* 168 */     else if ((path.length() > 0) && (!(path.endsWith("/"))))
/* 169 */       this.basePath = path + "/";
/*     */     else
/* 171 */       this.basePath = path;
/*     */   }
/*     */ 
/*     */   public void setDigesterRulesDTD(String dtdURL)
/*     */   {
/* 180 */     this.digesterDtdUrl = dtdURL;
/*     */   }
/*     */ 
/*     */   protected String getDigesterRulesDTD()
/*     */   {
/* 191 */     return this.digesterDtdUrl;
/*     */   }
/*     */ 
/*     */   public void add(Rule rule)
/*     */   {
/* 202 */     this.targetDigester.addRule(this.basePath + this.patternStack.toString(), rule);
/*     */   }
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */   {
/* 217 */     String ruleClassName = Rule.class.getName();
/* 218 */     digester.register("-//Jakarta Apache //DTD digester-rules XML V1.0//EN", getDigesterRulesDTD());
/*     */ 
/* 220 */     digester.addRule("*/pattern", new PatternRule("value"));
/*     */ 
/* 222 */     digester.addRule("*/include", new IncludeRule());
/*     */ 
/* 224 */     digester.addFactoryCreate("*/bean-property-setter-rule", new BeanPropertySetterRuleFactory(null));
/* 225 */     digester.addRule("*/bean-property-setter-rule", new PatternRule("pattern"));
/* 226 */     digester.addSetNext("*/bean-property-setter-rule", "add", ruleClassName);
/*     */ 
/* 228 */     digester.addFactoryCreate("*/call-method-rule", new CallMethodRuleFactory());
/* 229 */     digester.addRule("*/call-method-rule", new PatternRule("pattern"));
/* 230 */     digester.addSetNext("*/call-method-rule", "add", ruleClassName);
/*     */ 
/* 232 */     digester.addFactoryCreate("*/object-param-rule", new ObjectParamRuleFactory());
/* 233 */     digester.addRule("*/object-param-rule", new PatternRule("pattern"));
/* 234 */     digester.addSetNext("*/object-param-rule", "add", ruleClassName);
/*     */ 
/* 236 */     digester.addFactoryCreate("*/call-param-rule", new CallParamRuleFactory());
/* 237 */     digester.addRule("*/call-param-rule", new PatternRule("pattern"));
/* 238 */     digester.addSetNext("*/call-param-rule", "add", ruleClassName);
/*     */ 
/* 240 */     digester.addFactoryCreate("*/factory-create-rule", new FactoryCreateRuleFactory());
/* 241 */     digester.addRule("*/factory-create-rule", new PatternRule("pattern"));
/* 242 */     digester.addSetNext("*/factory-create-rule", "add", ruleClassName);
/*     */ 
/* 244 */     digester.addFactoryCreate("*/object-create-rule", new ObjectCreateRuleFactory());
/* 245 */     digester.addRule("*/object-create-rule", new PatternRule("pattern"));
/* 246 */     digester.addSetNext("*/object-create-rule", "add", ruleClassName);
/*     */ 
/* 248 */     digester.addFactoryCreate("*/set-properties-rule", new SetPropertiesRuleFactory());
/* 249 */     digester.addRule("*/set-properties-rule", new PatternRule("pattern"));
/* 250 */     digester.addSetNext("*/set-properties-rule", "add", ruleClassName);
/*     */ 
/* 252 */     digester.addRule("*/set-properties-rule/alias", new SetPropertiesAliasRule());
/*     */ 
/* 254 */     digester.addFactoryCreate("*/set-property-rule", new SetPropertyRuleFactory());
/* 255 */     digester.addRule("*/set-property-rule", new PatternRule("pattern"));
/* 256 */     digester.addSetNext("*/set-property-rule", "add", ruleClassName);
/*     */ 
/* 258 */     digester.addFactoryCreate("*/set-top-rule", new SetTopRuleFactory());
/* 259 */     digester.addRule("*/set-top-rule", new PatternRule("pattern"));
/* 260 */     digester.addSetNext("*/set-top-rule", "add", ruleClassName);
/*     */ 
/* 262 */     digester.addFactoryCreate("*/set-next-rule", new SetNextRuleFactory());
/* 263 */     digester.addRule("*/set-next-rule", new PatternRule("pattern"));
/* 264 */     digester.addSetNext("*/set-next-rule", "add", ruleClassName);
/* 265 */     digester.addFactoryCreate("*/set-root-rule", new SetRootRuleFactory());
/* 266 */     digester.addRule("*/set-root-rule", new PatternRule("pattern"));
/* 267 */     digester.addSetNext("*/set-root-rule", "add", ruleClassName);
/*     */   }
/*     */ 
/*     */   DigesterRuleParser(Digester x0, PatternStack x1, Set x2, 1 x3)
/*     */   {
/*  63 */     this(x0, x1, x2);
/*     */   }
/*     */ 
/*     */   protected class SetPropertiesAliasRule extends Rule
/*     */   {
/*     */     public void begin(Attributes attributes)
/*     */     {
/* 741 */       String attrName = attributes.getValue("attr-name");
/* 742 */       String propName = attributes.getValue("prop-name");
/*     */ 
/* 744 */       SetPropertiesRule rule = (SetPropertiesRule)this.digester.peek();
/* 745 */       rule.addAlias(attrName, propName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SetRootRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 715 */       String methodName = attributes.getValue("methodname");
/* 716 */       String paramType = attributes.getValue("paramtype");
/* 717 */       return new SetRootRule(methodName, paramType);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SetNextRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 702 */       String methodName = attributes.getValue("methodname");
/* 703 */       String paramType = attributes.getValue("paramtype");
/* 704 */       return new SetNextRule(methodName, paramType);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SetTopRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 689 */       String methodName = attributes.getValue("methodname");
/* 690 */       String paramType = attributes.getValue("paramtype");
/* 691 */       return new SetTopRule(methodName, paramType);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SetPropertyRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 678 */       String name = attributes.getValue("name");
/* 679 */       String value = attributes.getValue("value");
/* 680 */       return new SetPropertyRule(name, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class SetPropertiesRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 669 */       return new SetPropertiesRule();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class ObjectCreateRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 656 */       String className = attributes.getValue("classname");
/* 657 */       String attrName = attributes.getValue("attrname");
/* 658 */       return new ObjectCreateRule(className, attrName);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class FactoryCreateRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 641 */       String className = attributes.getValue("classname");
/* 642 */       String attrName = attributes.getValue("attrname");
/* 643 */       boolean ignoreExceptions = "true".equalsIgnoreCase(attributes.getValue("ignore-exceptions"));
/*     */ 
/* 645 */       return new FactoryCreateRule(className, attrName, ignoreExceptions);
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class ObjectParamRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */       throws Exception
/*     */     {
/* 605 */       int paramIndex = Integer.parseInt(attributes.getValue("paramnumber"));
/* 606 */       String attributeName = attributes.getValue("attrname");
/* 607 */       String type = attributes.getValue("type");
/* 608 */       String value = attributes.getValue("value");
/*     */ 
/* 610 */       Rule objectParamRule = null;
/*     */ 
/* 613 */       if (type == null) {
/* 614 */         throw new RuntimeException("Attribute 'type' is required.");
/*     */       }
/*     */ 
/* 618 */       Object param = null;
/* 619 */       Class clazz = Class.forName(type);
/* 620 */       if (value == null)
/* 621 */         param = clazz.newInstance();
/*     */       else {
/* 623 */         param = ConvertUtils.convert(value, clazz);
/*     */       }
/*     */ 
/* 626 */       if (attributeName == null)
/* 627 */         objectParamRule = new ObjectParamRule(paramIndex, param);
/*     */       else {
/* 629 */         objectParamRule = new ObjectParamRule(paramIndex, attributeName, param);
/*     */       }
/* 631 */       return objectParamRule;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class CallParamRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 570 */       int paramIndex = Integer.parseInt(attributes.getValue("paramnumber"));
/* 571 */       String attributeName = attributes.getValue("attrname");
/* 572 */       String fromStack = attributes.getValue("from-stack");
/* 573 */       Rule callParamRule = null;
/* 574 */       if (attributeName == null) {
/* 575 */         if (fromStack == null)
/*     */         {
/* 577 */           callParamRule = new CallParamRule(paramIndex);
/*     */         }
/*     */         else
/*     */         {
/* 581 */           callParamRule = new CallParamRule(paramIndex, Boolean.valueOf(fromStack).booleanValue());
/*     */         }
/*     */ 
/*     */       }
/* 585 */       else if (fromStack == null)
/*     */       {
/* 587 */         callParamRule = new CallParamRule(paramIndex, attributeName);
/*     */       }
/*     */       else
/*     */       {
/* 592 */         throw new RuntimeException("Attributes from-stack and attrname cannot both be present.");
/*     */       }
/*     */ 
/* 595 */       return callParamRule;
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class CallMethodRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     public Object createObject(Attributes attributes)
/*     */     {
/* 534 */       Rule callMethodRule = null;
/* 535 */       String methodName = attributes.getValue("methodname");
/* 536 */       if (attributes.getValue("paramcount") == null)
/*     */       {
/* 538 */         callMethodRule = new CallMethodRule(methodName);
/*     */       }
/*     */       else {
/* 541 */         int paramCount = Integer.parseInt(attributes.getValue("paramcount"));
/*     */ 
/* 543 */         String paramTypesAttr = attributes.getValue("paramtypes");
/* 544 */         if ((paramTypesAttr == null) || (paramTypesAttr.length() == 0)) {
/* 545 */           callMethodRule = new CallMethodRule(methodName, paramCount);
/*     */         }
/*     */         else
/*     */         {
/* 549 */           ArrayList paramTypes = new ArrayList();
/* 550 */           StringTokenizer tokens = new StringTokenizer(paramTypesAttr, " \t\n\r,");
/* 551 */           while (tokens.hasMoreTokens()) {
/* 552 */             paramTypes.add(tokens.nextToken());
/*     */           }
/* 554 */           callMethodRule = new CallMethodRule(methodName, paramCount, (String[])paramTypes.toArray(new String[0]));
/*     */         }
/*     */ 
/*     */       }
/*     */ 
/* 559 */       return callMethodRule;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class BeanPropertySetterRuleFactory extends AbstractObjectCreationFactory
/*     */   {
/*     */     private final DigesterRuleParser this$0;
/*     */ 
/*     */     private BeanPropertySetterRuleFactory()
/*     */     {
/* 512 */       this.this$0 = this$0; }
/*     */ 
/*     */     public Object createObject(Attributes attributes) throws Exception { Rule beanPropertySetterRule = null;
/* 515 */       String propertyname = attributes.getValue("propertyname");
/*     */ 
/* 517 */       if (propertyname == null)
/*     */       {
/* 519 */         beanPropertySetterRule = new BeanPropertySetterRule();
/*     */       }
/*     */       else beanPropertySetterRule = new BeanPropertySetterRule(propertyname);
/*     */ 
/* 524 */       return beanPropertySetterRule;
/*     */     }
/*     */ 
/*     */     BeanPropertySetterRuleFactory(DigesterRuleParser.1 x1)
/*     */     {
/* 512 */       this(x0);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class RulesPrefixAdapter
/*     */     implements Rules
/*     */   {
/*     */     private Rules delegate;
/*     */     private String prefix;
/*     */ 
/*     */     public RulesPrefixAdapter(String patternPrefix, Rules rules)
/*     */     {
/* 428 */       this.prefix = patternPrefix;
/* 429 */       this.delegate = rules;
/*     */     }
/*     */ 
/*     */     public void add(String pattern, Rule rule)
/*     */     {
/* 437 */       StringBuffer buffer = new StringBuffer();
/* 438 */       buffer.append(this.prefix);
/* 439 */       if (!(pattern.startsWith("/"))) {
/* 440 */         buffer.append('/');
/*     */       }
/* 442 */       buffer.append(pattern);
/* 443 */       this.delegate.add(buffer.toString(), rule);
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/* 450 */       this.delegate.clear();
/*     */     }
/*     */ 
/*     */     public Digester getDigester()
/*     */     {
/* 457 */       return this.delegate.getDigester();
/*     */     }
/*     */ 
/*     */     public String getNamespaceURI()
/*     */     {
/* 464 */       return this.delegate.getNamespaceURI();
/*     */     }
/*     */ 
/*     */     /** @deprecated */
/*     */     public List match(String pattern)
/*     */     {
/* 471 */       return this.delegate.match(pattern);
/*     */     }
/*     */ 
/*     */     public List match(String namespaceURI, String pattern)
/*     */     {
/* 478 */       return this.delegate.match(namespaceURI, pattern);
/*     */     }
/*     */ 
/*     */     public List rules()
/*     */     {
/* 485 */       return this.delegate.rules();
/*     */     }
/*     */ 
/*     */     public void setDigester(Digester digester)
/*     */     {
/* 492 */       this.delegate.setDigester(digester);
/*     */     }
/*     */ 
/*     */     public void setNamespaceURI(String namespaceURI)
/*     */     {
/* 499 */       this.delegate.setNamespaceURI(namespaceURI);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class IncludeRule extends Rule
/*     */   {
/*     */     public void begin(Attributes attributes)
/*     */       throws Exception
/*     */     {
/* 336 */       String fileName = attributes.getValue("path");
/* 337 */       if ((fileName != null) && (fileName.length() > 0)) {
/* 338 */         includeXMLRules(fileName);
/*     */       }
/*     */ 
/* 343 */       String className = attributes.getValue("class");
/* 344 */       if ((className != null) && (className.length() > 0))
/* 345 */         includeProgrammaticRules(className);
/*     */     }
/*     */ 
/*     */     private void includeXMLRules(String fileName)
/*     */       throws IOException, SAXException, CircularIncludeException
/*     */     {
/* 356 */       ClassLoader cl = Thread.currentThread().getContextClassLoader();
/* 357 */       if (cl == null) {
/* 358 */         cl = DigesterRuleParser.this.getClass().getClassLoader();
/*     */       }
/* 360 */       URL fileURL = cl.getResource(fileName);
/* 361 */       if (fileURL == null) {
/* 362 */         throw new FileNotFoundException("File \"" + fileName + "\" not found.");
/*     */       }
/* 364 */       fileName = fileURL.toExternalForm();
/* 365 */       if (!(DigesterRuleParser.this.includedFiles.add(fileName)))
/*     */       {
/* 367 */         throw new CircularIncludeException(fileName);
/*     */       }
/*     */ 
/* 370 */       DigesterRuleParser includedSet = new DigesterRuleParser(DigesterRuleParser.this.targetDigester, DigesterRuleParser.this.patternStack, DigesterRuleParser.this.includedFiles, null);
/*     */ 
/* 372 */       includedSet.setDigesterRulesDTD(DigesterRuleParser.this.getDigesterRulesDTD());
/* 373 */       Digester digester = new Digester();
/* 374 */       digester.addRuleSet(includedSet);
/* 375 */       digester.push(DigesterRuleParser.this);
/* 376 */       digester.parse(fileName);
/* 377 */       DigesterRuleParser.this.includedFiles.remove(fileName);
/*     */     }
/*     */ 
/*     */     private void includeProgrammaticRules(String className)
/*     */       throws ClassNotFoundException, ClassCastException, InstantiationException, IllegalAccessException
/*     */     {
/* 392 */       Class cls = Class.forName(className);
/* 393 */       DigesterRulesSource rulesSource = (DigesterRulesSource)cls.newInstance();
/*     */ 
/* 396 */       Rules digesterRules = DigesterRuleParser.this.targetDigester.getRules();
/* 397 */       Rules prefixWrapper = new DigesterRuleParser.RulesPrefixAdapter(DigesterRuleParser.this, DigesterRuleParser.this.patternStack.toString(), digesterRules);
/*     */ 
/* 400 */       DigesterRuleParser.this.targetDigester.setRules(prefixWrapper);
/*     */       try {
/* 402 */         rulesSource.getRules(DigesterRuleParser.this.targetDigester);
/*     */       }
/*     */       finally {
/* 405 */         DigesterRuleParser.this.targetDigester.setRules(digesterRules);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class PatternRule extends Rule
/*     */   {
/*     */     private String attrName;
/* 282 */     private String pattern = null;
/*     */ 
/*     */     public PatternRule(String attrName)
/*     */     {
/* 289 */       this.attrName = attrName;
/*     */     }
/*     */ 
/*     */     public void begin(Attributes attributes)
/*     */     {
/* 297 */       this.pattern = attributes.getValue(this.attrName);
/* 298 */       if (this.pattern != null)
/* 299 */         DigesterRuleParser.this.patternStack.push(this.pattern);
/*     */     }
/*     */ 
/*     */     public void end()
/*     */     {
/* 308 */       if (this.pattern != null)
/* 309 */         DigesterRuleParser.this.patternStack.pop();
/*     */     }
/*     */   }
/*     */ 
/*     */   protected class PatternStack extends ArrayStack
/*     */   {
/*     */     public String toString()
/*     */     {
/*  87 */       StringBuffer str = new StringBuffer();
/*  88 */       for (int i = 0; i < size(); ++i) {
/*  89 */         String elem = get(i).toString();
/*  90 */         if (elem.length() > 0) {
/*  91 */           if (str.length() > 0) {
/*  92 */             str.append('/');
/*     */           }
/*  94 */           str.append(elem);
/*     */         }
/*     */       }
/*  97 */       return str.toString();
/*     */     }
/*     */   }
/*     */ }