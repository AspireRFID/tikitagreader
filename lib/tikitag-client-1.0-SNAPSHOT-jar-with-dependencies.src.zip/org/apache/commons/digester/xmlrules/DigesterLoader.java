/*     */ package org.apache.commons.digester.xmlrules;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.Reader;
/*     */ import java.net.URL;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.RuleSet;
/*     */ import org.xml.sax.InputSource;
/*     */ import org.xml.sax.SAXException;
/*     */ 
/*     */ public class DigesterLoader
/*     */ {
/*     */   public static Digester createDigester(InputSource rulesSource)
/*     */   {
/*  49 */     RuleSet ruleSet = new FromXmlRuleSet(rulesSource);
/*  50 */     Digester digester = new Digester();
/*  51 */     digester.addRuleSet(ruleSet);
/*  52 */     return digester;
/*     */   }
/*     */ 
/*     */   public static Digester createDigester(InputSource rulesSource, Digester rulesDigester)
/*     */   {
/*  65 */     RuleSet ruleSet = new FromXmlRuleSet(rulesSource, rulesDigester);
/*  66 */     Digester digester = new Digester();
/*  67 */     digester.addRuleSet(ruleSet);
/*  68 */     return digester;
/*     */   }
/*     */ 
/*     */   public static Digester createDigester(URL rulesXml)
/*     */   {
/*  77 */     RuleSet ruleSet = new FromXmlRuleSet(rulesXml);
/*  78 */     Digester digester = new Digester();
/*  79 */     digester.addRuleSet(ruleSet);
/*  80 */     return digester;
/*     */   }
/*     */ 
/*     */   public static Digester createDigester(URL rulesXml, Digester rulesDigester)
/*     */   {
/*  95 */     RuleSet ruleSet = new FromXmlRuleSet(rulesXml, rulesDigester);
/*  96 */     Digester digester = new Digester();
/*  97 */     digester.addRuleSet(ruleSet);
/*  98 */     return digester;
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, URL fileURL)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 113 */     return load(digesterRules, classLoader, fileURL.openStream());
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, InputStream input)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 128 */     Digester digester = createDigester(digesterRules);
/* 129 */     digester.setClassLoader(classLoader);
/*     */     try {
/* 131 */       return digester.parse(input);
/*     */     }
/*     */     catch (XmlLoadException ex)
/*     */     {
/* 136 */       throw new DigesterLoadingException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, Reader reader)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 158 */     Digester digester = createDigester(digesterRules);
/* 159 */     digester.setClassLoader(classLoader);
/*     */     try {
/* 161 */       return digester.parse(reader);
/*     */     }
/*     */     catch (XmlLoadException ex)
/*     */     {
/* 166 */       throw new DigesterLoadingException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, URL fileURL, Object rootObject)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 187 */     return load(digesterRules, classLoader, fileURL.openStream(), rootObject);
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, InputStream input, Object rootObject)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 205 */     Digester digester = createDigester(digesterRules);
/* 206 */     digester.setClassLoader(classLoader);
/* 207 */     digester.push(rootObject);
/*     */     try {
/* 209 */       return digester.parse(input);
/*     */     }
/*     */     catch (XmlLoadException ex)
/*     */     {
/* 214 */       throw new DigesterLoadingException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static Object load(URL digesterRules, ClassLoader classLoader, Reader input, Object rootObject)
/*     */     throws IOException, SAXException, DigesterLoadingException
/*     */   {
/* 239 */     Digester digester = createDigester(digesterRules);
/* 240 */     digester.setClassLoader(classLoader);
/* 241 */     digester.push(rootObject);
/*     */     try {
/* 243 */       return digester.parse(input);
/*     */     }
/*     */     catch (XmlLoadException ex)
/*     */     {
/* 248 */       throw new DigesterLoadingException(ex.getMessage(), ex);
/*     */     }
/*     */   }
/*     */ }