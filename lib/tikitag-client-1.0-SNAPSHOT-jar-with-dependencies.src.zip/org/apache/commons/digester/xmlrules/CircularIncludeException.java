/*    */ package org.apache.commons.digester.xmlrules;
/*    */ 
/*    */ public class CircularIncludeException extends XmlLoadException
/*    */ {
/*    */   public CircularIncludeException(String fileName)
/*    */   {
/* 36 */     super("Circular file inclusion detected for file: " + fileName);
/*    */   }
/*    */ }