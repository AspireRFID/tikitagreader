/*    */ package org.apache.commons.digester.xmlrules;
/*    */ 
/*    */ public class XmlLoadException extends RuntimeException
/*    */ {
/*    */   private Throwable cause;
/*    */ 
/*    */   public XmlLoadException(Throwable cause)
/*    */   {
/* 35 */     this(cause.getMessage());
/* 36 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public XmlLoadException(String msg) {
/* 40 */     super(msg);
/*    */ 
/* 29 */     this.cause = null;
/*    */   }
/*    */ 
/*    */   public XmlLoadException(String msg, Throwable cause)
/*    */   {
/* 44 */     this(msg);
/* 45 */     this.cause = cause;
/*    */   }
/*    */ 
/*    */   public Throwable getCause()
/*    */   {
/* 53 */     return this.cause;
/*    */   }
/*    */ }