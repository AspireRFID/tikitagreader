/*     */ package org.apache.commons.digester.xmlrules;
/*     */ 
/*     */ import java.net.URL;
/*     */ import org.apache.commons.digester.Digester;
/*     */ import org.apache.commons.digester.RuleSetBase;
/*     */ import org.xml.sax.InputSource;
/*     */ 
/*     */ public class FromXmlRuleSet extends RuleSetBase
/*     */ {
/*     */   public static final String DIGESTER_DTD_PATH = "org/apache/commons/digester/xmlrules/digester-rules.dtd";
/*     */   private XMLRulesLoader rulesLoader;
/*     */   private DigesterRuleParser parser;
/*     */   private Digester rulesDigester;
/*     */ 
/*     */   public FromXmlRuleSet(URL rulesXml)
/*     */   {
/*  59 */     this(rulesXml, new DigesterRuleParser(), new Digester());
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(URL rulesXml, Digester rulesDigester)
/*     */   {
/*  69 */     this(rulesXml, new DigesterRuleParser(), rulesDigester);
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(URL rulesXml, DigesterRuleParser parser)
/*     */   {
/*  77 */     this(rulesXml, parser, new Digester());
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(URL rulesXml, DigesterRuleParser parser, Digester rulesDigester)
/*     */   {
/*  86 */     init(new URLXMLRulesLoader(rulesXml), parser, rulesDigester);
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(InputSource inputSource)
/*     */   {
/*  95 */     this(inputSource, new DigesterRuleParser(), new Digester());
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(InputSource inputSource, Digester rulesDigester)
/*     */   {
/* 105 */     this(inputSource, new DigesterRuleParser(), rulesDigester);
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(InputSource inputSource, DigesterRuleParser parser)
/*     */   {
/* 113 */     this(inputSource, parser, new Digester());
/*     */   }
/*     */ 
/*     */   public FromXmlRuleSet(InputSource inputSource, DigesterRuleParser parser, Digester rulesDigester)
/*     */   {
/* 122 */     init(new InputSourceXMLRulesLoader(inputSource), parser, rulesDigester);
/*     */   }
/*     */ 
/*     */   private void init(XMLRulesLoader rulesLoader, DigesterRuleParser parser, Digester rulesDigester)
/*     */   {
/* 129 */     this.rulesLoader = rulesLoader;
/* 130 */     this.parser = parser;
/* 131 */     this.rulesDigester = rulesDigester;
/*     */   }
/*     */ 
/*     */   public void addRuleInstances(Digester digester)
/*     */     throws XmlLoadException
/*     */   {
/* 140 */     addRuleInstances(digester, null);
/*     */   }
/*     */ 
/*     */   public void addRuleInstances(Digester digester, String basePath)
/*     */     throws XmlLoadException
/*     */   {
/* 163 */     URL dtdURL = super.getClass().getClassLoader().getResource("org/apache/commons/digester/xmlrules/digester-rules.dtd");
/* 164 */     if (dtdURL == null) {
/* 165 */       throw new XmlLoadException("Cannot find resource \"org/apache/commons/digester/xmlrules/digester-rules.dtd\"");
/*     */     }
/*     */ 
/* 168 */     this.parser.setDigesterRulesDTD(dtdURL.toString());
/* 169 */     this.parser.setTarget(digester);
/* 170 */     this.parser.setBasePath(basePath);
/*     */ 
/* 172 */     this.rulesDigester.addRuleSet(this.parser);
/* 173 */     this.rulesDigester.push(this.parser);
/*     */ 
/* 175 */     this.rulesLoader.loadRules();
/*     */   }
/*     */ 
/*     */   private class InputSourceXMLRulesLoader extends FromXmlRuleSet.XMLRulesLoader
/*     */   {
/*     */     private InputSource inputSource;
/*     */ 
/*     */     public InputSourceXMLRulesLoader(InputSource inputSource)
/*     */     {
/* 206 */       super(null);
/* 207 */       this.inputSource = inputSource;
/*     */     }
/*     */ 
/*     */     public void loadRules() throws XmlLoadException {
/*     */       try {
/* 212 */         FromXmlRuleSet.this.rulesDigester.parse(this.inputSource);
/*     */       } catch (Exception ex) {
/* 214 */         throw new XmlLoadException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class URLXMLRulesLoader extends FromXmlRuleSet.XMLRulesLoader
/*     */   {
/*     */     private URL url;
/*     */ 
/*     */     public URLXMLRulesLoader(URL url)
/*     */     {
/* 190 */       super(null);
/* 191 */       this.url = url;
/*     */     }
/*     */ 
/*     */     public void loadRules() throws XmlLoadException {
/*     */       try {
/* 196 */         FromXmlRuleSet.this.rulesDigester.parse(this.url.openStream());
/*     */       } catch (Exception ex) {
/* 198 */         throw new XmlLoadException(ex);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static abstract class XMLRulesLoader
/*     */   {
/*     */     private XMLRulesLoader()
/*     */     {
/*     */     }
/*     */ 
/*     */     public abstract void loadRules()
/*     */       throws XmlLoadException;
/*     */ 
/*     */     XMLRulesLoader(FromXmlRuleSet.1 x0)
/*     */     {
/*     */     }
/*     */   }
/*     */ }