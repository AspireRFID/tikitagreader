package org.apache.commons.digester.xmlrules;

import org.apache.commons.digester.Digester;

public abstract interface DigesterRulesSource
{
  public abstract void getRules(Digester paramDigester);
}