/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.List;
/*     */ 
/*     */ public abstract class AbstractRulesImpl
/*     */   implements Rules
/*     */ {
/*     */   private Digester digester;
/*     */   private String namespaceURI;
/*     */ 
/*     */   public Digester getDigester()
/*     */   {
/*  55 */     return this.digester;
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/*  64 */     this.digester = digester;
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/*  72 */     return this.namespaceURI;
/*     */   }
/*     */ 
/*     */   public void setNamespaceURI(String namespaceURI)
/*     */   {
/*  84 */     this.namespaceURI = namespaceURI;
/*     */   }
/*     */ 
/*     */   public void add(String pattern, Rule rule)
/*     */   {
/*  99 */     if (this.digester != null) {
/* 100 */       rule.setDigester(this.digester);
/*     */     }
/*     */ 
/* 103 */     if (this.namespaceURI != null) {
/* 104 */       rule.setNamespaceURI(this.namespaceURI);
/*     */     }
/*     */ 
/* 107 */     registerRule(pattern, rule);
/*     */   }
/*     */ 
/*     */   protected abstract void registerRule(String paramString, Rule paramRule);
/*     */ 
/*     */   public abstract void clear();
/*     */ 
/*     */   /** @deprecated */
/*     */   public List match(String pattern)
/*     */   {
/* 139 */     return match(this.namespaceURI, pattern);
/*     */   }
/*     */ 
/*     */   public abstract List match(String paramString1, String paramString2);
/*     */ 
/*     */   public abstract List rules();
/*     */ }