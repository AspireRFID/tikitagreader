/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ public class RulesBase
/*     */   implements Rules
/*     */ {
/*     */   protected HashMap cache;
/*     */   protected Digester digester;
/*     */   protected String namespaceURI;
/*     */   protected ArrayList rules;
/*     */ 
/*     */   public RulesBase()
/*     */   {
/*  56 */     this.cache = new HashMap();
/*     */ 
/*  62 */     this.digester = null;
/*     */ 
/*  70 */     this.namespaceURI = null;
/*     */ 
/*  77 */     this.rules = new ArrayList();
/*     */   }
/*     */ 
/*     */   public Digester getDigester()
/*     */   {
/*  89 */     return this.digester;
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/* 101 */     this.digester = digester;
/* 102 */     Iterator items = this.rules.iterator();
/* 103 */     while (items.hasNext()) {
/* 104 */       Rule item = (Rule)items.next();
/* 105 */       item.setDigester(digester);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/* 117 */     return this.namespaceURI;
/*     */   }
/*     */ 
/*     */   public void setNamespaceURI(String namespaceURI)
/*     */   {
/* 132 */     this.namespaceURI = namespaceURI;
/*     */   }
/*     */ 
/*     */   public void add(String pattern, Rule rule)
/*     */   {
/* 148 */     int patternLength = pattern.length();
/* 149 */     if ((patternLength > 1) && (pattern.endsWith("/"))) {
/* 150 */       pattern = pattern.substring(0, patternLength - 1);
/*     */     }
/*     */ 
/* 154 */     List list = (List)this.cache.get(pattern);
/* 155 */     if (list == null) {
/* 156 */       list = new ArrayList();
/* 157 */       this.cache.put(pattern, list);
/*     */     }
/* 159 */     list.add(rule);
/* 160 */     this.rules.add(rule);
/* 161 */     if (this.digester != null) {
/* 162 */       rule.setDigester(this.digester);
/*     */     }
/* 164 */     if (this.namespaceURI != null)
/* 165 */       rule.setNamespaceURI(this.namespaceURI);
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 176 */     this.cache.clear();
/* 177 */     this.rules.clear();
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public List match(String pattern)
/*     */   {
/* 195 */     return match(null, pattern);
/*     */   }
/*     */ 
/*     */   public List match(String namespaceURI, String pattern)
/*     */   {
/* 214 */     List rulesList = lookup(namespaceURI, pattern);
/* 215 */     if ((rulesList == null) || (rulesList.size() < 1))
/*     */     {
/* 217 */       String longKey = "";
/* 218 */       Iterator keys = this.cache.keySet().iterator();
/* 219 */       while (keys.hasNext()) {
/* 220 */         String key = (String)keys.next();
/* 221 */         if ((!(key.startsWith("*/"))) || 
/* 222 */           ((!(pattern.equals(key.substring(2)))) && (!(pattern.endsWith(key.substring(1))))) || 
/* 224 */           (key.length() <= longKey.length()))
/*     */           continue;
/* 226 */         rulesList = lookup(namespaceURI, key);
/* 227 */         longKey = key;
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 233 */     if (rulesList == null) {
/* 234 */       rulesList = new ArrayList();
/*     */     }
/* 236 */     return rulesList;
/*     */   }
/*     */ 
/*     */   public List rules()
/*     */   {
/* 250 */     return this.rules;
/*     */   }
/*     */ 
/*     */   protected List lookup(String namespaceURI, String pattern)
/*     */   {
/* 270 */     List list = (List)this.cache.get(pattern);
/* 271 */     if (list == null) {
/* 272 */       return null;
/*     */     }
/* 274 */     if ((namespaceURI == null) || (namespaceURI.length() == 0)) {
/* 275 */       return list;
/*     */     }
/*     */ 
/* 279 */     ArrayList results = new ArrayList();
/* 280 */     Iterator items = list.iterator();
/* 281 */     while (items.hasNext()) {
/* 282 */       Rule item = (Rule)items.next();
/* 283 */       if ((!(namespaceURI.equals(item.getNamespaceURI()))) && (item.getNamespaceURI() != null))
/*     */         continue;
/* 285 */       results.add(item);
/*     */     }
/*     */ 
/* 288 */     return results;
/*     */   }
/*     */ }