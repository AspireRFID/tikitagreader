/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ 
/*     */ public class WithDefaultsRulesWrapper
/*     */   implements Rules
/*     */ {
/*     */   private Rules wrappedRules;
/*  56 */   private List defaultRules = new ArrayList();
/*     */ 
/*  58 */   private List allRules = new ArrayList();
/*     */ 
/*     */   public WithDefaultsRulesWrapper(Rules wrappedRules)
/*     */   {
/*  69 */     if (wrappedRules == null) {
/*  70 */       throw new IllegalArgumentException("Wrapped rules must not be null");
/*     */     }
/*  72 */     this.wrappedRules = wrappedRules;
/*     */   }
/*     */ 
/*     */   public Digester getDigester()
/*     */   {
/*  79 */     return this.wrappedRules.getDigester();
/*     */   }
/*     */ 
/*     */   public void setDigester(Digester digester)
/*     */   {
/*  84 */     this.wrappedRules.setDigester(digester);
/*  85 */     Iterator it = this.defaultRules.iterator();
/*  86 */     while (it.hasNext()) {
/*  87 */       Rule rule = (Rule)it.next();
/*  88 */       rule.setDigester(digester);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String getNamespaceURI()
/*     */   {
/*  94 */     return this.wrappedRules.getNamespaceURI();
/*     */   }
/*     */ 
/*     */   public void setNamespaceURI(String namespaceURI)
/*     */   {
/*  99 */     this.wrappedRules.setNamespaceURI(namespaceURI);
/*     */   }
/*     */ 
/*     */   public List getDefaults()
/*     */   {
/* 104 */     return this.defaultRules;
/*     */   }
/*     */ 
/*     */   public List match(String pattern)
/*     */   {
/* 110 */     return match("", pattern);
/*     */   }
/*     */ 
/*     */   public List match(String namespaceURI, String pattern)
/*     */   {
/* 119 */     List matches = this.wrappedRules.match(namespaceURI, pattern);
/* 120 */     if ((matches == null) || (matches.isEmpty()))
/*     */     {
/* 122 */       return new ArrayList(this.defaultRules);
/*     */     }
/*     */ 
/* 125 */     return matches;
/*     */   }
/*     */ 
/*     */   public void addDefault(Rule rule)
/*     */   {
/* 131 */     if (this.wrappedRules.getDigester() != null) {
/* 132 */       rule.setDigester(this.wrappedRules.getDigester());
/*     */     }
/*     */ 
/* 135 */     if (this.wrappedRules.getNamespaceURI() != null) {
/* 136 */       rule.setNamespaceURI(this.wrappedRules.getNamespaceURI());
/*     */     }
/*     */ 
/* 139 */     this.defaultRules.add(rule);
/* 140 */     this.allRules.add(rule);
/*     */   }
/*     */ 
/*     */   public List rules()
/*     */   {
/* 145 */     return this.allRules;
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/* 150 */     this.wrappedRules.clear();
/* 151 */     this.allRules.clear();
/* 152 */     this.defaultRules.clear();
/*     */   }
/*     */ 
/*     */   public void add(String pattern, Rule rule)
/*     */   {
/* 160 */     this.wrappedRules.add(pattern, rule);
/* 161 */     this.allRules.add(rule);
/*     */   }
/*     */ }