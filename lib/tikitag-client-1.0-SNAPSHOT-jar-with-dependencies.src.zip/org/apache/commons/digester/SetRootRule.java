/*     */ package org.apache.commons.digester;
/*     */ 
/*     */ import org.apache.commons.beanutils.MethodUtils;
/*     */ import org.apache.commons.logging.Log;
/*     */ 
/*     */ public class SetRootRule extends Rule
/*     */ {
/*     */   protected String methodName;
/*     */   protected String paramType;
/*     */   protected boolean useExactMatch;
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetRootRule(Digester digester, String methodName)
/*     */   {
/*  55 */     this(methodName);
/*     */   }
/*     */ 
/*     */   /** @deprecated */
/*     */   public SetRootRule(Digester digester, String methodName, String paramType)
/*     */   {
/*  76 */     this(methodName, paramType);
/*     */   }
/*     */ 
/*     */   public SetRootRule(String methodName)
/*     */   {
/*  89 */     this(methodName, null);
/*     */   }
/*     */ 
/*     */   public SetRootRule(String methodName, String paramType)
/*     */   {
/* 117 */     this.methodName = null;
/*     */ 
/* 123 */     this.paramType = null;
/*     */ 
/* 128 */     this.useExactMatch = false;
/*     */ 
/* 106 */     this.methodName = methodName;
/* 107 */     this.paramType = paramType;
/*     */   }
/*     */ 
/*     */   public boolean isExactMatch()
/*     */   {
/* 156 */     return this.useExactMatch;
/*     */   }
/*     */ 
/*     */   public void setExactMatch(boolean useExactMatch)
/*     */   {
/* 170 */     this.useExactMatch = useExactMatch;
/*     */   }
/*     */ 
/*     */   public void end()
/*     */     throws Exception
/*     */   {
/* 179 */     Object child = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.peek(0);
/* 180 */     Object parent = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.root;
/* 181 */     if (this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.isDebugEnabled()) {
/* 182 */       if (parent == null) {
/* 183 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetRootRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call [NULL ROOT]." + this.methodName + "(" + child + ")");
/*     */       }
/*     */       else
/*     */       {
/* 187 */         this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.log.debug("[SetRootRule]{" + this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.match + "} Call " + parent.getClass().getName() + "." + this.methodName + "(" + child + ")");
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 194 */     Class[] paramTypes = new Class[1];
/* 195 */     if (this.paramType != null) {
/* 196 */       paramTypes[0] = this.jdField_digester_of_type_OrgApacheCommonsDigesterDigester.getClassLoader().loadClass(this.paramType);
/*     */     }
/*     */     else {
/* 199 */       paramTypes[0] = child.getClass();
/*     */     }
/*     */ 
/* 202 */     if (this.useExactMatch)
/*     */     {
/* 204 */       MethodUtils.invokeExactMethod(parent, this.methodName, new Object[] { child }, paramTypes);
/*     */     }
/*     */     else
/*     */     {
/* 209 */       MethodUtils.invokeMethod(parent, this.methodName, new Object[] { child }, paramTypes);
/*     */     }
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 221 */     StringBuffer sb = new StringBuffer("SetRootRule[");
/* 222 */     sb.append("methodName=");
/* 223 */     sb.append(this.methodName);
/* 224 */     sb.append(", paramType=");
/* 225 */     sb.append(this.paramType);
/* 226 */     sb.append("]");
/* 227 */     return sb.toString();
/*     */   }
/*     */ }