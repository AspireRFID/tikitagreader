package com.tikitag.client.tagservice;

public abstract interface ReaderMonitor
{
  public abstract void onReaderEvent(ReaderEvent paramReaderEvent);
}