/*    */ package com.tikitag.client.tagservice;
/*    */ 
/*    */ import com.tikitag.ons.model.util.ReaderId;
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.util.Arrays;
/*    */ import javax.smartcardio.CardTerminal;
/*    */ 
/*    */ public class ExtendedReaderId
/*    */ {
/*    */   private final ReaderId readerId;
/*    */   private transient CardTerminal systemId;
/*    */ 
/*    */   public ExtendedReaderId(CardTerminal systemId, byte[] readerId, String serialNr)
/*    */   {
/* 18 */     this.readerId = new ReaderId(readerId, serialNr);
/* 19 */     this.systemId = systemId;
/*    */   }
/*    */ 
/*    */   public ReaderId getReaderId() {
/* 23 */     return this.readerId;
/*    */   }
/*    */ 
/*    */   public CardTerminal getSystemId() {
/* 27 */     return this.systemId;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 31 */     return "Reader[" + this.systemId + ":" + HexFormatter.toHexString(this.readerId.getUid()) + "]";
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 36 */     int prime = 31;
/* 37 */     int result = 1;
/* 38 */     result = 31 * result + Arrays.hashCode(this.readerId.getUid());
/* 39 */     result = 31 * result + ((this.systemId == null) ? 0 : this.systemId.hashCode());
/* 40 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 45 */     if (this == obj)
/* 46 */       return true;
/* 47 */     if (obj == null)
/* 48 */       return false;
/* 49 */     if (super.getClass() != obj.getClass())
/* 50 */       return false;
/* 51 */     ExtendedReaderId other = (ExtendedReaderId)obj;
/* 52 */     if (!(Arrays.equals(this.readerId.getUid(), other.readerId.getUid())))
/* 53 */       return false;
/* 54 */     if (this.systemId == null) {
/* 55 */       if (other.systemId == null) break label85;
/* 56 */       return false;
/*    */     }
/* 58 */     label85: return (!(this.systemId.equals(other.systemId)));
/*    */   }
/*    */ }