package com.tikitag.client.tagservice;

public abstract interface TagServiceConfigurationListener
{
  public abstract void onClientIdChange(TagServiceConfiguration.ClientIdChangeEvent paramClientIdChangeEvent);
}