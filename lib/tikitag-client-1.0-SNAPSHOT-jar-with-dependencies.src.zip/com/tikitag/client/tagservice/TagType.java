/*    */ package com.tikitag.client.tagservice;
/*    */ 
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ public enum TagType
/*    */ {
/*  6 */   INNOVISION_TOPAZ_JEWEL, MIFARE, FELICA_212, FELICA_424, ISO14443_4A, ISO14443_4B;
/*    */ 
/*    */   private static final Map<Byte, TagType> TAG_TYPES;
/*    */   private final byte typeId;
/*    */ 
/*    */   private static Map<Byte, TagType> initializeTagTypes()
/*    */   {
/* 17 */     Map tagTypes = new HashMap();
/* 18 */     for (TagType tagType : values()) {
/* 19 */       tagTypes.put(Byte.valueOf(tagType.getTypeId()), tagType);
/*    */     }
/* 21 */     return tagTypes;
/*    */   }
/*    */ 
/*    */   public static TagType fromTypeId(byte typeId) {
/* 25 */     return ((TagType)TAG_TYPES.get(Byte.valueOf(typeId)));
/*    */   }
/*    */ 
/*    */   public byte getTypeId()
/*    */   {
/* 35 */     return this.typeId;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 14 */     TAG_TYPES = initializeTagTypes();
/*    */   }
/*    */ }