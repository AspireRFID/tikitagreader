package com.tikitag.client.tagservice;

import com.tikitag.ons.model.util.ReaderId;

public abstract interface TagService
{
  public abstract void start();

  public abstract void shutdown();

  public abstract void addTagMonitor(TagMonitor paramTagMonitor);

  public abstract void removeTagMonitor(TagMonitor paramTagMonitor);

  public abstract void addReaderMonitor(ReaderMonitor paramReaderMonitor);

  public abstract void removeReaderMonitor(ReaderMonitor paramReaderMonitor);

  public abstract void forceRedetect(ReaderId paramReaderId);

  public abstract boolean writeLock(ReaderId paramReaderId, String paramString);

  public abstract boolean writePage(ReaderId paramReaderId, int paramInt, String paramString);

  public abstract boolean writeUserData(ReaderId paramReaderId, String paramString);
}