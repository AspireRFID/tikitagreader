/*    */ package com.tikitag.client.tagservice.impl;
/*    */ 
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public enum MifareType
/*    */ {
/* 10 */   MIFARE_ULTRALIGHT, MIFARE_1K, MIFARE_MINI, MIFARE_4K, MIFARE_DESFIRE, JCOP30, MIFARE_4K_ALT, GEMPLUS_MPCOS, UNKNOWN;
/*    */ 
/*    */   private static final Map<Byte, MifareType> TAG_TYPES;
/*    */   private static final Logger log;
/*    */   private final byte typeId;
/*    */ 
/*    */   private static Map<Byte, MifareType> initializeTagTypes()
/*    */   {
/* 25 */     Map tagTypes = new HashMap();
/* 26 */     for (MifareType tagType : values()) {
/* 27 */       tagTypes.put(Byte.valueOf(tagType.getTypeId()), tagType);
/*    */     }
/* 29 */     return tagTypes;
/*    */   }
/*    */ 
/*    */   public static MifareType fromTypeId(byte typeId) {
/* 33 */     MifareType mifareType = (MifareType)TAG_TYPES.get(Byte.valueOf(typeId));
/* 34 */     if (mifareType == null) {
/* 35 */       log.warn("Could not find a known MifareType for type identifier " + HexFormatter.toHexString(new byte[] { typeId }));
/* 36 */       return UNKNOWN;
/*    */     }
/* 38 */     return mifareType;
/*    */   }
/*    */ 
/*    */   public byte getTypeId()
/*    */   {
/* 48 */     return this.typeId;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 21 */     TAG_TYPES = initializeTagTypes();
/* 22 */     log = Logger.getLogger(MifareType.class);
/*    */   }
/*    */ }