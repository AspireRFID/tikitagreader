/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class CandidateActionState extends TagState
/*    */ {
/*    */   private TagInfo actionTag;
/*    */ 
/*    */   CandidateActionState(TagStateMachine engine, TagInfo actionTag)
/*    */   {
/*  9 */     super(engine);
/* 10 */     this.actionTag = actionTag;
/*    */   }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag)
/*    */   {
/* 15 */     if (tag.getTagId().equals(this.actionTag.getTagId())) {
/* 16 */       this.engine.cancelPutThresholdTimer();
/* 17 */       this.engine.fireTouch(this.actionTag, null);
/* 18 */       return this.engine.noTags();
/*    */     }
/* 20 */     throw new IllegalStateException("Only expecting remove of " + this.actionTag + ", while receiving remove of " + tag);
/*    */   }
/*    */ 
/*    */   TagState onPutThresholdReached()
/*    */   {
/* 25 */     this.engine.firePut(this.actionTag, null);
/* 26 */     return this.engine.candidateContext(this.actionTag);
/*    */   }
/*    */ 
/*    */   TagState onTagAdded(TagInfo tag)
/*    */   {
/* 31 */     this.engine.cancelPutThresholdTimer();
/* 32 */     this.engine.firePut(tag, null);
/* 33 */     this.engine.schedulePutThresholdTimer();
/*    */ 
/* 35 */     return this.engine.candidateActionWithContext(tag, this.actionTag);
/*    */   }
/*    */ }