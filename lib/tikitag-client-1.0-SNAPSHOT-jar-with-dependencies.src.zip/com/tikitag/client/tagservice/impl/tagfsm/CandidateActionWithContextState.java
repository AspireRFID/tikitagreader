/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class CandidateActionWithContextState extends TagState
/*    */ {
/*    */   private TagInfo actionTag;
/*    */   private TagInfo contextTag;
/*    */ 
/*    */   CandidateActionWithContextState(TagStateMachine engine, TagInfo actionTag, TagInfo contextTag)
/*    */   {
/* 10 */     super(engine);
/* 11 */     this.actionTag = actionTag;
/* 12 */     this.contextTag = contextTag;
/*    */   }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag)
/*    */   {
/* 17 */     if (tag.getTagId().equals(this.actionTag.getTagId())) {
/* 18 */       this.engine.cancelPutThresholdTimer();
/* 19 */       this.engine.fireTouch(this.actionTag, this.contextTag);
/* 20 */       return this.engine.candidateContext(this.contextTag); }
/* 21 */     if (tag.getTagId().equals(this.contextTag.getTagId())) {
/* 22 */       this.engine.fireRemove(this.contextTag, this.actionTag);
/* 23 */       return this.engine.candidateAction(this.actionTag);
/*    */     }
/* 25 */     throw new IllegalStateException("Was expecting either remove of " + this.actionTag + " or " + this.contextTag + ", but received " + tag);
/*    */   }
/*    */ 
/*    */   TagState onPutThresholdReached()
/*    */   {
/* 30 */     this.engine.firePut(this.actionTag, this.contextTag);
/* 31 */     return this.engine.actionWithContext(this.actionTag, this.contextTag);
/*    */   }
/*    */ 
/*    */   TagState onTagsRemoved(TagInfo tag1, TagInfo tag2)
/*    */   {
/* 36 */     this.engine.cancelPutThresholdTimer();
/* 37 */     this.engine.fireRemove(this.contextTag, null);
/* 38 */     this.engine.fireRemove(this.actionTag, null);
/* 39 */     return this.engine.noTags();
/*    */   }
/*    */ }