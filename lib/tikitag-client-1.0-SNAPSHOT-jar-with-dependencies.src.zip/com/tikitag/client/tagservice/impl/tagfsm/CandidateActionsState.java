/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class CandidateActionsState extends TagState
/*    */ {
/*    */   private TagInfo tag1;
/*    */   private TagInfo tag2;
/*    */ 
/*    */   CandidateActionsState(TagStateMachine engine, TagInfo tag1, TagInfo tag2)
/*    */   {
/* 10 */     super(engine);
/* 11 */     this.tag1 = tag1;
/* 12 */     this.tag2 = tag2;
/*    */   }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag)
/*    */   {
/* 17 */     if (tag.getTagId().equals(this.tag1.getTagId())) {
/* 18 */       this.engine.fireTouch(this.tag1, this.tag2);
/* 19 */       return this.engine.candidateAction(this.tag2); }
/* 20 */     if (tag.getTagId().equals(this.tag2.getTagId())) {
/* 21 */       this.engine.fireTouch(this.tag2, this.tag1);
/* 22 */       return this.engine.candidateAction(this.tag1);
/*    */     }
/* 24 */     throw new IllegalStateException("Was expecting either remove of " + this.tag1 + " or " + this.tag2 + ", but received " + tag);
/*    */   }
/*    */ 
/*    */   TagState onTagsRemoved(TagInfo tag1, TagInfo tag2)
/*    */   {
/* 29 */     this.engine.cancelPutThresholdTimer();
/* 30 */     this.engine.fireTouch(this.tag1, null);
/* 31 */     this.engine.fireTouch(this.tag2, null);
/* 32 */     return this.engine.noTags();
/*    */   }
/*    */ 
/*    */   TagState onPutThresholdReached()
/*    */   {
/* 37 */     this.engine.firePut(this.tag1, null);
/* 38 */     this.engine.firePut(this.tag2, null);
/* 39 */     return this.engine.actions(this.tag1, this.tag2);
/*    */   }
/*    */ }