/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class NoTagsState extends TagState
/*    */ {
/*    */   NoTagsState(TagStateMachine engine)
/*    */   {
/*  8 */     super(engine);
/*    */   }
/*    */ 
/*    */   TagState onTagAdded(TagInfo tag)
/*    */   {
/* 13 */     this.engine.schedulePutThresholdTimer();
/* 14 */     return this.engine.candidateAction(tag);
/*    */   }
/*    */ 
/*    */   TagState onTagsAdded(TagInfo tag1, TagInfo tag2)
/*    */   {
/* 19 */     this.engine.schedulePutThresholdTimer();
/* 20 */     return this.engine.candidateActions(tag1, tag2);
/*    */   }
/*    */ }