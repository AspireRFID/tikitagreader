/*     */ package com.tikitag.client.tagservice.impl.tagfsm;
/*     */ 
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.client.tagservice.impl.MonitorSupport.TagEvents;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TagStateMachine
/*     */ {
/*     */   private final Logger log;
/*  15 */   private static final TagServiceConfiguration config = new TagServiceConfiguration();
/*     */   private TagState activeState;
/*     */   private boolean startTimer;
/*     */   private Timer thresholdTimer;
/*     */   private MonitorSupport.TagEvents tagEvents;
/*     */ 
/*     */   public TagStateMachine(MonitorSupport.TagEvents tagEvents)
/*     */   {
/*  23 */     this.log = Logger.getLogger("TagFSM.TagFSM-" + super.hashCode());
/*  24 */     this.activeState = noTags();
/*  25 */     this.tagEvents = tagEvents;
/*     */ 
/*  27 */     this.startTimer = false;
/*  28 */     this.thresholdTimer = null;
/*     */   }
/*     */ 
/*     */   private void setState(TagState newState) {
/*  32 */     this.log.debug(this.activeState + " -> " + newState);
/*  33 */     this.activeState = newState;
/*  34 */     if (this.startTimer)
/*  35 */       startPutThresholdTimer();
/*     */   }
/*     */ 
/*     */   public synchronized void tagsAdded(TagInfo tag1, TagInfo tag2)
/*     */   {
/*  40 */     this.log.debug("tagsAdded(" + tag1 + ", " + tag2);
/*  41 */     setState(this.activeState.onTagsAdded(tag1, tag2));
/*     */   }
/*     */ 
/*     */   public synchronized void tagAdded(TagInfo tag) {
/*  45 */     this.log.debug("tagAdded(" + tag + ")");
/*  46 */     setState(this.activeState.onTagAdded(tag));
/*     */   }
/*     */ 
/*     */   public synchronized void tagsRemoved(TagInfo tag1, TagInfo tag2) {
/*  50 */     this.log.debug("tagsRemoved(" + tag1 + ", " + tag2 + ")");
/*  51 */     setState(this.activeState.onTagsRemoved(tag1, tag2));
/*     */   }
/*     */ 
/*     */   public synchronized void tagRemoved(TagInfo tag) {
/*  55 */     this.log.debug("tagRemoved(" + tag + ")");
/*  56 */     setState(this.activeState.onTagRemoved(tag));
/*     */   }
/*     */ 
/*     */   synchronized void schedulePutThresholdTimer()
/*     */   {
/*  65 */     this.startTimer = true;
/*     */   }
/*     */ 
/*     */   private synchronized void startPutThresholdTimer()
/*     */   {
/*  74 */     this.startTimer = false;
/*  75 */     if (this.thresholdTimer != null) {
/*  76 */       throw new IllegalStateException("Timer is already running !");
/*     */     }
/*  78 */     this.thresholdTimer = new Timer("Put Threshold Timer", true);
/*  79 */     this.thresholdTimer.schedule(new TimerTask()
/*     */     {
/*     */       public void run()
/*     */       {
/*  83 */         TagStateMachine.this.cancelPutThresholdTimer();
/*  84 */         synchronized (TagStateMachine.this) {
/*  85 */           TagStateMachine.this.log.debug("putThresholdReached");
/*  86 */           TagStateMachine.this.setState(TagStateMachine.this.activeState.onPutThresholdReached());
/*     */         }
/*     */       }
/*     */     }
/*     */     , config.getPutThresholdTime());
/*     */   }
/*     */ 
/*     */   synchronized void cancelPutThresholdTimer()
/*     */   {
/*  93 */     if (this.thresholdTimer == null) {
/*  94 */       throw new IllegalStateException("Timer is no longer running !");
/*     */     }
/*  96 */     this.thresholdTimer.cancel();
/*  97 */     this.thresholdTimer = null;
/*  98 */     this.startTimer = false;
/*     */   }
/*     */ 
/*     */   TagState noTags() {
/* 102 */     return new NoTagsState(this);
/*     */   }
/*     */ 
/*     */   TagState candidateAction(TagInfo tag) {
/* 106 */     return new CandidateActionState(this, tag);
/*     */   }
/*     */ 
/*     */   TagState candidateContext(TagInfo tag) {
/* 110 */     return new CandidateContextState(this, tag);
/*     */   }
/*     */ 
/*     */   TagState candidateActionWithContext(TagInfo actionTag, TagInfo contextTag) {
/* 114 */     return new CandidateActionWithContextState(this, actionTag, contextTag);
/*     */   }
/*     */ 
/*     */   TagState actionWithContext(TagInfo actionTag, TagInfo contextTag) {
/* 118 */     return new ActionWithContextState(this, actionTag, contextTag);
/*     */   }
/*     */ 
/*     */   TagState candidateActions(TagInfo tag1, TagInfo tag2) {
/* 122 */     return new CandidateActionsState(this, tag1, tag2);
/*     */   }
/*     */ 
/*     */   TagState actions(TagInfo tag1, TagInfo tag2) {
/* 126 */     return new ActionsState(this, tag1, tag2);
/*     */   }
/*     */ 
/*     */   void fireTouch(TagInfo actionTag, TagInfo contextTag) {
/* 130 */     this.log.debug("fireTouch(" + actionTag + ", " + contextTag + ")");
/* 131 */     this.tagEvents.fireTouch(actionTag, contextTag);
/*     */   }
/*     */ 
/*     */   void firePut(TagInfo actionTag, TagInfo contextTag) {
/* 135 */     this.log.debug("firePut(" + actionTag + ", " + contextTag + ")");
/* 136 */     this.tagEvents.firePut(actionTag, contextTag);
/*     */   }
/*     */ 
/*     */   void fireRemove(TagInfo actionTag, TagInfo contextTag) {
/* 140 */     this.log.debug("fireRemove(" + actionTag + ", " + contextTag + ")");
/* 141 */     this.tagEvents.fireRemove(actionTag, contextTag);
/*     */   }
/*     */ }