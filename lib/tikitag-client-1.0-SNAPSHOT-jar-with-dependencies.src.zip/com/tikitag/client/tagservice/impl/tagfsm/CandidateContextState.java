/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class CandidateContextState extends TagState
/*    */ {
/*    */   private TagInfo contextTag;
/*    */ 
/*    */   CandidateContextState(TagStateMachine engine, TagInfo contextTag)
/*    */   {
/*  9 */     super(engine);
/* 10 */     this.contextTag = contextTag;
/*    */   }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag)
/*    */   {
/* 15 */     if (tag.getTagId().equals(this.contextTag.getTagId())) {
/* 16 */       this.engine.fireRemove(this.contextTag, null);
/* 17 */       return this.engine.noTags();
/*    */     }
/* 19 */     throw new IllegalStateException("Only expecting remove of " + this.contextTag + ", while receiving remove of " + tag);
/*    */   }
/*    */ 
/*    */   TagState onTagAdded(TagInfo tag)
/*    */   {
/* 24 */     this.engine.schedulePutThresholdTimer();
/* 25 */     return this.engine.candidateActionWithContext(tag, this.contextTag);
/*    */   }
/*    */ }