/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public class ActionWithContextState extends TagState
/*    */ {
/*    */   private TagInfo actionTag;
/*    */   private TagInfo contextTag;
/*    */ 
/*    */   ActionWithContextState(TagStateMachine engine, TagInfo actionTag, TagInfo contextTag)
/*    */   {
/* 10 */     super(engine);
/* 11 */     this.actionTag = actionTag;
/* 12 */     this.contextTag = contextTag;
/*    */   }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag)
/*    */   {
/* 17 */     if (tag.getTagId().equals(this.actionTag.getTagId())) {
/* 18 */       this.engine.fireRemove(this.actionTag, this.contextTag);
/* 19 */       return this.engine.candidateContext(this.contextTag); }
/* 20 */     if (tag.getTagId().equals(this.contextTag.getTagId())) {
/* 21 */       this.engine.fireRemove(this.contextTag, this.actionTag);
/* 22 */       return this.engine.candidateContext(this.actionTag);
/*    */     }
/* 24 */     throw new IllegalStateException("Was expecting either remove of " + this.actionTag + " or " + this.contextTag + ", but received " + tag);
/*    */   }
/*    */ 
/*    */   TagState onTagsRemoved(TagInfo tag1, TagInfo tag2)
/*    */   {
/* 29 */     this.engine.fireRemove(this.contextTag, null);
/* 30 */     this.engine.fireRemove(this.actionTag, null);
/* 31 */     return this.engine.noTags();
/*    */   }
/*    */ }