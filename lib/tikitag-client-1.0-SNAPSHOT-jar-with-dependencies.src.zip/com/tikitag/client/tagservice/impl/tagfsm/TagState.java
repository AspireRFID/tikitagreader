/*    */ package com.tikitag.client.tagservice.impl.tagfsm;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ 
/*    */ public abstract class TagState
/*    */ {
/*    */   protected TagStateMachine engine;
/*    */ 
/*    */   protected TagState(TagStateMachine engine)
/*    */   {
/*  9 */     this.engine = engine;
/*    */   }
/*    */ 
/*    */   TagState onTagsAdded(TagInfo tag1, TagInfo tag2) {
/* 13 */     throw new IllegalStateException("tagsAdded(" + tag1 + ", " + tag2 + ") is not supported in state " + super.getClass());
/*    */   }
/*    */ 
/*    */   TagState onTagAdded(TagInfo tag) {
/* 17 */     throw new IllegalStateException("tagAdded(" + tag + ") is not supported in state " + super.getClass());
/*    */   }
/*    */ 
/*    */   TagState onTagsRemoved(TagInfo tag1, TagInfo tag2) {
/* 21 */     throw new IllegalStateException("tagsRemoved(" + tag1 + ", " + tag2 + ") is not supported in state " + super.getClass()); }
/*    */ 
/*    */   TagState onTagRemoved(TagInfo tag) {
/* 24 */     throw new IllegalStateException("tagRemoved(" + tag + ") is not supported in state " + super.getClass());
/*    */   }
/*    */ 
/*    */   TagState onPutThresholdReached() {
/* 28 */     throw new IllegalStateException("putThresholdReached is not supported in state " + super.getClass());
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return super.getClass().getSimpleName();
/*    */   }
/*    */ }