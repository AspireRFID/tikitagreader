/*     */ package com.tikitag.client.tagservice.impl;
/*     */ 
/*     */ import com.tikitag.client.tagservice.ExtendedReaderId;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CardTerminal;
/*     */ import javax.smartcardio.CardTerminals;
/*     */ import javax.smartcardio.TerminalFactory;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ReaderManager
/*     */ {
/*  23 */   private static final Logger log = Logger.getLogger(ReaderManager.class);
/*     */   private final MonitorSupport monitorSupport;
/*  26 */   private final Map<CardTerminal, Acr122TagReader> tikitagReaders = new HashMap();
/*     */   private final ReaderDetector readerDetector;
/*  28 */   private Set<CardTerminal> unsupportedReaders = new HashSet();
/*     */ 
/*     */   public ReaderManager(MonitorSupport monitorSupport) {
/*  31 */     this.monitorSupport = monitorSupport;
/*  32 */     this.readerDetector = new ReaderDetector(null);
/*     */   }
/*     */ 
/*     */   public void start() {
/*  36 */     Thread thread = new Thread(this.readerDetector);
/*  37 */     thread.start();
/*     */   }
/*     */ 
/*     */   public void shutdown() {
/*  41 */     this.readerDetector.stop();
/*  42 */     for (Acr122TagReader reader : this.tikitagReaders.values())
/*  43 */       reader.shutdown();
/*     */   }
/*     */ 
/*     */   private Acr122TagReader findReader(ReaderId readerId)
/*     */   {
/* 141 */     for (Acr122TagReader reader : this.tikitagReaders.values()) {
/* 142 */       if (reader.getId().getReaderId().equals(readerId)) {
/* 143 */         return reader;
/*     */       }
/*     */     }
/* 146 */     throw new IllegalArgumentException("Failed to obtain Reader with id " + readerId);
/*     */   }
/*     */ 
/*     */   public void forceRedetect(ReaderId readerId) {
/* 150 */     findReader(readerId).forceRedetect();
/*     */   }
/*     */ 
/*     */   public boolean writeLock(ReaderId readerId, String lock) {
/* 154 */     return findReader(readerId).writeLock(lock);
/*     */   }
/*     */ 
/*     */   public boolean writePage(ReaderId readerId, int pageNr, String hexPageContent) {
/* 158 */     return findReader(readerId).writePage(pageNr, hexPageContent);
/*     */   }
/*     */ 
/*     */   public boolean writeUserData(ReaderId readerId, String hexUserData) {
/* 162 */     return findReader(readerId).writeUserData(hexUserData);
/*     */   }
/*     */ 
/*     */   private class ReaderDetector
/*     */     implements Runnable
/*     */   {
/*     */     private final AtomicBoolean detect;
/*     */ 
/*     */     private ReaderDetector()
/*     */     {
/*  48 */       this.detect = new AtomicBoolean(true); }
/*     */ 
/*     */     public void run() {
/*  51 */       TerminalFactory factory = TerminalFactory.getDefault();
/*     */ 
/*  53 */       ReaderManager.log.info("Starting to detect readers...");
/*  54 */       while (this.detect.get()) {
/*  55 */         cleanupDisconnectedTikitagReaders();
/*  56 */         List terminals = getAllConnectedTerminals(factory);
/*  57 */         addNewTikitagReadersAndResetUnsupportedReaders(terminals);
/*     */         try
/*     */         {
/*  61 */           Thread.sleep(5000L);
/*     */         } catch (InterruptedException e) {
/*  63 */           ReaderManager.log.warn("Interrupted...");
/*     */         }
/*     */       }
/*     */ 
/*  67 */       ReaderManager.log.info("Stopped detecting readers");
/*     */     }
/*     */ 
/*     */     private void addNewTikitagReadersAndResetUnsupportedReaders(List<CardTerminal> terminals)
/*     */     {
/*  77 */       if (terminals == null)
/*     */       {
/*  79 */         ReaderManager.access$202(ReaderManager.this, new HashSet());
/*  80 */         return;
/*     */       }
/*     */ 
/*  83 */       Set maintainedUnsupportedReaders = new HashSet();
/*  84 */       for (CardTerminal terminal : terminals) {
/*  85 */         if (ReaderManager.this.unsupportedReaders.contains(terminal))
/*     */         {
/*  87 */           maintainedUnsupportedReaders.add(terminal);
/*  88 */         } else if (!(ReaderManager.this.tikitagReaders.containsKey(terminal)))
/*     */         {
/*     */           try
/*     */           {
/*  92 */             ReaderManager.log.debug("Detected new terminal: " + terminal);
/*     */ 
/*  94 */             ReaderManager.this.tikitagReaders.put(terminal, new Acr122TagReader(terminal, ReaderManager.this.monitorSupport));
/*  95 */             ReaderManager.log.debug("-> Succesfully added new Tikitag terminal !");
/*     */           } catch (Exception e) {
/*  97 */             maintainedUnsupportedReaders.add(terminal);
/*  98 */             ReaderManager.log.debug("Failed to start monitoring on " + terminal + ": " + e.getMessage());
/*  99 */             ReaderManager.log.trace("Failed to start monitoring on " + terminal, e);
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 104 */       ReaderManager.access$202(ReaderManager.this, maintainedUnsupportedReaders);
/*     */     }
/*     */ 
/*     */     private List<CardTerminal> getAllConnectedTerminals(TerminalFactory factory) {
/* 108 */       List terminals = null;
/*     */       try {
/* 110 */         terminals = factory.terminals().list();
/*     */       }
/*     */       catch (CardException e)
/*     */       {
/* 114 */         ReaderManager.log.debug("No readers detected");
/* 115 */         ReaderManager.log.trace("Failed to query the system for readers: ", e);
/*     */       }
/* 117 */       return terminals;
/*     */     }
/*     */ 
/*     */     private void cleanupDisconnectedTikitagReaders()
/*     */     {
/* 122 */       List stoppedTerminals = new ArrayList();
/* 123 */       for (Acr122TagReader reader : ReaderManager.this.tikitagReaders.values()) {
/* 124 */         if (reader.isDisconnected()) {
/* 125 */           ReaderManager.log.debug(reader + " got disconnected... Cleaning up");
/* 126 */           stoppedTerminals.add(reader.getId().getSystemId());
/*     */         }
/*     */       }
/* 129 */       for (CardTerminal stoppedTerminal : stoppedTerminals)
/* 130 */         ReaderManager.this.tikitagReaders.remove(stoppedTerminal);
/*     */     }
/*     */ 
/*     */     public void stop()
/*     */     {
/* 135 */       this.detect.set(false);
/*     */     }
/*     */   }
/*     */ }