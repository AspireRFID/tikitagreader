/*     */ package com.tikitag.client.tagservice.impl;
/*     */ 
/*     */ import com.tikitag.client.tagservice.ReaderEvent;
/*     */ import com.tikitag.client.tagservice.ReaderEvent.ReaderEventType;
/*     */ import com.tikitag.client.tagservice.ReaderMonitor;
/*     */ import com.tikitag.client.tagservice.TagMonitor;
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.model.util.TagEvent.TagEventType;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MonitorSupport
/*     */ {
/*  26 */   private static final Logger m_log = Logger.getLogger(MonitorSupport.class);
/*     */   private final TagServiceConfiguration tagServiceConfiguration;
/*  29 */   private final List<ReaderMonitor> readerMonitors = new ArrayList();
/*  30 */   private final List<TagMonitor> tagMonitors = new ArrayList();
/*  31 */   private ExecutorService executor = null;
/*     */ 
/*     */   public MonitorSupport(TagServiceConfiguration tagServiceConfiguration)
/*     */   {
/*  35 */     this.tagServiceConfiguration = tagServiceConfiguration;
/*     */   }
/*     */ 
/*     */   public void start() {
/*  39 */     this.executor = Executors.newSingleThreadExecutor();
/*     */   }
/*     */ 
/*     */   public void shutdown() {
/*  43 */     if (this.executor != null) {
/*  44 */       this.executor.shutdown();
/*  45 */       this.executor = null;
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTagMonitor(TagMonitor tagMonitor) {
/*  50 */     synchronized (this.tagMonitors) {
/*  51 */       this.tagMonitors.add(tagMonitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeTagMonitor(TagMonitor tagMonitor) {
/*  56 */     synchronized (this.tagMonitors) {
/*  57 */       this.tagMonitors.remove(tagMonitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addReaderMonitor(ReaderMonitor readerMonitor) {
/*  62 */     synchronized (this.readerMonitors) {
/*  63 */       this.readerMonitors.add(readerMonitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void removeReaderMonitor(ReaderMonitor readerMonitor) {
/*  68 */     synchronized (this.readerMonitors) {
/*  69 */       this.readerMonitors.remove(readerMonitor);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TagEvents tags(ReaderId readerId) {
/*  74 */     return new TagEvents(readerId);
/*     */   }
/*     */ 
/*     */   public void fireTagEvent(ReaderId readerId, TagInfo actionTag, TagInfo contextTag, TagEvent.TagEventType eventType)
/*     */   {
/*     */     List safeMonitors;
/* 108 */     if (this.executor == null) {
/* 109 */       m_log.warn("No event dispatched for " + readerId + " and " + actionTag + ", because the monitor support has not been started yet");
/* 110 */       return;
/*     */     }
/*     */ 
/* 114 */     synchronized (this.tagMonitors) {
/* 115 */       safeMonitors = new ArrayList(this.tagMonitors);
/*     */     }
/*     */ 
/* 118 */     TagEvent tagEvent = new TagEvent(eventType, this.tagServiceConfiguration.getClientId(), readerId, actionTag, contextTag);
/*     */ 
/* 120 */     for (TagMonitor tagMonitor : safeMonitors)
/* 121 */       this.executor.submit(new TagEventDelivery(tagMonitor, tagEvent));
/*     */   }
/*     */ 
/*     */   public ReaderEvents reader(ReaderId readerId)
/*     */   {
/* 126 */     return new ReaderEvents(readerId);
/*     */   }
/*     */ 
/*     */   public void fireReaderEvent(ReaderId readerId, ReaderEvent.ReaderEventType eventType)
/*     */   {
/*     */     List safeMonitors;
/* 151 */     if (this.executor == null) {
/* 152 */       m_log.warn("No event dispatched for " + readerId + ", because the monitor support has not been started yet");
/* 153 */       return;
/*     */     }
/*     */ 
/* 157 */     synchronized (this.readerMonitors) {
/* 158 */       safeMonitors = new ArrayList(this.readerMonitors);
/*     */     }
/* 160 */     ReaderEvent readerEvent = new ReaderEvent(readerId, eventType);
/* 161 */     for (ReaderMonitor readerMonitor : safeMonitors)
/* 162 */       this.executor.submit(new ReaderEventDelivery(readerMonitor, readerEvent));
/*     */   }
/*     */ 
/*     */   private static class ReaderEventDelivery
/*     */     implements Runnable
/*     */   {
/*     */     private final ReaderMonitor readerMonitor;
/*     */     private final ReaderEvent readerEvent;
/*     */ 
/*     */     public ReaderEventDelivery(ReaderMonitor readerMonitor, ReaderEvent readerEvent)
/*     */     {
/* 190 */       this.readerMonitor = readerMonitor;
/* 191 */       this.readerEvent = readerEvent;
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 196 */         this.readerMonitor.onReaderEvent(this.readerEvent);
/*     */       } catch (Exception e) {
/* 198 */         MonitorSupport.m_log.error("Exception caught while delivering " + this.readerEvent + " to monitor " + this.readerMonitor + " : " + e.getMessage());
/* 199 */         MonitorSupport.m_log.debug("Exception: ", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TagEventDelivery
/*     */     implements Runnable
/*     */   {
/*     */     private final TagMonitor tagMonitor;
/*     */     private final TagEvent tagEvent;
/*     */ 
/*     */     public TagEventDelivery(TagMonitor tagMonitor, TagEvent tagsDetected)
/*     */     {
/* 171 */       this.tagMonitor = tagMonitor;
/* 172 */       this.tagEvent = tagsDetected;
/*     */     }
/*     */ 
/*     */     public void run() {
/*     */       try {
/* 177 */         this.tagMonitor.onTagEvent(this.tagEvent);
/*     */       } catch (Exception e) {
/* 179 */         MonitorSupport.m_log.error("Exception caught while delivering " + this.tagEvent + " to monitor " + this.tagMonitor + " : " + e.getMessage());
/* 180 */         MonitorSupport.m_log.debug("Exception:", e);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public class ReaderEvents
/*     */   {
/*     */     private final ReaderId readerId;
/*     */ 
/*     */     public ReaderEvents(ReaderId paramReaderId)
/*     */     {
/* 133 */       this.readerId = paramReaderId;
/*     */     }
/*     */ 
/*     */     public void fireAdded() {
/* 137 */       MonitorSupport.this.fireReaderEvent(this.readerId, ReaderEvent.ReaderEventType.READER_ADDED);
/*     */     }
/*     */ 
/*     */     public void fireRemoved() {
/* 141 */       MonitorSupport.this.fireReaderEvent(this.readerId, ReaderEvent.ReaderEventType.READER_REMOVED);
/*     */     }
/*     */ 
/*     */     public void fireFailure() {
/* 145 */       MonitorSupport.this.fireReaderEvent(this.readerId, ReaderEvent.ReaderEventType.READER_FAILURE);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class TagEvents
/*     */   {
/*     */     private final ReaderId readerId;
/*     */ 
/*     */     public TagEvents(ReaderId paramReaderId)
/*     */     {
/*  81 */       this.readerId = paramReaderId;
/*     */     }
/*     */ 
/*     */     public void firePut(TagInfo actionTag, TagInfo contextTag) {
/*  85 */       MonitorSupport.this.fireTagEvent(this.readerId, actionTag, contextTag, TagEvent.TagEventType.PUT);
/*     */     }
/*     */ 
/*     */     public void fireTouch(TagInfo actionTag, TagInfo contextTag) {
/*  89 */       MonitorSupport.this.fireTagEvent(this.readerId, actionTag, contextTag, TagEvent.TagEventType.TOUCH);
/*     */     }
/*     */ 
/*     */     public void fireRemove(TagInfo actionTag, TagInfo contextTag) {
/*  93 */       MonitorSupport.this.fireTagEvent(this.readerId, actionTag, contextTag, TagEvent.TagEventType.REMOVE);
/*     */     }
/*     */   }
/*     */ }