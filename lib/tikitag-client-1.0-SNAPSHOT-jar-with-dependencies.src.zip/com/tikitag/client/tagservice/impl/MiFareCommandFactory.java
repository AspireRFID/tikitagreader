/*     */ package com.tikitag.client.tagservice.impl;
/*     */ 
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import java.util.ArrayList;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CommandAPDU;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class MiFareCommandFactory
/*     */ {
/*  16 */   private static final Logger log = Logger.getLogger(MiFareCommandFactory.class);
/*     */   private static final String GET_RESPONSE_COMMAND = "FF000000";
/*     */   private static final String AUTHENTICATE_COMMAND = "D4400160";
/*     */   public static final String AUTHENTICATION_CONFIRMATION = "D541009000";
/*     */   public static final String READ_COMMAND = "FF00000005D4400130";
/*     */   public static final String WRITE_COMMAND = "D44001A0";
/*     */   public static final String MIFARE_1K_ZERO_PADDING = "000000000000000000000000";
/*     */   public static final String UPDATE_COMMAND = "D44001A2";
/*     */   public static final String UPDATE_LENGTH = "09";
/*     */   public static final String WRITE_LENGTH = "15";
/*     */ 
/*     */   public static CommandAPDU authenticateTagForBlock(String uid, String block)
/*     */   {
/*  55 */     return authenticateTagForBlock(uid, block, AuthenticationKey.DEFAULT);
/*     */   }
/*     */ 
/*     */   public static CommandAPDU authenticateTagForBlock(String uid, String block, AuthenticationKey key) {
/*  59 */     int length = ("D4400160".length() + key.getHexKey().length() + uid.length() + block.length()) / 2;
/*  60 */     byte[] commandArray = HexFormatter.fromHexString("FF000000" + HexFormatter.toHexString(length) + "D4400160" + block + key.getHexKey() + uid);
/*  61 */     CommandAPDU command = new CommandAPDU(commandArray);
/*  62 */     return command;
/*     */   }
/*     */ 
/*     */   public static boolean authenticateBlock(TagId id, int blockAddr, CardChannel channel)
/*     */     throws CardException
/*     */   {
/*  78 */     for (AuthenticationKey key : AuthenticationKey.values()) {
/*  79 */       CommandAPDU cmd = authenticateTagForBlock(id.getIdentifier(), HexFormatter.toHexString(blockAddr), key);
/*  80 */       ResponseAPDU response = channel.transmit(cmd);
/*  81 */       String responseHex = HexFormatter.toHexString(response.getBytes());
/*  82 */       if (responseHex.equals("D541009000")) {
/*  83 */         log.debug("Succesfully authenticated " + id + " block " + blockAddr + " using key " + key);
/*  84 */         return true;
/*     */       }
/*     */     }
/*  87 */     return false;
/*     */   }
/*     */ 
/*     */   public static CommandAPDU readTagForBlock(String block) {
/*  91 */     byte[] commandArray = HexFormatter.fromHexString("FF00000005D4400130" + block);
/*  92 */     CommandAPDU command = new CommandAPDU(commandArray);
/*  93 */     return command;
/*     */   }
/*     */ 
/*     */   public static CommandAPDU writeTagForBlock(String block, String data)
/*     */   {
/* 101 */     byte[] commandArray = HexFormatter.fromHexString("FF00000015D44001A0" + block + data + "000000000000000000000000");
/* 102 */     CommandAPDU command = new CommandAPDU(commandArray);
/* 103 */     return command;
/*     */   }
/*     */ 
/*     */   public static CommandAPDU updateTagForBlock(String block, String data) {
/* 107 */     byte[] commandArray = HexFormatter.fromHexString("FF00000009D44001A2" + block + data);
/* 108 */     CommandAPDU command = new CommandAPDU(commandArray);
/* 109 */     return command;
/*     */   }
/*     */ 
/*     */   public static ArrayList<CommandAPDU> writeContentForTag(String content)
/*     */   {
/* 117 */     ArrayList commandArray = new ArrayList();
/*     */ 
/* 119 */     int addr = 1;
/* 120 */     for (int i = 4; i <= 15; ++i) {
/* 121 */       String str = content.substring(addr, addr + 7);
/* 122 */       log.info("writing ..." + str);
/* 123 */       commandArray.add(writeTagForBlock(HexFormatter.toHexString(i), str));
/* 124 */       addr += 8;
/*     */     }
/* 126 */     return commandArray;
/*     */   }
/*     */ 
/*     */   public static enum AuthenticationKey
/*     */   {
/*  23 */     DEFAULT, MANUFACTURER_1, MANUFACTURER_2;
/*     */ 
/*     */     private final String hexKey;
/*     */ 
/*     */     public String getHexKey()
/*     */     {
/*  35 */       return this.hexKey;
/*     */     }
/*     */   }
/*     */ }