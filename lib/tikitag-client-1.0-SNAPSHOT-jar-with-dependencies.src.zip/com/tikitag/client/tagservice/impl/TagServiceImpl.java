/*    */ package com.tikitag.client.tagservice.impl;
/*    */ 
/*    */ import com.tikitag.client.tagservice.ReaderMonitor;
/*    */ import com.tikitag.client.tagservice.TagMonitor;
/*    */ import com.tikitag.client.tagservice.TagService;
/*    */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*    */ import com.tikitag.ons.model.util.ReaderId;
/*    */ 
/*    */ public class TagServiceImpl
/*    */   implements TagService
/*    */ {
/*    */   private final MonitorSupport monitorSupport;
/*    */   private final ReaderManager readerManager;
/*    */ 
/*    */   public TagServiceImpl(TagServiceConfiguration tagServiceConfiguration)
/*    */   {
/* 21 */     this.monitorSupport = new MonitorSupport(tagServiceConfiguration);
/* 22 */     this.readerManager = new ReaderManager(this.monitorSupport);
/*    */   }
/*    */ 
/*    */   public void start()
/*    */   {
/* 27 */     this.monitorSupport.start();
/* 28 */     this.readerManager.start();
/*    */   }
/*    */ 
/*    */   public void shutdown() {
/* 32 */     this.readerManager.shutdown();
/* 33 */     this.monitorSupport.shutdown();
/*    */   }
/*    */ 
/*    */   public void addTagMonitor(TagMonitor tagMonitor)
/*    */   {
/* 39 */     this.monitorSupport.addTagMonitor(tagMonitor);
/*    */   }
/*    */ 
/*    */   public void removeTagMonitor(TagMonitor tagMonitor) {
/* 43 */     this.monitorSupport.removeTagMonitor(tagMonitor);
/*    */   }
/*    */ 
/*    */   public void addReaderMonitor(ReaderMonitor readerMonitor) {
/* 47 */     this.monitorSupport.addReaderMonitor(readerMonitor);
/*    */   }
/*    */ 
/*    */   public void removeReaderMonitor(ReaderMonitor readerMonitor) {
/* 51 */     this.monitorSupport.removeReaderMonitor(readerMonitor);
/*    */   }
/*    */ 
/*    */   public void forceRedetect(ReaderId readerId) {
/* 55 */     this.readerManager.forceRedetect(readerId);
/*    */   }
/*    */ 
/*    */   public boolean writeLock(ReaderId readerId, String lock) {
/* 59 */     return this.readerManager.writeLock(readerId, lock);
/*    */   }
/*    */ 
/*    */   public boolean writePage(ReaderId readerId, int pageNr, String hexPageContent) {
/* 63 */     return this.readerManager.writePage(readerId, pageNr, hexPageContent);
/*    */   }
/*    */ 
/*    */   public boolean writeUserData(ReaderId readerId, String hexUserData) {
/* 67 */     return this.readerManager.writeUserData(readerId, hexUserData);
/*    */   }
/*    */ }