/*     */ package com.tikitag.client.tagservice.impl;
/*     */ 
/*     */ import com.tikitag.client.tagservice.TagType;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ 
/*     */ public class PollResponse
/*     */ {
/* 108 */   private Set<Tag> tags = new HashSet();
/*     */ 
/*     */   public static boolean isValid(ResponseAPDU pollResponse)
/*     */   {
/*  16 */     byte[] response = pollResponse.getBytes();
/*  17 */     return ((response[0] == -43) && (response[1] == 97));
/*     */   }
/*     */ 
/*     */   public static PollResponse parse(ResponseAPDU pollResponse) {
/*  21 */     return new PollResponse(pollResponse);
/*     */   }
/*     */ 
/*     */   private PollResponse(ResponseAPDU pollResponse)
/*     */   {
/* 111 */     if (!(isValid(pollResponse))) {
/* 112 */       throw new IllegalArgumentException("The ResponseAPDU does not represent a valid polling response");
/*     */     }
/*     */ 
/* 115 */     byte[] response = pollResponse.getBytes();
/*     */ 
/* 117 */     int nrOfTagsFound = response[2];
/*     */ 
/* 119 */     int responseIndex = 3;
/* 120 */     for (int i = 0; i < nrOfTagsFound; ++i) {
/* 121 */       TagType tagType = TagType.fromTypeId(response[(responseIndex++)]);
/* 122 */       int tagInfoSize = response[(responseIndex++)];
/* 123 */       int targetNr = response[(responseIndex++)];
/*     */ 
/* 125 */       switch (1.$SwitchMap$com$tikitag$client$tagservice$TagType[tagType.ordinal()])
/*     */       {
/*     */       case 1:
/* 127 */         ++responseIndex;
/* 128 */         ++responseIndex;
/* 129 */         int selRes = response[(responseIndex++)];
/* 130 */         MifareType mifareType = MifareType.fromTypeId((byte)selRes);
/* 131 */         int uidLength = response[(responseIndex++)];
/* 132 */         byte[] uid = new byte[uidLength];
/* 133 */         System.arraycopy(response, responseIndex, uid, 0, uidLength);
/* 134 */         responseIndex += uidLength;
/*     */ 
/* 136 */         this.tags.add(new MifareTag(targetNr, new TagId(uid), mifareType));
/* 137 */         break;
/*     */       case 2:
/*     */       case 3:
/*     */       case 4:
/*     */       case 5:
/*     */       case 6:
/*     */       default:
/* 144 */         responseIndex += tagInfoSize - 1;
/* 145 */         this.tags.add(new UnsupportedTag(targetNr, tagType));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public Set<Tag> getTags() {
/* 151 */     return this.tags;
/*     */   }
/*     */ 
/*     */   public static class MifareTag extends PollResponse.Tag
/*     */   {
/*     */     private final MifareType mifareType;
/*     */ 
/*     */     public MifareTag(int targetNr, TagId tagId, MifareType mifareType)
/*     */     {
/*  94 */       super(targetNr, tagId, TagType.MIFARE);
/*  95 */       this.mifareType = mifareType;
/*     */     }
/*     */ 
/*     */     public MifareType getMifareType() {
/*  99 */       return this.mifareType;
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/* 104 */       return "MifareTag(target=" + getTargetNr() + ", tagId=" + getTagId() + ", mifareType=" + this.mifareType + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class UnsupportedTag extends PollResponse.Tag
/*     */   {
/*     */     public UnsupportedTag(int targetNr, TagType tagType)
/*     */     {
/*  81 */       super(targetNr, null, tagType);
/*     */     }
/*     */ 
/*     */     public String toString()
/*     */     {
/*  86 */       return "UnsupportedTag(target=" + getTargetNr() + ", tagType=" + getTagType() + ")";
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class Tag
/*     */   {
/*     */     private final int targetNr;
/*     */     private final TagId tagId;
/*     */     private final TagType tagType;
/*     */ 
/*     */     public Tag(int targetNr, TagId tagId, TagType tagType)
/*     */     {
/*  30 */       this.targetNr = targetNr;
/*  31 */       this.tagId = tagId;
/*  32 */       this.tagType = tagType;
/*     */     }
/*     */ 
/*     */     public int getTargetNr() {
/*  36 */       return this.targetNr;
/*     */     }
/*     */ 
/*     */     public TagId getTagId() {
/*  40 */       return this.tagId;
/*     */     }
/*     */ 
/*     */     public TagType getTagType() {
/*  44 */       return this.tagType;
/*     */     }
/*     */ 
/*     */     public final int hashCode()
/*     */     {
/*  49 */       int prime = 31;
/*  50 */       int result = 1;
/*  51 */       result = 31 * result + ((this.tagId == null) ? 0 : this.tagId.hashCode());
/*  52 */       result = 31 * result + ((this.tagType == null) ? 0 : this.tagType.hashCode());
/*  53 */       return result;
/*     */     }
/*     */ 
/*     */     public final boolean equals(Object obj)
/*     */     {
/*  58 */       if (this == obj)
/*  59 */         return true;
/*  60 */       if (obj == null)
/*  61 */         return false;
/*  62 */       if (!(obj instanceof Tag))
/*  63 */         return false;
/*  64 */       Tag other = (Tag)obj;
/*  65 */       if (this.tagId == null) {
/*  66 */         if (other.tagId == null) break label59;
/*  67 */         return false; }
/*  68 */       if (!(this.tagId.equals(other.tagId)))
/*  69 */         return false;
/*  70 */       if (this.tagType == null) {
/*  71 */         label59: if (other.tagType == null) break label91;
/*  72 */         return false;
/*     */       }
/*  74 */       label91: return (!(this.tagType.equals(other.tagType)));
/*     */     }
/*     */   }
/*     */ }