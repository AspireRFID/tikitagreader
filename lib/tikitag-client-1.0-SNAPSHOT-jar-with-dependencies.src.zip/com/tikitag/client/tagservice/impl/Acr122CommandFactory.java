/*    */ package com.tikitag.client.tagservice.impl;
/*    */ 
/*    */ import com.tikitag.client.tagservice.TagType;
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import javax.smartcardio.CommandAPDU;
/*    */ 
/*    */ public class Acr122CommandFactory
/*    */ {
/*    */   public static final int INFINITE_RETRIES = 255;
/*    */   public static final String PSEUDO_ATR = "3B00";
/*    */ 
/*    */   public static CommandAPDU setPollingRetryToOne()
/*    */   {
/* 13 */     return new CommandAPDU(255, 0, 0, 0, HexFormatter.fromHexString("D43205000000"));
/*    */   }
/*    */ 
/*    */   public static CommandAPDU setPollingRetryTo(int retries) {
/* 17 */     if (retries < 0)
/* 18 */       retries = 0;
/* 19 */     else if (retries > 255) {
/* 20 */       retries = 255;
/*    */     }
/*    */ 
/* 23 */     return new CommandAPDU(255, 0, 0, 0, new byte[] { -44, 50, 5, 0, 0, (byte)retries });
/*    */   }
/*    */ 
/*    */   public static CommandAPDU pollAllTags() {
/* 27 */     return new CommandAPDU(255, 0, 0, 0, HexFormatter.fromHexString("D4600101202311121004"));
/*    */   }
/*    */ 
/*    */   public static CommandAPDU pollTagsOfType(TagType[] tagTypes) {
/* 31 */     byte[] command = new byte[4 + tagTypes.length];
/* 32 */     command[0] = -44;
/* 33 */     command[1] = 96;
/* 34 */     command[2] = 1;
/* 35 */     command[3] = 1;
/* 36 */     for (int i = 0; i < tagTypes.length; ++i) {
/* 37 */       command[(4 + i)] = tagTypes[i].getTypeId();
/*    */     }
/* 39 */     return new CommandAPDU(255, 0, 0, 0, command);
/*    */   }
/*    */ 
/*    */   public static CommandAPDU getFirmwareInfo() {
/* 43 */     return new CommandAPDU(HexFormatter.fromHexString("FF00480000"));
/*    */   }
/*    */ 
/*    */   public static CommandAPDU getCardInfo() {
/* 47 */     return new CommandAPDU(HexFormatter.fromHexString("8014000008"));
/*    */   }
/*    */ 
/*    */   public static CommandAPDU getSerialFromCard() {
/* 51 */     return new CommandAPDU(HexFormatter.fromHexString("8014040006"));
/*    */   }
/*    */ }