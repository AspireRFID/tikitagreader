/*     */ package com.tikitag.client.tagservice.impl;
/*     */ 
/*     */ import com.tikitag.client.tagservice.ExtendedReaderId;
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.client.tagservice.impl.tagfsm.TagStateMachine;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Collections;
/*     */ import java.util.Formatter;
/*     */ import java.util.Iterator;
/*     */ import java.util.LinkedHashSet;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.atomic.AtomicBoolean;
/*     */ import javax.smartcardio.ATR;
/*     */ import javax.smartcardio.Card;
/*     */ import javax.smartcardio.CardChannel;
/*     */ import javax.smartcardio.CardException;
/*     */ import javax.smartcardio.CardTerminal;
/*     */ import javax.smartcardio.ResponseAPDU;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class Acr122TagReader
/*     */ {
/*     */   private static final int HEX_LOCK_LENGTH = 4;
/*     */   private static final int HEX_USERDATA_LENGTH = 96;
/*     */   private static final int HEX_PAGE_LENGTH = 8;
/*  41 */   private static final Logger log = Logger.getLogger(Acr122TagReader.class);
/*     */   private final Card card;
/*     */   private final ExtendedReaderId readerId;
/*     */   private final CardChannel channel;
/*     */   private final MonitorSupport monitorSupport;
/*  48 */   private final TagDetector tagDetector = new TagDetector(null);
/*     */ 
/*  50 */   private Set<PollResponse.Tag> lastTags = new LinkedHashSet();
/*     */   private ATR atr;
/*     */   private TagStateMachine tagState;
/*     */ 
/*     */   public Acr122TagReader(CardTerminal terminal, MonitorSupport monitorSupport)
/*     */     throws CardException
/*     */   {
/*  55 */     validateIsTikitagReader(terminal);
/*     */ 
/*  57 */     this.card = terminal.connect("T=0");
/*  58 */     this.channel = this.card.getBasicChannel();
/*     */ 
/*  62 */     this.atr = this.card.getATR();
/*  63 */     byte[] atrBytes = this.atr.getBytes();
/*  64 */     String atrString = HexFormatter.toHexString(atrBytes);
/*  65 */     byte[] uniqueReaderId = null;
/*  66 */     String serialReader = null;
/*  67 */     if (atrString.equals("3B00")) {
/*  68 */       log.warn("No SAM card available in reader.");
/*     */ 
/*  72 */       uniqueReaderId = atrBytes;
/*     */     } else {
/*     */       try {
/*  75 */         ResponseAPDU response = this.channel.transmit(Acr122CommandFactory.getCardInfo());
/*  76 */         uniqueReaderId = response.getData();
/*  77 */         log.debug("GetCardInfo response = " + HexFormatter.toHexString(uniqueReaderId));
/*  78 */         ResponseAPDU serialResponse = this.channel.transmit(Acr122CommandFactory.getSerialFromCard());
/*  79 */         serialReader = HexFormatter.convertByteToUnicodeString(serialResponse.getData());
/*  80 */         log.debug("GetSerialFromCard response = " + serialReader);
/*     */       } catch (Exception e) {
/*  82 */         throw new CardException("No unique identifier could be obtained, although a SAM card is present", e);
/*     */       }
/*     */     }
/*  85 */     this.readerId = new ExtendedReaderId(terminal, uniqueReaderId, serialReader);
/*  86 */     this.monitorSupport = monitorSupport;
/*     */ 
/*  89 */     monitorSupport.reader(this.readerId.getReaderId()).fireAdded();
/*     */ 
/*  92 */     this.tagState = new TagStateMachine(monitorSupport.tags(this.readerId.getReaderId()));
/*  93 */     Thread detectorThread = new Thread(this.tagDetector);
/*  94 */     detectorThread.start();
/*     */   }
/*     */ 
/*     */   private void validateIsTikitagReader(CardTerminal terminal) throws CardException {
/*  98 */     if (terminal.isCardPresent())
/*     */       return;
/* 100 */     throw new IllegalStateException("No card present");
/*     */   }
/*     */ 
/*     */   public ExtendedReaderId getId()
/*     */   {
/* 105 */     return this.readerId;
/*     */   }
/*     */ 
/*     */   public String getInfo() {
/*     */     try {
/* 110 */       ResponseAPDU response = this.channel.transmit(Acr122CommandFactory.getFirmwareInfo());
/* 111 */       return new String(response.getData(), "US-ASCII");
/*     */     } catch (CardException e) {
/* 113 */       log.warn("Failed to obtain firmware information");
/* 114 */       log.debug(e);
/*     */     } catch (UnsupportedEncodingException e) {
/* 116 */       log.warn("Failed to convert firmware identification into human readable format");
/* 117 */       log.debug(e);
/*     */     }
/* 119 */     return "No Info";
/*     */   }
/*     */ 
/*     */   public boolean isDisconnected() {
/* 123 */     return this.tagDetector.isStopped();
/*     */   }
/*     */ 
/*     */   public void shutdown() {
/* 127 */     this.tagDetector.stop();
/*     */   }
/*     */ 
/*     */   public String toString() {
/* 131 */     return this.readerId.toString();
/*     */   }
/*     */ 
/*     */   private void handlePollResponse(ResponseAPDU pollResponse) {
/* 135 */     boolean trace = log.isTraceEnabled();
/* 136 */     if (trace) {
/* 137 */       log.trace("Raw Poll Response = " + HexFormatter.toHexString(pollResponse.getBytes()));
/*     */     }
/*     */ 
/* 140 */     if (PollResponse.isValid(pollResponse))
/*     */     {
/*     */       Iterator i$;
/*     */       Iterator it;
/*     */       TagInfo tag;
/*     */       TagInfo tag1;
/*     */       TagInfo tag2;
/* 142 */       PollResponse response = PollResponse.parse(pollResponse);
/*     */ 
/* 145 */       Set detectedTags = response.getTags();
/*     */ 
/* 147 */       Set removedTags = extractRemovedTags(detectedTags);
/*     */ 
/* 149 */       Set addedTags = extractAddedTags(detectedTags);
/*     */ 
/* 151 */       synchronized (this) {
/* 152 */         this.lastTags = detectedTags;
/*     */       }
/*     */ 
/* 157 */       if (trace) {
/* 158 */         log.trace("Removed Tags: " + removedTags.size());
/* 159 */         for (i$ = removedTags.iterator(); i$.hasNext(); ) { tag = (TagInfo)i$.next();
/* 160 */           log.trace("  " + tag);
/*     */         }
/*     */       }
/* 163 */       if (removedTags.size() == 2) {
/* 164 */         it = removedTags.iterator();
/* 165 */         tag1 = (TagInfo)it.next();
/* 166 */         tag2 = (TagInfo)it.next();
/* 167 */         this.tagState.tagsRemoved(tag1, tag2);
/* 168 */       } else if (removedTags.size() == 1) {
/* 169 */         this.tagState.tagRemoved((TagInfo)removedTags.iterator().next());
/*     */       }
/*     */ 
/* 172 */       if (trace) {
/* 173 */         log.trace("Added Tags: " + addedTags.size());
/* 174 */         for (it = addedTags.iterator(); it.hasNext(); ) { tag1 = (TagInfo)it.next();
/* 175 */           log.trace("  " + tag1);
/*     */         }
/*     */       }
/* 178 */       if (addedTags.size() == 2) {
/* 179 */         it = addedTags.iterator();
/* 180 */         tag1 = (TagInfo)it.next();
/* 181 */         tag2 = (TagInfo)it.next();
/* 182 */         this.tagState.tagsAdded(tag1, tag2);
/* 183 */       } else if (addedTags.size() == 1) {
/* 184 */         this.tagState.tagAdded((TagInfo)addedTags.iterator().next());
/*     */       }
/*     */     }
/*     */     else {
/* 188 */       log.warn("Invalid poll response type");
/*     */     }
/*     */   }
/*     */ 
/*     */   private Set<TagInfo> createTagInfo(Set<PollResponse.Tag> tags, boolean performRead) {
/* 193 */     Set result = new LinkedHashSet();
/* 194 */     for (PollResponse.Tag tag : tags) {
/* 195 */       if (tag instanceof PollResponse.MifareTag) {
/* 196 */         PollResponse.MifareTag mifareTag = (PollResponse.MifareTag)tag;
/* 197 */         TagInfo tagInfo = new TagInfo(mifareTag.getTagId());
/* 198 */         if (performRead) {
/* 199 */           tagInfo.setTagData(readMifareData(mifareTag.getMifareType(), mifareTag.getTagId()));
/*     */         }
/* 201 */         result.add(tagInfo);
/*     */       } else {
/* 203 */         log.warn("Unsupported Tag: " + tag);
/*     */       }
/*     */     }
/* 206 */     return result;
/*     */   }
/*     */ 
/*     */   public byte[] readMifareData(MifareType mifareType, TagId id)
/*     */   {
/* 211 */     ByteArrayOutputStream responseBuffer = new ByteArrayOutputStream();
/*     */     try {
/* 213 */       switch (1.$SwitchMap$com$tikitag$client$tagservice$impl$MifareType[mifareType.ordinal()])
/*     */       {
/*     */       case 1:
/* 215 */         log.debug("Reading Mifare 1K : " + id);
/*     */ 
/* 217 */         for (int page64 = 1; page64 < 16; ++page64) {
/* 218 */           int blockAdr = page64 * 4;
/* 219 */           if (!(MiFareCommandFactory.authenticateBlock(id, blockAdr, this.channel)))
/*     */             continue;
/* 221 */           for (int block16 = 0; block16 < 3; ++block16) {
/* 222 */             ResponseAPDU readResponse = this.channel.transmit(MiFareCommandFactory.readTagForBlock(HexFormatter.toHexString(blockAdr + block16)));
/* 223 */             byte[] data = readResponse.getData();
/* 224 */             log.debug("Read page64=" + page64 + " block16=" + block16 + " : " + HexFormatter.toHexString(data));
/*     */ 
/* 226 */             responseBuffer.write(data, 3, data.length - 3);
/*     */           }
/*     */         }
/*     */ 
/* 230 */         return responseBuffer.toByteArray();
/*     */       case 2:
/* 233 */         log.debug("Reading Mifare Ultralight : " + id);
/* 234 */         for (int page16 = 0; page16 < 4; ++page16) {
/* 235 */           int blockA = page16 * 4;
/* 236 */           ResponseAPDU readResponse = this.channel.transmit(MiFareCommandFactory.readTagForBlock(HexFormatter.toHexString(blockA)));
/* 237 */           byte[] data = readResponse.getData();
/* 238 */           log.debug("Read page16=" + page16 + " : " + HexFormatter.toHexString(data));
/*     */ 
/* 240 */           responseBuffer.write(data, 3, data.length - 3);
/*     */         }
/*     */ 
/* 243 */         return responseBuffer.toByteArray();
/*     */       }
/* 245 */       log.warn("Data reading is not supported for type " + mifareType);
/*     */     }
/*     */     catch (CardException e) {
/* 248 */       log.error("Card exception: " + e.toString());
/*     */     }
/* 250 */     return new byte[0];
/*     */   }
/*     */ 
/*     */   private Set<TagInfo> extractAddedTags(Set<PollResponse.Tag> tags) {
/* 254 */     Set newTags = new LinkedHashSet(tags);
/* 255 */     synchronized (this) {
/* 256 */       newTags.removeAll(this.lastTags);
/*     */     }
/* 258 */     return createTagInfo(newTags, true);
/*     */   }
/*     */ 
/*     */   private Set<TagInfo> extractRemovedTags(Set<PollResponse.Tag> tags) {
/* 262 */     Set deletedTags = new LinkedHashSet();
/* 263 */     synchronized (this) {
/* 264 */       deletedTags.addAll(this.lastTags);
/* 265 */       deletedTags.removeAll(tags);
/*     */     }
/* 267 */     return createTagInfo(deletedTags, false);
/*     */   }
/*     */ 
/*     */   public void forceRedetect()
/*     */   {
/* 318 */     synchronized (this) {
/* 319 */       this.lastTags = Collections.emptySet();
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean writeLock(String lock)
/*     */   {
/* 331 */     if (lock.length() != 4) {
/* 332 */       throw new IllegalArgumentException("Lock information should be represented by  4 HEX characters, representing the 2 lock bytes");
/*     */     }
/* 334 */     String lockPage = "0000" + lock;
/* 335 */     return writePage(2, lockPage);
/*     */   }
/*     */ 
/*     */   public boolean writePage(int pageNr, String hexPageContent)
/*     */   {
/* 348 */     if (hexPageContent.length() != 8) {
/* 349 */       throw new IllegalArgumentException("Page content should be represented by  8 HEX characters, representing the 4 page bytes");
/*     */     }
/* 351 */     boolean isSuccess = false;
/*     */     try {
/* 353 */       log.info("Writing " + hexPageContent + " to page " + pageNr + "...");
/* 354 */       ResponseAPDU readResponse = this.channel.transmit(MiFareCommandFactory.updateTagForBlock(HexFormatter.toHexString(pageNr), hexPageContent));
/*     */ 
/* 356 */       int responseCode = readResponse.getBytes()[2];
/* 357 */       isSuccess = responseCode == 0;
/*     */ 
/* 359 */       if (log.isInfoEnabled()) {
/* 360 */         String status = "OK";
/* 361 */         if (!(isSuccess)) {
/* 362 */           status = "ERROR Code " + responseCode;
/*     */         }
/*     */ 
/* 365 */         log.info(new Formatter().format("Page %04X : %s\n", new Object[] { Integer.valueOf(pageNr), status }).out().toString());
/*     */       }
/*     */     } catch (CardException e) {
/* 368 */       log.error("Exception while writing page " + pageNr, e);
/*     */     }
/* 370 */     return isSuccess;
/*     */   }
/*     */ 
/*     */   public boolean writeUserData(String hexUserData)
/*     */   {
/* 381 */     if (hexUserData.length() != 96) {
/* 382 */       throw new IllegalArgumentException("User data content should be represented by 96 HEX characters, representing the 48 user data bytes");
/*     */     }
/* 384 */     int addr = 0;
/* 385 */     for (int pageNr = 4; pageNr < 16; ++pageNr) {
/* 386 */       String pageContent = hexUserData.substring(addr, addr + 8);
/* 387 */       if (!(writePage(pageNr, pageContent))) {
/* 388 */         log.error("Aborted writing userData at page " + pageNr + ", due to write failure");
/* 389 */         return false;
/*     */       }
/* 391 */       addr += 8;
/*     */     }
/* 393 */     return true;
/*     */   }
/*     */ 
/*     */   private class TagDetector
/*     */     implements Runnable
/*     */   {
/*     */     private final TagServiceConfiguration config;
/*     */     private final AtomicBoolean poll;
/*     */ 
/*     */     private TagDetector()
/*     */     {
/* 273 */       this.config = new TagServiceConfiguration();
/* 274 */       this.poll = new AtomicBoolean(true); }
/*     */ 
/*     */     public void run() {
/* 277 */       MonitorSupport.ReaderEvents readerEvents = Acr122TagReader.this.monitorSupport.reader(Acr122TagReader.this.readerId.getReaderId());
/*     */       try {
/* 279 */         Acr122TagReader.this.channel.transmit(Acr122CommandFactory.setPollingRetryToOne());
/*     */ 
/* 281 */         Acr122TagReader.log.info("Starting to poll for tags on " + Acr122TagReader.this.readerId + "...");
/* 282 */         while (this.poll.get()) {
/* 283 */           ResponseAPDU response = Acr122TagReader.this.channel.transmit(Acr122CommandFactory.pollTagsOfType(this.config.getDetectTagTypes()));
/* 284 */           Acr122TagReader.this.handlePollResponse(response);
/*     */           try
/*     */           {
/* 287 */             Thread.sleep(this.config.getPollInterval());
/*     */           } catch (InterruptedException e) {
/* 289 */             Acr122TagReader.log.warn("Interrupted...");
/*     */           }
/*     */         }
/*     */       } catch (CardException e) {
/* 293 */         Acr122TagReader.log.error("Problem detected, aborting tag polling on " + Acr122TagReader.this.readerId + ": " + e.getMessage());
/* 294 */         Acr122TagReader.log.debug(e);
/* 295 */         readerEvents.fireFailure();
/* 296 */         stop();
/*     */       }
/*     */       try {
/* 299 */         Acr122TagReader.this.card.disconnect(false);
/*     */       }
/*     */       catch (CardException e) {
/* 302 */         Acr122TagReader.log.debug("Attempted to disconnect from " + Acr122TagReader.this.readerId + ", but failed with " + e.getMessage(), e);
/*     */       }
/* 304 */       Acr122TagReader.log.info("Stopped polling for tags on " + Acr122TagReader.this.readerId);
/* 305 */       readerEvents.fireRemoved();
/*     */     }
/*     */ 
/*     */     public void stop() {
/* 309 */       this.poll.set(false);
/*     */     }
/*     */ 
/*     */     public boolean isStopped() {
/* 313 */       return (!(this.poll.get()));
/*     */     }
/*     */   }
/*     */ }