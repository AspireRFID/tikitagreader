package com.tikitag.client.tagservice;

import com.tikitag.ons.model.util.TagEvent;

public abstract interface TagMonitor
{
  public abstract void onTagEvent(TagEvent paramTagEvent);
}