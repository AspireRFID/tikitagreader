/*     */ package com.tikitag.client.tagservice;
/*     */ 
/*     */ import com.tikitag.ons.model.util.ClientId;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import com.tikitag.util.StringUtils;
/*     */ import java.net.InetAddress;
/*     */ import java.net.NetworkInterface;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class TagServiceConfiguration
/*     */ {
/*     */   private static final int DEFAULT_POLL_INTERVAL = 150;
/*     */   private static final int DEFAULT_PUT_THRESHOLD = 1500;
/*  19 */   private static final Logger log = Logger.getLogger(TagServiceConfiguration.class);
/*     */   private final Preferences prefs;
/*     */   private static final String POLL_INTERVAL_KEY = "reader.poll.interval";
/*     */   private static final String PUT_THRESHOLD_TIME_KEY = "put.threshold.time";
/*     */   public static final String CLIENT_ID_KEY = "client.id";
/*     */   public static final String CLIENT_NAME_KEY = "client.name";
/*     */   private static final String SERVER_RECONNECT_TRESHOLD_KEY = "server.reconnect.treshold.time";
/*     */   private static final String TAG_TYPES_KEY = "detect.tag.types";
/*     */   private final List<TagServiceConfigurationListener> tagServiceConfigurationListeners;
/*     */ 
/*     */   public TagServiceConfiguration()
/*     */   {
/*  20 */     this.prefs = Preferences.userNodeForPackage(TagServiceConfiguration.class);
/*     */ 
/*  29 */     this.tagServiceConfigurationListeners = new ArrayList();
/*     */   }
/*     */ 
/*     */   public long getPollInterval()
/*     */   {
/*  37 */     return this.prefs.getLong("reader.poll.interval", 150L);
/*     */   }
/*     */ 
/*     */   public void setPollInterval(long polInterval)
/*     */   {
/*  47 */     this.prefs.putLong("reader.poll.interval", polInterval);
/*     */   }
/*     */ 
/*     */   public long getPutThresholdTime()
/*     */   {
/*  58 */     return this.prefs.getLong("put.threshold.time", 1500L);
/*     */   }
/*     */ 
/*     */   public void setPutThresholdTime(long putThreshold)
/*     */   {
/*  68 */     this.prefs.putLong("put.threshold.time", putThreshold);
/*     */   }
/*     */ 
/*     */   public TagType[] getDetectTagTypes()
/*     */   {
/*  79 */     String tagTypesString = this.prefs.get("detect.tag.types", TagType.MIFARE.name());
/*  80 */     String[] tagTypeNames = StringUtils.fromCommaSeperated(tagTypesString);
/*  81 */     List tagTypes = new ArrayList(tagTypeNames.length);
/*  82 */     for (String tagTypeName : tagTypeNames) {
/*  83 */       tagTypes.add(TagType.valueOf(tagTypeName));
/*     */     }
/*  85 */     return ((TagType[])tagTypes.toArray(new TagType[tagTypes.size()]));
/*     */   }
/*     */ 
/*     */   public void setDetectTagTypes(TagType[] tagTypes)
/*     */   {
/*  94 */     List tagTypeNames = new ArrayList(tagTypes.length);
/*  95 */     for (TagType tagType : tagTypes) {
/*  96 */       tagTypeNames.add(tagType.name());
/*     */     }
/*  98 */     this.prefs.put("detect.tag.types", StringUtils.toCommaSeperated(tagTypeNames));
/*     */   }
/*     */ 
/*     */   public ClientId getClientId()
/*     */   {
/* 107 */     String id = this.prefs.get("client.id", generateClientId());
/* 108 */     String name = this.prefs.get("client.name", id);
/* 109 */     return new ClientId(id, name);
/*     */   }
/*     */ 
/*     */   public String generateClientId()
/*     */   {
/*     */     try
/*     */     {
/* 121 */       NetworkInterface primaryInterface = NetworkInterface.getByInetAddress(InetAddress.getLocalHost());
/* 122 */       byte[] hardwareAddress = primaryInterface.getHardwareAddress();
/* 123 */       if (hardwareAddress == null) {
/* 124 */         log.warn("Failed to generate ClientId: Primary interface has no MAC Address");
/* 125 */         return null;
/*     */       }
/* 127 */       return HexFormatter.toHexString(hardwareAddress);
/*     */     } catch (Exception e) {
/* 129 */       log.error("Failed to generate ClientId: " + e.getMessage(), e);
/*     */     }
/* 131 */     return null;
/*     */   }
/*     */ 
/*     */   public void setClientId(ClientId clientId) {
/* 135 */     ClientId currentClientId = getClientId();
/* 136 */     boolean nameChange = false;
/* 137 */     boolean idChange = false;
/* 138 */     if (!(clientId.getName().equals(currentClientId.getName()))) {
/* 139 */       nameChange = true;
/* 140 */       this.prefs.put("client.name", clientId.getName());
/*     */     }
/* 142 */     if (!(clientId.getId().equals(currentClientId.getId()))) {
/* 143 */       idChange = true;
/* 144 */       this.prefs.put("client.id", clientId.getId());
/*     */     }
/* 146 */     if ((nameChange) || (idChange)) {
/* 147 */       ClientIdChangeEvent clientIdChange = new ClientIdChangeEvent(clientId, idChange, nameChange);
/* 148 */       fireOnClientIdChange(clientIdChange);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void addTagServiceConfigurationListener(TagServiceConfigurationListener listener) {
/* 153 */     this.tagServiceConfigurationListeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeTagServiceConfigurationListener(TagServiceConfigurationListener listener) {
/* 157 */     this.tagServiceConfigurationListeners.remove(listener);
/*     */   }
/*     */ 
/*     */   public void fireOnClientIdChange(ClientIdChangeEvent clientIdChange) {
/* 161 */     for (TagServiceConfigurationListener listener : this.tagServiceConfigurationListeners) {
/* 162 */       listener.onClientIdChange(clientIdChange);
/* 163 */       log.debug("Send ClientIdChange event");
/*     */     }
/*     */   }
/*     */ 
/*     */   public long getServerReconnectTreshold()
/*     */   {
/* 194 */     return this.prefs.getLong("server.reconnect.treshold.time", 30000L);
/*     */   }
/*     */ 
/*     */   public void setServerReconnectTreshold(long serverReconnectTreshold)
/*     */   {
/* 204 */     this.prefs.putLong("server.reconnect.treshold.time", serverReconnectTreshold);
/*     */   }
/*     */ 
/*     */   public class ClientIdChangeEvent
/*     */   {
/*     */     private ClientId clientId;
/*     */     private boolean idChanged;
/*     */     private boolean nameChanged;
/*     */ 
/*     */     public ClientIdChangeEvent(ClientId paramClientId, boolean paramBoolean1, boolean paramBoolean2)
/*     */     {
/* 174 */       this.clientId = paramClientId;
/* 175 */       this.idChanged = paramBoolean1;
/* 176 */       this.nameChanged = paramBoolean2;
/*     */     }
/*     */ 
/*     */     public ClientId getClientId() {
/* 180 */       return this.clientId;
/*     */     }
/*     */ 
/*     */     public boolean isNameChanged() {
/* 184 */       return this.nameChanged;
/*     */     }
/*     */ 
/*     */     public boolean isIdChanged() {
/* 188 */       return this.idChanged;
/*     */     }
/*     */   }
/*     */ }