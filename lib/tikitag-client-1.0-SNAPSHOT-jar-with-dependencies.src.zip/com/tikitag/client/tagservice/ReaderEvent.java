/*    */ package com.tikitag.client.tagservice;
/*    */ 
/*    */ import com.tikitag.ons.model.util.ReaderId;
/*    */ 
/*    */ public class ReaderEvent
/*    */ {
/*    */   private final ReaderId readerId;
/*    */   private final ReaderEventType eventType;
/*    */ 
/*    */   public ReaderEvent(ReaderId readerId, ReaderEventType eventType)
/*    */   {
/* 19 */     this.readerId = readerId;
/* 20 */     this.eventType = eventType;
/*    */   }
/*    */ 
/*    */   public ReaderId getReaderId() {
/* 24 */     return this.readerId;
/*    */   }
/*    */ 
/*    */   public ReaderEventType getEventType() {
/* 28 */     return this.eventType;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 33 */     return "ReaderEvent[" + this.readerId + ", " + this.eventType + "]";
/*    */   }
/*    */ 
/*    */   public static enum ReaderEventType
/*    */   {
/* 14 */     READER_ADDED, READER_REMOVED, READER_FAILURE;
/*    */   }
/*    */ }