/*     */ package com.tikitag.client.tagservice;
/*     */ 
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import com.tikitag.util.KeyProvider;
/*     */ import com.tikitag.util.TikitagHashFactory;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Arrays;
/*     */ 
/*     */ public class GenuineTikitagHelper
/*     */ {
/*     */   private static final String LOCK = "FF7F";
/*     */   private static final String OTP1 = "E1";
/*     */   private static final String OTP2 = "10";
/*     */   private static final String OTP3 = "06";
/*     */   private static final String OTP4 = "00";
/*     */   private static final String NFC1 = "03";
/*     */   private static final String NFC2 = "1D";
/*     */   private static final String URL_H1 = "D1";
/*     */   private static final String URL_H2 = "01";
/*     */   private static final String URL_H3 = "19";
/*     */   private static final String URL_H4 = "55";
/*     */   private static final String URL_H5 = "01";
/*     */   public static final String URL_PREFIX = "747461672E62652F6D2F";
/*     */   public static final String FOR_FUTURE_USE = "00000000";
/*     */   private static final int HASH_OFFSET = 47;
/*     */   private final TikitagHashFactory hashFactory;
/*     */ 
/*     */   public GenuineTikitagHelper(KeyProvider keyProvider)
/*     */   {
/*  37 */     this.hashFactory = new TikitagHashFactory(keyProvider);
/*     */   }
/*     */ 
/*     */   public String getLockPage()
/*     */   {
/*  42 */     return "FF7F";
/*     */   }
/*     */ 
/*     */   public String getOtpPage() {
/*  46 */     return "E1100600";
/*     */   }
/*     */ 
/*     */   public String getTagData(TagId tagId) {
/*     */     try {
/*  51 */       return "031DD101195501747461672E62652F6D2F" + HexFormatter.toHexString(tagId.getIdentifier().getBytes("US-ASCII")) + HexFormatter.toHexString(this.hashFactory.generate(tagId.asByteArray())) + "00000000";
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/*  54 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isContentValid(TagInfo tag, boolean includeLock)
/*     */   {
/*  65 */     if (!(isMifareUltralight(tag)))
/*     */     {
/*  67 */       return false;
/*     */     }
/*  69 */     String expectedHex = "";
/*  70 */     if (includeLock) {
/*  71 */       expectedHex = getLockPage();
/*     */     }
/*  73 */     expectedHex = expectedHex + getOtpPage() + getTagData(tag.getTagId());
/*  74 */     byte[] expectedMemory = HexFormatter.fromHexString(expectedHex);
/*     */ 
/*  76 */     byte[] tikitagTagData = new byte[expectedMemory.length];
/*  77 */     System.arraycopy(tag.getTagData(), (includeLock) ? 10 : 12, tikitagTagData, 0, tikitagTagData.length);
/*     */ 
/*  79 */     return Arrays.equals(expectedMemory, tikitagTagData);
/*     */   }
/*     */ 
/*     */   public boolean isEmptyTag(TagInfo tag) {
/*  83 */     LockMode lockMode = determineLockMode(tag);
/*  84 */     if (lockMode != LockMode.UNLOCKED) {
/*  85 */       return false;
/*     */     }
/*     */ 
/*  88 */     byte[] otpPage = new byte[4];
/*  89 */     System.arraycopy(tag.getTagData(), 12, otpPage, 0, otpPage.length);
/*     */ 
/*  91 */     return Arrays.equals(otpPage, HexFormatter.fromHexString("00000000"));
/*     */   }
/*     */ 
/*     */   public boolean isInitable(TagInfo tag) {
/*  95 */     LockMode lockMode = determineLockMode(tag);
/*  96 */     if (lockMode != LockMode.UNLOCKED) {
/*  97 */       return false;
/*     */     }
/*     */ 
/* 100 */     byte[] otpPage = new byte[4];
/* 101 */     System.arraycopy(tag.getTagData(), 12, otpPage, 0, otpPage.length);
/*     */ 
/* 103 */     return ((Arrays.equals(otpPage, HexFormatter.fromHexString("00000000"))) || (Arrays.equals(otpPage, HexFormatter.fromHexString(getOtpPage()))));
/*     */   }
/*     */ 
/*     */   private boolean isMifareUltralight(TagInfo tag) {
/* 107 */     return ((tag.getTagId().asByteArray().length == 7) && (tag.getTagData().length == 64));
/*     */   }
/*     */ 
/*     */   public boolean isHashValid(TagInfo tag) {
/* 111 */     if (!(isMifareUltralight(tag)))
/*     */     {
/* 113 */       return false;
/*     */     }
/* 115 */     byte[] expectedHash = this.hashFactory.generate(tag.getTagId().asByteArray());
/* 116 */     byte[] retrievedHash = new byte[expectedHash.length];
/* 117 */     System.arraycopy(tag.getTagData(), 47, retrievedHash, 0, retrievedHash.length);
/* 118 */     return Arrays.equals(expectedHash, retrievedHash);
/*     */   }
/*     */ 
/*     */   public LockMode determineLockMode(TagInfo tag)
/*     */   {
/* 126 */     if (!(isMifareUltralight(tag)))
/*     */     {
/* 128 */       return LockMode.UNKNOWN;
/*     */     }
/*     */ 
/* 131 */     byte[] lockBytes = new byte[2];
/* 132 */     System.arraycopy(tag.getTagData(), 10, lockBytes, 0, lockBytes.length);
/*     */ 
/* 134 */     if ((lockBytes[0] == 0) && (lockBytes[1] == 0))
/* 135 */       return LockMode.UNLOCKED;
/* 136 */     if (Arrays.equals(lockBytes, HexFormatter.fromHexString("FF7F"))) {
/* 137 */       return LockMode.TIKITAG_LOCK;
/*     */     }
/* 139 */     return LockMode.PARTIAL_LOCK;
/*     */   }
/*     */ 
/*     */   public static enum LockMode
/*     */   {
/* 121 */     UNKNOWN, UNLOCKED, PARTIAL_LOCK, TIKITAG_LOCK;
/*     */   }
/*     */ }