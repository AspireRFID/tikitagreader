/*    */ package com.tikitag.client.actionlauncher;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class FallbackApplication
/*    */   implements Application
/*    */ {
/*    */   public static final String ID = "tikitag.standard.fallback";
/*    */ 
/*    */   public String getId()
/*    */   {
/* 13 */     return "tikitag.standard.fallback";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui) {
/* 17 */     ui.showStatusMessage("Unsupported Application", "Detected tag requires additional application: " + action.getName(), UiNotification.MessageType.WARNING);
/*    */   }
/*    */ }