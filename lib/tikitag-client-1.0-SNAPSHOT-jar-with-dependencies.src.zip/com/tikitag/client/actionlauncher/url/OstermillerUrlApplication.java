/*    */ package com.tikitag.client.actionlauncher.url;
/*    */ 
/*    */ import com.Ostermiller.util.Browser;
/*    */ import com.tikitag.client.actionlauncher.Application;
/*    */ import com.tikitag.client.actionlauncher.UiNotification;
/*    */ import com.tikitag.client.actionlauncher.UiNotification.MessageType;
/*    */ import com.tikitag.ons.block.actioncontext.UrlActionContext;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.io.IOException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class OstermillerUrlApplication
/*    */   implements Application
/*    */ {
/* 18 */   private static final Logger log = Logger.getLogger(OstermillerUrlApplication.class);
/*    */ 
/*    */   public OstermillerUrlApplication() {
/* 21 */     Browser.init();
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 25 */     return "tikitag.standard.url";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui) {
/* 29 */     String url = UrlActionContext.fromActionContext(action).getUrl();
/*    */     try {
/* 31 */       log.debug("Launching " + url);
/* 32 */       ui.showStatusMessage("Tikitag URL", "Opening " + url, UiNotification.MessageType.INFO);
/* 33 */       Browser.displayURL(url);
/* 34 */       log.debug("Browser opened on " + url);
/*    */     } catch (IOException e) {
/* 36 */       log.error("Failed to open " + url + " in a browser");
/* 37 */       ui.showStatusMessage("Tikitag URL Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     }
/*    */   }
/*    */ }