/*    */ package com.tikitag.client.actionlauncher.url;
/*    */ 
/*    */ import com.tikitag.client.actionlauncher.Application;
/*    */ import com.tikitag.client.actionlauncher.UiNotification;
/*    */ import com.tikitag.client.actionlauncher.UiNotification.MessageType;
/*    */ import com.tikitag.ons.block.actioncontext.UrlActionContext;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.awt.Desktop;
/*    */ import java.awt.Desktop.Action;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DesktopApiUrlApplication
/*    */   implements Application
/*    */ {
/* 20 */   private static final Logger log = Logger.getLogger(DesktopApiUrlApplication.class);
/*    */   private final Desktop desktop;
/*    */ 
/*    */   public DesktopApiUrlApplication()
/*    */   {
/* 25 */     if (!(Desktop.isDesktopSupported())) {
/* 26 */       throw new UnsupportedOperationException("Your platform does not seem to support the Java SE 6 Desktop API");
/*    */     }
/* 28 */     this.desktop = Desktop.getDesktop();
/* 29 */     if (!(this.desktop.isSupported(Desktop.Action.BROWSE)))
/* 30 */       throw new UnsupportedOperationException("Your platform does not seem to support the browse action");
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 35 */     return "tikitag.standard.url";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui) {
/* 39 */     String url = UrlActionContext.fromActionContext(action).getUrl();
/*    */     try {
/* 41 */       log.debug("Launching " + url);
/* 42 */       ui.showStatusMessage("Tikitag URL", "Opening " + url, UiNotification.MessageType.INFO);
/* 43 */       this.desktop.browse(new URI(url));
/* 44 */       log.debug("Browser opened on " + url);
/*    */     } catch (URISyntaxException e) {
/* 46 */       log.error("Failed to launch " + url + ": ", e);
/* 47 */       ui.showStatusMessage("Tikitag URL Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     } catch (IOException e) {
/* 49 */       log.error("Failed to launch " + url + ": ", e);
/* 50 */       ui.showStatusMessage("Tikitag URL Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     }
/*    */   }
/*    */ }