/*   */ package com.tikitag.client.actionlauncher;
/*   */ 
/*   */ public abstract interface UiNotification
/*   */ {
/*   */   public abstract void showStatusMessage(String paramString1, String paramString2, MessageType paramMessageType);
/*   */ 
/*   */   public static enum MessageType
/*   */   {
/* 8 */     INFO, WARNING, ERROR;
/*   */   }
/*   */ }