package com.tikitag.client.actionlauncher;

import com.tikitag.util.config.xml.ConfigContainer;

public abstract interface Application
{
  public abstract String getId();

  public abstract void handleAction(ConfigContainer paramConfigContainer, UiNotification paramUiNotification);
}