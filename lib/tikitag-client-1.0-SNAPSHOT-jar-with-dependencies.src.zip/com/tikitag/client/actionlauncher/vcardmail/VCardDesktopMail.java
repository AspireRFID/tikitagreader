/*    */ package com.tikitag.client.actionlauncher.vcardmail;
/*    */ 
/*    */ import com.tikitag.client.actionlauncher.Application;
/*    */ import com.tikitag.client.actionlauncher.UiNotification;
/*    */ import com.tikitag.client.actionlauncher.UiNotification.MessageType;
/*    */ import com.tikitag.ons.block.actioncontext.VCardActionContext;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.awt.Desktop;
/*    */ import java.awt.Desktop.Action;
/*    */ import java.io.IOException;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ 
/*    */ public class VCardDesktopMail
/*    */   implements Application
/*    */ {
/*    */   private final Desktop desktop;
/*    */ 
/*    */   public VCardDesktopMail()
/*    */   {
/* 26 */     if (!(Desktop.isDesktopSupported())) {
/* 27 */       throw new UnsupportedOperationException("Your platform does not seem to support the Java SE 6 Desktop API");
/*    */     }
/* 29 */     this.desktop = Desktop.getDesktop();
/* 30 */     if (!(this.desktop.isSupported(Desktop.Action.MAIL)))
/* 31 */       throw new UnsupportedOperationException("Your platform does not seem to support the mail action");
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 37 */     return "tikitag.standard.vcard";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui)
/*    */   {
/* 42 */     String address = "mailto:" + VCardActionContext.fromActionContext(action).getEmail();
/*    */     try {
/* 44 */       ui.showStatusMessage("Tikitag VCard", "Opening " + address, UiNotification.MessageType.INFO);
/* 45 */       this.desktop.mail(new URI(address));
/*    */     } catch (URISyntaxException e) {
/* 47 */       ui.showStatusMessage("Tikitag URL Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     } catch (IOException e) {
/* 49 */       ui.showStatusMessage("Tikitag URL Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     }
/*    */   }
/*    */ }