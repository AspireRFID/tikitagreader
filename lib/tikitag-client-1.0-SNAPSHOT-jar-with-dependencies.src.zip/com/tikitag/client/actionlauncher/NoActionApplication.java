/*    */ package com.tikitag.client.actionlauncher;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class NoActionApplication
/*    */   implements Application
/*    */ {
/* 12 */   private static final Logger log = Logger.getLogger(NoActionApplication.class);
/*    */ 
/*    */   public String getId() {
/* 15 */     return "tikitag.standard.noaction";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui)
/*    */   {
/* 20 */     log.debug("Server instructed to do nothing");
/*    */   }
/*    */ }