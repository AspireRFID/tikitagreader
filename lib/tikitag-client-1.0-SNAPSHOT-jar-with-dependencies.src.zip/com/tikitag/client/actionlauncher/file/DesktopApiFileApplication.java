/*    */ package com.tikitag.client.actionlauncher.file;
/*    */ 
/*    */ import com.tikitag.client.actionlauncher.Application;
/*    */ import com.tikitag.client.actionlauncher.UiNotification;
/*    */ import com.tikitag.client.actionlauncher.UiNotification.MessageType;
/*    */ import com.tikitag.ons.block.actioncontext.FileActionContext;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.awt.Desktop;
/*    */ import java.awt.Desktop.Action;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class DesktopApiFileApplication
/*    */   implements Application
/*    */ {
/* 19 */   private static final Logger log = Logger.getLogger(DesktopApiFileApplication.class);
/*    */   private final Desktop desktop;
/*    */ 
/*    */   public DesktopApiFileApplication()
/*    */   {
/* 24 */     if (!(Desktop.isDesktopSupported())) {
/* 25 */       throw new UnsupportedOperationException("Your platform does not seem to support the Java SE 6 Desktop API");
/*    */     }
/* 27 */     this.desktop = Desktop.getDesktop();
/* 28 */     if (!(this.desktop.isSupported(Desktop.Action.OPEN)))
/* 29 */       throw new UnsupportedOperationException("Your platform does not seem to support the open action");
/*    */   }
/*    */ 
/*    */   public String getId()
/*    */   {
/* 34 */     return "tikitag.standard.file";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui) {
/* 38 */     String file = FileActionContext.fromActionContext(action).getFile();
/*    */     try {
/* 40 */       log.debug("Opening " + file);
/* 41 */       ui.showStatusMessage("Tikitag File", "Opening " + file, UiNotification.MessageType.INFO);
/* 42 */       this.desktop.open(new File(file));
/* 43 */       log.debug("Opened file " + file);
/*    */     } catch (IllegalArgumentException e) {
/* 45 */       log.error("The file " + file + " doesn't exist ", e);
/* 46 */       ui.showStatusMessage("Tikitag File Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     } catch (IOException e) {
/* 48 */       log.error("No associated application for " + file + ": ", e);
/* 49 */       ui.showStatusMessage("Tikitag File Failed", e.getMessage(), UiNotification.MessageType.ERROR);
/*    */     }
/*    */   }
/*    */ }