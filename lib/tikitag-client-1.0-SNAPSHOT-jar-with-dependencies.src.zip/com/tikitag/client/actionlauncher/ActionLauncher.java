/*    */ package com.tikitag.client.actionlauncher;
/*    */ 
/*    */ import com.tikitag.client.TikitagServer;
/*    */ import com.tikitag.client.factory.AuthenticationException;
/*    */ import com.tikitag.client.tagservice.TagMonitor;
/*    */ import com.tikitag.ons.TikitagAction;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class ActionLauncher
/*    */   implements TagMonitor
/*    */ {
/* 21 */   private static final Logger m_log = Logger.getLogger(ActionLauncher.class);
/*    */   private final TikitagServer server;
/*    */   private final Application defaultApplication;
/*    */   private final UiNotification uiNotification;
/* 27 */   private final Map<String, Application> applications = new HashMap();
/*    */ 
/*    */   public ActionLauncher(TikitagServer server, Application defaultApplication, UiNotification uiNotification)
/*    */   {
/* 36 */     if ((server == null) || (defaultApplication == null)) {
/* 37 */       throw new IllegalArgumentException("Neither server or defaultApplication is allowed to be null");
/*    */     }
/*    */ 
/* 40 */     this.server = server;
/* 41 */     this.defaultApplication = defaultApplication;
/* 42 */     this.uiNotification = uiNotification;
/*    */   }
/*    */ 
/*    */   public void registerApplication(Application application) {
/* 46 */     this.applications.put(application.getId(), application);
/*    */   }
/*    */ 
/*    */   public void unregisterApplication(Application application) {
/* 50 */     this.applications.remove(application.getId());
/*    */   }
/*    */ 
/*    */   public void onTagEvent(TagEvent tagEvent) {
/*    */     ConfigContainer action;
/*    */     try {
/* 56 */       action = this.server.getTikitagAction(tagEvent).getContainer();
/*    */     } catch (AuthenticationException authE) {
/* 58 */       this.uiNotification.showStatusMessage("Tikitag Server Authentication Failure", "Failed to authenticate with Tikitag Server, please check your login credentials", UiNotification.MessageType.ERROR);
/* 59 */       m_log.error("Tikitag Server Authentication Failure", authE);
/* 60 */       return;
/*    */     } catch (Exception e) {
/* 62 */       this.uiNotification.showStatusMessage("Tikitag Server Failure", "Failed to communicate with server, see the log file for more details", UiNotification.MessageType.ERROR);
/* 63 */       m_log.error("Tikitag Server Failure", e);
/* 64 */       return;
/*    */     }
/* 66 */     Application application = (Application)this.applications.get(action.getName());
/* 67 */     if (application == null) {
/* 68 */       m_log.warn(action.getName() + " is not supported by this client. Delegating to default applicaton...");
/*    */ 
/* 70 */       application = this.defaultApplication;
/*    */     }
/*    */     try {
/* 73 */       application.handleAction(action, this.uiNotification);
/*    */     } catch (Exception e) {
/* 75 */       m_log.error(application.getId() + " encountered a problem while handling " + action, e);
/*    */     }
/*    */   }
/*    */ }