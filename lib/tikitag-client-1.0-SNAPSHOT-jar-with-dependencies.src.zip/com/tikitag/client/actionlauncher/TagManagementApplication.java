/*    */ package com.tikitag.client.actionlauncher;
/*    */ 
/*    */ import com.tikitag.ons.block.actioncontext.TagManagementActionContext;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class TagManagementApplication
/*    */   implements Application
/*    */ {
/*    */   public String getId()
/*    */   {
/* 13 */     return "tikitag.standard.tagManagement";
/*    */   }
/*    */ 
/*    */   public void handleAction(ConfigContainer action, UiNotification ui) {
/* 17 */     ui.showStatusMessage("Tag Management", TagManagementActionContext.fromActionContext(action).getMessage(), UiNotification.MessageType.INFO);
/*    */   }
/*    */ }