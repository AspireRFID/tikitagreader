/*     */ package com.tikitag.client;
/*     */ 
/*     */ import com.tikitag.client.factory.AuthenticationException;
/*     */ import com.tikitag.client.factory.ConnectionException;
/*     */ import com.tikitag.client.tagservice.ReaderEvent;
/*     */ import com.tikitag.client.tagservice.ReaderEvent.ReaderEventType;
/*     */ import com.tikitag.client.tagservice.ReaderMonitor;
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration.ClientIdChangeEvent;
/*     */ import com.tikitag.client.tagservice.TagServiceConfigurationListener;
/*     */ import com.tikitag.client.tagservice.impl.Acr122TagReader;
/*     */ import com.tikitag.ons.model.util.ChangeEvent;
/*     */ import com.tikitag.ons.model.util.ClientId;
/*     */ import com.tikitag.ons.model.util.ClientNameChange;
/*     */ import com.tikitag.ons.model.util.NewReaderEvent;
/*     */ import com.tikitag.ons.model.util.PingEvent;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import java.util.prefs.Preferences;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class ClientLifecycleHandler
/*     */   implements ReaderMonitor, TagServiceConfigurationListener
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(Acr122TagReader.class);
/*  29 */   private final Preferences prefs = Preferences.userNodeForPackage(ClientLifecycleHandler.class);
/*     */   private static final String READERSERIAL = "readers.list.snreader";
/*     */   private static final String READERINDEX = "readers.index";
/*     */   private TikitagServer server;
/*     */   private final TagServiceConfiguration tagServiceConfiguration;
/*  37 */   private List<ClientLifecycleListener> listeners = new ArrayList();
/*     */ 
/*  39 */   private Timer serverResendTimer = null;
/*     */ 
/*  41 */   private ChangeEvent failedChangeEvent = null;
/*  42 */   private PingEvent failedPingEvent = null;
/*     */ 
/*     */   public ClientLifecycleHandler(TikitagServer server, TagServiceConfiguration tagServiceConfiguration)
/*     */   {
/*  46 */     this.tagServiceConfiguration = tagServiceConfiguration;
/*  47 */     this.server = server;
/*  48 */     tagServiceConfiguration.addTagServiceConfigurationListener(this);
/*     */   }
/*     */ 
/*     */   public void onReaderEvent(ReaderEvent readerEvent)
/*     */   {
/*  54 */     if (!(readerEvent.getEventType().equals(ReaderEvent.ReaderEventType.READER_ADDED)))
/*     */       return;
/*  56 */     String readerSn = readerEvent.getReaderId().getSerialNr();
/*  57 */     boolean readerFound = false;
/*  58 */     for (int i = 1; i <= this.prefs.getInt("readers.index", 0); ++i) {
/*  59 */       if (readerSn.equals(this.prefs.get("readers.list.snreader." + i, null))) {
/*  60 */         readerFound = true;
/*     */       }
/*     */     }
/*  63 */     if (!(readerFound)) {
/*  64 */       int newReaderIndex = this.prefs.getInt("readers.index", 0) + 1;
/*  65 */       this.prefs.putInt("readers.index", newReaderIndex);
/*  66 */       this.prefs.put("readers.list.snreader." + newReaderIndex, readerSn);
/*  67 */       NewReaderEvent newReaderEvent = new NewReaderEvent(readerEvent.getReaderId());
/*  68 */       ChangeEvent changeEvent = new ChangeEvent(this.tagServiceConfiguration.getClientId(), newReaderEvent);
/*  69 */       fireChangeEvent(changeEvent);
/*     */     } else {
/*  71 */       log.debug("New reader detected, but already discovered, no further action.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void onClientIdChange(TagServiceConfiguration.ClientIdChangeEvent clientIdChange)
/*     */   {
/*  78 */     if (!(clientIdChange.isNameChanged()))
/*     */       return;
/*  80 */     ChangeEvent changeEvent = new ChangeEvent(this.tagServiceConfiguration.getClientId(), new ClientNameChange(clientIdChange.getClientId().getName()));
/*  81 */     fireChangeEvent(changeEvent);
/*     */   }
/*     */ 
/*     */   private void fireChangeEvent(ChangeEvent changeEvent)
/*     */   {
/*     */     try {
/*  87 */       this.server.changeEvent(changeEvent);
/*     */     } catch (AuthenticationException authE) {
/*  89 */       log.error("Tikitag Server Authentication Failure", authE);
/*  90 */       this.failedChangeEvent = changeEvent;
/*  91 */       resendChangeEvent();
/*  92 */       return;
/*     */     } catch (ConnectionException connE) {
/*  94 */       log.error("Tikitag Server Connection Failure", connE);
/*  95 */       this.failedChangeEvent = changeEvent;
/*  96 */       resendChangeEvent();
/*  97 */       return;
/*     */     } catch (Exception e) {
/*  99 */       log.error("Tikitag Server Failure", e);
/* 100 */       this.failedChangeEvent = changeEvent;
/* 101 */       resendChangeEvent();
/* 102 */       return;
/*     */     }
/* 104 */     log.debug("New reader discovered, stored in registry and notified server.");
/*     */   }
/*     */ 
/*     */   public void onTikitagClientStarted()
/*     */   {
/* 110 */     PingEvent pingEvent = new PingEvent(this.tagServiceConfiguration.getClientId());
/* 111 */     firePingEvent(pingEvent);
/*     */   }
/*     */ 
/*     */   private void resendChangeEvent() {
/* 115 */     if (this.failedChangeEvent != null) {
/* 116 */       this.serverResendTimer = new Timer("Try Reconnect Server Timer", true);
/* 117 */       this.serverResendTimer.schedule(new TimerTask()
/*     */       {
/*     */         public void run()
/*     */         {
/* 121 */           synchronized (ClientLifecycleHandler.this) {
/* 122 */             ClientLifecycleHandler.this.fireChangeEvent(ClientLifecycleHandler.this.failedChangeEvent);
/*     */           }
/*     */         }
/*     */       }
/*     */       , this.tagServiceConfiguration.getServerReconnectTreshold());
/*     */     }
/*     */     else
/*     */     {
/* 128 */       log.error("No failed ChangeEvent stored, could not resend event to server.");
/*     */     }
/*     */   }
/*     */ 
/*     */   private void resendPingEvent() {
/* 133 */     if (this.failedPingEvent != null) {
/* 134 */       this.serverResendTimer = new Timer("Try Reconnect Server Timer", true);
/* 135 */       this.serverResendTimer.schedule(new TimerTask()
/*     */       {
/*     */         public void run()
/*     */         {
/* 139 */           synchronized (ClientLifecycleHandler.this) {
/* 140 */             ClientLifecycleHandler.this.firePingEvent(ClientLifecycleHandler.this.failedPingEvent);
/*     */           }
/*     */         }
/*     */       }
/*     */       , this.tagServiceConfiguration.getServerReconnectTreshold());
/*     */     }
/*     */     else
/*     */     {
/* 147 */       log.error("No failed ChangeEvent stored, could not resend event to server."); }
/*     */   }
/*     */ 
/*     */   private void firePingEvent(PingEvent pingEvent) {
/*     */     ClientStatusChangeEvent event;
/*     */     try {
/* 153 */       this.server.ping(pingEvent);
/*     */     } catch (AuthenticationException authE) {
/* 155 */       event = new ClientStatusChangeEvent(ClientStatusChangeEvent.ClientStatus.NOT_AUTHENTICATED);
/* 156 */       fireClientStatusChangeEvent(event);
/* 157 */       log.error("Tikitag Server Authentication Failure", authE);
/* 158 */       this.failedPingEvent = pingEvent;
/* 159 */       resendPingEvent();
/* 160 */       return;
/*     */     } catch (ConnectionException connE) {
/* 162 */       event = new ClientStatusChangeEvent(ClientStatusChangeEvent.ClientStatus.NOT_CONNECTED);
/* 163 */       fireClientStatusChangeEvent(event);
/* 164 */       log.error("Tikitag Server Connection Failure", connE);
/* 165 */       this.failedPingEvent = pingEvent;
/* 166 */       resendPingEvent();
/* 167 */       return;
/*     */     } catch (Exception e) {
/* 169 */       event = new ClientStatusChangeEvent(ClientStatusChangeEvent.ClientStatus.NOT_CONNECTED);
/* 170 */       fireClientStatusChangeEvent(event);
/* 171 */       log.error("Tikitag Server Failure", e);
/* 172 */       this.failedPingEvent = pingEvent;
/* 173 */       resendPingEvent();
/* 174 */       return;
/*     */     }
/* 176 */     ClientStatusChangeEvent event = new ClientStatusChangeEvent(ClientStatusChangeEvent.ClientStatus.CONNECTED);
/* 177 */     fireClientStatusChangeEvent(event);
/* 178 */     log.debug("Client started, pinged server.");
/*     */   }
/*     */ 
/*     */   private void fireClientStatusChangeEvent(ClientStatusChangeEvent event)
/*     */   {
/* 183 */     for (ClientLifecycleListener listener : this.listeners)
/* 184 */       listener.onClientStatusCange(event);
/*     */   }
/*     */ 
/*     */   public void addClientLifecycleListener(ClientLifecycleListener listener)
/*     */   {
/* 189 */     this.listeners.add(listener);
/*     */   }
/*     */ 
/*     */   public void removeClientLifecycleListener(ClientLifecycleListener listener) {
/* 193 */     this.listeners.remove(listener);
/*     */   }
/*     */ }