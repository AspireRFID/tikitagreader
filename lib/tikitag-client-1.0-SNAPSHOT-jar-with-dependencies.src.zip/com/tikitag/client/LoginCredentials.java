/*    */ package com.tikitag.client;
/*    */ 
/*    */ import java.util.prefs.Preferences;
/*    */ 
/*    */ public class LoginCredentials
/*    */ {
/*    */   private static final String ANONYMOUS_KEY = "isAnonymous";
/*    */   private static final String USERNAME_KEY = "username";
/*    */   private static final String PASSWORD_KEY = "password";
/*    */   private final Preferences prefs;
/*    */ 
/*    */   public LoginCredentials()
/*    */   {
/* 11 */     this.prefs = Preferences.userNodeForPackage(LoginCredentials.class); }
/*    */ 
/*    */   public boolean isAnonymous() {
/* 14 */     return this.prefs.getBoolean("isAnonymous", true);
/*    */   }
/*    */ 
/*    */   public String getUsername() {
/* 18 */     return this.prefs.get("username", "");
/*    */   }
/*    */ 
/*    */   public String getPassword()
/*    */   {
/* 23 */     return this.prefs.get("password", "");
/*    */   }
/*    */ 
/*    */   public void setCredentials(String username, String password) {
/* 27 */     this.prefs.putBoolean("isAnonymous", false);
/* 28 */     this.prefs.put("username", username);
/*    */ 
/* 30 */     this.prefs.put("password", password);
/*    */   }
/*    */ 
/*    */   public void setAnonymous() {
/* 34 */     this.prefs.putBoolean("isAnonymous", true);
/* 35 */     this.prefs.put("username", "");
/* 36 */     this.prefs.put("password", "");
/*    */   }
/*    */ }