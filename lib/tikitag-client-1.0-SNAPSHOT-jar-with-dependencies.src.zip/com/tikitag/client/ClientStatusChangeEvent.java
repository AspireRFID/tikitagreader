/*    */ package com.tikitag.client;
/*    */ 
/*    */ public class ClientStatusChangeEvent
/*    */ {
/*    */   private ClientStatus status;
/*    */ 
/*    */   public ClientStatusChangeEvent(ClientStatus status)
/*    */   {
/* 11 */     this.status = status;
/*    */   }
/*    */ 
/*    */   public ClientStatus getStatus() {
/* 15 */     return this.status;
/*    */   }
/*    */ 
/*    */   public static enum ClientStatus
/*    */   {
/*  6 */     NOT_AUTHENTICATED, CONNECTED, NOT_CONNECTED;
/*    */   }
/*    */ }