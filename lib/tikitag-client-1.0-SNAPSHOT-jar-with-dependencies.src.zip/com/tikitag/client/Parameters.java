/*    */ package com.tikitag.client;
/*    */ 
/*    */ import java.io.PrintStream;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public class Parameters
/*    */ {
/*  6 */   private static final Logger log = Logger.getLogger(Parameters.class);
/*    */   private String interfaceIdentifier;
/*    */   private String endpointLocation;
/*    */ 
/*    */   public Parameters(String interfaceIdentifier, String endpointLocation, String proxyHost, String proxyPort)
/*    */   {
/* 12 */     log.debug("Parameters(" + interfaceIdentifier + ", " + endpointLocation + ", " + proxyHost + ", " + proxyPort + ")");
/*    */ 
/* 14 */     if (interfaceIdentifier == null)
/* 15 */       this.interfaceIdentifier = "rmi://localhost";
/*    */     else {
/* 17 */       this.interfaceIdentifier = interfaceIdentifier;
/*    */     }
/* 19 */     this.endpointLocation = endpointLocation;
/* 20 */     if (proxyHost != null) {
/* 21 */       log.debug("Setting http.proxyHost to " + proxyHost);
/* 22 */       System.setProperty("http.proxyHost", proxyHost);
/*    */     }
/* 24 */     if (proxyPort != null) {
/* 25 */       log.debug("Setting http.proxyPort to " + proxyPort);
/* 26 */       System.setProperty("http.proxyPort", proxyPort);
/*    */     }
/*    */   }
/*    */ 
/*    */   public static Parameters parse(String[] args) {
/* 31 */     String interfaceIdentifier = null;
/* 32 */     String endpointLocation = null;
/* 33 */     String proxyHost = null;
/* 34 */     String proxyPort = null;
/*    */ 
/* 36 */     for (String arg : args) {
/* 37 */       log.debug("Analyzing parameter: " + arg);
/* 38 */       String[] splittedArg = arg.split("=");
/* 39 */       if (log.isDebugEnabled()) {
/* 40 */         for (String argPart : splittedArg) {
/* 41 */           log.debug("  parameter part: " + argPart);
/*    */         }
/*    */       }
/*    */ 
/* 45 */       if (splittedArg.length == 2) {
/* 46 */         String paramId = splittedArg[0];
/* 47 */         String paramValue = splittedArg[1];
/* 48 */         if (paramId.equals("proxy")) {
/* 49 */           String[] proxyParts = paramValue.split(":");
/* 50 */           proxyHost = proxyParts[0];
/* 51 */           if (proxyParts.length == 2)
/* 52 */             proxyPort = proxyParts[1];
/*    */         }
/* 54 */         else if (paramId.equals("if")) {
/* 55 */           interfaceIdentifier = paramValue;
/* 56 */         } else if (paramId.equals("endpoint")) {
/* 57 */           endpointLocation = paramValue;
/*    */         }
/*    */       } else {
/* 60 */         printUsage();
/* 61 */         break;
/*    */       }
/*    */     }
/*    */ 
/* 65 */     return new Parameters(interfaceIdentifier, endpointLocation, proxyHost, proxyPort);
/*    */   }
/*    */ 
/*    */   private static void printUsage() {
/* 69 */     System.out.println("The following parameters are supported:");
/* 70 */     System.out.println("if=<INTERFACE IDENTIFIER>");
/* 71 */     System.out.println("    Where INTERFACE IDENTIFIER is a URI indicating the interface to be used.");
/* 72 */     System.out.println("    The following formats are supported:");
/* 73 */     System.out.println("    urn:dummy                       A local dummy placeholder interface");
/* 74 */     System.out.println("    urn:local                       Reserved for use within our ACS, uses the EJB local interface");
/* 75 */     System.out.println("    rmi://<ip>[:<port>]             Contacts the server using RMI on the specified ip and port");
/* 76 */     System.out.println("    http://<ip>[:<port>]/<wsdlpath> Contacts the server using the SOAP web services as described by the WSDL");
/* 77 */     System.out.println("endpoint=<ENDPOINT LOCATION>");
/* 78 */     System.out.println("    Only supported on SOAP interfaces.");
/* 79 */     System.out.println("    Overrides the endpoint location of the WSDL");
/* 80 */     System.out.println("proxy=<PROXY HOST>[:<PROXY PORT>]");
/* 81 */     System.out.println("    Specifies a proxy server (used for SOAP)");
/*    */   }
/*    */ 
/*    */   public String getInterfaceIdentifier()
/*    */   {
/* 86 */     return this.interfaceIdentifier;
/*    */   }
/*    */ 
/*    */   public String getEndpointLocation() {
/* 90 */     return this.endpointLocation;
/*    */   }
/*    */ }