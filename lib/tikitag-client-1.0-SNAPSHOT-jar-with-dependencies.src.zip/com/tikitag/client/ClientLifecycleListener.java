package com.tikitag.client;

public abstract interface ClientLifecycleListener
{
  public abstract void onClientStatusCange(ClientStatusChangeEvent paramClientStatusChangeEvent);
}