package com.tikitag.client;

import com.tikitag.client.factory.AuthenticationException;
import com.tikitag.client.factory.ConnectionException;
import com.tikitag.ons.TikitagAction;
import com.tikitag.ons.model.util.ChangeEvent;
import com.tikitag.ons.model.util.PingEvent;
import com.tikitag.ons.model.util.TagEvent;
import java.net.URI;

public abstract interface TikitagServer
{
  public abstract TikitagAction getTikitagAction(TagEvent paramTagEvent)
    throws AuthenticationException, ConnectionException;

  public abstract void changeEvent(ChangeEvent paramChangeEvent)
    throws AuthenticationException, ConnectionException;

  public abstract URI getActualConnectionUri();

  public abstract void ping(PingEvent paramPingEvent)
    throws AuthenticationException, ConnectionException;
}