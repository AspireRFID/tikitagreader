/*     */ package com.tikitag.client.factory;
/*     */ 
/*     */ import com.tikitag.client.LoginCredentials;
/*     */ import com.tikitag.client.TikitagServer;
/*     */ import com.tikitag.ons.TikitagAction;
/*     */ import com.tikitag.ons.facade.CorrelatorException_Exception;
/*     */ import com.tikitag.ons.facade.remote.CorrelationProxy;
/*     */ import com.tikitag.ons.model.util.ChangeEvent;
/*     */ import com.tikitag.ons.model.util.PingEvent;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import java.net.MalformedURLException;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.net.URL;
/*     */ import java.util.Map;
/*     */ import javax.xml.namespace.QName;
/*     */ import javax.xml.ws.BindingProvider;
/*     */ import javax.xml.ws.Service;
/*     */ 
/*     */ class JAXWSServer
/*     */   implements TikitagServer
/*     */ {
/*     */   private static final String SERVICE_NAME = "CorrelationProxy";
/*     */   public static final String TARGET_NS = "http://www.tikitag.com";
/*     */   private final LoginCredentials loginCredentials;
/*     */   private URI wsdlUri;
/*     */   private URI endpointUri;
/*     */ 
/*     */   public JAXWSServer(URI wsdlUri, URI endpointUri)
/*     */   {
/*  37 */     this.loginCredentials = new LoginCredentials();
/*  38 */     if (!(wsdlUri.toString().endsWith("?wsdl")))
/*     */       try {
/*  40 */         wsdlUri = new URI("http://127.0.0.1:8080/tikitag-soap/correlation?wsdl");
/*     */       }
/*     */       catch (URISyntaxException e)
/*     */       {
/*     */       }
/*  45 */     this.wsdlUri = wsdlUri;
/*  46 */     this.endpointUri = endpointUri;
/*     */   }
/*     */ 
/*     */   public TikitagAction getTikitagAction(TagEvent tagEvent) throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try {
/*  52 */       CorrelationProxy proxy = (CorrelationProxy)getService("CorrelationProxy").getPort(CorrelationProxy.class);
/*  53 */       addProxyConfiguration(proxy);
/*  54 */       return proxy.getTikitagAction(tagEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/*  56 */       throw new RuntimeException(e);
/*     */     } catch (Exception e) {
/*  58 */       handleException(e);
/*     */     }
/*  60 */     return null;
/*     */   }
/*     */ 
/*     */   private void handleException(Exception e) throws AuthenticationException, ConnectionException
/*     */   {
/*  65 */     if ((e.getMessage() != null) && (e.getMessage().endsWith("Unauthorized"))) {
/*  66 */       throw new AuthenticationException(e);
/*     */     }
/*     */ 
/*  69 */     throw new ConnectionException(e);
/*     */   }
/*     */ 
/*     */   private void addProxyConfiguration(CorrelationProxy service)
/*     */   {
/*  74 */     BindingProvider proxy = (BindingProvider)service;
/*     */ 
/*  76 */     proxy.getRequestContext().put("javax.xml.ws.security.auth.username", this.loginCredentials.getUsername());
/*  77 */     proxy.getRequestContext().put("javax.xml.ws.security.auth.password", this.loginCredentials.getPassword());
/*     */ 
/*  80 */     if (this.endpointUri != null)
/*  81 */       proxy.getRequestContext().put("javax.xml.ws.service.endpoint.address", this.endpointUri.toString());
/*     */   }
/*     */ 
/*     */   public Service getService(String serviceName)
/*     */     throws MalformedURLException
/*     */   {
/*  91 */     QName qName = new QName("http://www.tikitag.com", serviceName);
/*  92 */     URL wsdlURL = this.wsdlUri.toURL();
/*  93 */     return Service.create(wsdlURL, qName);
/*     */   }
/*     */ 
/*     */   public URI getActualConnectionUri()
/*     */   {
/*  98 */     return this.wsdlUri;
/*     */   }
/*     */ 
/*     */   public void changeEvent(ChangeEvent changeEvent) throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try {
/* 104 */       CorrelationProxy proxy = (CorrelationProxy)getService("CorrelationProxy").getPort(CorrelationProxy.class);
/* 105 */       addProxyConfiguration(proxy);
/* 106 */       proxy.changeEvent(changeEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/* 108 */       throw new RuntimeException(e);
/*     */     } catch (Exception e) {
/* 110 */       handleException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ping(PingEvent pingEvent) throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try {
/* 117 */       CorrelationProxy proxy = (CorrelationProxy)getService("CorrelationProxy").getPort(CorrelationProxy.class);
/* 118 */       addProxyConfiguration(proxy);
/* 119 */       proxy.ping(pingEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/* 121 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (Exception e) {
/* 124 */       handleException(e);
/*     */     }
/*     */   }
/*     */ }