/*    */ package com.tikitag.client.factory;
/*    */ 
/*    */ import com.tikitag.client.LoginCredentials;
/*    */ import com.tikitag.client.TikitagServer;
/*    */ import com.tikitag.ons.TikitagAction;
/*    */ import com.tikitag.ons.facade.CorrelatorException_Exception;
/*    */ import com.tikitag.ons.facade.remote.CorrelationProxy;
/*    */ import com.tikitag.ons.model.util.ChangeEvent;
/*    */ import com.tikitag.ons.model.util.PingEvent;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import java.net.URI;
/*    */ import java.util.Properties;
/*    */ import javax.naming.Context;
/*    */ import javax.naming.InitialContext;
/*    */ import javax.naming.NamingException;
/*    */ 
/*    */ public class LocalServer
/*    */   implements TikitagServer
/*    */ {
/*    */   private static final String CORRELATION_FACADE_BEAN = "Tikitag/ONS/Facade/Correlation/local";
/*    */   private final LoginCredentials loginCredentials;
/*    */ 
/*    */   public LocalServer()
/*    */   {
/* 26 */     this.loginCredentials = new LoginCredentials();
/*    */   }
/*    */ 
/*    */   public URI getActualConnectionUri()
/*    */   {
/* 31 */     return URI.create("urn:local");
/*    */   }
/*    */ 
/*    */   public TikitagAction getTikitagAction(TagEvent tagEvent) throws AuthenticationException, ConnectionException
/*    */   {
/*    */     try {
/* 37 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext().lookup("Tikitag/ONS/Facade/Correlation/local");
/* 38 */       return proxy.getTikitagAction(tagEvent);
/*    */     } catch (CorrelatorException_Exception e) {
/* 40 */       throw new RuntimeException(e);
/*    */     }
/*    */     catch (Exception e) {
/* 43 */       if (e.getMessage().endsWith("Unauthorized")) {
/* 44 */         throw new AuthenticationException(e);
/*    */       }
/*    */ 
/* 47 */       throw new ConnectionException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   private Context getInitialContext() throws NamingException
/*    */   {
/* 53 */     Properties environment = new Properties();
/* 54 */     environment.setProperty("java.naming.security.principal", this.loginCredentials.getUsername());
/* 55 */     environment.setProperty("java.naming.security.credentials", this.loginCredentials.getPassword());
/* 56 */     environment.setProperty("java.naming.factory.initial", "org.jboss.security.jndi.JndiLoginInitialContextFactory");
/* 57 */     return new InitialContext(environment);
/*    */   }
/*    */ 
/*    */   public void changeEvent(ChangeEvent changeEvent) throws AuthenticationException, ConnectionException
/*    */   {
/*    */     try {
/* 63 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext().lookup("Tikitag/ONS/Facade/Correlation/local");
/* 64 */       proxy.changeEvent(changeEvent);
/*    */     } catch (CorrelatorException_Exception e) {
/* 66 */       throw new RuntimeException(e);
/*    */     }
/*    */     catch (Exception e) {
/* 69 */       if (e.getMessage().endsWith("Unauthorized")) {
/* 70 */         throw new AuthenticationException(e);
/*    */       }
/*    */ 
/* 73 */       throw new ConnectionException(e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void ping(PingEvent pingEvent)
/*    */     throws AuthenticationException, ConnectionException
/*    */   {
/*    */     try
/*    */     {
/* 82 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext().lookup("Tikitag/ONS/Facade/Correlation/local");
/* 83 */       proxy.ping(pingEvent);
/*    */     } catch (CorrelatorException_Exception e) {
/* 85 */       throw new RuntimeException(e);
/*    */     }
/*    */     catch (Exception e)
/*    */     {
/* 89 */       if (e.getMessage().endsWith("Unauthorized")) {
/* 90 */         throw new AuthenticationException(e);
/*    */       }
/*    */ 
/* 93 */       throw new ConnectionException(e);
/*    */     }
/*    */   }
/*    */ }