/*    */ package com.tikitag.client.factory;
/*    */ 
/*    */ import com.tikitag.client.TikitagServer;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ 
/*    */ public class TikitagServerFactory
/*    */ {
/*    */   public static TikitagServer newServer(String interfaceIdentifier, String endpointLocation)
/*    */   {
/*    */     try
/*    */     {
/* 33 */       URI interfaceUri = new URI(interfaceIdentifier);
/* 34 */       String protocol = interfaceUri.getScheme();
/* 35 */       if (interfaceUri.toString().equals("urn:dummy"))
/* 36 */         return new DummyTikitagServer();
/* 37 */       if (interfaceUri.toString().equals("urn:local"))
/* 38 */         return new LocalServer();
/* 39 */       if (protocol.equals("rmi"))
/* 40 */         return new RMIServer(interfaceUri);
/* 41 */       if (protocol.equals("http")) {
/* 42 */         URI endpointUri = null;
/* 43 */         if (endpointLocation != null) {
/* 44 */           endpointUri = new URI(endpointLocation);
/*    */         }
/* 46 */         return new JAXWSServer(interfaceUri, endpointUri);
/*    */       }
/* 48 */       throw new IllegalArgumentException("Unsupported remoting scheme '" + interfaceIdentifier + "'!");
/*    */     }
/*    */     catch (URISyntaxException urise) {
/* 51 */       throw new IllegalArgumentException("Invalid connection string!", urise);
/*    */     }
/*    */   }
/*    */ }