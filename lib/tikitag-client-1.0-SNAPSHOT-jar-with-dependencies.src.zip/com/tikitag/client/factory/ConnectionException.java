/*    */ package com.tikitag.client.factory;
/*    */ 
/*    */ public class ConnectionException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ConnectionException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ConnectionException(String message, Throwable cause)
/*    */   {
/* 14 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public ConnectionException(String message) {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public ConnectionException(Throwable cause) {
/* 22 */     super(cause);
/*    */   }
/*    */ }