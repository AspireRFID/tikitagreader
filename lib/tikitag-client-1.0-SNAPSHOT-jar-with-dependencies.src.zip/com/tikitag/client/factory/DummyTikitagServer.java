/*    */ package com.tikitag.client.factory;
/*    */ 
/*    */ import com.tikitag.client.TikitagServer;
/*    */ import com.tikitag.ons.TikitagAction;
/*    */ import com.tikitag.ons.model.util.ChangeEvent;
/*    */ import com.tikitag.ons.model.util.PingEvent;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import com.tikitag.util.config.xml.ConfigAttribute;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.net.URI;
/*    */ import java.net.URISyntaxException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ class DummyTikitagServer
/*    */   implements TikitagServer
/*    */ {
/* 23 */   private static final Map<TagId, ConfigContainer> tagActions = new HashMap();
/*    */ 
/*    */   public DummyTikitagServer() {
/* 26 */     tagActions.put(tag("044501b9bf0284"), urlAction("http://www.google.com"));
/* 27 */     tagActions.put(tag("046b13b9bf0284"), urlAction("http://www.flickr.com"));
/*    */   }
/*    */ 
/*    */   private TagId tag(String hexUid) {
/* 31 */     return new TagId(HexFormatter.fromHexString(hexUid));
/*    */   }
/*    */ 
/*    */   private ConfigContainer urlAction(String url) {
/* 35 */     return toActionContext(url);
/*    */   }
/*    */ 
/*    */   private ConfigContainer toActionContext(String url) {
/* 39 */     return new ConfigContainer("tikitag.standard.url").set(new ConfigContainer("v1.0").set(new ConfigAttribute("url", url)));
/*    */   }
/*    */ 
/*    */   private ConfigContainer unknownAction()
/*    */   {
/* 46 */     return new ConfigContainer("unknown");
/*    */   }
/*    */ 
/*    */   public TikitagAction getTikitagAction(TagEvent tagEvent) {
/* 50 */     ConfigContainer action = (ConfigContainer)tagActions.get(tagEvent.getActionTag());
/* 51 */     if (action == null) {
/* 52 */       action = unknownAction();
/*    */     }
/* 54 */     TikitagAction result = new TikitagAction();
/* 55 */     result.setContainer(action);
/* 56 */     return result;
/*    */   }
/*    */ 
/*    */   public URI getActualConnectionUri()
/*    */   {
/*    */     try {
/* 62 */       return new URI("urn:local");
/*    */     }
/*    */     catch (URISyntaxException e) {
/* 65 */       throw new RuntimeException("Internal Invariants Broken", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void changeEvent(ChangeEvent changeEvent)
/*    */   {
/*    */   }
/*    */ 
/*    */   public void ping(PingEvent pingEvent)
/*    */   {
/*    */   }
/*    */ }