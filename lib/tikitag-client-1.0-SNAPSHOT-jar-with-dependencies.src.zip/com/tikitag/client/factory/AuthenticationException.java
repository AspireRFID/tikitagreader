/*    */ package com.tikitag.client.factory;
/*    */ 
/*    */ public class AuthenticationException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public AuthenticationException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public AuthenticationException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public AuthenticationException(Throwable cause) {
/* 17 */     super(cause);
/*    */   }
/*    */ 
/*    */   public AuthenticationException(String message, Throwable cause) {
/* 21 */     super(message, cause);
/*    */   }
/*    */ }