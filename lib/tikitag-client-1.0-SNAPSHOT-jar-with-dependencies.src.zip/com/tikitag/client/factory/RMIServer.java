/*     */ package com.tikitag.client.factory;
/*     */ 
/*     */ import com.tikitag.client.LoginCredentials;
/*     */ import com.tikitag.client.TikitagServer;
/*     */ import com.tikitag.ons.TikitagAction;
/*     */ import com.tikitag.ons.facade.CorrelatorException_Exception;
/*     */ import com.tikitag.ons.facade.remote.CorrelationProxy;
/*     */ import com.tikitag.ons.model.util.ChangeEvent;
/*     */ import com.tikitag.ons.model.util.PingEvent;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import java.net.URI;
/*     */ import java.net.URISyntaxException;
/*     */ import java.util.Properties;
/*     */ import javax.naming.Context;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ 
/*     */ class RMIServer
/*     */   implements TikitagServer
/*     */ {
/*     */   private static final String CORRELATION_FACADE_BEAN = "Tikitag/ONS/Facade/Correlation/remote";
/*     */   private final LoginCredentials loginCredentials;
/*     */   private String host;
/*     */   private int port;
/*     */ 
/*     */   public RMIServer(URI connectionURI)
/*     */   {
/*  29 */     this.loginCredentials = new LoginCredentials();
/*  30 */     this.host = connectionURI.getHost();
/*  31 */     if (this.host == null)
/*  32 */       throw new IllegalArgumentException("Host required in connection string!");
/*  33 */     this.port = connectionURI.getPort();
/*  34 */     if (this.port == -1)
/*  35 */       this.port = 1099;
/*     */   }
/*     */ 
/*     */   public TikitagAction getTikitagAction(TagEvent tagEvent) throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try {
/*  41 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext(this.host, this.port).lookup("Tikitag/ONS/Facade/Correlation/remote");
/*  42 */       return proxy.getTikitagAction(tagEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/*  44 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (Exception e) {
/*  47 */       if (e.getMessage().endsWith("Unauthorized")) {
/*  48 */         throw new AuthenticationException(e);
/*     */       }
/*     */ 
/*  51 */       throw new ConnectionException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private Context getInitialContext(String host, int port)
/*     */     throws NamingException
/*     */   {
/*  58 */     Properties environment = new Properties();
/*  59 */     environment.setProperty("java.naming.security.principal", this.loginCredentials.getUsername());
/*  60 */     environment.setProperty("java.naming.security.credentials", this.loginCredentials.getPassword());
/*  61 */     environment.setProperty("java.naming.factory.initial", "org.jboss.security.jndi.JndiLoginInitialContextFactory");
/*     */ 
/*  64 */     environment.setProperty("java.naming.provider.url", host + ":" + port);
/*  65 */     environment.setProperty("java.naming.factory.url.pkgs", "org.jboss.naming");
/*  66 */     return new InitialContext(environment);
/*     */   }
/*     */ 
/*     */   public URI getActualConnectionUri()
/*     */   {
/*     */     try {
/*  72 */       return new URI("rmi://" + this.host + ":" + this.port);
/*     */     }
/*     */     catch (URISyntaxException e) {
/*  75 */       throw new RuntimeException("Internal Invariants Broken !", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void changeEvent(ChangeEvent changeEvent) throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try {
/*  82 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext(this.host, this.port).lookup("Tikitag/ONS/Facade/Correlation/remote");
/*  83 */       proxy.changeEvent(changeEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/*  85 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (Exception e) {
/*  88 */       if (e.getMessage().endsWith("Unauthorized")) {
/*  89 */         throw new AuthenticationException(e);
/*     */       }
/*     */ 
/*  92 */       throw new ConnectionException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public void ping(PingEvent pingEvent)
/*     */     throws AuthenticationException, ConnectionException
/*     */   {
/*     */     try
/*     */     {
/* 101 */       CorrelationProxy proxy = (CorrelationProxy)getInitialContext(this.host, this.port).lookup("Tikitag/ONS/Facade/Correlation/remote");
/* 102 */       proxy.ping(pingEvent);
/*     */     } catch (CorrelatorException_Exception e) {
/* 104 */       throw new RuntimeException(e);
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/* 108 */       if (e.getMessage().endsWith("Unauthorized")) {
/* 109 */         throw new AuthenticationException(e);
/*     */       }
/*     */ 
/* 112 */       throw new ConnectionException(e);
/*     */     }
/*     */   }
/*     */ }