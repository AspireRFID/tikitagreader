/*     */ package com.tikitag.client;
/*     */ 
/*     */ import com.tikitag.client.actionlauncher.ActionLauncher;
/*     */ import com.tikitag.client.actionlauncher.Application;
/*     */ import com.tikitag.client.actionlauncher.FallbackApplication;
/*     */ import com.tikitag.client.actionlauncher.NoActionApplication;
/*     */ import com.tikitag.client.actionlauncher.TagManagementApplication;
/*     */ import com.tikitag.client.actionlauncher.file.DesktopApiFileApplication;
/*     */ import com.tikitag.client.actionlauncher.url.DesktopApiUrlApplication;
/*     */ import com.tikitag.client.actionlauncher.url.OstermillerUrlApplication;
/*     */ import com.tikitag.client.actionlauncher.vcardmail.VCardDesktopMail;
/*     */ import com.tikitag.client.factory.TikitagServerFactory;
/*     */ import com.tikitag.client.gui.ActionFactory;
/*     */ import com.tikitag.client.gui.LoginCredentialsGUI;
/*     */ import com.tikitag.client.gui.SystemTrayGUI;
/*     */ import com.tikitag.client.gui.TagServiceConfigurationGUI;
/*     */ import com.tikitag.client.gui.TagToolsGUI;
/*     */ import com.tikitag.client.tagservice.TagMonitor;
/*     */ import com.tikitag.client.tagservice.TagService;
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.client.tagservice.impl.TagServiceImpl;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import com.tikitag.util.PrefsKeyProvider;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.io.PrintStream;
/*     */ import java.util.prefs.Preferences;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.Action;
/*     */ import javax.swing.JOptionPane;
/*     */ 
/*     */ public class TikitagClient
/*     */   implements ActionFactory
/*     */ {
/*     */   private TagService tagService;
/*     */   private TikitagServer server;
/*     */   private ActionLauncher actionLauncher;
/*     */   private TagServiceConfiguration tagServiceConfiguration;
/*     */ 
/*     */   public TikitagClient(TikitagServer server)
/*     */   {
/*  40 */     this.server = server;
/*     */   }
/*     */ 
/*     */   public static void main(String[] args)
/*     */   {
/*  47 */     Parameters params = Parameters.parse(args);
/*     */ 
/*  49 */     System.out.println("Requesting connection to " + params.getInterfaceIdentifier());
/*  50 */     TikitagServer server = TikitagServerFactory.newServer(params.getInterfaceIdentifier(), params.getEndpointLocation());
/*  51 */     System.out.println("Actually connecting to " + server.getActualConnectionUri());
/*     */ 
/*  53 */     TikitagClient client = new TikitagClient(server);
/*  54 */     client.start();
/*     */   }
/*     */ 
/*     */   public void start() {
/*  58 */     this.tagServiceConfiguration = new TagServiceConfiguration();
/*  59 */     this.tagService = new TagServiceImpl(this.tagServiceConfiguration);
/*     */ 
/*  61 */     ClientLifecycleHandler clientLifeCycleHandler = new ClientLifecycleHandler(this.server, this.tagServiceConfiguration);
/*  62 */     this.tagService.addReaderMonitor(clientLifeCycleHandler);
/*     */ 
/*  64 */     this.tagService.addTagMonitor(new TagMonitor() {
/*     */       public void onTagEvent(TagEvent tagEvent) {
/*  66 */         StringBuilder sb = new StringBuilder();
/*  67 */         sb.append("\n  Action  Tag = " + tagEvent.getActionTag());
/*  68 */         sb.append("\n  Context Tag = " + tagEvent.getContextTag());
/*  69 */         System.out.println("Detected tags: " + sb.toString());
/*     */       }
/*     */     });
/*  73 */     SystemTrayGUI gui = new SystemTrayGUI(this);
/*  74 */     clientLifeCycleHandler.addClientLifecycleListener(gui.getClientLifecycleListener());
/*     */ 
/*  76 */     this.tagService.addReaderMonitor(gui.getReaderMonitor());
/*     */ 
/*  78 */     this.actionLauncher = new ActionLauncher(this.server, new FallbackApplication(), gui.getUiNotifiction());
/*     */     try {
/*  80 */       this.actionLauncher.registerApplication(new DesktopApiUrlApplication());
/*     */     }
/*     */     catch (UnsupportedOperationException e) {
/*  83 */       this.actionLauncher.registerApplication(new OstermillerUrlApplication());
/*     */     }
/*  85 */     this.actionLauncher.registerApplication(new TagManagementApplication());
/*  86 */     this.actionLauncher.registerApplication(new NoActionApplication());
/*  87 */     this.actionLauncher.registerApplication(new VCardDesktopMail());
/*     */     try {
/*  89 */       this.actionLauncher.registerApplication(new DesktopApiFileApplication());
/*     */     }
/*     */     catch (UnsupportedOperationException e) {
/*  92 */       e.printStackTrace();
/*     */     }
/*  94 */     if (getActionLauncherAction().isActionLauncherEnabled()) {
/*  95 */       this.tagService.addTagMonitor(this.actionLauncher);
/*     */     }
/*     */ 
/*  98 */     gui.start();
/*  99 */     clientLifeCycleHandler.onTikitagClientStarted();
/* 100 */     this.tagService.start();
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 108 */     this.tagService.shutdown();
/*     */   }
/*     */ 
/*     */   public void registerApplication(Application application)
/*     */   {
/* 115 */     this.actionLauncher.registerApplication(application);
/*     */   }
/*     */ 
/*     */   public void unregisterApplication(Application application) {
/* 119 */     this.actionLauncher.unregisterApplication(application);
/*     */   }
/*     */ 
/*     */   public Action getExitAction() {
/* 123 */     return new ExitAction();
/*     */   }
/*     */ 
/*     */   public Action getReadWriteTagAction() {
/* 127 */     return new ReadWriteTagction();
/*     */   }
/*     */ 
/*     */   public ActionLauncherAction getActionLauncherAction()
/*     */   {
/* 158 */     return new ActionLauncherAction();
/*     */   }
/*     */ 
/*     */   public Action getKeyConfigurationAction()
/*     */   {
/* 163 */     return new KeyConfigurationAction();
/*     */   }
/*     */ 
/*     */   public Action getLoginCredentialsAction()
/*     */   {
/* 215 */     return new LoginCredentialsAction();
/*     */   }
/*     */ 
/*     */   public Action getTagServiceConfigurationAction()
/*     */   {
/* 235 */     return new TagServiceConfigurationAction();
/*     */   }
/*     */ 
/*     */   public class TagServiceConfigurationAction extends AbstractAction {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final TagServiceConfigurationGUI tagServiceConfigGUI;
/*     */ 
/*     */     public TagServiceConfigurationAction() {
/* 243 */       super("Tag Service Configuration");
/* 244 */       this.tagServiceConfigGUI = new TagServiceConfigurationGUI(TikitagClient.this.tagServiceConfiguration);
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 249 */       this.tagServiceConfigGUI.show();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class LoginCredentialsAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final LoginCredentialsGUI loginCredentialsGUI;
/*     */ 
/*     */     public LoginCredentialsAction()
/*     */     {
/* 223 */       super("Login Credentials");
/* 224 */       this.loginCredentialsGUI = new LoginCredentialsGUI();
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 229 */       this.loginCredentialsGUI.show();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class KeyConfigurationAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final PrefsKeyProvider keyProvider;
/*     */ 
/*     */     public KeyConfigurationAction()
/*     */     {
/* 200 */       super("Tikitag Key Configuration");
/* 201 */       this.keyProvider = new PrefsKeyProvider();
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 206 */       String newKey = JOptionPane.showInputDialog("Tikitag Shared Secret Key (HEX)", HexFormatter.toHexString(this.keyProvider.getKey()));
/* 207 */       if (newKey != null)
/* 208 */         this.keyProvider.setKey(newKey);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class ActionLauncherAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private static final String ACTION_LAUNCHER_ENABLED_KEY = "actionLauncher.enabled";
/* 170 */     private Preferences prefs = Preferences.userNodeForPackage(ActionLauncherAction.class);
/*     */ 
/*     */     public ActionLauncherAction() {
/* 173 */       super("Enable Action Launcher");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 178 */       if (isActionLauncherEnabled())
/* 179 */         TikitagClient.this.tagService.removeTagMonitor(TikitagClient.this.actionLauncher);
/*     */       else {
/* 181 */         TikitagClient.this.tagService.addTagMonitor(TikitagClient.this.actionLauncher);
/*     */       }
/* 183 */       setActionLauncherEnabled(!(isActionLauncherEnabled()));
/*     */     }
/*     */ 
/*     */     public boolean isActionLauncherEnabled() {
/* 187 */       return this.prefs.getBoolean("actionLauncher.enabled", true);
/*     */     }
/*     */ 
/*     */     public void setActionLauncherEnabled(boolean enabled) {
/* 191 */       this.prefs.putBoolean("actionLauncher.enabled", enabled);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ReadWriteTagction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public ReadWriteTagction()
/*     */     {
/* 147 */       super("Tag Tools");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e) {
/* 151 */       TagToolsGUI gui = new TagToolsGUI(TikitagClient.this.tagService);
/* 152 */       gui.setVisible(true);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class ExitAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public ExitAction()
/*     */     {
/* 134 */       super("Exit");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e) {
/* 138 */       TikitagClient.this.stop();
/* 139 */       System.exit(0);
/*     */     }
/*     */   }
/*     */ }