/*     */ package com.tikitag.client.gui;
/*     */ 
/*     */ import com.tikitag.client.LoginCredentials;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.ActionListener;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JComboBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JPasswordField;
/*     */ 
/*     */ public class LoginCredentialsGUI
/*     */ {
/*     */   private static final String ANONYMOUS = "anonymous";
/*     */   private JDialog userConfigDialog;
/*     */   private LoginCredentials loginCredentials;
/*     */   private JComboBox userNameCombo;
/*     */   private JPasswordField passwordField;
/*     */ 
/*     */   public LoginCredentialsGUI()
/*     */   {
/*  28 */     this.loginCredentials = new LoginCredentials();
/*     */ 
/*  30 */     this.userConfigDialog = new JDialog();
/*  31 */     this.userConfigDialog.setTitle("Login Credentials Configuration");
/*  32 */     this.userConfigDialog.setLocation(100, 100);
/*     */ 
/*  34 */     JComponent content = buildContent();
/*  35 */     this.userConfigDialog.getContentPane().add(content);
/*     */ 
/*  37 */     initializeCredentials();
/*     */ 
/*  39 */     this.userConfigDialog.pack();
/*     */   }
/*     */ 
/*     */   private void initializeCredentials() {
/*  43 */     if (!(this.loginCredentials.isAnonymous())) {
/*  44 */       this.userNameCombo.setSelectedItem(this.loginCredentials.getUsername());
/*  45 */       this.passwordField.setText(this.loginCredentials.getPassword());
/*     */     }
/*     */   }
/*     */ 
/*     */   private JComponent buildContent() {
/*  50 */     JPanel rootPanel = new JPanel(new BorderLayout());
/*  51 */     rootPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*     */ 
/*  53 */     JPanel credentialsPanel = new JPanel(new GridLayout(2, 2));
/*  54 */     credentialsPanel.setBorder(BorderFactory.createTitledBorder("Login as ..."));
/*     */ 
/*  56 */     this.userNameCombo = new JComboBox(new Object[] { "", "anonymous" });
/*  57 */     this.userNameCombo.setEditable(true);
/*  58 */     this.userNameCombo.addActionListener(new ActionListener()
/*     */     {
/*     */       public void actionPerformed(ActionEvent e) {
/*  61 */         if (LoginCredentialsGUI.this.userNameCombo.getSelectedItem().equals("anonymous")) {
/*  62 */           LoginCredentialsGUI.this.passwordField.setText(null);
/*  63 */           LoginCredentialsGUI.this.passwordField.setEnabled(false);
/*  64 */           LoginCredentialsGUI.this.passwordField.setFocusable(true);
/*     */         } else {
/*  66 */           LoginCredentialsGUI.this.passwordField.setEnabled(true);
/*     */         }
/*     */       }
/*     */     });
/*  69 */     this.passwordField = new JPasswordField();
/*     */ 
/*  71 */     credentialsPanel.add(new JLabel("Username"));
/*  72 */     credentialsPanel.add(this.userNameCombo);
/*  73 */     credentialsPanel.add(new JLabel("Password"));
/*  74 */     credentialsPanel.add(this.passwordField);
/*     */ 
/*  76 */     JPanel buttonsPanel = new JPanel(new GridLayout(1, 2));
/*  77 */     buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
/*  78 */     buttonsPanel.add(new JButton(new OkAction()));
/*  79 */     buttonsPanel.add(new JButton(new CancelAction()));
/*     */ 
/*  81 */     rootPanel.add(credentialsPanel, "Center");
/*  82 */     rootPanel.add(buttonsPanel, "South");
/*     */ 
/*  84 */     return rootPanel;
/*     */   }
/*     */ 
/*     */   public void show() {
/*  88 */     this.userConfigDialog.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void hide() {
/*  92 */     this.userConfigDialog.setVisible(false);
/*     */   }
/*     */ 
/*     */   public class CancelAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public CancelAction()
/*     */     {
/* 120 */       super("CANCEL");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 125 */       LoginCredentialsGUI.this.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class OkAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public OkAction()
/*     */     {
/*  99 */       super("OK");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 104 */       String username = (String)LoginCredentialsGUI.this.userNameCombo.getSelectedItem();
/* 105 */       if (username.equals("anonymous"))
/* 106 */         LoginCredentialsGUI.this.loginCredentials.setAnonymous();
/*     */       else {
/* 108 */         LoginCredentialsGUI.this.loginCredentials.setCredentials(username, new String(LoginCredentialsGUI.this.passwordField.getPassword()));
/*     */       }
/*     */ 
/* 111 */       LoginCredentialsGUI.this.hide();
/*     */     }
/*     */   }
/*     */ }