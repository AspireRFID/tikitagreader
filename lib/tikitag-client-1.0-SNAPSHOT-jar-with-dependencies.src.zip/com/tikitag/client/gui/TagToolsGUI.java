/*     */ package com.tikitag.client.gui;
/*     */ 
/*     */ import com.tikitag.client.tagservice.GenuineTikitagHelper;
/*     */ import com.tikitag.client.tagservice.GenuineTikitagHelper.LockMode;
/*     */ import com.tikitag.client.tagservice.TagMonitor;
/*     */ import com.tikitag.client.tagservice.TagService;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import com.tikitag.util.KeyProvider;
/*     */ import com.tikitag.util.PrefsKeyProvider;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Color;
/*     */ import java.awt.Component;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.FlowLayout;
/*     */ import java.awt.Font;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.Image;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.awt.event.WindowAdapter;
/*     */ import java.awt.event.WindowEvent;
/*     */ import java.net.URL;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JFrame;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JOptionPane;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JScrollPane;
/*     */ import javax.swing.JSplitPane;
/*     */ import javax.swing.JTextArea;
/*     */ import javax.swing.JTextField;
/*     */ 
/*     */ public class TagToolsGUI extends JFrame
/*     */   implements TagMonitor
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private final TagService tagService;
/*  49 */   private TagEvent lastTagEvent = null;
/*     */   private JTextField uidField;
/*     */   private JButton isHashValid;
/*     */   private JTextArea dataOutput;
/*     */   private JTextField blockAddressField;
/*     */   private JTextField blockDataField;
/*     */   private JTextField lockField;
/*     */   private JTextField otpField;
/*     */   private JTextField tagDataField;
/*     */   private JButton isContentValid;
/*     */   private JCheckBox autoCreateGenuineTikitags;
/*     */   private JButton isLocked;
/*     */   private KeyProvider keyProvider;
/*     */   private GenuineTikitagHelper genuineTikitagHelper;
/*     */ 
/*     */   public TagToolsGUI(TagService tagService)
/*     */   {
/*  75 */     super("Tikitag Tools");
/*  76 */     setIconImage(getTrayImage());
/*  77 */     setDefaultCloseOperation(2);
/*  78 */     setLocation(100, 100);
/*     */ 
/*  80 */     this.keyProvider = new PrefsKeyProvider();
/*  81 */     this.genuineTikitagHelper = new GenuineTikitagHelper(this.keyProvider);
/*     */ 
/*  83 */     this.tagService = tagService;
/*  84 */     tagService.addTagMonitor(this);
/*     */ 
/*  86 */     addWindowListener(new WindowAdapter(tagService)
/*     */     {
/*     */       public void windowClosed(WindowEvent e) {
/*  89 */         this.val$tagService.removeTagMonitor(TagToolsGUI.this);
/*     */       }
/*     */     });
/*  93 */     JSplitPane mainPane = new JSplitPane(0);
/*  94 */     mainPane.setOneTouchExpandable(true);
/*  95 */     mainPane.setResizeWeight(1.0D);
/*  96 */     mainPane.setPreferredSize(new Dimension(800, 500));
/*  97 */     mainPane.add(getReadPanel(), "top");
/*  98 */     mainPane.add(getWritePanel(), "bottom");
/*     */ 
/* 100 */     getContentPane().add(mainPane);
/* 101 */     pack();
/*     */   }
/*     */ 
/*     */   private Component getReadPanel() {
/* 105 */     JPanel readPanel = new JPanel(new BorderLayout());
/* 106 */     readPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/* 107 */     JPanel headerPanel = new JPanel(new BorderLayout());
/*     */ 
/* 109 */     JLabel readTagLabel = new JLabel("Read Tag  UID : ");
/* 110 */     this.uidField = new JTextField();
/* 111 */     this.uidField.setEditable(false);
/*     */ 
/* 113 */     JPanel checksPanel = new JPanel(new GridLayout(1, 2));
/* 114 */     this.isHashValid = new JButton(" NO TAG ");
/* 115 */     this.isHashValid.setForeground(Color.GRAY);
/* 116 */     this.isHashValid.setEnabled(false);
/* 117 */     this.isContentValid = new JButton(" NO TAG ");
/* 118 */     this.isContentValid.setForeground(Color.GRAY);
/* 119 */     this.isContentValid.setEnabled(false);
/* 120 */     this.isLocked = new JButton(" NO TAG ");
/* 121 */     this.isLocked.setForeground(Color.GRAY);
/* 122 */     this.isLocked.setEnabled(false);
/* 123 */     checksPanel.add(this.isHashValid);
/* 124 */     checksPanel.add(this.isContentValid);
/* 125 */     checksPanel.add(this.isLocked);
/*     */ 
/* 127 */     headerPanel.add(readTagLabel, "West");
/* 128 */     headerPanel.add(this.uidField, "Center");
/* 129 */     headerPanel.add(checksPanel, "East");
/*     */ 
/* 131 */     this.dataOutput = new JTextArea();
/* 132 */     this.dataOutput.setEditable(false);
/* 133 */     this.dataOutput.setFont(Font.decode("COURIER"));
/* 134 */     JScrollPane scrollPane = new JScrollPane(this.dataOutput);
/* 135 */     scrollPane.setAutoscrolls(false);
/*     */ 
/* 137 */     readPanel.add(headerPanel, "North");
/* 138 */     readPanel.add(scrollPane, "Center");
/* 139 */     return readPanel;
/*     */   }
/*     */ 
/*     */   private Component getWritePanel() {
/* 143 */     JPanel writePanel = new JPanel(new GridLayout(4, 1));
/* 144 */     writePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*     */ 
/* 146 */     JLabel writeTagLabel = new JLabel("Write Tag (All input in Hexadecimal representation)");
/*     */ 
/* 148 */     JPanel writeBlockPanel = new JPanel(new BorderLayout());
/* 149 */     JPanel leftPanel = new JPanel(new FlowLayout(1, 3, 0));
/* 150 */     JLabel blockAddressLabel = new JLabel("Block address : ");
/* 151 */     this.blockAddressField = new JTextField(8);
/* 152 */     JLabel blockDataLabel = new JLabel("Block data : ");
/* 153 */     leftPanel.add(blockAddressLabel);
/* 154 */     leftPanel.add(this.blockAddressField);
/* 155 */     leftPanel.add(blockDataLabel);
/* 156 */     this.blockDataField = new JTextField();
/* 157 */     JButton writeBlockButton = new JButton(new WriteBlockAction());
/* 158 */     writeBlockPanel.add(leftPanel, "West");
/* 159 */     writeBlockPanel.add(this.blockDataField, "Center");
/* 160 */     writeBlockPanel.add(writeBlockButton, "East");
/*     */ 
/* 162 */     JPanel writeTagPanel = new JPanel(new BorderLayout());
/* 163 */     JPanel specialPagesPanel = new JPanel(new FlowLayout(1, 3, 0));
/* 164 */     JLabel lockLabel = new JLabel("Lock : ");
/* 165 */     this.lockField = new JTextField(4);
/* 166 */     JLabel otpLabel = new JLabel("OTP : ");
/* 167 */     this.otpField = new JTextField(8);
/* 168 */     JLabel tagDataLabel = new JLabel("Tag data : ");
/* 169 */     specialPagesPanel.add(lockLabel);
/* 170 */     specialPagesPanel.add(this.lockField);
/* 171 */     specialPagesPanel.add(otpLabel);
/* 172 */     specialPagesPanel.add(this.otpField);
/* 173 */     specialPagesPanel.add(tagDataLabel);
/* 174 */     this.tagDataField = new JTextField();
/* 175 */     JButton writeTagButton = new JButton(new WriteTagAction());
/* 176 */     writeTagPanel.add(specialPagesPanel, "West");
/* 177 */     writeTagPanel.add(this.tagDataField, "Center");
/* 178 */     writeTagPanel.add(writeTagButton, "East");
/*     */ 
/* 180 */     JPanel genuinePanel = new JPanel(new BorderLayout());
/* 181 */     JButton createGenuineTikitagButton = new JButton(new WriteGenuineAction());
/* 182 */     this.autoCreateGenuineTikitags = new JCheckBox("Auto Create", false);
/* 183 */     this.autoCreateGenuineTikitags.setToolTipText("Automatically attempt to convert a read tag to a Tikitag");
/* 184 */     genuinePanel.add(createGenuineTikitagButton, "Center");
/* 185 */     genuinePanel.add(this.autoCreateGenuineTikitags, "East");
/*     */ 
/* 187 */     writePanel.add(writeTagLabel);
/* 188 */     writePanel.add(writeBlockPanel);
/* 189 */     writePanel.add(writeTagPanel);
/* 190 */     writePanel.add(genuinePanel);
/*     */ 
/* 192 */     return writePanel;
/*     */   }
/*     */ 
/*     */   private Image getTrayImage() {
/* 196 */     URL imageUrl = super.getClass().getClassLoader().getResource("tikitag.png");
/* 197 */     return Toolkit.getDefaultToolkit().getImage(imageUrl);
/*     */   }
/*     */ 
/*     */   private void writeBlock(String pageHex, String pageData) {
/* 201 */     if (this.lastTagEvent == null) {
/* 202 */       JOptionPane.showMessageDialog(this, "No tag detected to apply write operation on", "Write Failure", 0);
/*     */     }
/*     */     else {
/* 205 */       int pageNr = Integer.parseInt(pageHex, 16);
/* 206 */       ReaderId reader = this.lastTagEvent.getReaderId();
/* 207 */       this.tagService.writePage(reader, pageNr, pageData);
/* 208 */       this.tagService.forceRedetect(reader);
/*     */     }
/*     */   }
/*     */ 
/*     */   private void writeTag(String lockPage, String otpPage, String tagData) {
/* 213 */     if (this.lastTagEvent == null) {
/* 214 */       JOptionPane.showMessageDialog(this, "No tag detected to apply write operation on", "Write Failure", 0);
/*     */     }
/*     */     else {
/* 217 */       ReaderId reader = this.lastTagEvent.getReaderId();
/* 218 */       if (isNotEmpty(tagData)) {
/* 219 */         this.tagService.writeUserData(reader, tagData);
/*     */       }
/* 221 */       if (isNotEmpty(otpPage)) {
/* 222 */         this.tagService.writePage(reader, 3, otpPage);
/*     */       }
/* 224 */       if (isNotEmpty(lockPage)) {
/* 225 */         this.tagService.writeLock(reader, lockPage);
/*     */       }
/* 227 */       this.tagService.forceRedetect(reader);
/*     */     }
/*     */   }
/*     */ 
/*     */   private boolean isNotEmpty(String setting) {
/* 232 */     return ((setting != null) && (setting.length() != 0));
/*     */   }
/*     */ 
/*     */   public void onTagEvent(TagEvent tagEvent)
/*     */   {
/* 284 */     this.lastTagEvent = tagEvent;
/* 285 */     if (tagEvent.getContextTag() != null) {
/* 286 */       JOptionPane.showMessageDialog(this, "Only one Tikitag is allowed on the reader when using Tag Tools");
/* 287 */       resetReadOutput();
/* 288 */       return;
/*     */     }
/* 290 */     TagInfo tag = tagEvent.getActionTag();
/*     */ 
/* 292 */     this.uidField.setText(tag.getTagId().getIdentifier());
/* 293 */     if (this.keyProvider.getKey().length != 0) {
/* 294 */       this.autoCreateGenuineTikitags.setEnabled(true);
/* 295 */       if (this.genuineTikitagHelper.isHashValid(tag)) {
/* 296 */         this.isHashValid.setText("HASH  OK");
/* 297 */         this.isHashValid.setForeground(Color.GREEN);
/*     */       } else {
/* 299 */         this.isHashValid.setText("HASH NOK");
/* 300 */         this.isHashValid.setForeground(Color.BLUE);
/*     */       }
/* 302 */       if (this.genuineTikitagHelper.isContentValid(tag, false)) {
/* 303 */         this.isContentValid.setText("DATA  OK");
/* 304 */         this.isContentValid.setForeground(Color.GREEN);
/*     */       } else {
/* 306 */         this.isContentValid.setText("DATA NOK");
/* 307 */         this.isContentValid.setForeground(Color.BLUE);
/*     */       }
/*     */     } else {
/* 310 */       this.isHashValid.setText(" NO KEY ");
/* 311 */       this.isHashValid.setForeground(Color.GRAY);
/* 312 */       this.isContentValid.setText(" NO KEY ");
/* 313 */       this.isContentValid.setForeground(Color.GRAY);
/*     */     }
/*     */ 
/* 316 */     GenuineTikitagHelper.LockMode lockMode = this.genuineTikitagHelper.determineLockMode(tag);
/* 317 */     switch (2.$SwitchMap$com$tikitag$client$tagservice$GenuineTikitagHelper$LockMode[lockMode.ordinal()])
/*     */     {
/*     */     case 1:
/* 319 */       this.isLocked.setText("UNLOCKED");
/* 320 */       this.isLocked.setForeground(Color.BLUE);
/* 321 */       break;
/*     */     case 2:
/* 323 */       this.isLocked.setText("PARTIAL LOCK");
/* 324 */       this.isLocked.setForeground(Color.CYAN);
/* 325 */       break;
/*     */     case 3:
/* 327 */       this.isLocked.setText("TIKITAG LOCK");
/* 328 */       this.isLocked.setForeground(Color.GREEN);
/* 329 */       break;
/*     */     case 4:
/* 331 */       this.isLocked.setText("UNKNOWN");
/* 332 */       this.isLocked.setForeground(Color.RED);
/*     */     }
/*     */ 
/* 337 */     this.dataOutput.setText(HexFormatter.pageView(HexFormatter.toHexString(tag.getTagData())));
/*     */ 
/* 339 */     if (this.autoCreateGenuineTikitags.isSelected())
/* 340 */       if (this.keyProvider.getKey().length != 0) {
/* 341 */         if ((!(this.genuineTikitagHelper.isContentValid(tag, false))) && (lockMode != GenuineTikitagHelper.LockMode.TIKITAG_LOCK)) {
/* 342 */           writeTag(this.genuineTikitagHelper.getLockPage(), this.genuineTikitagHelper.getOtpPage(), this.genuineTikitagHelper.getTagData(tag.getTagId()));
/*     */         }
/*     */       }
/*     */       else
/* 346 */         this.autoCreateGenuineTikitags.setEnabled(false);
/*     */   }
/*     */ 
/*     */   private void resetReadOutput()
/*     */   {
/* 352 */     this.lastTagEvent = null;
/* 353 */     this.isHashValid.setText(" NO TAG ");
/* 354 */     this.isHashValid.setForeground(Color.GRAY);
/* 355 */     this.isContentValid.setText(" NO TAG ");
/* 356 */     this.isContentValid.setForeground(Color.GRAY);
/* 357 */     this.isLocked.setText(" NO TAG ");
/* 358 */     this.isLocked.setForeground(Color.GRAY);
/* 359 */     this.uidField.setText("");
/* 360 */     this.dataOutput.setText("");
/*     */   }
/*     */ 
/*     */   private class WriteGenuineAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public WriteGenuineAction()
/*     */     {
/* 265 */       super("Create Genuine Tikitag");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 270 */       if (TagToolsGUI.this.lastTagEvent == null) {
/* 271 */         JOptionPane.showMessageDialog(TagToolsGUI.this, "No tag detected to apply write operation on", "Write Failure", 0);
/*     */       }
/*     */       else {
/* 274 */         TagId tagId = TagToolsGUI.this.lastTagEvent.getActionTag().getTagId();
/* 275 */         TagToolsGUI.this.writeTag(TagToolsGUI.this.genuineTikitagHelper.getLockPage(), TagToolsGUI.this.genuineTikitagHelper.getOtpPage(), TagToolsGUI.this.genuineTikitagHelper.getTagData(tagId));
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WriteTagAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public WriteTagAction()
/*     */     {
/* 252 */       super("Write Tag");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 257 */       TagToolsGUI.this.writeTag(TagToolsGUI.this.lockField.getText(), TagToolsGUI.this.otpField.getText(), TagToolsGUI.this.tagDataField.getText());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class WriteBlockAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public WriteBlockAction()
/*     */     {
/* 239 */       super("Write Block");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 244 */       TagToolsGUI.this.writeBlock(TagToolsGUI.this.blockAddressField.getText(), TagToolsGUI.this.blockDataField.getText());
/*     */     }
/*     */   }
/*     */ }