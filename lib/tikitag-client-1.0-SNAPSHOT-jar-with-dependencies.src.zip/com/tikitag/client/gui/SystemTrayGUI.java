/*     */ package com.tikitag.client.gui;
/*     */ 
/*     */ import com.tikitag.client.ClientLifecycleListener;
/*     */ import com.tikitag.client.ClientStatusChangeEvent;
/*     */ import com.tikitag.client.TikitagClient.ActionLauncherAction;
/*     */ import com.tikitag.client.actionlauncher.UiNotification;
/*     */ import com.tikitag.client.actionlauncher.UiNotification.MessageType;
/*     */ import com.tikitag.client.tagservice.ReaderEvent;
/*     */ import com.tikitag.client.tagservice.ReaderMonitor;
/*     */ import com.tikitag.client.tagservice.TagMonitor;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import java.awt.AWTException;
/*     */ import java.awt.Image;
/*     */ import java.awt.SystemTray;
/*     */ import java.awt.Toolkit;
/*     */ import java.awt.TrayIcon.MessageType;
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import javax.swing.JCheckBoxMenuItem;
/*     */ import javax.swing.JMenu;
/*     */ import javax.swing.JPopupMenu;
/*     */ import javax.swing.UIManager;
/*     */ 
/*     */ public class SystemTrayGUI
/*     */   implements UiNotification
/*     */ {
/*  30 */   private static final Map<UiNotification.MessageType, TrayIcon.MessageType> MESSAGE_TYPES = intializeMessageTypes();
/*     */   private final SystemTray systemTray;
/*     */   private final JXTrayIcon trayIcon;
/*     */   private final GuiTagMonitor tagMonitor;
/*     */   private final GuiReaderMonitor readerMonitor;
/*     */   private final GuiClientLifecycleListener clientLifecycleListener;
/*     */ 
/*     */   private static Map<UiNotification.MessageType, TrayIcon.MessageType> intializeMessageTypes()
/*     */   {
/*  33 */     Map messageTypes = new HashMap();
/*  34 */     messageTypes.put(UiNotification.MessageType.INFO, TrayIcon.MessageType.INFO);
/*  35 */     messageTypes.put(UiNotification.MessageType.WARNING, TrayIcon.MessageType.WARNING);
/*  36 */     messageTypes.put(UiNotification.MessageType.ERROR, TrayIcon.MessageType.ERROR);
/*  37 */     return messageTypes;
/*     */   }
/*     */ 
/*     */   public SystemTrayGUI(ActionFactory actionFactory)
/*     */   {
/*  48 */     if (!(SystemTray.isSupported())) {
/*  49 */       throw new UnsupportedOperationException("This system does not support system tray functionality.");
/*     */     }
/*     */     try
/*     */     {
/*  53 */       UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
/*     */     }
/*     */     catch (Exception e)
/*     */     {
/*     */     }
/*  58 */     this.systemTray = SystemTray.getSystemTray();
/*     */ 
/*  60 */     JMenu settingsMenu = new JMenu("Settings");
/*  61 */     TikitagClient.ActionLauncherAction actionLauncherAction = actionFactory.getActionLauncherAction();
/*  62 */     JCheckBoxMenuItem actionLauncherItem = new JCheckBoxMenuItem(actionLauncherAction);
/*  63 */     actionLauncherItem.setSelected(actionLauncherAction.isActionLauncherEnabled());
/*  64 */     settingsMenu.add(actionLauncherItem);
/*  65 */     settingsMenu.add(actionFactory.getKeyConfigurationAction());
/*  66 */     settingsMenu.add(actionFactory.getLoginCredentialsAction());
/*  67 */     settingsMenu.add(actionFactory.getTagServiceConfigurationAction());
/*     */ 
/*  69 */     JPopupMenu menu = new JPopupMenu();
/*  70 */     menu.add(actionFactory.getReadWriteTagAction());
/*  71 */     menu.add(settingsMenu);
/*  72 */     menu.add(actionFactory.getExitAction());
/*     */ 
/*  74 */     Image image = getTrayImage();
/*  75 */     this.trayIcon = new JXTrayIcon(image);
/*  76 */     this.trayIcon.setToolTip("Tikitag");
/*  77 */     this.trayIcon.setJPopuMenu(menu);
/*  78 */     this.trayIcon.setImageAutoSize(true);
/*     */ 
/*  80 */     this.tagMonitor = new GuiTagMonitor(null);
/*  81 */     this.readerMonitor = new GuiReaderMonitor(null);
/*  82 */     this.clientLifecycleListener = new GuiClientLifecycleListener(null);
/*     */   }
/*     */ 
/*     */   private Image getTrayImage()
/*     */   {
/*  88 */     URL imageUrl = super.getClass().getClassLoader().getResource("tikitag.png");
/*  89 */     return Toolkit.getDefaultToolkit().getImage(imageUrl);
/*     */   }
/*     */ 
/*     */   public void start() {
/*     */     try {
/*  94 */       this.systemTray.add(this.trayIcon);
/*     */     } catch (AWTException e) {
/*  96 */       throw new RuntimeException("Failed to add trayIcon to systemTray", e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public TagMonitor getTagMonitor() {
/* 101 */     return this.tagMonitor;
/*     */   }
/*     */ 
/*     */   public ReaderMonitor getReaderMonitor() {
/* 105 */     return this.readerMonitor; }
/*     */ 
/*     */   public ClientLifecycleListener getClientLifecycleListener() {
/* 108 */     return this.clientLifecycleListener;
/*     */   }
/*     */ 
/*     */   public UiNotification getUiNotifiction() {
/* 112 */     return this;
/*     */   }
/*     */ 
/*     */   public void showStatusMessage(String title, String message, UiNotification.MessageType messageType)
/*     */   {
/* 143 */     this.trayIcon.displayMessage(title, message, (TrayIcon.MessageType)MESSAGE_TYPES.get(messageType));
/*     */   }
/*     */ 
/*     */   private class GuiClientLifecycleListener implements ClientLifecycleListener {
/*     */     private static final String CLIENTLIFECYCLETITLE = "Tikitag status";
/*     */     private static final String URL = "http://www.tikitag.com";
/*     */ 
/*     */     public void onClientStatusCange(ClientStatusChangeEvent event) {
/* 151 */       switch (SystemTrayGUI.1.$SwitchMap$com$tikitag$client$ClientStatusChangeEvent$ClientStatus[event.getStatus().ordinal()])
/*     */       {
/*     */       case 1:
/* 153 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag status", "Succesfully connected to server.", TrayIcon.MessageType.INFO);
/* 154 */         break;
/*     */       case 2:
/* 156 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag status", "Unable to connect to server, check network connectivity.", TrayIcon.MessageType.ERROR);
/* 157 */         break;
/*     */       case 3:
/* 159 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag status", "Authentication failure, are you registered yet on http://www.tikitag.com?", TrayIcon.MessageType.ERROR);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GuiReaderMonitor
/*     */     implements ReaderMonitor
/*     */   {
/*     */     public void onReaderEvent(ReaderEvent readerEvent)
/*     */     {
/* 128 */       switch (SystemTrayGUI.1.$SwitchMap$com$tikitag$client$tagservice$ReaderEvent$ReaderEventType[readerEvent.getEventType().ordinal()])
/*     */       {
/*     */       case 1:
/* 130 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag Reader Detected", "Tikitag Reader with id " + readerEvent.getReaderId() + " detected.", TrayIcon.MessageType.INFO);
/* 131 */         break;
/*     */       case 2:
/* 133 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag Reader Unavailable", "Tikitag Reader with id " + readerEvent.getReaderId() + " is no longer available.", TrayIcon.MessageType.INFO);
/* 134 */         break;
/*     */       case 3:
/* 136 */         SystemTrayGUI.this.trayIcon.displayMessage("Tikitag Reader Failure", "Tikitag Reader with id " + readerEvent.getReaderId() + " encountered a problem.", TrayIcon.MessageType.WARNING);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GuiTagMonitor
/*     */     implements TagMonitor
/*     */   {
/*     */     public void onTagEvent(TagEvent tagEvent)
/*     */     {
/* 118 */       StringBuilder sb = new StringBuilder();
/* 119 */       sb.append("Action  Tag = " + tagEvent.getActionTag());
/* 120 */       sb.append("Context Tag = " + tagEvent.getContextTag());
/* 121 */       SystemTrayGUI.this.trayIcon.displayMessage("Tikitags Detected", sb.toString(), TrayIcon.MessageType.INFO);
/*     */     }
/*     */   }
/*     */ }