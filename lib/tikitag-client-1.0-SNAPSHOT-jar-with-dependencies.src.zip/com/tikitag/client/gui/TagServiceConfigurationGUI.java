/*     */ package com.tikitag.client.gui;
/*     */ 
/*     */ import com.tikitag.client.tagservice.TagServiceConfiguration;
/*     */ import com.tikitag.client.tagservice.TagType;
/*     */ import com.tikitag.ons.model.util.ClientId;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Container;
/*     */ import java.awt.Dimension;
/*     */ import java.awt.GridLayout;
/*     */ import java.awt.event.ActionEvent;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import javax.swing.AbstractAction;
/*     */ import javax.swing.BorderFactory;
/*     */ import javax.swing.BoxLayout;
/*     */ import javax.swing.JButton;
/*     */ import javax.swing.JCheckBox;
/*     */ import javax.swing.JComponent;
/*     */ import javax.swing.JDialog;
/*     */ import javax.swing.JLabel;
/*     */ import javax.swing.JPanel;
/*     */ import javax.swing.JSlider;
/*     */ import javax.swing.JTextField;
/*     */ import javax.swing.SpringLayout;
/*     */ import javax.swing.event.ChangeEvent;
/*     */ import javax.swing.event.ChangeListener;
/*     */ 
/*     */ public class TagServiceConfigurationGUI
/*     */ {
/*     */   private JDialog configDialog;
/*     */   private TagServiceConfiguration tagServiceConfig;
/*     */   private JTextField clientIdField;
/*     */   private JTextField clientNameField;
/*     */   private JSlider pollDelaySlider;
/*     */   private JSlider putThresholdSlider;
/*     */   private JSlider serverReconnectThresholdSlider;
/*     */   private ArrayList<TagTypeCheck> tagTypeChecks;
/*     */ 
/*     */   public TagServiceConfigurationGUI(TagServiceConfiguration tagServiceConfig)
/*     */   {
/*  43 */     this.tagServiceConfig = tagServiceConfig;
/*     */ 
/*  45 */     this.configDialog = new JDialog();
/*  46 */     this.configDialog.setTitle("Tag Service Configuration");
/*  47 */     this.configDialog.setLocation(100, 100);
/*     */ 
/*  49 */     JComponent content = buildContent();
/*  50 */     this.configDialog.getContentPane().add(content);
/*     */ 
/*  52 */     this.configDialog.pack();
/*     */   }
/*     */ 
/*     */   private JComponent buildContent() {
/*  56 */     JPanel rootPanel = new JPanel(new BorderLayout());
/*  57 */     rootPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
/*     */ 
/*  59 */     JPanel clientPanel = getClientIdPanel();
/*  60 */     JPanel centerPanel = new JPanel();
/*  61 */     centerPanel.setLayout(new BoxLayout(centerPanel, 1));
/*  62 */     JPanel timingsPanel = getTimingsPanel();
/*  63 */     JPanel tagTypesPanel = getTagTypesPanel();
/*  64 */     centerPanel.add(timingsPanel);
/*  65 */     centerPanel.add(tagTypesPanel);
/*  66 */     JPanel buttonsPanel = getButtonsPanel();
/*     */ 
/*  68 */     rootPanel.add(clientPanel, "North");
/*  69 */     rootPanel.add(centerPanel, "Center");
/*  70 */     rootPanel.add(buttonsPanel, "South");
/*     */ 
/*  72 */     return rootPanel;
/*     */   }
/*     */ 
/*     */   private JPanel getTagTypesPanel() {
/*  76 */     JPanel tagTypesPanel = new JPanel(new GridLayout((TagType.values().length + 1) / 2, 2));
/*  77 */     tagTypesPanel.setBorder(BorderFactory.createTitledBorder("Detected Tag Types"));
/*  78 */     Set detectedTagTypes = new HashSet(Arrays.asList(this.tagServiceConfig.getDetectTagTypes()));
/*  79 */     this.tagTypeChecks = new ArrayList(TagType.values().length);
/*  80 */     for (TagType tagType : TagType.values()) {
/*  81 */       TagTypeCheck tagTypeCheck = new TagTypeCheck(tagType);
/*  82 */       this.tagTypeChecks.add(tagTypeCheck);
/*     */ 
/*  84 */       JCheckBox checkBox = tagTypeCheck.getCheckBox();
/*  85 */       if (detectedTagTypes.contains(tagType)) {
/*  86 */         checkBox.setSelected(true);
/*     */       }
/*  88 */       tagTypesPanel.add(checkBox);
/*     */     }
/*     */ 
/*  91 */     return tagTypesPanel;
/*     */   }
/*     */ 
/*     */   private JPanel getButtonsPanel() {
/*  95 */     JPanel buttonsPanel = new JPanel(new GridLayout(1, 2));
/*  96 */     buttonsPanel.setBorder(BorderFactory.createEmptyBorder(0, 30, 0, 30));
/*  97 */     buttonsPanel.add(new JButton(new OkAction()));
/*  98 */     buttonsPanel.add(new JButton(new CancelAction()));
/*  99 */     return buttonsPanel;
/*     */   }
/*     */ 
/*     */   private JPanel getClientIdPanel() {
/* 103 */     JPanel clientPanel = new JPanel(new GridLayout(2, 1));
/* 104 */     clientPanel.setBorder(BorderFactory.createTitledBorder("Client Identification"));
/*     */ 
/* 106 */     JPanel clientIdPanel = new JPanel(new BorderLayout());
/* 107 */     this.clientIdField = new JTextField(this.tagServiceConfig.getClientId().getId());
/* 108 */     JButton generateClientIdButton = new JButton(new GenerateClientIdAction());
/* 109 */     clientIdPanel.add(new JLabel("Id   "), "West");
/* 110 */     clientIdPanel.add(this.clientIdField, "Center");
/* 111 */     clientIdPanel.add(generateClientIdButton, "East");
/*     */ 
/* 113 */     JPanel clientNamePanel = new JPanel(new BorderLayout());
/* 114 */     this.clientNameField = new JTextField(this.tagServiceConfig.getClientId().getName());
/* 115 */     clientNamePanel.add(new JLabel("Name "), "West");
/* 116 */     clientNamePanel.add(this.clientNameField, "Center");
/*     */ 
/* 118 */     clientPanel.add(clientIdPanel);
/* 119 */     clientPanel.add(clientNamePanel);
/* 120 */     return clientPanel;
/*     */   }
/*     */ 
/*     */   private JPanel getTimingsPanel() {
/* 124 */     SpringLayout timingsLayout = new SpringLayout();
/* 125 */     JPanel timingsPanel = new JPanel(timingsLayout);
/* 126 */     timingsPanel.setBorder(BorderFactory.createTitledBorder("Timings ..."));
/*     */ 
/* 128 */     JLabel pollDelayLabel = new JLabel("Poll Delay [ms]");
/* 129 */     JTextField pollDelayField = new JTextField(Long.toString(this.tagServiceConfig.getPollInterval()), 4);
/* 130 */     pollDelayField.setEditable(false);
/* 131 */     pollDelayField.setMaximumSize(new Dimension(pollDelayField.getPreferredSize().width, pollDelayField.getMaximumSize().height));
/* 132 */     this.pollDelaySlider = new JSlider(0, 2000, (int)this.tagServiceConfig.getPollInterval());
/* 133 */     this.pollDelaySlider.setMajorTickSpacing(1000);
/* 134 */     this.pollDelaySlider.setMinorTickSpacing(100);
/* 135 */     this.pollDelaySlider.setPaintTicks(true);
/* 136 */     this.pollDelaySlider.addChangeListener(new ChangeListener(pollDelayField)
/*     */     {
/*     */       public void stateChanged(ChangeEvent e) {
/* 139 */         this.val$pollDelayField.setText(Integer.toString(TagServiceConfigurationGUI.this.pollDelaySlider.getValue()));
/*     */       }
/*     */     });
/* 143 */     JLabel putThresholdLabel = new JLabel("Put Threshold [ms]");
/* 144 */     JTextField putThresholdField = new JTextField(Long.toString(this.tagServiceConfig.getPutThresholdTime()), 4);
/* 145 */     putThresholdField.setEditable(false);
/* 146 */     putThresholdField.setMaximumSize(new Dimension(putThresholdField.getPreferredSize().width, putThresholdField.getMaximumSize().height));
/* 147 */     this.putThresholdSlider = new JSlider(0, 10000, (int)this.tagServiceConfig.getPutThresholdTime());
/* 148 */     this.putThresholdSlider.setMajorTickSpacing(1000);
/* 149 */     this.putThresholdSlider.setMinorTickSpacing(250);
/* 150 */     this.putThresholdSlider.setPaintTicks(true);
/* 151 */     this.putThresholdSlider.addChangeListener(new ChangeListener(putThresholdField)
/*     */     {
/*     */       public void stateChanged(ChangeEvent e) {
/* 154 */         this.val$putThresholdField.setText(Integer.toString(TagServiceConfigurationGUI.this.putThresholdSlider.getValue()));
/*     */       }
/*     */     });
/* 158 */     JLabel serverReconnectThresholdLabel = new JLabel("Server Reconnect Threshold [ms]");
/* 159 */     JTextField serverReconnectThresholdField = new JTextField(Long.toString(this.tagServiceConfig.getServerReconnectTreshold()), 4);
/* 160 */     serverReconnectThresholdField.setEditable(false);
/* 161 */     serverReconnectThresholdField.setMaximumSize(new Dimension(serverReconnectThresholdField.getPreferredSize().width, serverReconnectThresholdField.getMaximumSize().height));
/* 162 */     this.serverReconnectThresholdSlider = new JSlider(0, 60000, (int)this.tagServiceConfig.getServerReconnectTreshold());
/* 163 */     this.serverReconnectThresholdSlider.setMajorTickSpacing(6000);
/* 164 */     this.serverReconnectThresholdSlider.setMinorTickSpacing(1500);
/* 165 */     this.serverReconnectThresholdSlider.setPaintTicks(true);
/* 166 */     this.serverReconnectThresholdSlider.addChangeListener(new ChangeListener(serverReconnectThresholdField)
/*     */     {
/*     */       public void stateChanged(ChangeEvent e) {
/* 169 */         this.val$serverReconnectThresholdField.setText(Integer.toString(TagServiceConfigurationGUI.this.serverReconnectThresholdSlider.getValue()));
/*     */       }
/*     */     });
/* 173 */     timingsPanel.add(pollDelayLabel);
/* 174 */     timingsPanel.add(this.pollDelaySlider);
/* 175 */     timingsPanel.add(pollDelayField);
/*     */ 
/* 177 */     timingsPanel.add(putThresholdLabel);
/* 178 */     timingsPanel.add(this.putThresholdSlider);
/* 179 */     timingsPanel.add(putThresholdField);
/*     */ 
/* 181 */     timingsPanel.add(serverReconnectThresholdLabel);
/* 182 */     timingsPanel.add(this.serverReconnectThresholdSlider);
/* 183 */     timingsPanel.add(serverReconnectThresholdField);
/*     */ 
/* 185 */     timingsLayout.putConstraint("West", pollDelayLabel, 0, "West", timingsPanel);
/* 186 */     timingsLayout.putConstraint("West", this.pollDelaySlider, 5, "East", pollDelayLabel);
/* 187 */     timingsLayout.putConstraint("West", pollDelayField, 5, "East", this.pollDelaySlider);
/* 188 */     timingsLayout.putConstraint("West", putThresholdLabel, 0, "West", timingsPanel);
/* 189 */     timingsLayout.putConstraint("West", this.putThresholdSlider, 5, "East", putThresholdLabel);
/* 190 */     timingsLayout.putConstraint("West", putThresholdField, 5, "East", this.putThresholdSlider);
/* 191 */     timingsLayout.putConstraint("West", serverReconnectThresholdLabel, 0, "West", timingsPanel);
/* 192 */     timingsLayout.putConstraint("West", this.serverReconnectThresholdSlider, 5, "East", serverReconnectThresholdLabel);
/* 193 */     timingsLayout.putConstraint("West", serverReconnectThresholdField, 5, "East", this.serverReconnectThresholdSlider);
/*     */ 
/* 195 */     timingsLayout.putConstraint("North", pollDelayLabel, 0, "North", timingsPanel);
/* 196 */     timingsLayout.putConstraint("North", this.pollDelaySlider, 0, "North", timingsPanel);
/* 197 */     timingsLayout.putConstraint("North", pollDelayField, 0, "North", timingsPanel);
/* 198 */     timingsLayout.putConstraint("North", putThresholdLabel, 5, "South", pollDelayField);
/* 199 */     timingsLayout.putConstraint("North", this.putThresholdSlider, 5, "South", pollDelayField);
/* 200 */     timingsLayout.putConstraint("North", putThresholdField, 5, "South", pollDelayField);
/* 201 */     timingsLayout.putConstraint("North", serverReconnectThresholdLabel, 5, "South", putThresholdField);
/* 202 */     timingsLayout.putConstraint("North", this.serverReconnectThresholdSlider, 5, "South", putThresholdField);
/* 203 */     timingsLayout.putConstraint("North", serverReconnectThresholdField, 5, "South", putThresholdField);
/*     */ 
/* 205 */     timingsLayout.putConstraint("East", timingsPanel, 0, "East", serverReconnectThresholdField);
/* 206 */     timingsLayout.putConstraint("South", timingsPanel, 0, "South", serverReconnectThresholdField);
/*     */ 
/* 208 */     timingsLayout.putConstraint("East", pollDelayLabel, 0, "East", putThresholdLabel);
/* 209 */     timingsLayout.putConstraint("East", this.pollDelaySlider, 0, "East", this.putThresholdSlider);
/* 210 */     timingsLayout.putConstraint("East", pollDelayField, 0, "East", putThresholdField);
/*     */ 
/* 212 */     timingsLayout.putConstraint("East", putThresholdLabel, 0, "East", serverReconnectThresholdLabel);
/* 213 */     timingsLayout.putConstraint("East", this.putThresholdSlider, 0, "East", this.serverReconnectThresholdSlider);
/* 214 */     timingsLayout.putConstraint("East", putThresholdField, 0, "East", serverReconnectThresholdField);
/* 215 */     return timingsPanel;
/*     */   }
/*     */ 
/*     */   public void show() {
/* 219 */     this.configDialog.setVisible(true);
/*     */   }
/*     */ 
/*     */   private void hide() {
/* 223 */     this.configDialog.setVisible(false);
/*     */   }
/*     */ 
/*     */   private class CancelAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public CancelAction()
/*     */     {
/* 294 */       super("CANCEL");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 299 */       TagServiceConfigurationGUI.this.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class OkAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public OkAction()
/*     */     {
/* 266 */       super("OK");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 271 */       TagServiceConfigurationGUI.this.tagServiceConfig.setClientId(new ClientId(TagServiceConfigurationGUI.this.clientIdField.getText(), TagServiceConfigurationGUI.this.clientNameField.getText()));
/* 272 */       TagServiceConfigurationGUI.this.tagServiceConfig.setPollInterval(TagServiceConfigurationGUI.this.pollDelaySlider.getValue());
/* 273 */       TagServiceConfigurationGUI.this.tagServiceConfig.setPutThresholdTime(TagServiceConfigurationGUI.this.putThresholdSlider.getValue());
/* 274 */       TagServiceConfigurationGUI.this.tagServiceConfig.setServerReconnectTreshold(TagServiceConfigurationGUI.this.serverReconnectThresholdSlider.getValue());
/*     */ 
/* 276 */       List detectTagTypes = new ArrayList();
/* 277 */       for (TagServiceConfigurationGUI.TagTypeCheck tagTypeCheck : TagServiceConfigurationGUI.this.tagTypeChecks) {
/* 278 */         if (tagTypeCheck.isChecked()) {
/* 279 */           detectTagTypes.add(tagTypeCheck.getTagType());
/*     */         }
/*     */       }
/* 282 */       TagServiceConfigurationGUI.this.tagServiceConfig.setDetectTagTypes((TagType[])detectTagTypes.toArray(new TagType[detectTagTypes.size()]));
/*     */ 
/* 284 */       TagServiceConfigurationGUI.this.hide();
/*     */     }
/*     */   }
/*     */ 
/*     */   private class GenerateClientIdAction extends AbstractAction
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */ 
/*     */     public GenerateClientIdAction()
/*     */     {
/* 252 */       super("Generate");
/*     */     }
/*     */ 
/*     */     public void actionPerformed(ActionEvent e)
/*     */     {
/* 257 */       TagServiceConfigurationGUI.this.clientIdField.setText(TagServiceConfigurationGUI.this.tagServiceConfig.generateClientId());
/*     */     }
/*     */   }
/*     */ 
/*     */   private class TagTypeCheck
/*     */   {
/*     */     private JCheckBox checkBox;
/*     */     private TagType tagType;
/*     */ 
/*     */     public TagTypeCheck(TagType paramTagType)
/*     */     {
/* 231 */       this.checkBox = new JCheckBox(paramTagType.toString());
/* 232 */       this.tagType = paramTagType;
/*     */     }
/*     */ 
/*     */     public JCheckBox getCheckBox() {
/* 236 */       return this.checkBox;
/*     */     }
/*     */ 
/*     */     public TagType getTagType() {
/* 240 */       return this.tagType;
/*     */     }
/*     */ 
/*     */     public boolean isChecked() {
/* 244 */       return this.checkBox.isSelected();
/*     */     }
/*     */   }
/*     */ }