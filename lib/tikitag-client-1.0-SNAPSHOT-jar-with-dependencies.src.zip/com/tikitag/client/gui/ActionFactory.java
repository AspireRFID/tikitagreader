package com.tikitag.client.gui;

import com.tikitag.client.TikitagClient.ActionLauncherAction;
import javax.swing.Action;

public abstract interface ActionFactory
{
  public abstract Action getExitAction();

  public abstract Action getReadWriteTagAction();

  public abstract TikitagClient.ActionLauncherAction getActionLauncherAction();

  public abstract Action getKeyConfigurationAction();

  public abstract Action getLoginCredentialsAction();

  public abstract Action getTagServiceConfigurationAction();
}