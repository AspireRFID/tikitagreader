/*    */ package com.tikitag.client.gui;
/*    */ 
/*    */ import java.awt.Dimension;
/*    */ import java.awt.Frame;
/*    */ import java.awt.Image;
/*    */ import java.awt.TrayIcon;
/*    */ import java.awt.event.MouseAdapter;
/*    */ import java.awt.event.MouseEvent;
/*    */ import javax.swing.JDialog;
/*    */ import javax.swing.JPopupMenu;
/*    */ import javax.swing.event.PopupMenuEvent;
/*    */ import javax.swing.event.PopupMenuListener;
/*    */ 
/*    */ public class JXTrayIcon extends TrayIcon
/*    */ {
/*    */   private JPopupMenu menu;
/* 19 */   private static JDialog dialog = new JDialog((Frame)null, "TrayDialog");
/*    */   private static PopupMenuListener popupListener;
/*    */ 
/*    */   public JXTrayIcon(Image image)
/*    */   {
/* 39 */     super(image);
/* 40 */     addMouseListener(new MouseAdapter() {
/*    */       public void mousePressed(MouseEvent e) {
/* 42 */         JXTrayIcon.this.showJPopupMenu(e);
/*    */       }
/*    */ 
/*    */       public void mouseReleased(MouseEvent e) {
/* 46 */         JXTrayIcon.this.showJPopupMenu(e);
/*    */       }
/*    */     });
/*    */   }
/*    */ 
/*    */   private void showJPopupMenu(MouseEvent e) {
/* 52 */     if ((e.isPopupTrigger()) && (this.menu != null)) {
/* 53 */       Dimension size = this.menu.getPreferredSize();
/* 54 */       dialog.setLocation(e.getX(), e.getY() - size.height);
/* 55 */       dialog.setVisible(true);
/* 56 */       this.menu.show(dialog.getContentPane(), 0, 0);
/*    */ 
/* 58 */       dialog.toFront();
/*    */     }
/*    */   }
/*    */ 
/*    */   public JPopupMenu getJPopuMenu() {
/* 63 */     return this.menu;
/*    */   }
/*    */ 
/*    */   public void setJPopuMenu(JPopupMenu menu) {
/* 67 */     if (this.menu != null) {
/* 68 */       this.menu.removePopupMenuListener(popupListener);
/*    */     }
/* 70 */     this.menu = menu;
/* 71 */     menu.addPopupMenuListener(popupListener);
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 20 */     dialog.setUndecorated(true);
/* 21 */     dialog.setAlwaysOnTop(true);
/*    */ 
/* 24 */     popupListener = new PopupMenuListener() {
/*    */       public void popupMenuWillBecomeVisible(PopupMenuEvent e) {
/*    */       }
/*    */ 
/*    */       public void popupMenuWillBecomeInvisible(PopupMenuEvent e) {
/* 29 */         JXTrayIcon.dialog.setVisible(false);
/*    */       }
/*    */ 
/*    */       public void popupMenuCanceled(PopupMenuEvent e) {
/* 33 */         JXTrayIcon.dialog.setVisible(false);
/*    */       }
/*    */     };
/*    */   }
/*    */ }