/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.util.Comparator;
/*    */ 
/*    */ public class ClassHierarchyComparator
/*    */   implements Comparator<Class<?>>
/*    */ {
/*    */   public int compare(Class<?> o1, Class<?> o2)
/*    */   {
/* 13 */     if (o1 == null) {
/* 14 */       if (o2 == null) {
/* 15 */         return 0;
/*    */       }
/*    */ 
/* 18 */       return 1;
/*    */     }
/* 20 */     if (o2 == null)
/*    */     {
/* 22 */       return -1;
/*    */     }
/*    */ 
/* 26 */     if ((!(o1 instanceof Class)) || (!(o2 instanceof Class)))
/* 27 */       throw new IllegalArgumentException("Only arguments of type java.lang.Class allowed!");
/* 28 */     Class c1 = o1;
/* 29 */     Class c2 = o2;
/*    */ 
/* 32 */     if (c1.equals(c2)) {
/* 33 */       return 0;
/*    */     }
/*    */ 
/* 38 */     boolean c1Lower = c2.isAssignableFrom(c1);
/* 39 */     boolean c2Lower = c1.isAssignableFrom(c2);
/*    */ 
/* 41 */     if ((c1Lower) && (!(c2Lower)))
/* 42 */       return -1;
/* 43 */     if ((c2Lower) && (!(c1Lower))) {
/* 44 */       return 1;
/*    */     }
/*    */ 
/* 48 */     return c1.getName().compareTo(c2.getName());
/*    */   }
/*    */ }