/*     */ package com.tikitag.util;
/*     */ 
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.Formatter;
/*     */ 
/*     */ public class HexFormatter
/*     */ {
/*  24 */   static char[] hexChar = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
/*     */ 
/*     */   public static String toHexString(byte[] b)
/*     */   {
/*  12 */     StringBuffer sb = new StringBuffer(b.length * 2);
/*  13 */     for (int i = 0; i < b.length; ++i)
/*     */     {
/*  15 */       sb.append(hexChar[((b[i] & 0xF0) >>> 4)]);
/*     */ 
/*  18 */       sb.append(hexChar[(b[i] & 0xF)]);
/*     */     }
/*  20 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static byte[] fromHexString(String s)
/*     */   {
/*  34 */     int stringLength = s.length();
/*  35 */     if ((stringLength & 0x1) != 0)
/*     */     {
/*  38 */       s = new StringBuilder().append("0").append(s).toString();
/*  39 */       stringLength = s.length();
/*     */     }
/*  41 */     byte[] b = new byte[stringLength / 2];
/*     */ 
/*  43 */     int i = 0; for (int j = 0; i < stringLength; ++j) {
/*  44 */       int high = charToNibble(s.charAt(i));
/*  45 */       int low = charToNibble(s.charAt(i + 1));
/*  46 */       b[j] = (byte)(high << 4 | low);
/*     */ 
/*  43 */       i += 2;
/*     */     }
/*     */ 
/*  48 */     return b;
/*     */   }
/*     */ 
/*     */   private static int charToNibble(char c) {
/*  52 */     if (('0' <= c) && (c <= '9'))
/*  53 */       return (c - '0');
/*  54 */     if (('a' <= c) && (c <= 'f'))
/*  55 */       return (c - 'a' + 10);
/*  56 */     if (('A' <= c) && (c <= 'F')) {
/*  57 */       return (c - 'A' + 10);
/*     */     }
/*  59 */     throw new IllegalArgumentException(new StringBuilder().append("Invalid hex character: ").append(c).toString());
/*     */   }
/*     */ 
/*     */   public static String toHexString(int i)
/*     */   {
/*  64 */     String response = Integer.toHexString(i);
/*  65 */     if (response.length() == 1) {
/*  66 */       response = new StringBuilder().append("0").append(response.toUpperCase()).toString();
/*     */     }
/*  68 */     return response;
/*     */   }
/*     */ 
/*     */   public static String pageView(String hexString)
/*     */   {
/*  77 */     StringBuilder pageView = new StringBuilder();
/*  78 */     Formatter offsetFormat = new Formatter(pageView);
/*     */ 
/*  80 */     if (hexString.length() % 8 != 0) {
/*  81 */       hexString = new StringBuilder().append(hexString).append(addPadding(hexString.length() % 8)).toString();
/*     */     }
/*  83 */     int pages = hexString.length() / 8;
/*  84 */     for (int page = 0; page < pages; ++page) {
/*  85 */       String pageContent = hexString.substring(page * 8, page * 8 + 8);
/*  86 */       String byte0 = pageContent.substring(0, 2);
/*  87 */       String byte1 = pageContent.substring(2, 4);
/*  88 */       String byte2 = pageContent.substring(4, 6);
/*  89 */       String byte3 = pageContent.substring(6, 8);
/*     */ 
/*  91 */       offsetFormat.format("Page %04X : %2s:%2s:%2s:%2s     %s\n", new Object[] { Integer.valueOf(page), byte0, byte1, byte2, byte3, utf8(fromHexString(pageContent.replaceAll("-", "0"))) });
/*     */     }
/*     */ 
/* 101 */     return pageView.toString();
/*     */   }
/*     */ 
/*     */   public static String utf8(byte[] data)
/*     */   {
/*     */     try
/*     */     {
/* 111 */       return new String(data, "UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 114 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public static byte[] utf8(String string)
/*     */   {
/*     */     try
/*     */     {
/* 125 */       return string.getBytes("UTF-8");
/*     */     }
/*     */     catch (UnsupportedEncodingException e) {
/* 128 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static String addPadding(int requiredPadding) {
/* 133 */     StringBuilder sb = new StringBuilder();
/* 134 */     for (int i = 0; i < requiredPadding; ++i) {
/* 135 */       sb.append("-");
/*     */     }
/* 137 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public static String convertToUnicodeString(String hexString) {
/* 141 */     return utf8(fromHexString(hexString));
/*     */   }
/*     */ 
/*     */   public static String convertByteToUnicodeString(byte[] b)
/*     */   {
/* 154 */     return convertToUnicodeString(toHexString(b));
/*     */   }
/*     */ }