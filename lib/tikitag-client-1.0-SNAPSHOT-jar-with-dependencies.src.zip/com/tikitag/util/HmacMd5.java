/*     */ package com.tikitag.util;
/*     */ 
/*     */ import java.security.MessageDigest;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ 
/*     */ public class HmacMd5
/*     */ {
/*     */   private byte[] digest;
/*     */   private byte[] kIpad;
/*     */   private byte[] kOpad;
/*     */   private MessageDigest innerMD5;
/*     */ 
/*     */   public HmacMd5(byte[] key)
/*     */   {
/*  35 */     int kLen = key.length;
/*     */ 
/*  38 */     if (kLen > 64)
/*     */     {
/*  40 */       MessageDigest md5 = newMD5();
/*  41 */       md5.update(key);
/*  42 */       key = md5.digest();
/*     */     }
/*     */ 
/*  45 */     this.kIpad = new byte[64];
/*     */ 
/*  47 */     this.kOpad = new byte[64];
/*     */ 
/*  50 */     System.arraycopy(key, 0, this.kIpad, 0, kLen);
/*  51 */     System.arraycopy(key, 0, this.kOpad, 0, kLen);
/*     */ 
/*  54 */     for (int i = 0; i < 64; ++i)
/*     */     {
/*     */       int tmp79_78 = i;
/*     */       byte[] tmp79_75 = this.kIpad; tmp79_75[tmp79_78] = (byte)(tmp79_75[tmp79_78] ^ 0x36);
/*     */       int tmp91_90 = i;
/*     */       byte[] tmp91_87 = this.kOpad; tmp91_87[tmp91_90] = (byte)(tmp91_87[tmp91_90] ^ 0x5C);
/*     */     }
/*     */ 
/*  60 */     clear();
/*     */   }
/*     */ 
/*     */   public void clear()
/*     */   {
/*  70 */     this.innerMD5 = newMD5();
/*  71 */     this.innerMD5.update(this.kIpad);
/*     */ 
/*  73 */     this.digest = null;
/*     */   }
/*     */ 
/*     */   public void addData(byte[] text)
/*     */   {
/*  87 */     addData(text, 0, text.length);
/*     */   }
/*     */ 
/*     */   public void addData(byte[] text, int textStart, int textLen)
/*     */   {
/* 103 */     this.innerMD5.update(text, textStart, textLen);
/*     */   }
/*     */ 
/*     */   public byte[] sign()
/*     */   {
/* 123 */     this.digest = this.innerMD5.digest();
/*     */ 
/* 127 */     MessageDigest md5 = newMD5();
/* 128 */     md5.update(this.kOpad);
/* 129 */     md5.update(this.digest);
/* 130 */     this.digest = md5.digest();
/*     */ 
/* 132 */     return this.digest;
/*     */   }
/*     */ 
/*     */   private MessageDigest newMD5()
/*     */   {
/*     */     try {
/* 138 */       return MessageDigest.getInstance("MD5");
/*     */     } catch (NoSuchAlgorithmException e) {
/* 140 */       throw new RuntimeException(e);
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean verify(byte[] signature)
/*     */   {
/* 155 */     if (this.digest == null) {
/* 156 */       sign();
/*     */     }
/* 158 */     int sigLen = signature.length;
/* 159 */     int digLen = this.digest.length;
/*     */ 
/* 161 */     if (sigLen != digLen) {
/* 162 */       return false;
/*     */     }
/* 164 */     for (int i = 0; i < sigLen; ++i) {
/* 165 */       if (signature[i] != this.digest[i])
/* 166 */         return false;
/*     */     }
/* 168 */     return true;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 179 */     if (this.digest == null) {
/* 180 */       sign();
/*     */     }
/* 182 */     StringBuffer r = new StringBuffer();
/* 183 */     String hex = "0123456789ABCDEF";
/* 184 */     byte[] b = this.digest;
/*     */ 
/* 186 */     for (int i = 0; i < 16; ++i)
/*     */     {
/* 188 */       int c = b[i] >>> 4 & 0xF;
/* 189 */       r.append("0123456789ABCDEF".charAt(c));
/* 190 */       c = b[i] & 0xF;
/* 191 */       r.append("0123456789ABCDEF".charAt(c));
/*     */     }
/*     */ 
/* 194 */     return r.toString();
/*     */   }
/*     */ }