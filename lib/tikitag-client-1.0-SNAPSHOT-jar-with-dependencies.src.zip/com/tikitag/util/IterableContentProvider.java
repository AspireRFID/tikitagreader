/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.Collection;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class IterableContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 18 */     String result = null;
/* 19 */     if (object.getClass().isArray()) {
/* 20 */       result = "array";
/*    */     }
/* 22 */     else if (object instanceof List) {
/* 23 */       result = "list";
/*    */     }
/* 25 */     else if (object instanceof Set) {
/* 26 */       result = "set";
/*    */     }
/* 28 */     else if (object instanceof Collection)
/* 29 */       result = "collection";
/*    */     else
/* 31 */       result = "iterable";
/* 32 */     return result;
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 37 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 42 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 47 */     Object[] result = TreeContentProvider.EMPTY_OBJECT_ARRAY;
/* 48 */     if (object.getClass().isArray())
/* 49 */       return ((Object[])(Object[])object);
/* 50 */     if (object instanceof Iterable) {
/* 51 */       Iterable iterable = (Iterable)object;
/* 52 */       List objectList = new ArrayList();
/* 53 */       for (Iterator i$ = iterable.iterator(); i$.hasNext(); ) { Object candidate = i$.next();
/* 54 */         objectList.add(candidate); }
/* 55 */       result = objectList.toArray();
/*    */     }
/* 57 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 62 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 67 */     return true;
/*    */   }
/*    */ }