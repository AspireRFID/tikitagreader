package com.tikitag.util;

public abstract interface InnerContentDelegate
{
  public abstract Class<?>[] getSupportedClasses();
}