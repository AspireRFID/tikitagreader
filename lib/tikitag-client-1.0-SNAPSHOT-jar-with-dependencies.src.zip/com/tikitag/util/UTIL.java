package com.tikitag.util;

public class UTIL
{
  public static final long UID = 1L;
}