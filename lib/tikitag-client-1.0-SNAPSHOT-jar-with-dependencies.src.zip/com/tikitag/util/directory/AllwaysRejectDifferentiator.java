/*    */ package com.tikitag.util.directory;
/*    */ 
/*    */ public class AllwaysRejectDifferentiator
/*    */   implements Differentiator
/*    */ {
/*    */   public Attribute differentiate(Entry entry)
/*    */     throws NoKnownStrategyException
/*    */   {
/* 11 */     throw new NoKnownStrategyException("Differentiation is not supported!");
/*    */   }
/*    */ }