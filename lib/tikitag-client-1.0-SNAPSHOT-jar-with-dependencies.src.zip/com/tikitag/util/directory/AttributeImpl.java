/*    */ package com.tikitag.util.directory;
/*    */ 
/*    */ public class AttributeImpl
/*    */   implements Attribute
/*    */ {
/*    */   private String name;
/*    */   private String value;
/*    */ 
/*    */   public AttributeImpl(String name, String value)
/*    */   {
/* 11 */     this.name = name;
/* 12 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 17 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getValue()
/*    */   {
/* 22 */     return this.value;
/*    */   }
/*    */ }