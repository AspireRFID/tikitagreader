package com.tikitag.util.directory;

import java.util.Set;

public abstract interface Directory
{
  public abstract Set<Object> findAll(String paramString);

  public abstract Object find(String paramString);

  public abstract boolean exists(String paramString);

  public abstract int count(String paramString);

  public abstract Entry bind(Object paramObject, String paramString)
    throws DirectoryException;

  public abstract Entry remove(String paramString);

  public abstract void setDefaultDifferentiator(Differentiator paramDifferentiator);
}