/*    */ package com.tikitag.util.directory;
/*    */ 
/*    */ public class DirectoryException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = -7887482399994405060L;
/*    */ 
/*    */   public DirectoryException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public DirectoryException(String message)
/*    */   {
/* 13 */     super(message);
/*    */   }
/*    */ 
/*    */   public DirectoryException(Throwable cause) {
/* 17 */     super(cause);
/*    */   }
/*    */ 
/*    */   public DirectoryException(String message, Throwable cause) {
/* 21 */     super(message, cause);
/*    */   }
/*    */ }