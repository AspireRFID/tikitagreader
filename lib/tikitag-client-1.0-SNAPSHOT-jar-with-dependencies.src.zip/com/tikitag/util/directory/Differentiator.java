package com.tikitag.util.directory;

public abstract interface Differentiator
{
  public abstract Attribute differentiate(Entry paramEntry)
    throws NoKnownStrategyException;
}