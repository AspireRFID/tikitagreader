package com.tikitag.util.directory;

import java.util.List;

public abstract interface Entry
{
  public abstract Container getContainer();

  public abstract List<Attribute> getAttributes();

  public abstract void add(Attribute paramAttribute);

  public abstract boolean hasAttribute(String paramString);

  public abstract int count(String paramString);
}