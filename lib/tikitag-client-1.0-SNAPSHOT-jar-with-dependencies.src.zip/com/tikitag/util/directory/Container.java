package com.tikitag.util.directory;

import java.util.List;

public abstract interface Container extends Entry
{
  public abstract List<Entry> getEntries();

  public abstract Differentiator getDifferentiator();

  public abstract Entry bind(Object paramObject, String paramString);

  public abstract Entry bind(Object paramObject, List<Attribute> paramList);

  public abstract Container deepen(String paramString);
}