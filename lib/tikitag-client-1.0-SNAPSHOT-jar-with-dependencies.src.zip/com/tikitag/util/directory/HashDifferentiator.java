/*    */ package com.tikitag.util.directory;
/*    */ 
/*    */ public class HashDifferentiator
/*    */   implements Differentiator
/*    */ {
/*    */   public Attribute differentiate(Entry entry)
/*    */     throws NoKnownStrategyException
/*    */   {
/* 12 */     if (entry instanceof Object) {
/* 13 */       differentiate((Object)entry);
/*    */     }
/* 15 */     else if (entry instanceof Container) {
/* 16 */       differentiate((Container)entry);
/*    */     }
/* 18 */     throw new NoKnownStrategyException("Unknown directory entry type " + entry.getClass() + "!");
/*    */   }
/*    */ 
/*    */   private Attribute differentiate(Container container) throws NoKnownStrategyException {
/* 22 */     if (container.hasAttribute("hash"))
/* 23 */       throw new NoKnownStrategyException("Hash attribute already defined!");
/* 24 */     Attribute result = new AttributeImpl("hash", String.valueOf(container.hashCode()));
/* 25 */     container.add(result);
/* 26 */     return result;
/*    */   }
/*    */ 
/*    */   private Attribute differentiate(Object object) throws NoKnownStrategyException {
/* 30 */     if (object.hasAttribute("hash"))
/* 31 */       throw new NoKnownStrategyException("Hash attribute already defined!");
/* 32 */     Attribute result = new AttributeImpl("hash", String.valueOf(object.hashCode()));
/* 33 */     object.add(result);
/* 34 */     return result;
/*    */   }
/*    */ }