/*    */ package com.tikitag.util.directory;
/*    */ 
/*    */ public class NoKnownStrategyException extends DirectoryException
/*    */ {
/*    */   private static final long serialVersionUID = 8692734883446227596L;
/*    */ 
/*    */   public NoKnownStrategyException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public NoKnownStrategyException(String message, Throwable cause)
/*    */   {
/* 19 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public NoKnownStrategyException(String message) {
/* 23 */     super(message);
/*    */   }
/*    */ 
/*    */   public NoKnownStrategyException(Throwable cause) {
/* 27 */     super(cause);
/*    */   }
/*    */ }