package com.tikitag.util.directory;

public abstract interface Object<T> extends Entry
{
  public abstract T get();
}