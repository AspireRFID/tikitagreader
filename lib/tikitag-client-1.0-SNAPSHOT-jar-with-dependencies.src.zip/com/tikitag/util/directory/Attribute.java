package com.tikitag.util.directory;

public abstract interface Attribute
{
  public abstract String getName();

  public abstract String getValue();
}