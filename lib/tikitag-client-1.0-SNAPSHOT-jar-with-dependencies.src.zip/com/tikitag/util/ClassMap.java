/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.util.Collection;
/*    */ import java.util.Comparator;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Map.Entry;
/*    */ import java.util.Set;
/*    */ import java.util.TreeMap;
/*    */ 
/*    */ public class ClassMap<E>
/*    */   implements Map<Class<?>, E>
/*    */ {
/* 21 */   static final Comparator<Class<?>> CLASS_COMPARATOR = new ClassHierarchyComparator();
/*    */   private Map<Class<?>, E> map;
/*    */ 
/*    */   public ClassMap()
/*    */   {
/* 23 */     this.map = new TreeMap(CLASS_COMPARATOR); }
/*    */ 
/*    */   public void clear() {
/* 26 */     this.map.clear();
/*    */   }
/*    */ 
/*    */   public boolean containsKey(Object key) {
/* 30 */     if (!(key instanceof Class))
/* 31 */       throw new IllegalArgumentException("Only class keys allowed!");
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean containsValue(Object value) {
/* 36 */     return this.map.containsValue(value);
/*    */   }
/*    */ 
/*    */   public Set<Map.Entry<Class<?>, E>> entrySet() {
/* 40 */     return this.map.entrySet();
/*    */   }
/*    */ 
/*    */   public E get(Object key) {
/* 44 */     if (!(key instanceof Class))
/* 45 */       throw new IllegalArgumentException("Only class keys allowed!");
/* 46 */     Class clazz = (Class)key;
/* 47 */     Iterator iterator = this.map.keySet().iterator();
/* 48 */     while (iterator.hasNext()) {
/* 49 */       Class candidate = (Class)iterator.next();
/* 50 */       if (candidate.isAssignableFrom(clazz))
/* 51 */         return this.map.get(candidate);
/*    */     }
/* 53 */     return null;
/*    */   }
/*    */ 
/*    */   public boolean isEmpty() {
/* 57 */     return this.map.isEmpty();
/*    */   }
/*    */ 
/*    */   public Set<Class<?>> keySet() {
/* 61 */     return this.map.keySet();
/*    */   }
/*    */ 
/*    */   public E put(Class<?> key, E value) {
/* 65 */     if (!(key instanceof Class))
/* 66 */       throw new IllegalArgumentException("Only class keys allowed!");
/* 67 */     return this.map.put(key, value);
/*    */   }
/*    */ 
/*    */   public void putAll(Map map)
/*    */   {
/* 74 */     Iterator iterator = map.keySet().iterator();
/*    */     do if (!(iterator.hasNext())) break label43;
/* 76 */     while (iterator.next() instanceof Class);
/* 77 */     throw new IllegalArgumentException("Only class keys allowed!");
/* 78 */     label43: map.putAll(map);
/*    */   }
/*    */ 
/*    */   public E remove(Object key) {
/* 82 */     return this.map.remove(key);
/*    */   }
/*    */ 
/*    */   public int size() {
/* 86 */     return this.map.size();
/*    */   }
/*    */ 
/*    */   public Collection<E> values() {
/* 90 */     return this.map.values();
/*    */   }
/*    */ }