/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.io.ByteArrayOutputStream;
/*    */ import java.io.IOException;
/*    */ import java.io.InputStream;
/*    */ 
/*    */ public class IOUtil
/*    */ {
/*    */   public static byte[] readInputStream(InputStream inputStream)
/*    */   {
/* 10 */     ByteArrayOutputStream output = new ByteArrayOutputStream();
/* 11 */     byte[] buffer = new byte[512];
/* 12 */     int readBytes = 0;
/*    */     try
/*    */     {
/* 15 */       readBytes = inputStream.read(buffer);
/* 16 */       while (readBytes != -1) {
/* 17 */         output.write(buffer, 0, readBytes);
/* 18 */         readBytes = inputStream.read(buffer);
/*    */       }
/*    */     } catch (IOException e) {
/* 21 */       e.printStackTrace();
/*    */     }
/*    */ 
/* 24 */     return output.toByteArray();
/*    */   }
/*    */ }