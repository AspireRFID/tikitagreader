/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.util.prefs.Preferences;
/*    */ 
/*    */ public class PrefsKeyProvider
/*    */   implements KeyProvider
/*    */ {
/*    */   private static final String TIKITAG_HASH_KEY = "tikitag.hash.key";
/*  7 */   private static final Preferences prefs = Preferences.userNodeForPackage(PrefsKeyProvider.class);
/*    */ 
/*    */   public byte[] getKey() {
/* 10 */     return HexFormatter.fromHexString(prefs.get("tikitag.hash.key", ""));
/*    */   }
/*    */ 
/*    */   public void setKey(String hexKey) {
/* 14 */     prefs.put("tikitag.hash.key", hexKey);
/*    */   }
/*    */ }