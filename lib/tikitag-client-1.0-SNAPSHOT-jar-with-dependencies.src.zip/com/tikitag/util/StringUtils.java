/*    */ package com.tikitag.util;
/*    */ 
/*    */ import java.util.List;
/*    */ 
/*    */ public class StringUtils
/*    */ {
/*    */   public static String toCommaSeperated(String[] parts)
/*    */   {
/* 15 */     StringBuilder result = new StringBuilder();
/* 16 */     for (String part : parts) {
/* 17 */       if (result.length() != 0) {
/* 18 */         result.append(", ");
/*    */       }
/* 20 */       result.append(part);
/*    */     }
/* 22 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public static String toCommaSeperated(List<String> parts)
/*    */   {
/* 33 */     return toCommaSeperated((String[])parts.toArray(new String[parts.size()]));
/*    */   }
/*    */ 
/*    */   public static String[] fromCommaSeperated(String commaSeperatedString)
/*    */   {
/* 44 */     return commaSeperatedString.split("\\s*,\\s*");
/*    */   }
/*    */ }