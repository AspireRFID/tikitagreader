/*    */ package com.tikitag.util;
/*    */ 
/*    */ public abstract interface TreeContentProvider
/*    */ {
/* 13 */   public static final Object[] EMPTY_OBJECT_ARRAY = new Object[0];
/*    */ 
/*    */   public abstract boolean hasChildren(Object paramObject);
/*    */ 
/*    */   public abstract Object[] getChildren(Object paramObject);
/*    */ 
/*    */   public abstract boolean hasAttributes(Object paramObject);
/*    */ 
/*    */   public abstract Object[] getAttributes(Object paramObject);
/*    */ 
/*    */   public abstract String asString(Object paramObject);
/*    */ 
/*    */   public abstract String asString(Object paramObject1, Object paramObject2);
/*    */ }