/*     */ package com.tikitag.util.config.xml;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.TreeMap;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlElement;
/*     */ import javax.xml.bind.annotation.adapters.XmlAdapter;
/*     */ import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;
/*     */ 
/*     */ @XmlJavaTypeAdapter(ConfigContainerAdapter.class)
/*     */ public class ConfigContainer
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String name;
/*  26 */   private Map<String, List<ConfigAttribute>> attributes = new TreeMap();
/*  27 */   private Map<String, List<ConfigContainer>> containers = new TreeMap();
/*     */ 
/*     */   protected ConfigContainer() { }
/*     */ 
/*     */   public ConfigContainer(String name) {
/*  32 */     if (name == null) {
/*  33 */       throw new IllegalArgumentException("name is required");
/*     */     }
/*  35 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  41 */     return this.name;
/*     */   }
/*     */ 
/*     */   public ConfigContainer set(ConfigAttribute attribute)
/*     */   {
/*  52 */     String attributeName = attribute.getName();
/*     */ 
/*  55 */     List atts = new ArrayList();
/*  56 */     atts.add(attribute);
/*     */ 
/*  58 */     this.attributes.put(attributeName, atts);
/*  59 */     return this;
/*     */   }
/*     */ 
/*     */   public ConfigContainer add(ConfigAttribute attribute)
/*     */   {
/*  69 */     String attributeName = attribute.getName();
/*     */ 
/*  71 */     List atts = (List)this.attributes.get(attributeName);
/*  72 */     if (atts == null) {
/*  73 */       atts = new ArrayList();
/*     */     }
/*  75 */     atts.add(attribute);
/*     */ 
/*  77 */     this.attributes.put(attributeName, atts);
/*  78 */     return this;
/*     */   }
/*     */ 
/*     */   public ConfigAttribute getAttribute(String name)
/*     */   {
/*  88 */     ConfigAttribute result = null;
/*  89 */     List attributeValues = (List)this.attributes.get(name);
/*  90 */     if ((attributeValues != null) && (attributeValues.size() > 0)) {
/*  91 */       result = (ConfigAttribute)attributeValues.get(0);
/*     */     }
/*     */ 
/*  94 */     return result;
/*     */   }
/*     */ 
/*     */   public List<ConfigAttribute> getAttributes(String name)
/*     */   {
/* 104 */     List result = null;
/* 105 */     List attributeValues = (List)this.attributes.get(name);
/* 106 */     if (attributeValues != null) {
/* 107 */       result = Collections.unmodifiableList(attributeValues);
/*     */     }
/*     */ 
/* 110 */     return result;
/*     */   }
/*     */ 
/*     */   public List<List<ConfigAttribute>> getAttributes() {
/* 114 */     List result = new ArrayList();
/* 115 */     for (List attributeValues : this.attributes.values()) {
/* 116 */       result.add(Collections.unmodifiableList(attributeValues));
/*     */     }
/*     */ 
/* 119 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public void removeAttribute(ConfigAttribute attribute) {
/* 123 */     this.attributes.remove(attribute.getName());
/*     */   }
/*     */ 
/*     */   public ConfigContainer set(ConfigContainer container)
/*     */   {
/* 134 */     String containerName = container.getName();
/*     */ 
/* 137 */     List conts = new ArrayList();
/* 138 */     conts.add(container);
/*     */ 
/* 140 */     this.containers.put(containerName, conts);
/* 141 */     return this;
/*     */   }
/*     */ 
/*     */   public ConfigContainer add(ConfigContainer container)
/*     */   {
/* 151 */     String containerName = container.getName();
/*     */ 
/* 153 */     List conts = (List)this.containers.get(containerName);
/* 154 */     if (conts == null) {
/* 155 */       conts = new ArrayList();
/*     */     }
/* 157 */     conts.add(container);
/*     */ 
/* 159 */     this.containers.put(containerName, conts);
/* 160 */     return this;
/*     */   }
/*     */ 
/*     */   public ConfigContainer getContainer(String name)
/*     */   {
/* 172 */     ConfigContainer result = null;
/* 173 */     List containerValues = (List)this.containers.get(name);
/* 174 */     if ((containerValues != null) && (containerValues.size() > 0)) {
/* 175 */       result = (ConfigContainer)containerValues.get(0);
/*     */     }
/*     */ 
/* 178 */     return result;
/*     */   }
/*     */ 
/*     */   public List<ConfigContainer> getContainers(String name)
/*     */   {
/* 188 */     List result = null;
/* 189 */     List containerValues = (List)this.containers.get(name);
/* 190 */     if (containerValues != null) {
/* 191 */       result = Collections.unmodifiableList(containerValues);
/*     */     }
/*     */ 
/* 194 */     return result;
/*     */   }
/*     */ 
/*     */   public List<List<ConfigContainer>> getContainers() {
/* 198 */     List result = new ArrayList();
/* 199 */     for (List containerValues : this.containers.values()) {
/* 200 */       result.add(Collections.unmodifiableList(containerValues));
/*     */     }
/*     */ 
/* 203 */     return Collections.unmodifiableList(result);
/*     */   }
/*     */ 
/*     */   public void removeContainers(ConfigContainer container)
/*     */   {
/* 212 */     this.containers.remove(container.getName());
/*     */   }
/*     */ 
/*     */   public void removeContainer(ConfigContainer container)
/*     */   {
/* 221 */     List containerValues = (List)this.containers.get(container.getName());
/* 222 */     if (containerValues != null)
/* 223 */       containerValues.remove(container);
/*     */   }
/*     */ 
/*     */   public ConfigContainer findContainer(String name)
/*     */   {
/* 236 */     if (name == null) {
/* 237 */       throw new IllegalArgumentException("name is required");
/*     */     }
/*     */ 
/* 240 */     ConfigContainer result = null;
/* 241 */     if (getName().equals(name)) {
/* 242 */       result = this;
/*     */     } else {
/* 244 */       List conts = findContainers(name);
/* 245 */       if ((conts != null) && (!(conts.isEmpty()))) {
/* 246 */         result = (ConfigContainer)conts.get(0);
/*     */       }
/*     */     }
/*     */ 
/* 250 */     return result;
/*     */   }
/*     */ 
/*     */   public List<ConfigContainer> findContainers(String name)
/*     */   {
/* 259 */     if (name == null) {
/* 260 */       throw new IllegalArgumentException("name is required");
/*     */     }
/*     */ 
/* 263 */     List result = null;
/* 264 */     for (List conts : getContainers()) {
/* 265 */       if ((!(conts.isEmpty())) && (((ConfigContainer)conts.get(0)).getName().equals(name))) {
/* 266 */         result = conts;
/* 267 */         break;
/*     */       }
/*     */     }
/*     */ 
/* 271 */     return result;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 279 */     StringBuilder sb = new StringBuilder();
/* 280 */     sb.append(new StringBuilder().append("name[").append(this.name).append("]").toString());
/* 281 */     sb.append("\nattributes START");
/* 282 */     for (List atts : this.attributes.values()) {
/* 283 */       for (ConfigAttribute att : atts) {
/* 284 */         sb.append("\n").append(att.toString());
/*     */       }
/*     */     }
/* 287 */     sb.append("\nattributes END");
/* 288 */     sb.append("\ncontainers START");
/* 289 */     for (List conts : this.containers.values()) {
/* 290 */       for (ConfigContainer cont : conts) {
/* 291 */         sb.append("\n").append(cont.toString());
/*     */       }
/*     */     }
/* 294 */     sb.append("\ncontainers END");
/*     */ 
/* 296 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   public ConfigContainerXML toXML()
/*     */   {
/* 302 */     return new ConfigContainerAdapter().marshal(this);
/*     */   }
/*     */ 
/*     */   public static class ConfigContainerAdapter extends XmlAdapter<ConfigContainer.ConfigContainerXML, ConfigContainer>
/*     */   {
/*     */     public ConfigContainer.ConfigContainerXML marshal(ConfigContainer configContainer)
/*     */     {
/* 323 */       ConfigContainer.ConfigContainerXML result = new ConfigContainer.ConfigContainerXML();
/* 324 */       result.name = configContainer.name;
/* 325 */       for (List conts : configContainer.getContainers()) {
/* 326 */         for (ConfigContainer cont : conts) {
/* 327 */           result.containers.add(cont.toXML());
/*     */         }
/*     */       }
/* 330 */       for (List atts : configContainer.getAttributes()) {
/* 331 */         for (ConfigAttribute att : atts) {
/* 332 */           result.attributes.add(att);
/*     */         }
/*     */       }
/* 335 */       return result;
/*     */     }
/*     */ 
/*     */     public ConfigContainer unmarshal(ConfigContainer.ConfigContainerXML configContainerXML)
/*     */     {
/* 340 */       ConfigContainer result = new ConfigContainer(configContainerXML.name);
/*     */ 
/* 342 */       for (ConfigContainer.ConfigContainerXML subContainer : configContainerXML.containers) {
/* 343 */         result.set(toConfigContainer(subContainer));
/*     */       }
/* 345 */       for (ConfigAttribute attribute : configContainerXML.attributes) {
/* 346 */         result.set(attribute);
/*     */       }
/* 348 */       return result;
/*     */     }
/*     */ 
/*     */     private static ConfigContainer toConfigContainer(ConfigContainer.ConfigContainerXML configContainerXML)
/*     */     {
/* 353 */       ConfigContainer result = new ConfigContainer(configContainerXML.name);
/* 354 */       for (ConfigAttribute attribute : configContainerXML.attributes)
/*     */       {
/* 356 */         result.add(attribute);
/*     */       }
/*     */ 
/* 359 */       for (ConfigContainer.ConfigContainerXML containerXML : configContainerXML.containers) {
/* 360 */         result.set(toConfigContainer(containerXML));
/*     */       }
/* 362 */       return result;
/*     */     }
/*     */   }
/*     */ 
/*     */   @XmlAccessorType(XmlAccessType.NONE)
/*     */   public static class ConfigContainerXML
/*     */   {
/*     */ 
/*     */     @XmlAttribute
/*     */     public String name;
/*     */ 
/*     */     @XmlElement(name="container")
/*     */     public List<ConfigContainerXML> containers;
/*     */ 
/*     */     @XmlElement(name="attribute")
/*     */     public List<ConfigAttribute> attributes;
/*     */ 
/*     */     public ConfigContainerXML()
/*     */     {
/* 312 */       this.containers = new ArrayList();
/*     */ 
/* 315 */       this.attributes = new ArrayList();
/*     */     }
/*     */   }
/*     */ }