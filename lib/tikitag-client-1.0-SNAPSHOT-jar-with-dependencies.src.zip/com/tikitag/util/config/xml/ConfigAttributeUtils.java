/*    */ package com.tikitag.util.config.xml;
/*    */ 
/*    */ public final class ConfigAttributeUtils
/*    */ {
/*    */   public static String asString(ConfigAttribute configAttribute)
/*    */   {
/* 16 */     String result = null;
/*    */ 
/* 18 */     if (configAttribute != null) {
/* 19 */       result = configAttribute.asString();
/*    */     }
/*    */ 
/* 22 */     return result;
/*    */   }
/*    */ }