/*     */ package com.tikitag.util.config.xml;
/*     */ 
/*     */ import java.io.Serializable;
/*     */ import javax.xml.bind.annotation.XmlAccessType;
/*     */ import javax.xml.bind.annotation.XmlAccessorType;
/*     */ import javax.xml.bind.annotation.XmlAttribute;
/*     */ import javax.xml.bind.annotation.XmlElements;
/*     */ 
/*     */ @XmlAccessorType(XmlAccessType.NONE)
/*     */ public class ConfigAttribute
/*     */   implements Serializable
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   @XmlAttribute
/*     */   private String name;
/*     */ 
/*     */   @XmlElements({@javax.xml.bind.annotation.XmlElement(name="int", type=Integer.class), @javax.xml.bind.annotation.XmlElement(name="long", type=Long.class), @javax.xml.bind.annotation.XmlElement(name="double", type=Double.class), @javax.xml.bind.annotation.XmlElement(name="string", type=String.class), @javax.xml.bind.annotation.XmlElement(name="boolean", type=Boolean.class)})
/*     */   private Object value;
/*     */ 
/*     */   public ConfigAttribute(String name, int value)
/*     */   {
/*  32 */     init(name, new Integer(value));
/*     */   }
/*     */ 
/*     */   public ConfigAttribute(String name, long value) {
/*  36 */     init(name, new Long(value));
/*     */   }
/*     */ 
/*     */   public ConfigAttribute(String name, double value) {
/*  40 */     init(name, new Double(value));
/*     */   }
/*     */ 
/*     */   public ConfigAttribute(String name, String value) {
/*  44 */     init(name, value);
/*     */   }
/*     */ 
/*     */   public ConfigAttribute(String name, Boolean bool) {
/*  48 */     init(name, Boolean.valueOf(bool.booleanValue()));
/*     */   }
/*     */ 
/*     */   private void init(String name, Object value) {
/*  52 */     this.name = name;
/*  53 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public ConfigAttribute(String name) {
/*  57 */     init(name, null);
/*     */   }
/*     */ 
/*     */   public Object getValue() {
/*  61 */     return this.value;
/*     */   }
/*     */ 
/*     */   public void setValue(Object value) {
/*  65 */     this.value = value;
/*     */   }
/*     */ 
/*     */   public int asInt() {
/*  69 */     if (this.value instanceof Integer) {
/*  70 */       return ((Integer)this.value).intValue();
/*     */     }
/*  72 */     throw new UnsupportedOperationException("Unsupported Type Conversion");
/*     */   }
/*     */ 
/*     */   public long asLong() {
/*  76 */     if (this.value instanceof Long) {
/*  77 */       return ((Long)this.value).longValue();
/*     */     }
/*  79 */     throw new UnsupportedOperationException("Unsupported Type Conversion");
/*     */   }
/*     */ 
/*     */   public double asDouble() {
/*  83 */     if (this.value instanceof Double) {
/*  84 */       return ((Double)this.value).doubleValue();
/*     */     }
/*  86 */     throw new UnsupportedOperationException("Unsupported Type Conversion");
/*     */   }
/*     */ 
/*     */   public String asString() {
/*  90 */     if (this.value == null) {
/*  91 */       return null;
/*     */     }
/*  93 */     return this.value.toString();
/*     */   }
/*     */ 
/*     */   public boolean asBoolean() {
/*  97 */     if (this.value instanceof Boolean) {
/*  98 */       return ((Boolean)this.value).booleanValue();
/*     */     }
/* 100 */     throw new UnsupportedOperationException("Unsupported Type Conversion");
/*     */   }
/*     */ 
/*     */   public String getName() {
/* 104 */     return this.name;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 109 */     return "name[" + this.name + "], value[" + this.value + "]";
/*     */   }
/*     */ 
/*     */   protected ConfigAttribute()
/*     */   {
/*     */   }
/*     */ }