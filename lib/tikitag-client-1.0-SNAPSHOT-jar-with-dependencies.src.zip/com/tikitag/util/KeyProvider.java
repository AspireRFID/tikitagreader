package com.tikitag.util;

public abstract interface KeyProvider
{
  public abstract byte[] getKey();
}