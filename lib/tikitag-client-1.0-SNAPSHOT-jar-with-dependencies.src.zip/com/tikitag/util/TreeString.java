/*    */ package com.tikitag.util;
/*    */ 
/*    */ public class TreeString
/*    */ {
/*    */   private static final String FRAGMENT_ATTRIBUTE = "`->";
/*    */   private static final String FRAGMENT_CLEAR = "   ";
/*    */   private static final String FRAGMENT_TERMINATOR = " \\-";
/*    */   private static final String FRAGMENT_SIBLING = " +-";
/*    */   private static final String FRAGMENT_GUIDE = " | ";
/*    */   private TreeContentProvider provider;
/*    */ 
/*    */   public TreeString(TreeContentProvider provider)
/*    */   {
/* 26 */     this.provider = provider;
/*    */   }
/*    */ 
/*    */   public String convert(Object node)
/*    */   {
/* 36 */     StringBuilder builder = new StringBuilder();
/* 37 */     String prefix = " \\-";
/* 38 */     build(builder, prefix, node);
/* 39 */     return builder.toString();
/*    */   }
/*    */ 
/*    */   private void build(StringBuilder builder, String prefix, Object node)
/*    */   {
/*    */     int i;
/*    */     String extension;
/* 43 */     builder.append(prefix);
/* 44 */     builder.append(this.provider.asString(node));
/* 45 */     builder.append('\n');
/* 46 */     if (this.provider.hasAttributes(node)) {
/* 47 */       Object[] attributes = this.provider.getAttributes(node);
/* 48 */       if (attributes == null)
/* 49 */         throw new NullPointerException("Node of type " + node.getClass() + " has attributes but provider returned <null>!");
/* 50 */       for (i = 0; i < attributes.length; ++i) {
/* 51 */         extension = "   ";
/* 52 */         if (this.provider.hasChildren(node))
/* 53 */           extension = " | ";
/* 54 */         builder.append(replaceLast(prefix, extension + "`->"));
/* 55 */         builder.append(' ');
/* 56 */         builder.append(this.provider.asString(node, attributes[i]));
/* 57 */         builder.append("\n");
/*    */       }
/*    */     }
/* 60 */     if (this.provider.hasChildren(node)) {
/* 61 */       Object[] children = this.provider.getChildren(node);
/* 62 */       for (i = 0; i < children.length; ++i) {
/* 63 */         extension = " +-";
/* 64 */         if (i == children.length - 1)
/* 65 */           extension = " \\-";
/* 66 */         build(builder, replaceLast(prefix, extension), children[i]);
/*    */       }
/*    */     }
/*    */   }
/*    */ 
/*    */   private String replaceLast(String prefix, String extension) {
/* 72 */     StringBuffer buffer = new StringBuffer(prefix);
/* 73 */     String replacement = "   ";
/* 74 */     if (prefix.endsWith(" +-"))
/* 75 */       replacement = " | ";
/* 76 */     int length = prefix.length();
/* 77 */     buffer.replace(length - replacement.length(), length, replacement);
/* 78 */     buffer.append(extension);
/* 79 */     return buffer.toString();
/*    */   }
/*    */ }