/*    */ package com.tikitag.util;
/*    */ 
/*    */ public class TikitagHashFactory
/*    */ {
/*    */   private static final int HASH_LENGTH = 13;
/*    */   private final KeyProvider keyProvider;
/*    */ 
/*    */   public TikitagHashFactory(KeyProvider keyProvider)
/*    */   {
/* 12 */     this.keyProvider = keyProvider;
/*    */   }
/*    */ 
/*    */   public byte[] generate(byte[] tagUid)
/*    */   {
/* 21 */     HmacMd5 hasher = new HmacMd5(this.keyProvider.getKey());
/* 22 */     hasher.addData(tagUid);
/* 23 */     byte[] hash = hasher.sign();
/*    */ 
/* 25 */     byte[] truncatedHash = new byte[13];
/* 26 */     System.arraycopy(hash, 0, truncatedHash, 0, truncatedHash.length);
/*    */ 
/* 28 */     return truncatedHash;
/*    */   }
/*    */ }