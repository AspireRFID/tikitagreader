/*     */ package com.tikitag.util;
/*     */ 
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.io.FilterInputStream;
/*     */ import java.io.FilterOutputStream;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.io.OutputStream;
/*     */ import java.io.PrintStream;
/*     */ import java.io.Serializable;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.util.zip.Deflater;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.GZIPOutputStream;
/*     */ 
/*     */ public class Base64
/*     */ {
/*     */   public static final int NO_OPTIONS = 0;
/*     */   public static final int ENCODE = 1;
/*     */   public static final int DECODE = 0;
/*     */   public static final int GZIP = 2;
/*     */   public static final int DONT_BREAK_LINES = 8;
/*     */   private static final int MAX_LINE_LENGTH = 76;
/*     */   private static final byte EQUALS_SIGN = 61;
/*     */   private static final byte NEW_LINE = 10;
/*     */   private static final String PREFERRED_ENCODING = "UTF-8";
/*     */   private static final byte[] ALPHABET;
/*     */   private static final byte[] _NATIVE_ALPHABET;
/*     */   private static final byte[] DECODABET;
/*     */   private static final byte WHITE_SPACE_ENC = -5;
/*     */   private static final byte EQUALS_SIGN_ENC = -1;
/*     */ 
/*     */   private static byte[] encode3to4(byte[] b4, byte[] threeBytes, int numSigBytes)
/*     */   {
/* 129 */     encode3to4(threeBytes, 0, numSigBytes, b4, 0);
/* 130 */     return b4;
/*     */   }
/*     */ 
/*     */   private static byte[] encode3to4(byte[] source, int srcOffset, int numSigBytes, byte[] destination, int destOffset)
/*     */   {
/* 168 */     int inBuff = ((numSigBytes > 0) ? source[srcOffset] << 24 >>> 8 : 0) | ((numSigBytes > 1) ? source[(srcOffset + 1)] << 24 >>> 16 : 0) | ((numSigBytes > 2) ? source[(srcOffset + 2)] << 24 >>> 24 : 0);
/*     */ 
/* 172 */     switch (numSigBytes)
/*     */     {
/*     */     case 3:
/* 174 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/* 175 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/* 176 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/* 177 */       destination[(destOffset + 3)] = ALPHABET[(inBuff & 0x3F)];
/* 178 */       return destination;
/*     */     case 2:
/* 180 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/* 181 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/* 182 */       destination[(destOffset + 2)] = ALPHABET[(inBuff >>> 6 & 0x3F)];
/* 183 */       destination[(destOffset + 3)] = 61;
/* 184 */       return destination;
/*     */     case 1:
/* 186 */       destination[destOffset] = ALPHABET[(inBuff >>> 18)];
/* 187 */       destination[(destOffset + 1)] = ALPHABET[(inBuff >>> 12 & 0x3F)];
/* 188 */       destination[(destOffset + 2)] = 61;
/* 189 */       destination[(destOffset + 3)] = 61;
/* 190 */       return destination;
/*     */     }
/* 192 */     return destination;
/*     */   }
/*     */ 
/*     */   public static String encodeObject(Serializable serializableObject)
/*     */   {
/* 208 */     return encodeObject(serializableObject, 0);
/*     */   }
/*     */ 
/*     */   public static String encodeObject(Serializable serializableObject, int options)
/*     */   {
/* 236 */     ByteArrayOutputStream baos = null;
/* 237 */     OutputStream b64os = null;
/* 238 */     ObjectOutputStream oos = null;
/*     */ 
/* 240 */     int gzip = options & 0x2;
/* 241 */     int dontBreakLines = options & 0x8;
/*     */     try
/*     */     {
/* 244 */       baos = new ByteArrayOutputStream();
/* 245 */       b64os = new OutputStream(baos, 0x1 | dontBreakLines);
/*     */ 
/* 247 */       if (gzip == 2) {
/* 248 */         oos = new ObjectOutputStream(new GZIPOutputStream(b64os)
/*     */         {
/*     */         });
/*     */       }
/*     */       else
/*     */       {
/* 255 */         oos = new ObjectOutputStream(b64os); }
/* 256 */       oos.writeObject(serializableObject);
/*     */     }
/*     */     catch (IOException e) {
/* 259 */       e.printStackTrace();
/* 260 */       Object localObject1 = null;
/*     */ 
/* 264 */       return localObject1;
/*     */     }
/*     */     finally
/*     */     {
/*     */       try
/*     */       {
/* 262 */         oos.close(); } catch (Exception e) { }
/*     */       try { b64os.close(); } catch (Exception e) { }
/*     */       try { baos.close(); } catch (Exception e) {
/*     */       }
/*     */     }
/*     */     try {
/* 268 */       return new String(baos.toByteArray(), "UTF-8"); } catch (UnsupportedEncodingException uue) {
/*     */     }
/* 270 */     return new String(baos.toByteArray());
/*     */   }
/*     */ 
/*     */   public static String encodeBytes(byte[] source)
/*     */   {
/* 282 */     return encodeBytes(source, 0, source.length, 0);
/*     */   }
/*     */ 
/*     */   public static String encodeBytes(byte[] source, int options)
/*     */   {
/* 306 */     return encodeBytes(source, 0, source.length, options);
/*     */   }
/*     */ 
/*     */   public static String encodeBytes(byte[] source, int off, int len)
/*     */   {
/* 319 */     return encodeBytes(source, off, len, 0);
/*     */   }
/*     */ 
/*     */   public static String encodeBytes(byte[] source, int off, int len, int options)
/*     */   {
/*     */     int i;
/*     */     int j;
/* 347 */     int dontBreakLines = options & 0x8;
/* 348 */     int gzip = options & 0x2;
/*     */ 
/* 350 */     if (gzip == 2) {
/* 351 */       ByteArrayOutputStream baos = null;
/* 352 */       GZIPOutputStream gzos = null;
/* 353 */       OutputStream b64os = null;
/*     */       try
/*     */       {
/* 356 */         baos = new ByteArrayOutputStream();
/* 357 */         b64os = new OutputStream(baos, 0x1 | dontBreakLines);
/* 358 */         gzos = new GZIPOutputStream(b64os);
/* 359 */         gzos.write(source, off, len);
/* 360 */         gzos.close();
/*     */       } catch (IOException e) {
/* 362 */         e.printStackTrace();
/* 363 */         Object localObject1 = null;
/*     */ 
/* 367 */         return localObject1;
/*     */       }
/*     */       finally
/*     */       {
/*     */         try
/*     */         {
/* 365 */           gzos.close(); } catch (Exception e) { }
/*     */         try { b64os.close(); } catch (Exception e) { }
/*     */         try { baos.close(); } catch (Exception e) {
/*     */         }
/*     */       }
/*     */       try {
/* 371 */         return new String(baos.toByteArray(), "UTF-8");
/*     */       } catch (UnsupportedEncodingException uue) {
/* 373 */         return new String(baos.toByteArray());
/*     */       }
/*     */ 
/*     */     }
/*     */ 
/* 379 */     boolean breakLines = dontBreakLines == 0;
/* 380 */     int len43 = len * 4 / 3;
/* 381 */     byte[] outBuff = new byte[len43 + ((len % 3 > 0) ? 4 : 0) + ((breakLines) ? len43 / 76 : 0)];
/*     */ 
/* 384 */     int d = 0;
/* 385 */     int i = 0;
/* 386 */     int len2 = len - 2;
/* 387 */     int j = 0;
/* 388 */     for (; d < len2; i += 4) {
/* 389 */       encode3to4(source, d + off, 3, outBuff, i);
/* 390 */       j += 4;
/* 391 */       if ((breakLines) && (j == 76)) {
/* 392 */         outBuff[(i + 4)] = 10;
/* 393 */         ++i;
/* 394 */         j = 0;
/*     */       }
/* 388 */       d += 3;
/*     */     }
/*     */ 
/* 397 */     if (d < len) {
/* 398 */       encode3to4(source, d + off, len - d, outBuff, i);
/* 399 */       i += 4;
/*     */     }
/*     */     try
/*     */     {
/* 403 */       return new String(outBuff, 0, i, "UTF-8"); } catch (UnsupportedEncodingException uue) {
/*     */     }
/* 405 */     return new String(outBuff, 0, i);
/*     */   }
/*     */ 
/*     */   private static int decode4to3(byte[] source, int srcOffset, byte[] destination, int destOffset)
/*     */   {
/*     */     int outBuff;
/* 434 */     if (source[(srcOffset + 2)] == 61)
/*     */     {
/* 438 */       outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12;
/*     */ 
/* 440 */       destination[destOffset] = (byte)(outBuff >>> 16);
/* 441 */       return 1;
/*     */     }
/*     */ 
/* 445 */     if (source[(srcOffset + 3)] == 61)
/*     */     {
/* 450 */       outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6;
/*     */ 
/* 453 */       destination[destOffset] = (byte)(outBuff >>> 16);
/* 454 */       destination[(destOffset + 1)] = (byte)(outBuff >>> 8);
/* 455 */       return 2;
/*     */     }
/*     */ 
/*     */     try
/*     */     {
/* 465 */       outBuff = (DECODABET[source[srcOffset]] & 0xFF) << 18 | (DECODABET[source[(srcOffset + 1)]] & 0xFF) << 12 | (DECODABET[source[(srcOffset + 2)]] & 0xFF) << 6 | DECODABET[source[(srcOffset + 3)]] & 0xFF;
/*     */ 
/* 469 */       destination[destOffset] = (byte)(outBuff >> 16);
/* 470 */       destination[(destOffset + 1)] = (byte)(outBuff >> 8);
/* 471 */       destination[(destOffset + 2)] = (byte)outBuff;
/* 472 */       return 3;
/*     */     } catch (Exception e) {
/* 474 */       System.out.println("" + source[srcOffset] + ": " + DECODABET[source[srcOffset]]);
/* 475 */       System.out.println("" + source[(srcOffset + 1)] + ": " + DECODABET[source[(srcOffset + 1)]]);
/* 476 */       System.out.println("" + source[(srcOffset + 2)] + ": " + DECODABET[source[(srcOffset + 2)]]);
/* 477 */       System.out.println("" + source[(srcOffset + 3)] + ": " + DECODABET[source[(srcOffset + 3)]]); }
/* 478 */     return -1;
/*     */   }
/*     */ 
/*     */   public static byte[] decode(byte[] source, int off, int len)
/*     */   {
/* 495 */     int len34 = len * 3 / 4;
/* 496 */     byte[] outBuff = new byte[len34];
/* 497 */     int outBuffPosn = 0;
/* 498 */     byte[] b4 = new byte[4];
/* 499 */     int b4Posn = 0;
/* 500 */     int i = 0;
/* 501 */     byte sbiCrop = 0;
/* 502 */     byte sbiDecode = 0;
/* 503 */     for (i = off; i < off + len; ++i)
/*     */     {
/* 505 */       sbiCrop = (byte)(source[i] & 0x7F);
/* 506 */       sbiDecode = DECODABET[sbiCrop];
/*     */ 
/* 508 */       if (sbiDecode >= -5) {
/* 509 */         if (sbiDecode < -1) continue;
/* 510 */         b4[(b4Posn++)] = sbiCrop;
/* 511 */         if (b4Posn <= 3) continue;
/* 512 */         outBuffPosn += decode4to3(b4, 0, outBuff, outBuffPosn);
/* 513 */         b4Posn = 0;
/*     */ 
/* 515 */         if (sbiCrop != 61) continue;
/* 516 */         break;
/*     */       }
/*     */ 
/* 520 */       System.err.println("Bad Base64 input character at " + i + ": " + source[i] + "(decimal)");
/* 521 */       return null;
/*     */     }
/*     */ 
/* 524 */     byte[] out = new byte[outBuffPosn];
/* 525 */     System.arraycopy(outBuff, 0, out, 0, outBuffPosn);
/* 526 */     return out;
/*     */   }
/*     */ 
/*     */   public static byte[] decode(String s)
/*     */   {
/*     */     try
/*     */     {
/* 540 */       bytes = s.getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException uee) {
/* 542 */       bytes = s.getBytes();
/*     */     }
/*     */ 
/* 545 */     byte[] bytes = decode(bytes, 0, bytes.length);
/*     */ 
/* 548 */     if (bytes.length >= 2) {
/* 549 */       int head = bytes[0] & 0xFF | bytes[1] << 8 & 0xFF00;
/* 550 */       if ((bytes != null) && (bytes.length >= 4) && (35615 == head))
/*     */       {
/* 555 */         ByteArrayInputStream bais = null;
/* 556 */         GZIPInputStream gzis = null;
/* 557 */         ByteArrayOutputStream baos = null;
/* 558 */         byte[] buffer = new byte[2048];
/* 559 */         int length = 0;
/*     */         try {
/* 561 */           baos = new ByteArrayOutputStream();
/* 562 */           bais = new ByteArrayInputStream(bytes);
/* 563 */           gzis = new GZIPInputStream(bais);
/* 564 */           while ((length = gzis.read(buffer)) >= 0) {
/* 565 */             baos.write(buffer, 0, length);
/*     */           }
/*     */ 
/* 568 */           bytes = baos.toByteArray();
/*     */         } catch (IOException e) {
/*     */         } finally {
/*     */           try {
/* 572 */             baos.close(); } catch (Exception e) { }
/*     */           try { gzis.close(); } catch (Exception e) { }
/*     */           try { bais.close(); } catch (Exception e) { }
/*     */         }
/*     */       }
/*     */     }
/* 578 */     return bytes;
/*     */   }
/*     */ 
/*     */   public static Object decodeToObject(String encodedObject)
/*     */   {
/* 591 */     byte[] objBytes = decode(encodedObject);
/* 592 */     ByteArrayInputStream bais = null;
/* 593 */     ObjectInputStream ois = null;
/* 594 */     Object obj = null;
/*     */     try {
/* 596 */       bais = new ByteArrayInputStream(objBytes);
/* 597 */       ois = new ObjectInputStream(bais);
/* 598 */       obj = ois.readObject();
/*     */     } catch (IOException e) {
/* 600 */       e.printStackTrace();
/* 601 */       obj = null;
/*     */     } catch (ClassNotFoundException e) {
/* 603 */       e.printStackTrace();
/* 604 */       obj = null; } finally {
/*     */       try {
/* 606 */         bais.close(); } catch (Exception e) { }
/*     */       try { ois.close(); } catch (Exception e) { }
/*     */     }
/* 609 */     return obj;
/*     */   }
/*     */ 
/*     */   static
/*     */   {
/*     */     byte[] __bytes;
/*  43 */     _NATIVE_ALPHABET = new byte[] { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
/*     */     try
/*     */     {
/*  61 */       __bytes = new String("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/").getBytes("UTF-8");
/*     */     } catch (UnsupportedEncodingException use) {
/*  63 */       __bytes = _NATIVE_ALPHABET;
/*     */     }
/*  65 */     ALPHABET = __bytes;
/*     */ 
/*  73 */     DECODABET = new byte[] { -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -5, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, -5, -9, -9, -9, -9, -9, -9, -9, -9, -9, -9, 62, -9, -9, -9, 63, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, -9, -9, -9, -1, -9, -9, -9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, -9, -9, -9, -9, -9, -9, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, -9, -9, -9, -9 };
/*     */   }
/*     */ 
/*     */   public static class OutputStream extends FilterOutputStream
/*     */   {
/*     */     private boolean encode;
/*     */     private int position;
/*     */     private byte[] buffer;
/*     */     private int bufferLength;
/*     */     private int lineLength;
/*     */     private boolean breakLines;
/*     */     private byte[] b4;
/*     */     private boolean suspendEncoding;
/*     */ 
/*     */     public OutputStream(OutputStream out)
/*     */     {
/* 812 */       this(out, 1);
/*     */     }
/*     */ 
/*     */     public OutputStream(OutputStream out, int options)
/*     */     {
/* 836 */       super(out);
/* 837 */       this.breakLines = ((options & 0x8) != 8);
/* 838 */       this.encode = ((options & 0x1) == 1);
/* 839 */       this.bufferLength = ((this.encode) ? 3 : 4);
/* 840 */       this.buffer = new byte[this.bufferLength];
/* 841 */       this.position = 0;
/* 842 */       this.lineLength = 0;
/* 843 */       this.suspendEncoding = false;
/* 844 */       this.b4 = new byte[4];
/*     */     }
/*     */ 
/*     */     public void write(int theByte)
/*     */       throws IOException
/*     */     {
/* 861 */       if (this.suspendEncoding) {
/* 862 */         this.out.write(theByte);
/* 863 */         return;
/*     */       }
/*     */ 
/* 866 */       if (this.encode) {
/* 867 */         this.buffer[(this.position++)] = (byte)theByte;
/*     */ 
/* 869 */         if (this.position >= this.bufferLength) {
/* 870 */           this.out.write(Base64.access$300(this.b4, this.buffer, this.bufferLength));
/* 871 */           this.lineLength += 4;
/* 872 */           if ((this.breakLines) && (this.lineLength >= 76)) {
/* 873 */             this.out.write(10);
/* 874 */             this.lineLength = 0;
/*     */           }
/* 876 */           this.position = 0;
/*     */         }
/*     */ 
/*     */       }
/* 882 */       else if (Base64.DECODABET[(theByte & 0x7F)] > -5) {
/* 883 */         this.buffer[(this.position++)] = (byte)theByte;
/*     */ 
/* 885 */         if (this.position >= this.bufferLength) {
/* 886 */           int len = Base64.access$200(this.buffer, 0, this.b4, 0);
/* 887 */           this.out.write(this.b4, 0, len);
/*     */ 
/* 889 */           this.position = 0;
/*     */         }
/*     */       }
/* 892 */       else if (Base64.DECODABET[(theByte & 0x7F)] != -5) {
/* 893 */         throw new IOException("Invalid character in Base64 data.");
/*     */       }
/*     */     }
/*     */ 
/*     */     public void write(byte[] theBytes, int off, int len)
/*     */       throws IOException
/*     */     {
/* 909 */       if (this.suspendEncoding) {
/* 910 */         this.out.write(theBytes, off, len);
/* 911 */         return;
/*     */       }
/* 913 */       for (int i = 0; i < len; ++i)
/* 914 */         write(theBytes[(off + i)]);
/*     */     }
/*     */ 
/*     */     public void flushBase64()
/*     */       throws IOException
/*     */     {
/* 923 */       if (this.position > 0)
/* 924 */         if (this.encode) {
/* 925 */           this.out.write(Base64.access$300(this.b4, this.buffer, this.position));
/* 926 */           this.position = 0;
/*     */         } else {
/* 928 */           throw new IOException("Base64 input not properly padded.");
/*     */         }
/*     */     }
/*     */ 
/*     */     public void close()
/*     */       throws IOException
/*     */     {
/* 940 */       flushBase64();
/*     */ 
/* 943 */       super.close();
/* 944 */       this.buffer = null;
/* 945 */       this.out = null;
/*     */     }
/*     */ 
/*     */     public void suspendEncoding()
/*     */       throws IOException
/*     */     {
/* 956 */       flushBase64();
/* 957 */       this.suspendEncoding = true;
/*     */     }
/*     */ 
/*     */     public void resumeEncoding()
/*     */     {
/* 968 */       this.suspendEncoding = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   public static class InputStream extends FilterInputStream
/*     */   {
/*     */     private boolean encode;
/*     */     private int position;
/*     */     private byte[] buffer;
/*     */     private int bufferLength;
/*     */     private int numSigBytes;
/*     */     private int lineLength;
/*     */     private boolean breakLines;
/*     */ 
/*     */     public InputStream(InputStream in)
/*     */     {
/* 637 */       this(in, 0);
/*     */     }
/*     */ 
/*     */     public InputStream(InputStream in, int options)
/*     */     {
/* 662 */       super(in);
/* 663 */       this.breakLines = ((options & 0x8) != 8);
/* 664 */       this.encode = ((options & 0x1) == 1);
/* 665 */       this.bufferLength = ((this.encode) ? 4 : 3);
/* 666 */       this.buffer = new byte[this.bufferLength];
/* 667 */       this.position = -1;
/* 668 */       this.lineLength = 0;
/*     */     }
/*     */ 
/*     */     public int read()
/*     */       throws IOException
/*     */     {
/* 680 */       if (this.position < 0) {
/* 681 */         if (this.encode) {
/* 682 */           byte[] b3 = new byte[3];
/* 683 */           int numBinaryBytes = 0;
/* 684 */           for (int i = 0; i < 3; ++i) {
/*     */             try {
/* 686 */               int b = this.in.read();
/*     */ 
/* 688 */               if (b >= 0) {
/* 689 */                 b3[i] = (byte)b;
/* 690 */                 ++numBinaryBytes;
/*     */               }
/*     */             }
/*     */             catch (IOException e) {
/* 694 */               if (i == 0)
/* 695 */                 throw e;
/*     */             }
/*     */           }
/* 698 */           if (numBinaryBytes > 0) {
/* 699 */             Base64.access$000(b3, 0, numBinaryBytes, this.buffer, 0);
/* 700 */             this.position = 0;
/* 701 */             this.numSigBytes = 4;
/*     */           } else {
/* 703 */             return -1;
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 708 */           byte[] b4 = new byte[4];
/* 709 */           int i = 0;
/* 710 */           for (i = 0; i < 4; ++i)
/*     */           {
/* 712 */             int b = 0;
/*     */             do b = this.in.read();
/* 714 */             while ((b >= 0) && (Base64.DECODABET[(b & 0x7F)] <= -5));
/* 715 */             if (b < 0)
/*     */               break;
/* 717 */             b4[i] = (byte)b;
/*     */           }
/* 719 */           if (i == 4) {
/* 720 */             this.numSigBytes = Base64.access$200(b4, 0, this.buffer, 0);
/* 721 */             this.position = 0; } else {
/* 722 */             if (i == 0) {
/* 723 */               return -1;
/*     */             }
/*     */ 
/* 726 */             throw new IOException("Improperly padded Base64 input.");
/*     */           }
/*     */         }
/*     */       }
/*     */ 
/* 731 */       if (this.position >= 0)
/*     */       {
/* 733 */         if (this.position >= this.numSigBytes)
/* 734 */           return -1;
/* 735 */         if ((this.encode) && (this.breakLines) && (this.lineLength >= 76)) {
/* 736 */           this.lineLength = 0;
/* 737 */           return 10;
/*     */         }
/* 739 */         this.lineLength += 1;
/*     */ 
/* 742 */         int b = this.buffer[(this.position++)];
/* 743 */         if (this.position >= this.bufferLength)
/* 744 */           this.position = -1;
/* 745 */         return (b & 0xFF);
/*     */       }
/*     */ 
/* 752 */       throw new IOException("Error in Base64 code reading stream.");
/*     */     }
/*     */ 
/*     */     public int read(byte[] dest, int off, int len)
/*     */       throws IOException
/*     */     {
/* 771 */       for (int i = 0; i < len; ++i) {
/* 772 */         int b = read();
/*     */ 
/* 775 */         if (b >= 0) {
/* 776 */           dest[(off + i)] = (byte)b; } else {
/* 777 */           if (i != 0) break;
/* 778 */           return -1;
/*     */         }
/*     */       }
/*     */ 
/* 782 */       return i;
/*     */     }
/*     */   }
/*     */ }