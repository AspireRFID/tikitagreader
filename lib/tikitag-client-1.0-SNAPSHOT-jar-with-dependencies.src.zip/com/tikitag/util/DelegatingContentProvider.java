/*    */ package com.tikitag.util;
/*    */ 
/*    */ public class DelegatingContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/* 13 */   private ClassMap<TreeContentProvider> map = new ClassMap();
/*    */ 
/*    */   public DelegatingContentProvider() {
/* 16 */     this.map.put(Object.class, new DefaultContentProvider(null));
/* 17 */     this.map.put(Iterable.class, new IterableContentProvider());
/*    */   }
/*    */ 
/*    */   public void register(Class<?> clazz, TreeContentProvider provider) {
/* 21 */     this.map.put(clazz, provider);
/* 22 */     if (provider instanceof InnerContentDelegate) {
/* 23 */       InnerContentDelegate delegate = (InnerContentDelegate)provider;
/* 24 */       for (Class type : delegate.getSupportedClasses())
/* 25 */         this.map.put(type, provider);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String asString(Object object)
/*    */   {
/* 31 */     return delegate(object).asString(object);
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 36 */     return delegate(object).asString(object, attribute);
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 41 */     return delegate(object).getAttributes(object);
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 46 */     return delegate(object).getChildren(object);
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 51 */     return delegate(object).hasAttributes(object);
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 56 */     return delegate(object).hasChildren(object);
/*    */   }
/*    */ 
/*    */   private TreeContentProvider delegate(Object object) {
/* 60 */     return ((TreeContentProvider)this.map.get(object.getClass()));
/*    */   }
/*    */ 
/*    */   private class DefaultContentProvider implements TreeContentProvider
/*    */   {
/*    */     public String asString(Object object)
/*    */     {
/* 67 */       return "?Object:{" + object.toString() + "}";
/*    */     }
/*    */ 
/*    */     public String asString(Object object, Object attribute)
/*    */     {
/* 72 */       throw new UnsupportedOperationException();
/*    */     }
/*    */ 
/*    */     public Object[] getAttributes(Object object)
/*    */     {
/* 77 */       throw new UnsupportedOperationException();
/*    */     }
/*    */ 
/*    */     public Object[] getChildren(Object object)
/*    */     {
/* 82 */       throw new UnsupportedOperationException();
/*    */     }
/*    */ 
/*    */     public boolean hasAttributes(Object object)
/*    */     {
/* 87 */       return false;
/*    */     }
/*    */ 
/*    */     public boolean hasChildren(Object object)
/*    */     {
/* 92 */       return false;
/*    */     }
/*    */   }
/*    */ }