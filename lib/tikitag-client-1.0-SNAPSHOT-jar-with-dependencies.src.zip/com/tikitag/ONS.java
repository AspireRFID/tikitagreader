package com.tikitag;

public class ONS
{
  public static final long UID = 1L;
  public static final String PERSISTENCE_UNIT_NAME = "tikitag";
  public static final String TIKITAG_JNDI_PREFIX = "Tikitag/ONS";
  public static final String TIKI_BLOCK_JNDI_PREFIX = "Tikitag/ONS/Block";
  public static final String TIKI_SERVICE_JNDI_PREFIX = "Tikitag/ONS/Service";
  public static final String TIKI_FACADE_JNDI_PREFIX = "Tikitag/ONS/Facade";
  public static final String TIKI_USURPER_ROLE = "tiki:usurper";
  public static final String TIKI_ADMIN_ROLE = "tiki:admin";
  public static final String TIKI_DRUPAL_ROLE = "tiki:drupal";
  public static final String TIKI_USER_ROLE = "tiki:user";
  public static final String TIKI_GIMP_ROLE = "tiki:gimp";
}