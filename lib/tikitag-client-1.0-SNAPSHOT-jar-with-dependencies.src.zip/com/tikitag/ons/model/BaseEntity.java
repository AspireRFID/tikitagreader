/*    */ package com.tikitag.ons.model;
/*    */ 
/*    */ import com.tikitag.ons.model.util.Identifiable;
/*    */ import java.io.Serializable;
/*    */ import javax.persistence.GeneratedValue;
/*    */ import javax.persistence.Id;
/*    */ import javax.persistence.MappedSuperclass;
/*    */ 
/*    */ @MappedSuperclass
/*    */ public abstract class BaseEntity
/*    */   implements Identifiable<Long>, Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @Id
/*    */   @GeneratedValue
/*    */   private Long id;
/*    */ 
/*    */   public void setId(Long id)
/*    */   {
/* 23 */     this.id = id;
/*    */   }
/*    */ 
/*    */   public Long getId() {
/* 27 */     return this.id;
/*    */   }
/*    */ }