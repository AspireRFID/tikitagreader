/*     */ package com.tikitag.ons.model;
/*     */ 
/*     */ import com.tikitag.util.StringUtils;
/*     */ import java.util.List;
/*     */ import javax.persistence.Column;
/*     */ import javax.persistence.Entity;
/*     */ import javax.persistence.Lob;
/*     */ 
/*     */ @Entity
/*     */ public class TikiUser extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   @Column(nullable=false, unique=true, updatable=false)
/*     */   private String userName;
/*     */ 
/*     */   @Column(nullable=true, unique=false, updatable=true)
/*     */   private String handle;
/*     */ 
/*     */   @Column(nullable=true, unique=false, updatable=true)
/*     */   private byte[] password;
/*     */   private String roleStanza;
/*     */   private String email;
/*     */ 
/*     */   protected TikiUser()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TikiUser(String handle, String userName, byte[] password)
/*     */   {
/*  53 */     this.handle = handle;
/*  54 */     this.userName = userName;
/*  55 */     this.password = password;
/*  56 */     this.roleStanza = "".intern();
/*  57 */     this.email = null;
/*     */   }
/*     */ 
/*     */   public TikiUser(String handle, String userName, byte[] password, String[] roles, String email)
/*     */   {
/*  79 */     this.handle = handle;
/*  80 */     this.userName = userName;
/*  81 */     this.password = password;
/*  82 */     this.roleStanza = StringUtils.toCommaSeperated(roles);
/*  83 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String getUserName()
/*     */   {
/*  92 */     return this.userName;
/*     */   }
/*     */ 
/*     */   public void setUserName(String userName)
/*     */   {
/* 101 */     this.userName = userName;
/*     */   }
/*     */ 
/*     */   public String getHandle()
/*     */   {
/* 110 */     return this.handle;
/*     */   }
/*     */ 
/*     */   public void setHandle(String handle)
/*     */   {
/* 119 */     this.handle = handle;
/*     */   }
/*     */ 
/*     */   @Lob
/*     */   public byte[] getPassword()
/*     */   {
/* 129 */     return this.password;
/*     */   }
/*     */ 
/*     */   public void setPassword(byte[] password)
/*     */   {
/* 138 */     this.password = password;
/*     */   }
/*     */ 
/*     */   public String getRoleStanza()
/*     */   {
/* 147 */     return this.roleStanza;
/*     */   }
/*     */ 
/*     */   public void setRoleStanza(String roleStanza)
/*     */   {
/* 156 */     this.roleStanza = roleStanza;
/*     */   }
/*     */ 
/*     */   public void setRoles(List<String> roles)
/*     */   {
/* 165 */     this.roleStanza = StringUtils.toCommaSeperated(roles);
/*     */   }
/*     */ 
/*     */   public String[] roles()
/*     */   {
/* 175 */     return StringUtils.fromCommaSeperated(this.roleStanza);
/*     */   }
/*     */ 
/*     */   public String getEmail()
/*     */   {
/* 184 */     return this.email;
/*     */   }
/*     */ 
/*     */   public void setEmail(String email)
/*     */   {
/* 193 */     this.email = email;
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 202 */     return "TikiUser:{userName=\"" + this.userName + "\",handle=\"" + this.handle + "\"}";
/*     */   }
/*     */ }