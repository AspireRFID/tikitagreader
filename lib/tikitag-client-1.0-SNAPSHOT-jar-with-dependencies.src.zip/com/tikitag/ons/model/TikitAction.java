/*    */ package com.tikitag.ons.model;
/*    */ 
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.model.util.TikitId;
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ import javax.persistence.Column;
/*    */ import javax.persistence.Entity;
/*    */ import javax.persistence.Lob;
/*    */ 
/*    */ @Entity
/*    */ public class TikitAction extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   static final String DEFAULT = "default";
/*    */   public String identifier;
/*    */   public String tikitIdentifier;
/*    */ 
/*    */   @Lob
/*    */   @Column(columnDefinition="BLOB")
/*    */   private ActionProviderMemento memento;
/*    */ 
/*    */   protected TikitAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TikitAction(TikitId tikitId, ActionProviderMemento memento)
/*    */   {
/* 35 */     this("default", tikitId, memento);
/*    */   }
/*    */ 
/*    */   public TikitAction(String identifier, TikitId tikitId, ActionProviderMemento memento)
/*    */   {
/* 40 */     this.identifier = identifier;
/* 41 */     this.tikitIdentifier = tikitId.getIdentifier();
/* 42 */     this.memento = memento;
/*    */   }
/*    */ 
/*    */   public String getIdentifier() {
/* 46 */     return this.identifier;
/*    */   }
/*    */ 
/*    */   public void setIdentifier(String identifier) {
/* 50 */     this.identifier = identifier;
/*    */   }
/*    */ 
/*    */   public String getTikitIdentifier() {
/* 54 */     return this.tikitIdentifier;
/*    */   }
/*    */ 
/*    */   public void setTikitIdentifier(String tikitIdentifier) {
/* 58 */     this.tikitIdentifier = tikitIdentifier;
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento getMemento() {
/* 62 */     return this.memento;
/*    */   }
/*    */ 
/*    */   public void setMemento(ActionProviderMemento memento) {
/* 66 */     this.memento = memento;
/*    */   }
/*    */ 
/*    */   public URN toURN() {
/* 70 */     return new URN("urn:tiki:action:" + this.tikitIdentifier + ":" + this.identifier);
/*    */   }
/*    */ }