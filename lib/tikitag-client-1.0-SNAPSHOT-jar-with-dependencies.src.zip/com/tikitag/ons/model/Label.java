/*    */ package com.tikitag.ons.model;
/*    */ 
/*    */ import javax.persistence.Entity;
/*    */ 
/*    */ @Entity
/*    */ public class Label extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String name;
/*    */ 
/*    */   protected Label()
/*    */   {
/*    */   }
/*    */ 
/*    */   public Label(String name)
/*    */   {
/* 21 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 26 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 31 */     return this.name;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 36 */     int prime = 31;
/* 37 */     int result = 1;
/* 38 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 39 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 44 */     if (this == obj)
/* 45 */       return true;
/* 46 */     if (obj == null)
/* 47 */       return false;
/* 48 */     if (!(obj instanceof Label))
/* 49 */       return false;
/* 50 */     Label other = (Label)obj;
/* 51 */     if (this.name == null) {
/* 52 */       if (other.name == null) break label59;
/* 53 */       return false;
/*    */     }
/* 55 */     label59: return (!(this.name.equals(other.name)));
/*    */   }
/*    */ }