/*    */ package com.tikitag.ons.model;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import javax.persistence.Entity;
/*    */ import javax.persistence.FetchType;
/*    */ import javax.persistence.ManyToOne;
/*    */ import javax.persistence.OneToOne;
/*    */ 
/*    */ @Entity
/*    */ public class TagAssociation extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @OneToOne(optional=false, cascade={javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.MERGE}, fetch=FetchType.EAGER)
/*    */   private TikiTag tag;
/*    */ 
/*    */   @ManyToOne(optional=false, cascade={javax.persistence.CascadeType.PERSIST, javax.persistence.CascadeType.MERGE}, fetch=FetchType.EAGER)
/*    */   TikitAction action;
/*    */ 
/*    */   protected TagAssociation()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TagAssociation(TikiTag tag, TikitAction action)
/*    */   {
/* 28 */     this.tag = tag;
/* 29 */     this.action = action;
/*    */   }
/*    */ 
/*    */   public TikiTag getTag() {
/* 33 */     return this.tag;
/*    */   }
/*    */ 
/*    */   protected void setTag(TikiTag tag) {
/* 37 */     this.tag = tag;
/*    */   }
/*    */ 
/*    */   public TikitAction getAction() {
/* 41 */     return this.action;
/*    */   }
/*    */ 
/*    */   public void setAction(TikitAction action) {
/* 45 */     this.action = action;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 50 */     int prime = 31;
/* 51 */     int result = 1;
/* 52 */     result = 31 * result + ((this.tag == null) ? 0 : this.tag.hashCode());
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 58 */     if (this == obj)
/* 59 */       return true;
/* 60 */     if (obj == null)
/* 61 */       return false;
/* 62 */     if (!(obj instanceof TagAssociation))
/* 63 */       return false;
/* 64 */     TagAssociation other = (TagAssociation)obj;
/* 65 */     if (this.tag == null) {
/* 66 */       if (other.tag == null) break label59;
/* 67 */       return false;
/*    */     }
/* 69 */     label59: return (!(this.tag.equals(other.tag)));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 75 */     return "TagAssociation:{tagId='" + this.tag.getTagId().getIdentifier() + "',actionId='" + this.action.getIdentifier() + "'}";
/*    */   }
/*    */ }