/*     */ package com.tikitag.ons.model;
/*     */ 
/*     */ import com.tikitag.ons.model.util.Owned;
/*     */ import com.tikitag.ons.model.util.TikitId;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.persistence.Column;
/*     */ import javax.persistence.Entity;
/*     */ import javax.persistence.FetchType;
/*     */ import javax.persistence.Lob;
/*     */ import javax.persistence.ManyToOne;
/*     */ import javax.persistence.MapKey;
/*     */ import javax.persistence.OneToMany;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ 
/*     */ @Entity
/*     */ public class Tikit extends BaseEntity
/*     */   implements Owned
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */ 
/*     */   @Column(nullable=false, unique=true)
/*     */   private String name;
/*     */ 
/*     */   @Column
/*     */   private String description;
/*     */ 
/*     */   @ManyToOne
/*     */   private TikiTemplateRef templateRef;
/*     */ 
/*     */   @OneToMany(cascade={javax.persistence.CascadeType.ALL}, fetch=FetchType.LAZY)
/*  46 */   private List<TagAssociation> tagAssociations = new ArrayList();
/*     */ 
/*     */   @OneToMany(cascade={javax.persistence.CascadeType.ALL}, fetch=FetchType.LAZY)
/*     */   @MapKey(name="identifier")
/*  49 */   private Map<String, TikitAction> actionMap = new HashMap();
/*     */ 
/*     */   @ManyToOne
/*     */   private TikiUser owner;
/*     */ 
/*     */   @Column(nullable=false)
/*     */   private boolean personal;
/*     */ 
/*     */   @Lob
/*     */   @Column(columnDefinition="BLOB")
/*     */   private byte[] templateConfig;
/*     */ 
/*     */   public Tikit(String name, TikiTemplateRef template)
/*     */   {
/*  64 */     this.name = name;
/*  65 */     this.templateRef = template; }
/*     */ 
/*     */   protected Tikit() {
/*     */   }
/*     */ 
/*     */   public String getName() {
/*  71 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  75 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public TikiTemplateRef getTemplateRef() {
/*  79 */     return this.templateRef;
/*     */   }
/*     */ 
/*     */   public TikiUser getOwner() {
/*  83 */     return this.owner;
/*     */   }
/*     */ 
/*     */   public void setOwner(TikiUser owner) {
/*  87 */     this.owner = owner;
/*     */   }
/*     */ 
/*     */   public List<TagAssociation> getTagAssociations() {
/*  91 */     return Collections.unmodifiableList(this.tagAssociations);
/*     */   }
/*     */ 
/*     */   public void setTagAssociations(List<TagAssociation> tagAssociations) {
/*  95 */     this.tagAssociations = new ArrayList(tagAssociations);
/*     */   }
/*     */ 
/*     */   public void associate(TikiTag tag) {
/*  99 */     associate(tag, "default");
/*     */   }
/*     */ 
/*     */   public void associate(TikiTag tag, String actionId) {
/* 103 */     TikitAction action = (TikitAction)this.actionMap.get(actionId);
/* 104 */     TagAssociation association = new TagAssociation(tag, action);
/* 105 */     this.tagAssociations.add(association);
/*     */   }
/*     */ 
/*     */   public void register(TikitAction action) {
/* 109 */     this.actionMap.put(action.getIdentifier(), action);
/*     */   }
/*     */ 
/*     */   public List<TikitAction> getTikiActions() {
/* 113 */     return new ArrayList(this.actionMap.values());
/*     */   }
/*     */ 
/*     */   public boolean isPersonal() {
/* 117 */     return this.personal;
/*     */   }
/*     */ 
/*     */   public void setPersonal(boolean personal) {
/* 121 */     this.personal = personal;
/*     */   }
/*     */ 
/*     */   public byte[] getTemplateConfig() {
/* 125 */     return this.templateConfig;
/*     */   }
/*     */ 
/*     */   public void setTemplateConfig(byte[] templateConfig) {
/* 129 */     this.templateConfig = templateConfig;
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/* 133 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) {
/* 137 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 142 */     int prime = 31;
/* 143 */     int result = 1;
/* 144 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 145 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 150 */     if (this == obj)
/* 151 */       return true;
/* 152 */     if (obj == null)
/* 153 */       return false;
/* 154 */     if (!(obj instanceof Tikit))
/* 155 */       return false;
/* 156 */     Tikit other = (Tikit)obj;
/* 157 */     if (this.name == null) {
/* 158 */       if (other.name == null) break label59;
/* 159 */       return false;
/*     */     }
/* 161 */     label59: return (!(this.name.equals(other.name)));
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 167 */     return new ToStringBuilder(this).append(this.name).append(this.templateRef).toString();
/*     */   }
/*     */ 
/*     */   public TikitId toId()
/*     */   {
/* 177 */     return new TikitId(this.name.getBytes());
/*     */   }
/*     */ }