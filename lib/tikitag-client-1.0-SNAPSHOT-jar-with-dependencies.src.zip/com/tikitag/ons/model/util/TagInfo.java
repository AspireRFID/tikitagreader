/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class TagInfo
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private TagId tagId;
/*    */ 
/*    */   @XmlElement
/*    */   private byte[] tagData;
/*    */ 
/*    */   protected TagInfo()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TagInfo(TagId tagId)
/*    */   {
/* 35 */     this.tagId = tagId;
/*    */   }
/*    */ 
/*    */   public TagId getTagId() {
/* 39 */     return this.tagId;
/*    */   }
/*    */ 
/*    */   public byte[] getTagData() {
/* 43 */     return this.tagData;
/*    */   }
/*    */ 
/*    */   public void setTagData(byte[] tagData) {
/* 47 */     this.tagData = tagData;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 52 */     int prime = 31;
/* 53 */     int result = 1;
/* 54 */     result = 31 * result + ((this.tagId == null) ? 0 : this.tagId.hashCode());
/* 55 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 60 */     if (this == obj)
/* 61 */       return true;
/* 62 */     if (obj == null)
/* 63 */       return false;
/* 64 */     if (!(obj instanceof TagInfo))
/* 65 */       return false;
/* 66 */     TagInfo other = (TagInfo)obj;
/* 67 */     if (this.tagId == null) {
/* 68 */       if (other.tagId == null) break label59;
/* 69 */       return false;
/*    */     }
/* 71 */     label59: return (!(this.tagId.equals(other.tagId)));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 77 */     return new StringBuilder().append("Tag(").append(this.tagId.getIdentifier()).append((this.tagData == null) ? "" : new StringBuilder().append(", HexData=").append(HexFormatter.toHexString(this.tagData)).toString()).append(")").toString();
/*    */   }
/*    */ }