package com.tikitag.ons.model.util;

import com.tikitag.ons.model.TikiUser;

public abstract interface Owned
{
  public abstract TikiUser getOwner();
}