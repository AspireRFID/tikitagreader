/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class ClientNameChange
/*    */ {
/*    */ 
/*    */   @XmlElement
/*    */   private String newClientName;
/*    */ 
/*    */   public ClientNameChange(String newClientName)
/*    */   {
/* 16 */     this.newClientName = newClientName;
/*    */   }
/*    */ 
/*    */   ClientNameChange()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getNewClientName() {
/* 24 */     return this.newClientName;
/*    */   }
/*    */ }