/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ 
/*    */ public class UserIdentifedTagEvent extends TagEvent
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private TikiUser user;
/*    */ 
/*    */   public UserIdentifedTagEvent(TikiUser user, TagEvent original)
/*    */   {
/* 14 */     super(original);
/* 15 */     this.user = user;
/*    */   }
/*    */ 
/*    */   public TikiUser getUser() {
/* 19 */     return this.user;
/*    */   }
/*    */ }