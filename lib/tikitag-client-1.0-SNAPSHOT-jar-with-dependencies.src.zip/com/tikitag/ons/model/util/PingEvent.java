/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class PingEvent
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private ClientId clientId;
/*    */ 
/*    */   public PingEvent(ClientId clientId)
/*    */   {
/* 23 */     this.clientId = clientId;
/*    */   }
/*    */ 
/*    */   PingEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ClientId getClientId() {
/* 31 */     return this.clientId;
/*    */   }
/*    */ }