/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.net.URI;
/*    */ import javax.persistence.Embeddable;
/*    */ 
/*    */ @Embeddable
/*    */ public class URN
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private String value;
/*    */ 
/*    */   protected URN()
/*    */   {
/*    */   }
/*    */ 
/*    */   public URN(String value)
/*    */   {
/* 26 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public String getValue() {
/* 30 */     return this.value;
/*    */   }
/*    */ 
/*    */   public void setValue(String value) {
/* 34 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object object)
/*    */   {
/* 39 */     if (object instanceof URN) {
/* 40 */       URN _URN = (URN)object;
/* 41 */       return this.value.equals(_URN.value);
/*    */     }
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 48 */     int prime = 31;
/* 49 */     int result = 1;
/* 50 */     result = 31 * result + ((this.value == null) ? 0 : this.value.hashCode());
/* 51 */     return result;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 56 */     return this.value;
/*    */   }
/*    */ 
/*    */   public URI toURI() {
/* 60 */     return URI.create(this.value);
/*    */   }
/*    */ }