/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlAttribute;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class TagEvent
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlAttribute
/*    */   private TagEventType tagEventType;
/*    */ 
/*    */   @XmlElement
/*    */   private ClientId clientId;
/*    */ 
/*    */   @XmlElement
/*    */   private ReaderId readerId;
/*    */ 
/*    */   @XmlElement
/*    */   private TagInfo actionTag;
/*    */ 
/*    */   @XmlElement
/*    */   private TagInfo contextTag;
/*    */ 
/*    */   public static TagEvent put(ClientId clientId, ReaderId readerId, TagInfo actionTag, TagInfo contextTag)
/*    */   {
/* 36 */     return new TagEvent(TagEventType.PUT, clientId, readerId, actionTag, contextTag);
/*    */   }
/*    */ 
/*    */   public static TagEvent touch(ClientId clientId, ReaderId readerId, TagInfo actionTag, TagInfo contextTag) {
/* 40 */     return new TagEvent(TagEventType.TOUCH, clientId, readerId, actionTag, contextTag);
/*    */   }
/*    */ 
/*    */   public static TagEvent remove(ClientId clientId, ReaderId readerId, TagInfo actionTag, TagInfo contextTag) {
/* 44 */     return new TagEvent(TagEventType.REMOVE, clientId, readerId, actionTag, contextTag);
/*    */   }
/*    */ 
/*    */   public TagEvent(TagEventType tagEventType, ClientId clientId, ReaderId readerId, TagInfo actionTag, TagInfo contextTag) {
/* 48 */     this.tagEventType = tagEventType;
/* 49 */     this.readerId = readerId;
/* 50 */     this.clientId = clientId;
/* 51 */     this.actionTag = actionTag;
/* 52 */     this.contextTag = contextTag;
/*    */   }
/*    */ 
/*    */   protected TagEvent(TagEvent original) {
/* 56 */     this.tagEventType = original.tagEventType;
/* 57 */     this.readerId = original.readerId;
/* 58 */     this.clientId = original.clientId;
/* 59 */     this.actionTag = original.actionTag;
/* 60 */     this.contextTag = original.contextTag;
/*    */   }
/*    */ 
/*    */   TagEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TagEventType getTagEventType() {
/* 68 */     return this.tagEventType;
/*    */   }
/*    */ 
/*    */   public ClientId getClientId() {
/* 72 */     return this.clientId;
/*    */   }
/*    */ 
/*    */   public ReaderId getReaderId() {
/* 76 */     return this.readerId;
/*    */   }
/*    */ 
/*    */   public TagInfo getActionTag() {
/* 80 */     return this.actionTag;
/*    */   }
/*    */ 
/*    */   public TagInfo getContextTag() {
/* 84 */     return this.contextTag;
/*    */   }
/*    */ 
/*    */   public static enum TagEventType
/*    */   {
/* 20 */     PUT, TOUCH, REMOVE;
/*    */   }
/*    */ }