/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.io.Serializable;
/*    */ 
/*    */ public class TikitId
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String URN_TIKI_T = "urn:tiki:t:";
/*    */   private String identifier;
/*    */ 
/*    */   public TikitId(byte[] bytes)
/*    */   {
/* 25 */     this.identifier = HexFormatter.toHexString(bytes);
/*    */   }
/*    */ 
/*    */   public TikitId(String identifier) {
/* 29 */     this.identifier = identifier;
/*    */   }
/*    */ 
/*    */   public TikitId(URN resourceName)
/*    */   {
/* 34 */     validate(resourceName.getValue());
/* 35 */     this.identifier = resourceName.getValue().substring("urn:tiki:t:".length());
/*    */   }
/*    */ 
/*    */   public String getIdentifier() {
/* 39 */     return this.identifier;
/*    */   }
/*    */ 
/*    */   public URN toURN() {
/* 43 */     return new URN("urn:tiki:t:" + this.identifier);
/*    */   }
/*    */ 
/*    */   private void validate(String value) {
/*    */     try {
/* 48 */       if (value.startsWith("urn:tiki:t:"))
/* 49 */         HexFormatter.fromHexString(value.substring("urn:tiki:t:".length()));
/*    */       else
/* 51 */         throw new IllegalArgumentException();
/*    */     } catch (Exception e) {
/* 53 */       throw new IllegalArgumentException("Invalid URN, expected 'urn:tiki:t:..'!");
/*    */     }
/*    */   }
/*    */ }