/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class NewReaderEvent
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private ReaderId readerId;
/*    */ 
/*    */   public NewReaderEvent(ReaderId readerId)
/*    */   {
/* 24 */     this.readerId = readerId;
/*    */   }
/*    */ 
/*    */   NewReaderEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReaderId getReaderId() {
/* 32 */     return this.readerId;
/*    */   }
/*    */ }