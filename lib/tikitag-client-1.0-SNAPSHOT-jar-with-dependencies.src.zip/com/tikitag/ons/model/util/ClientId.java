/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class ClientId
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private String id;
/*    */ 
/*    */   @XmlElement
/*    */   private String name;
/*    */ 
/*    */   public ClientId(String id)
/*    */   {
/* 24 */     this.id = id;
/* 25 */     this.name = id;
/*    */   }
/*    */ 
/*    */   public ClientId(String id, String name) {
/* 29 */     this.id = id;
/* 30 */     this.name = name;
/*    */   }
/*    */ 
/*    */   ClientId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public String getId() {
/* 38 */     return this.id;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 42 */     return this.name;
/*    */   }
/*    */ 
/*    */   public void setName(String name) {
/* 46 */     this.name = name;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return this.name + "(" + this.id + ")";
/*    */   }
/*    */ }