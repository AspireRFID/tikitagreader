/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlElements;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class ChangeEvent
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private ClientId clientId;
/*    */ 
/*    */   @XmlElements({@XmlElement(name="newReader", type=NewReaderEvent.class), @XmlElement(name="clientNameChange", type=ClientNameChange.class)})
/*    */   private Object subEvent;
/*    */ 
/*    */   public ChangeEvent(ClientId clientId, NewReaderEvent newReader)
/*    */   {
/* 30 */     this.clientId = clientId;
/* 31 */     this.subEvent = newReader;
/*    */   }
/*    */ 
/*    */   public ChangeEvent(ClientId clientId, ClientNameChange clientNameChange) {
/* 35 */     this.clientId = clientId;
/* 36 */     this.subEvent = clientNameChange;
/*    */   }
/*    */ 
/*    */   ChangeEvent()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ClientId getClientId() {
/* 44 */     return this.clientId;
/*    */   }
/*    */ 
/*    */   public ChangeType getChangeType()
/*    */   {
/* 52 */     if (this.subEvent instanceof NewReaderEvent)
/* 53 */       return ChangeType.NEW_READER;
/* 54 */     if (this.subEvent instanceof ClientNameChange) {
/* 55 */       return ChangeType.CLIENT_NAME_CHANGE;
/*    */     }
/* 57 */     throw new IllegalStateException("ChangeEvent is corrupt !");
/*    */   }
/*    */ 
/*    */   public NewReaderEvent getNewReader() {
/* 61 */     return ((NewReaderEvent)this.subEvent);
/*    */   }
/*    */ 
/*    */   public ClientNameChange getClientNameChange() {
/* 65 */     return ((ClientNameChange)this.subEvent);
/*    */   }
/*    */ 
/*    */   public static enum ChangeType
/*    */   {
/* 47 */     NEW_READER, CLIENT_NAME_CHANGE;
/*    */   }
/*    */ }