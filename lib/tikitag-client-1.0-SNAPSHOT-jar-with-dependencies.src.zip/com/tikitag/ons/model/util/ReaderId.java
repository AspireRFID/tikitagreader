/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.io.Serializable;
/*    */ import java.util.Arrays;
/*    */ import javax.persistence.Embeddable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ 
/*    */ @Embeddable
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public final class ReaderId
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement
/*    */   private byte[] uid;
/*    */ 
/*    */   @XmlElement
/*    */   private String serialNr;
/*    */ 
/*    */   ReaderId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ReaderId(byte[] uid, String serialNr)
/*    */   {
/* 32 */     if (uid == null) {
/* 33 */       throw new IllegalArgumentException("ReaderId should not be null");
/*    */     }
/* 35 */     this.uid = uid;
/* 36 */     this.serialNr = serialNr;
/*    */   }
/*    */ 
/*    */   public ReaderId(String hexUid, String serialNr) {
/* 40 */     this(HexFormatter.fromHexString(hexUid), serialNr);
/*    */   }
/*    */ 
/*    */   public byte[] getUid() {
/* 44 */     return this.uid;
/*    */   }
/*    */ 
/*    */   public String getSerialNr() {
/* 48 */     return this.serialNr;
/*    */   }
/*    */ 
/*    */   public String toString() {
/* 52 */     return "Reader[" + HexFormatter.toHexString(this.uid) + ", " + this.serialNr + "]";
/*    */   }
/*    */ 
/*    */   public int hashCode() {
/* 56 */     int prime = 31;
/* 57 */     int result = 1;
/* 58 */     result = 31 * result + Arrays.hashCode(this.uid);
/* 59 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj) {
/* 63 */     if (this == obj)
/* 64 */       return true;
/* 65 */     if (obj == null)
/* 66 */       return false;
/* 67 */     if (super.getClass() != obj.getClass())
/* 68 */       return false;
/* 69 */     ReaderId other = (ReaderId)obj;
/*    */ 
/* 71 */     return (!(Arrays.equals(this.uid, other.uid)));
/*    */   }
/*    */ }