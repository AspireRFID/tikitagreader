/*    */ package com.tikitag.ons.model.util;
/*    */ 
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.io.Serializable;
/*    */ import javax.persistence.Column;
/*    */ import javax.persistence.Embeddable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlValue;
/*    */ 
/*    */ @Embeddable
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public final class TagId
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private static final String URN_TIKI_TAG = "urn:tiki:tag:";
/*    */ 
/*    */   @XmlValue
/*    */   @Column(nullable=false, unique=true)
/*    */   private String identifier;
/*    */ 
/*    */   protected TagId()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TagId(byte[] bytes)
/*    */   {
/* 33 */     this(HexFormatter.toHexString(bytes));
/*    */   }
/*    */ 
/*    */   public TagId(String identifier) {
/* 37 */     this.identifier = identifier;
/*    */   }
/*    */ 
/*    */   public byte[] asByteArray() {
/* 41 */     return HexFormatter.fromHexString(this.identifier);
/*    */   }
/*    */ 
/*    */   public String getIdentifier() {
/* 45 */     return this.identifier;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 50 */     return "TagId[" + getIdentifier() + "]";
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 55 */     int prime = 31;
/* 56 */     int result = 1;
/* 57 */     result = 31 * result + ((this.identifier == null) ? 0 : this.identifier.hashCode());
/* 58 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 63 */     if (this == obj)
/* 64 */       return true;
/* 65 */     if (obj == null)
/* 66 */       return false;
/* 67 */     if (!(obj instanceof TagId))
/* 68 */       return false;
/* 69 */     TagId other = (TagId)obj;
/* 70 */     if (this.identifier == null) {
/* 71 */       if (other.identifier == null) break label59;
/* 72 */       return false;
/*    */     }
/* 74 */     label59: return (!(this.identifier.equals(other.identifier)));
/*    */   }
/*    */ 
/*    */   public URN toURN()
/*    */   {
/* 79 */     return new URN("urn:tiki:tag:" + getIdentifier());
/*    */   }
/*    */ }