/*    */ package com.tikitag.ons.model;
/*    */ 
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import javax.persistence.Embedded;
/*    */ import javax.persistence.Entity;
/*    */ import org.apache.commons.lang.builder.ToStringBuilder;
/*    */ 
/*    */ @Entity
/*    */ public class TikiTag extends BaseEntity
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @Embedded
/*    */   private TagId tagId;
/*    */ 
/*    */   public TikiTag(String hexTagId)
/*    */   {
/* 22 */     this.tagId = new TagId(hexTagId);
/*    */   }
/*    */ 
/*    */   protected TikiTag() {
/*    */   }
/*    */ 
/*    */   public TagId getTagId() {
/* 29 */     return this.tagId;
/*    */   }
/*    */ 
/*    */   protected void setTagId(TagId tagId) {
/* 33 */     this.tagId = tagId;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 38 */     int prime = 31;
/* 39 */     int result = 1;
/* 40 */     result = 31 * result + ((this.tagId == null) ? 0 : this.tagId.hashCode());
/* 41 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 46 */     if (this == obj)
/* 47 */       return true;
/* 48 */     if (obj == null)
/* 49 */       return false;
/* 50 */     if (super.getClass() != obj.getClass())
/* 51 */       return false;
/* 52 */     TikiTag other = (TikiTag)obj;
/* 53 */     if (this.tagId == null) {
/* 54 */       if (other.tagId == null) break label63;
/* 55 */       return false;
/*    */     }
/* 57 */     label63: return (!(this.tagId.equals(other.tagId)));
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 63 */     return new ToStringBuilder(this).append(this.tagId).toString();
/*    */   }
/*    */ }