/*     */ package com.tikitag.ons.model;
/*     */ 
/*     */ import com.tikitag.ons.model.util.URN;
/*     */ import com.tikitag.util.HexFormatter;
/*     */ import java.net.URI;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.persistence.Entity;
/*     */ import javax.persistence.ManyToMany;
/*     */ import javax.persistence.Transient;
/*     */ import org.apache.commons.lang.ObjectUtils;
/*     */ import org.apache.commons.lang.builder.ToStringBuilder;
/*     */ 
/*     */ @Entity
/*     */ public class TikiTemplateRef extends BaseEntity
/*     */ {
/*     */   private static final long serialVersionUID = 1L;
/*     */   private String name;
/*     */   private String description;
/*     */ 
/*     */   @ManyToMany
/*     */   private List<Label> labels;
/*     */   private URI createUri;
/*     */   private URI editUri;
/*     */   private URI copyUri;
/*     */ 
/*     */   protected TikiTemplateRef()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TikiTemplateRef(String name, String description, Label[] labels)
/*     */   {
/*  43 */     this.name = name;
/*  44 */     this.description = description;
/*  45 */     this.labels = Arrays.asList(labels);
/*     */   }
/*     */ 
/*     */   public String getName()
/*     */   {
/*  50 */     return this.name;
/*     */   }
/*     */ 
/*     */   public void setName(String name) {
/*  54 */     this.name = name;
/*     */   }
/*     */ 
/*     */   public URN toURN() {
/*  58 */     return new URN("urn:tiki:template:" + HexFormatter.toHexString(this.name.getBytes()));
/*     */   }
/*     */ 
/*     */   public String getDescription() {
/*  62 */     return this.description;
/*     */   }
/*     */ 
/*     */   public void setDescription(String description) {
/*  66 */     this.description = description;
/*     */   }
/*     */ 
/*     */   public List<Label> getLabels() {
/*  70 */     return this.labels;
/*     */   }
/*     */ 
/*     */   public void setLabels(List<Label> labels) {
/*  74 */     this.labels = labels;
/*     */   }
/*     */ 
/*     */   @Transient
/*     */   public URI getCreateUri() {
/*  79 */     return this.createUri;
/*     */   }
/*     */ 
/*     */   public void setCreateUri(URI createUri) {
/*  83 */     this.createUri = createUri;
/*     */   }
/*     */ 
/*     */   public String getCreateUriAsString() {
/*  87 */     return ObjectUtils.toString(this.createUri, null);
/*     */   }
/*     */ 
/*     */   public void setCreateUriAsString(String createUriAsString) {
/*  91 */     this.createUri = URI.create(createUriAsString);
/*     */   }
/*     */ 
/*     */   @Transient
/*     */   public URI getEditUri() {
/*  96 */     return this.editUri;
/*     */   }
/*     */ 
/*     */   public void setEditUri(URI editUri) {
/* 100 */     this.editUri = editUri;
/*     */   }
/*     */ 
/*     */   public String getEditUriAsString() {
/* 104 */     return ObjectUtils.toString(this.editUri, null);
/*     */   }
/*     */ 
/*     */   public void setEditUriAsString(String editUri) {
/* 108 */     this.editUri = URI.create(editUri);
/*     */   }
/*     */ 
/*     */   @Transient
/*     */   public URI getCopyUri() {
/* 113 */     return this.copyUri;
/*     */   }
/*     */ 
/*     */   public void setCopyUri(URI copyUri) {
/* 117 */     this.copyUri = copyUri;
/*     */   }
/*     */ 
/*     */   public String getCopyUriAsString() {
/* 121 */     return ObjectUtils.toString(this.copyUri, null);
/*     */   }
/*     */ 
/*     */   public void setCopyUriAsString(String copyUri) {
/* 125 */     this.copyUri = URI.create(copyUri);
/*     */   }
/*     */ 
/*     */   public String toString()
/*     */   {
/* 131 */     return new ToStringBuilder(this).append(this.name).toString();
/*     */   }
/*     */ 
/*     */   public int hashCode()
/*     */   {
/* 136 */     int prime = 31;
/* 137 */     int result = 1;
/* 138 */     result = 31 * result + ((this.name == null) ? 0 : this.name.hashCode());
/* 139 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean equals(Object obj)
/*     */   {
/* 144 */     if (this == obj)
/* 145 */       return true;
/* 146 */     if (obj == null)
/* 147 */       return false;
/* 148 */     if (!(obj instanceof TikiTemplateRef))
/* 149 */       return false;
/* 150 */     TikiTemplateRef other = (TikiTemplateRef)obj;
/* 151 */     if (this.name == null) {
/* 152 */       if (other.name == null) break label59;
/* 153 */       return false;
/*     */     }
/* 155 */     label59: return (!(this.name.equals(other.name)));
/*     */   }
/*     */ }