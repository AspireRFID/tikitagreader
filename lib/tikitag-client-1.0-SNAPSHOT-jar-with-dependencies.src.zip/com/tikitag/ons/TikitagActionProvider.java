package com.tikitag.ons;

import com.tikitag.ons.model.util.TagEvent;

public abstract interface TikitagActionProvider
{
  public abstract ActionAndMemento getTikitagAction(TagEvent paramTagEvent, ActionProviderMemento paramActionProviderMemento);
}