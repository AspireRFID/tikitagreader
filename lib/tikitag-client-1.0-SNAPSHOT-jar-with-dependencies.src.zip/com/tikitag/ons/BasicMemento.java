/*    */ package com.tikitag.ons;
/*    */ 
/*    */ public class BasicMemento
/*    */   implements ActionProviderMemento
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Class<? extends TikitagActionProvider> actionProviderClass;
/*    */ 
/*    */   public BasicMemento(Class<? extends TikitagActionProvider> actionProviderClass)
/*    */   {
/* 17 */     this.actionProviderClass = actionProviderClass;
/*    */   }
/*    */ 
/*    */   public Class<? extends TikitagActionProvider> getActionProviderClass()
/*    */   {
/* 22 */     return this.actionProviderClass;
/*    */   }
/*    */ }