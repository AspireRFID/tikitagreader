package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.CycleBlock;
import javax.ejb.Local;

@Local
public abstract interface CycleBlockFacade extends CycleBlock
{
}