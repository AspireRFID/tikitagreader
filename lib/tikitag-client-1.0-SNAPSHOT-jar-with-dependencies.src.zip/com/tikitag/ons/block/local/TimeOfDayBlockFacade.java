package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.TimeOfDayBlock;
import javax.ejb.Local;

@Local
public abstract interface TimeOfDayBlockFacade extends TimeOfDayBlock
{
}