package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.VCardMailBlock;
import javax.ejb.Local;

@Local
public abstract interface VCardMailBlockFacade extends VCardMailBlock
{
}