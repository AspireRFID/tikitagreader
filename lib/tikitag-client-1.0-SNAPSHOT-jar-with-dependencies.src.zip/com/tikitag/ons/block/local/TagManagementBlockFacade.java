package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.TagManagementBlock;
import javax.ejb.Local;

@Local
public abstract interface TagManagementBlockFacade extends TagManagementBlock
{
}