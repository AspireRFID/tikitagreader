package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.FileBlock;
import javax.ejb.Local;

@Local
public abstract interface FileBlockFacade extends FileBlock
{
}