package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.UrlBlock;
import javax.ejb.Local;

@Local
public abstract interface UrlBlockFacade extends UrlBlock
{
}