package com.tikitag.ons.block.local;

import com.tikitag.ons.block.remote.MusicBlock;
import javax.ejb.Local;

@Local
public abstract interface MusicBlockFacade extends MusicBlock
{
}