/*     */ package com.tikitag.ons.block;
/*     */ 
/*     */ import com.tikitag.ons.ActionAndMemento;
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.ActionProviderNotFoundException;
/*     */ import com.tikitag.ons.BasicMemento;
/*     */ import com.tikitag.ons.TikitagActionProvider;
/*     */ import com.tikitag.ons.block.actioncontext.NoActionContext;
/*     */ import com.tikitag.ons.block.actioncontext.TagManagementActionContext;
/*     */ import com.tikitag.ons.block.local.TagManagementBlockFacade;
/*     */ import com.tikitag.ons.block.mx.GenericMIF;
/*     */ import com.tikitag.ons.block.remote.TagManagementBlock;
/*     */ import com.tikitag.ons.model.TikiUser;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.ons.model.util.UserIdentifedTagEvent;
/*     */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*     */ import com.tikitag.util.config.xml.ConfigContainer;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.concurrent.SynchronousQueue;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.Depends;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ 
/*     */ @Service(objectName="tikitag.block:name=TagManagement")
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/TagManagement/local")
/*     */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*     */ public class TagManagementBlockService extends AbstractBlockService
/*     */   implements TagManagementBlockFacade, TagManagementBlock, GenericMIF
/*     */ {
/*     */   protected static final String NAME = "TagManagement";
/*  45 */   private static final Logger log = Logger.getLogger(TagManagementBlockService.class);
/*     */ 
/*  47 */   private static final ReaderId ALL_READERS = new ReaderId("00", null);
/*     */ 
/*  49 */   private Map<String, SynchronousQueue<TagId>> interceptedUsers = new HashMap();
/*  50 */   private Map<ReaderId, SynchronousQueue<TagId>> interceptedReaders = new HashMap();
/*     */ 
/*     */   public TagManagementBlockService()
/*     */   {
/*  41 */     super("TagManagement");
/*     */   }
/*     */ 
/*     */   public List<TikitagActionProvider> getTikitagActionProviders()
/*     */   {
/*  54 */     List providers = new ArrayList();
/*  55 */     providers.add(new TagDetectorFromUser());
/*     */ 
/*  57 */     providers.add(new DetectionController(null));
/*  58 */     providers.add(new DefaultTikitagActionProvider(null));
/*  59 */     return providers;
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento detectionControllerFromUser(ActionProviderMemento target) {
/*  63 */     ActionProviderMemento tagDetector = new BasicMemento(TagDetectorFromUser.class);
/*  64 */     return new DetectionControllerMemento(target, tagDetector);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento detectionController(ActionProviderMemento target)
/*     */   {
/*  74 */     return detectionControllerFromUser(target);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento getTagDetector()
/*     */   {
/*  79 */     return getTagDetectorFromUser();
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento defaultMemento() {
/*  83 */     return new BasicMemento(DefaultTikitagActionProvider.class);
/*     */   }
/*     */ 
/*     */   public ConfigContainer noAction() {
/*  87 */     return new NoActionContext().getActionContext();
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento getTagDetectorFromUser() {
/*  91 */     return new BasicMemento(TagDetectorFromUser.class);
/*     */   }
/*     */ 
/*     */   public TagId detectTag(TikiUser user, long timeout)
/*     */   {
/*     */     TagId localTagId1;
/*  99 */     log.info("Detecting tag for " + user + ".");
/* 100 */     String userName = user.getUserName();
/* 101 */     SynchronousQueue queue = new SynchronousQueue();
/* 102 */     synchronized (this) {
/* 103 */       if (this.interceptedUsers.containsKey(userName)) {
/* 104 */         log.warn("Detecting request from " + user + " already pending: ignoring!");
/* 105 */         return null;
/*     */       }
/* 107 */       this.interceptedUsers.put(userName, queue);
/*     */     }
/*     */     try {
/* 110 */       TagId tagId = (TagId)queue.poll(timeout, TimeUnit.MILLISECONDS);
/* 111 */       localTagId1 = tagId;
/*     */ 
/* 118 */       return localTagId1;
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 114 */       localTagId1 = null;
/*     */ 
/* 118 */       return localTagId1;
/*     */     }
/*     */     finally
/*     */     {
/* 116 */       synchronized (this) {
/* 117 */         this.interceptedUsers.remove(userName);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public TagId detectTag(ReaderId readerId, long timeout)
/*     */   {
/*     */     TagId localTagId1;
/* 124 */     if (readerId == null) {
/* 125 */       readerId = ALL_READERS;
/*     */     }
/*     */ 
/* 128 */     SynchronousQueue q = new SynchronousQueue();
/* 129 */     synchronized (this) {
/* 130 */       if (this.interceptedReaders.containsKey(readerId)) {
/* 131 */         return null;
/*     */       }
/* 133 */       this.interceptedReaders.put(readerId, q);
/*     */     }
/*     */     try {
/* 136 */       TagId tagId = (TagId)q.poll(timeout, TimeUnit.MILLISECONDS);
/* 137 */       localTagId1 = tagId;
/*     */ 
/* 144 */       return localTagId1;
/*     */     }
/*     */     catch (InterruptedException e)
/*     */     {
/* 140 */       localTagId1 = null;
/*     */ 
/* 144 */       return localTagId1;
/*     */     }
/*     */     finally
/*     */     {
/* 142 */       synchronized (this) {
/* 143 */         this.interceptedReaders.remove(readerId);
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DetectionController
/*     */     implements TikitagActionProvider
/*     */   {
/*     */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento actionProviderMemento)
/*     */     {
/* 248 */       TagManagementBlockService.DetectionControllerMemento memento = (TagManagementBlockService.DetectionControllerMemento)actionProviderMemento;
/*     */ 
/* 251 */       ConfigContainer action = null;
/*     */ 
/* 253 */       ActionProviderMemento filterMemento = memento.getFilterMemento();
/* 254 */       if (filterMemento != null) {
/*     */         try {
/* 256 */           ActionAndMemento filterResult = TagManagementBlockService.this.actionProviderCatalog.invokeActionProvider(filterMemento, tagEvent);
/* 257 */           action = filterResult.getAction();
/* 258 */           memento.setFilterMemento(filterResult.getMemento());
/*     */         } catch (ActionProviderNotFoundException e) {
/* 260 */           TagManagementBlockService.log.error("Failed to find filterProvider " + filterMemento.getActionProviderClass() + ". Will invoke target without filter applied.");
/*     */         }
/*     */       }
/*     */ 
/* 264 */       if (action == null) {
/* 265 */         ActionProviderMemento targetMemento = memento.getTargetMemento();
/* 266 */         ActionAndMemento targetResult = TagManagementBlockService.this.actionProviderCatalog.invokeActionProvider(targetMemento, tagEvent);
/* 267 */         action = targetResult.getAction();
/* 268 */         memento.setTargetMemento(targetResult.getMemento());
/*     */       }
/*     */ 
/* 271 */       return new ActionAndMemento(action, memento);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DetectionControllerMemento extends BasicMemento
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private ActionProviderMemento targetMemento;
/*     */     private ActionProviderMemento filterMemento;
/*     */ 
/*     */     public DetectionControllerMemento(ActionProviderMemento paramActionProviderMemento1, ActionProviderMemento paramActionProviderMemento2)
/*     */     {
/* 223 */       super(TagManagementBlockService.DetectionController.class);
/* 224 */       this.targetMemento = paramActionProviderMemento1;
/* 225 */       this.filterMemento = filterMemento;
/*     */     }
/*     */ 
/*     */     public ActionProviderMemento getFilterMemento() {
/* 229 */       return this.filterMemento;
/*     */     }
/*     */ 
/*     */     public ActionProviderMemento getTargetMemento() {
/* 233 */       return this.targetMemento;
/*     */     }
/*     */ 
/*     */     public void setTargetMemento(ActionProviderMemento targetMemento) {
/* 237 */       this.targetMemento = targetMemento;
/*     */     }
/*     */ 
/*     */     public void setFilterMemento(ActionProviderMemento filterMemento) {
/* 241 */       this.filterMemento = filterMemento;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DefaultTikitagActionProvider
/*     */     implements TikitagActionProvider
/*     */   {
/*     */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*     */     {
/* 209 */       TagId id = tagEvent.getActionTag().getTagId();
/* 210 */       return new ActionAndMemento(new TagManagementActionContext(id + " has no action associated").getActionContext(), memento);
/*     */     }
/*     */   }
/*     */ 
/*     */   public class TagDetectorFromUser
/*     */     implements TikitagActionProvider
/*     */   {
/*     */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*     */     {
/* 150 */       if (tagEvent instanceof UserIdentifedTagEvent)
/*     */       {
/*     */         Map interceptedUsersCopy;
/*     */         SynchronousQueue queue;
/* 151 */         UserIdentifedTagEvent userIdentifiedTagEvent = (UserIdentifedTagEvent)tagEvent;
/* 152 */         String userName = userIdentifiedTagEvent.getUser().getUserName();
/* 153 */         TagId tagId = userIdentifiedTagEvent.getActionTag().getTagId();
/*     */ 
/* 155 */         synchronized (this) {
/* 156 */           interceptedUsersCopy = new HashMap(TagManagementBlockService.this.interceptedUsers);
/*     */         }
/*     */ 
/* 159 */         if (interceptedUsersCopy.containsKey(userName))
/*     */         {
/* 161 */           queue = (SynchronousQueue)interceptedUsersCopy.get(userName);
/*     */         }
/*     */         else {
/* 164 */           return new ActionAndMemento(null, memento);
/*     */         }
/*     */ 
/* 167 */         queue.offer(tagId);
/*     */       } else {
/* 169 */         throw new RuntimeException("This detector is not compatible with the given arguments!"); }
/* 170 */       return new ActionAndMemento(new TagManagementActionContext("Tag (re)configuration in progress...").getActionContext(), memento);
/*     */     }
/*     */   }
/*     */ }