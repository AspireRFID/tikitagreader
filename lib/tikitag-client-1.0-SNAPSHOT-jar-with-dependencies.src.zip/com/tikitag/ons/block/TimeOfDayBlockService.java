/*     */ package com.tikitag.ons.block;
/*     */ 
/*     */ import com.tikitag.ons.ActionAndMemento;
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.BasicMemento;
/*     */ import com.tikitag.ons.TikitagActionProvider;
/*     */ import com.tikitag.ons.block.local.TimeOfDayBlockFacade;
/*     */ import com.tikitag.ons.block.mx.GenericMIF;
/*     */ import com.tikitag.ons.block.remote.TimeOfDayBlock;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*     */ import java.util.Date;
/*     */ import java.util.List;
/*     */ import org.apache.commons.collections.comparators.ComparableComparator;
/*     */ import org.apache.commons.lang.Validate;
/*     */ import org.jboss.annotation.ejb.Depends;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ 
/*     */ @Service(objectName="tikitag.block:name=TimeOfDay")
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/TimeOfDay/local")
/*     */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*     */ public class TimeOfDayBlockService extends AbstractBlockService
/*     */   implements TimeOfDayBlockFacade, TimeOfDayBlock, GenericMIF
/*     */ {
/*     */   protected static final String NAME = "TimeOfDay";
/*     */ 
/*     */   public TimeOfDayBlockService()
/*     */   {
/*  30 */     super("TimeOfDay");
/*     */   }
/*     */ 
/*     */   public List<TikitagActionProvider> getTikitagActionProviders()
/*     */   {
/*  35 */     return singleProvider(new TimeOfDayProvider(null));
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento getActionProvider(Date switchDate, ActionProviderMemento beforeActionProvider, ActionProviderMemento afterActionProvider) {
/*  39 */     return new TimeOfDayMemento(switchDate, beforeActionProvider, afterActionProvider);
/*     */   }
/*     */ 
/*     */   private class TimeOfDayProvider
/*     */     implements TikitagActionProvider
/*     */   {
/*     */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*     */     {
/*  87 */       TimeOfDayBlockService.TimeOfDayMemento todMemento = (TimeOfDayBlockService.TimeOfDayMemento)memento;
/*  88 */       ActionProviderMemento targetMemento = todMemento.getBeforeActionProvider();
/*     */ 
/*  90 */       Date currentTime = new Date();
/*  91 */       boolean afterSwitch = ComparableComparator.getInstance().compare(currentTime, todMemento.getSwitchDate()) > 0;
/*     */ 
/*  93 */       if (afterSwitch) {
/*  94 */         targetMemento = todMemento.getAfterActionProvider();
/*     */       }
/*     */ 
/*  98 */       ActionAndMemento targetResult = TimeOfDayBlockService.this.actionProviderCatalog.invokeActionProvider(targetMemento, tagEvent);
/*  99 */       if (afterSwitch)
/* 100 */         todMemento.setAfterActionProvider(targetResult.getMemento());
/*     */       else {
/* 102 */         todMemento.setBeforeActionProvider(targetResult.getMemento());
/*     */       }
/*     */ 
/* 105 */       return new ActionAndMemento(targetResult.getAction(), todMemento);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class TimeOfDayMemento extends BasicMemento
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private Date switchDate;
/*     */     private ActionProviderMemento beforeActionProvider;
/*     */     private ActionProviderMemento afterActionProvider;
/*     */ 
/*     */     public TimeOfDayMemento(Date switchDate, ActionProviderMemento beforeActionProvider, ActionProviderMemento afterActionProvider)
/*     */     {
/*  52 */       super(TimeOfDayBlockService.TimeOfDayProvider.class);
/*  53 */       Validate.notNull(switchDate, "switchDate is required");
/*  54 */       Validate.notNull(beforeActionProvider, "beforeActionProvider is required");
/*  55 */       Validate.notNull(afterActionProvider, "afterActionProvider is required");
/*     */ 
/*  57 */       this.switchDate = switchDate;
/*  58 */       this.beforeActionProvider = beforeActionProvider;
/*  59 */       this.afterActionProvider = afterActionProvider;
/*     */     }
/*     */ 
/*     */     public Date getSwitchDate() {
/*  63 */       return this.switchDate;
/*     */     }
/*     */ 
/*     */     public ActionProviderMemento getBeforeActionProvider() {
/*  67 */       return this.beforeActionProvider;
/*     */     }
/*     */ 
/*     */     public ActionProviderMemento getAfterActionProvider() {
/*  71 */       return this.afterActionProvider;
/*     */     }
/*     */ 
/*     */     public void setBeforeActionProvider(ActionProviderMemento beforeActionProvider) {
/*  75 */       this.beforeActionProvider = beforeActionProvider;
/*     */     }
/*     */ 
/*     */     public void setAfterActionProvider(ActionProviderMemento afterActionProvider) {
/*  79 */       this.afterActionProvider = afterActionProvider;
/*     */     }
/*     */   }
/*     */ }