package com.tikitag.ons.block.remote;

import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.block.TikiBlock;
import com.tikitag.ons.util.Info;
import java.util.Date;
import javax.ejb.Remote;

@Remote
public abstract interface TimeOfDayBlock extends TikiBlock
{
  @Info("Configures two different actions depending on the time of day.")
  public abstract ActionProviderMemento getActionProvider(@Info("The switch date.") Date paramDate, @Info("The action before an up to the switch date.") ActionProviderMemento paramActionProviderMemento1, @Info("The action after the swith date.") ActionProviderMemento paramActionProviderMemento2);
}