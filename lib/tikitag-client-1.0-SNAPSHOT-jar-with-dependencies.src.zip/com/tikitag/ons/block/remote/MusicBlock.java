package com.tikitag.ons.block.remote;

import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.block.TikiBlock;
import com.tikitag.ons.util.Info;
import javax.ejb.Remote;

@Remote
public abstract interface MusicBlock extends TikiBlock
{
  @Info("Configures an action to play a music file.")
  public abstract ActionProviderMemento playFile(@Info("The name of the music file.") String paramString);

  @Info("Configures an action to browse to an URL.")
  public abstract ActionProviderMemento openUrl(@Info("An URL.") String paramString);

  @Info("Configures an action to toggle between play and pause.")
  public abstract ActionProviderMemento playPause();

  @Info("Configures an action to stop music playing.")
  public abstract ActionProviderMemento stopPlay();

  @Info("Configures an action to seek fast forward.")
  public abstract ActionProviderMemento fastForward();

  @Info("Configures an action to rewind.")
  public abstract ActionProviderMemento rewind();

  @Info("Configures an action to skip to the next track.")
  public abstract ActionProviderMemento nextTrack();

  @Info("Configures an action to return to the previous track.")
  public abstract ActionProviderMemento previousTrack();

  @Info("Configures an action to turn the volume up.")
  public abstract ActionProviderMemento volumeUp();

  @Info("Configures an action to turn the volume down.")
  public abstract ActionProviderMemento volumeDown();
}