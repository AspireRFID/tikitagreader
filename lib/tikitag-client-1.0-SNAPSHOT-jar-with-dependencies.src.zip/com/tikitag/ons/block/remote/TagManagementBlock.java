package com.tikitag.ons.block.remote;

import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.block.TikiBlock;
import com.tikitag.ons.model.TikiUser;
import com.tikitag.ons.model.util.ReaderId;
import com.tikitag.ons.model.util.TagId;
import com.tikitag.util.config.xml.ConfigContainer;
import javax.ejb.Remote;

@Remote
public abstract interface TagManagementBlock extends TikiBlock
{
  public abstract ActionProviderMemento detectionController(ActionProviderMemento paramActionProviderMemento);

  public abstract ActionProviderMemento defaultMemento();

  public abstract ConfigContainer noAction();

  public abstract ActionProviderMemento getTagDetector();

  public abstract TagId detectTag(ReaderId paramReaderId, long paramLong);

  public abstract TagId detectTag(TikiUser paramTikiUser, long paramLong);
}