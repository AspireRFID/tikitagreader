package com.tikitag.ons.block.remote;

import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.block.TikiBlock;
import com.tikitag.ons.util.Info;
import javax.ejb.Remote;

@Remote
public abstract interface VCardMailBlock extends TikiBlock
{
  @Info("Configures a mailto action.")
  public abstract ActionProviderMemento mailTo();
}