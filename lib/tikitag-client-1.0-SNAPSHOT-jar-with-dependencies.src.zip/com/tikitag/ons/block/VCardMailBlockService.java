/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.ActionAndMemento;
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.BasicMemento;
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.block.actioncontext.VCardActionContext;
/*    */ import com.tikitag.ons.block.local.VCardMailBlockFacade;
/*    */ import com.tikitag.ons.block.mx.GenericMIF;
/*    */ import com.tikitag.ons.block.remote.VCardMailBlock;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import com.tikitag.ons.model.util.TagInfo;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.util.List;
/*    */ import org.jboss.annotation.ejb.Depends;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.block:name=VCardMail")
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/VCardMail/local")
/*    */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*    */ public class VCardMailBlockService extends AbstractBlockService
/*    */   implements VCardMailBlockFacade, VCardMailBlock, GenericMIF
/*    */ {
/*    */   protected static final String NAME = "VCardMail";
/*    */ 
/*    */   public VCardMailBlockService()
/*    */   {
/* 30 */     super("VCardMail");
/*    */   }
/*    */ 
/*    */   public List<TikitagActionProvider> getTikitagActionProviders()
/*    */   {
/* 35 */     return singleProvider(new MailToProvider(null));
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento mailTo() {
/* 39 */     return new BasicMemento(MailToProvider.class); }
/*    */ 
/*    */   private class MailToProvider implements TikitagActionProvider { private String mailto;
/*    */ 
/*    */     private MailToProvider() { this.mailto = "default@default.com";
/*    */     }
/*    */ 
/*    */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento) {
/* 47 */       TagInfo tag = tagEvent.getActionTag();
/* 48 */       String tagMetadata = getDataAsString(tag);
/* 49 */       if (!(tagMetadata.isEmpty())) {
/* 50 */         tagMetadata = tagMetadata.toLowerCase();
/* 51 */         int bVcard = tagMetadata.indexOf("email;pref;");
/* 52 */         int eVcard = tagMetadata.indexOf("title");
/* 53 */         tagMetadata = tagMetadata.substring(bVcard, eVcard - 1);
/* 54 */         bVcard = tagMetadata.indexOf(":");
/* 55 */         this.mailto = tagMetadata.substring(bVcard + 1);
/*    */       }
/*    */ 
/* 58 */       return new ActionAndMemento(new VCardActionContext(this.mailto).getActionContext(), memento);
/*    */     }
/*    */ 
/*    */     private String getDataAsString(TagInfo tag) {
/*    */       try {
/* 63 */         return new String(tag.getTagData(), "UTF-8");
/*    */       } catch (UnsupportedEncodingException e) {
/* 65 */         throw new RuntimeException(e);
/*    */       }
/*    */     }
/*    */   }
/*    */ }