package com.tikitag.ons.block;

import com.tikitag.ons.TikitagActionProvider;
import com.tikitag.ons.model.util.URN;
import java.util.List;

public abstract interface TikiBlock
{
  public abstract String getName();

  public abstract URN toURN();

  public abstract List<TikitagActionProvider> getTikitagActionProviders();
}