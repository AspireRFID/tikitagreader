package com.tikitag.ons.block.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface GenericMIF
{
  public abstract void start()
    throws Exception;

  public abstract void stop();
}