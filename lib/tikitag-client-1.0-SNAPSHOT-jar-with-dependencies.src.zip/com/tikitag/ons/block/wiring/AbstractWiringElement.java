/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ public abstract class AbstractWiringElement
/*    */   implements WiringPoint
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private WiringPoint[] points;
/*    */ 
/*    */   public AbstractWiringElement(WiringPoint[] points)
/*    */   {
/* 18 */     this.points = points;
/*    */   }
/*    */ 
/*    */   public WiringPoint[] getPoints()
/*    */   {
/* 23 */     return this.points;
/*    */   }
/*    */ }