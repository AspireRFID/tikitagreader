/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ import com.tikitag.ons.TikitagException;
/*    */ 
/*    */ public class WiringException extends TikitagException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public WiringException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public WiringException(String message, Throwable cause)
/*    */   {
/* 28 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public WiringException(String message)
/*    */   {
/* 35 */     super(message);
/*    */   }
/*    */ 
/*    */   public WiringException(Throwable cause)
/*    */   {
/* 42 */     super(cause);
/*    */   }
/*    */ }