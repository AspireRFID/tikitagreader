/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ 
/*    */ public class Wire extends AbstractWiringElement
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private URN resourceName;
/*    */ 
/*    */   public Wire(String refAsString)
/*    */   {
/* 21 */     this(refAsString, new WiringPoint[0]);
/*    */   }
/*    */ 
/*    */   public Wire(String resourceNameAsText, WiringPoint point) {
/* 25 */     this(resourceNameAsText, new WiringPoint[] { point });
/*    */   }
/*    */ 
/*    */   public Wire(String resourceNameAsText, WiringPoint[] points) {
/* 29 */     super(points);
/* 30 */     this.resourceName = new URN(resourceNameAsText);
/*    */   }
/*    */ 
/*    */   public Wire(URN resourceName) {
/* 34 */     this(resourceName, new WiringPoint[0]);
/*    */   }
/*    */ 
/*    */   public Wire(URN resourceName, WiringPoint[] points) {
/* 38 */     super(points);
/* 39 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public Wire(URN resourceName, WiringPoint point) {
/* 43 */     super(new WiringPoint[] { point });
/* 44 */     this.resourceName = resourceName;
/*    */   }
/*    */ 
/*    */   public URN getURN() {
/* 48 */     return this.resourceName;
/*    */   }
/*    */ 
/*    */   public URN getBlockURN() {
/* 52 */     String opaque = this.resourceName.getValue();
/* 53 */     int index = opaque.lastIndexOf(":");
/* 54 */     return new URN(opaque.substring(0, index));
/*    */   }
/*    */ }