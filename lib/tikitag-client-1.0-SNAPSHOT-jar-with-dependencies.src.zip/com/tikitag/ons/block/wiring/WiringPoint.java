package com.tikitag.ons.block.wiring;

import java.io.Serializable;

public abstract interface WiringPoint extends Serializable
{
  public abstract WiringPoint[] getPoints();
}