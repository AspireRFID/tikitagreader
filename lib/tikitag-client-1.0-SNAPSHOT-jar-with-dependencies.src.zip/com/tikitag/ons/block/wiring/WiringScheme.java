/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ import java.io.Serializable;
/*    */ import java.util.HashMap;
/*    */ import java.util.Iterator;
/*    */ import java.util.Map;
/*    */ import java.util.Set;
/*    */ 
/*    */ public class WiringScheme
/*    */   implements Serializable, Iterable<String>
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Map<String, Wire> wireMap;
/*    */ 
/*    */   public WiringScheme()
/*    */   {
/* 20 */     this.wireMap = new HashMap(); }
/*    */ 
/*    */   public void define(Wire wire) {
/* 23 */     this.wireMap.put("default", wire);
/*    */   }
/*    */ 
/*    */   public void define(String actionId, Wire wire) {
/* 27 */     this.wireMap.put(actionId, wire);
/*    */   }
/*    */ 
/*    */   public Iterator<String> iterator()
/*    */   {
/* 32 */     return this.wireMap.keySet().iterator();
/*    */   }
/*    */ 
/*    */   public Wire getWire(String actionId) {
/* 36 */     return ((Wire)this.wireMap.get(actionId));
/*    */   }
/*    */ }