/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ import java.util.AbstractList;
/*    */ 
/*    */ public class WireArray extends AbstractList<Wire>
/*    */   implements WiringPoint
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private Wire[] wires;
/*    */ 
/*    */   public WireArray(Wire[] wires)
/*    */   {
/* 23 */     this.wires = wires;
/*    */   }
/*    */ 
/*    */   public Wire get(int index)
/*    */   {
/* 28 */     return this.wires[index];
/*    */   }
/*    */ 
/*    */   public int size()
/*    */   {
/* 33 */     return this.wires.length;
/*    */   }
/*    */ 
/*    */   public WiringPoint[] getPoints()
/*    */   {
/* 38 */     return this.wires;
/*    */   }
/*    */ }