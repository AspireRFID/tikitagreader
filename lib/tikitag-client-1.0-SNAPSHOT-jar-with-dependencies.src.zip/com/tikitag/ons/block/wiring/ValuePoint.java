/*    */ package com.tikitag.ons.block.wiring;
/*    */ 
/*    */ import com.tikitag.util.ClassMap;
/*    */ import java.net.URI;
/*    */ import java.util.Date;
/*    */ 
/*    */ public class ValuePoint extends AbstractWiringElement
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/* 19 */   private static ClassMap<String> classMap = new ClassMap();
/*    */   private String type;
/*    */   private Object value;
/*    */ 
/*    */   public static ValuePoint valueOf(Object value)
/*    */   {
/* 34 */     String type = (String)classMap.get(value.getClass());
/* 35 */     return new ValuePoint(type, value);
/*    */   }
/*    */ 
/*    */   private ValuePoint(String type, Object value)
/*    */   {
/* 42 */     super(new WiringPoint[0]);
/* 43 */     this.type = type;
/* 44 */     this.value = value;
/*    */   }
/*    */ 
/*    */   public Object getValue() {
/* 48 */     return this.value;
/*    */   }
/*    */ 
/*    */   public String getType() {
/* 52 */     return this.type;
/*    */   }
/*    */ 
/*    */   static
/*    */   {
/* 22 */     classMap.put(Byte.class, "xsd:byte");
/* 23 */     classMap.put(Boolean.class, "xsd:boolean");
/* 24 */     classMap.put(Date.class, "xsd:dateTime");
/* 25 */     classMap.put(Double.class, "xsd:double");
/* 26 */     classMap.put(Float.class, "xsd:float");
/* 27 */     classMap.put(Integer.class, "xsd:int");
/* 28 */     classMap.put(Long.class, "xsd:long");
/* 29 */     classMap.put(String.class, "xsd:string");
/* 30 */     classMap.put(URI.class, "xsd:anyURI");
/*    */   }
/*    */ }