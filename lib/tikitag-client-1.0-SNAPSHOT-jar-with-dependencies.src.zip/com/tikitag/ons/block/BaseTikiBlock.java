/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ import com.tikitag.ons.util.CamelCased;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public abstract class BaseTikiBlock
/*    */   implements TikiBlock
/*    */ {
/*    */   protected CamelCased camelCasedName;
/*    */ 
/*    */   public BaseTikiBlock(String name)
/*    */   {
/* 18 */     this.camelCasedName = new CamelCased(name);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 22 */     return this.camelCasedName.toString();
/*    */   }
/*    */ 
/*    */   public URN toURN()
/*    */   {
/* 27 */     return new URN("urn:tiki:block:" + this.camelCasedName.asDashSeparated());
/*    */   }
/*    */ 
/*    */   protected List<TikitagActionProvider> singleProvider(TikitagActionProvider provider) {
/* 31 */     List providers = new ArrayList();
/* 32 */     providers.add(provider);
/* 33 */     return providers;
/*    */   }
/*    */ }