/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.ActionAndMemento;
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.BasicMemento;
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.block.actioncontext.UrlActionContext;
/*    */ import com.tikitag.ons.block.local.UrlBlockFacade;
/*    */ import com.tikitag.ons.block.mx.GenericMIF;
/*    */ import com.tikitag.ons.block.remote.UrlBlock;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import java.util.List;
/*    */ import org.jboss.annotation.ejb.Depends;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.block:name=Url")
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/Url/local")
/*    */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*    */ public class UrlBlockService extends AbstractBlockService
/*    */   implements UrlBlockFacade, UrlBlock, GenericMIF
/*    */ {
/*    */   protected static final String NAME = "Url";
/*    */ 
/*    */   public UrlBlockService()
/*    */   {
/* 28 */     super("Url");
/*    */   }
/*    */ 
/*    */   public List<TikitagActionProvider> getTikitagActionProviders()
/*    */   {
/* 33 */     return singleProvider(new UrlProvider(null));
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento launch(String url)
/*    */   {
/* 38 */     return new UrlMemento(url);
/*    */   }
/*    */ 
/*    */   private class UrlProvider
/*    */     implements TikitagActionProvider
/*    */   {
/*    */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*    */     {
/* 61 */       String url = ((UrlBlockService.UrlMemento)memento).getUrl();
/* 62 */       return new ActionAndMemento(new UrlActionContext(url).getActionContext(), memento);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class UrlMemento extends BasicMemento
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     private final String url;
/*    */ 
/*    */     public UrlMemento(String url)
/*    */     {
/* 49 */       super(UrlBlockService.UrlProvider.class);
/* 50 */       this.url = url;
/*    */     }
/*    */ 
/*    */     public String getUrl() {
/* 54 */       return this.url;
/*    */     }
/*    */   }
/*    */ }