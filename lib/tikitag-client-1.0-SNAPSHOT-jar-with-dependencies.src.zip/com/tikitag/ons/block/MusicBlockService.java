/*     */ package com.tikitag.ons.block;
/*     */ 
/*     */ import com.tikitag.ons.ActionAndMemento;
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.BasicMemento;
/*     */ import com.tikitag.ons.TikitagActionProvider;
/*     */ import com.tikitag.ons.block.actioncontext.MusicActionContext;
/*     */ import com.tikitag.ons.block.actioncontext.MusicCommand;
/*     */ import com.tikitag.ons.block.local.MusicBlockFacade;
/*     */ import com.tikitag.ons.block.mx.GenericMIF;
/*     */ import com.tikitag.ons.block.remote.MusicBlock;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import java.util.List;
/*     */ import org.jboss.annotation.ejb.Depends;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ 
/*     */ @Service(objectName="tikitag.block:name=Music")
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/Music/local")
/*     */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*     */ public class MusicBlockService extends AbstractBlockService
/*     */   implements MusicBlockFacade, MusicBlock, GenericMIF
/*     */ {
/*     */   protected static final String NAME = "Music";
/*     */ 
/*     */   public MusicBlockService()
/*     */   {
/*  29 */     super("Music");
/*     */   }
/*     */ 
/*     */   public List<TikitagActionProvider> getTikitagActionProviders()
/*     */   {
/*  34 */     return singleProvider(new MusicProvider(null));
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento playFile(String fileName) {
/*  38 */     return new MusicMemento(MusicCommand.PLAY_FILE, fileName);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento openUrl(String url) {
/*  42 */     return new MusicMemento(MusicCommand.OPEN_URL, url);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento playPause() {
/*  46 */     return new MusicMemento(MusicCommand.PLAY_PAUSE);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento stopPlay() {
/*  50 */     return new MusicMemento(MusicCommand.STOP);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento fastForward() {
/*  54 */     return new MusicMemento(MusicCommand.FAST_FORWARD);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento rewind() {
/*  58 */     return new MusicMemento(MusicCommand.REWIND);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento nextTrack() {
/*  62 */     return new MusicMemento(MusicCommand.NEXT_TRACK);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento previousTrack() {
/*  66 */     return new MusicMemento(MusicCommand.PREVIOUS_TRACK);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento volumeUp() {
/*  70 */     return new MusicMemento(MusicCommand.VOLUME_UP);
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento volumeDown() {
/*  74 */     return new MusicMemento(MusicCommand.VOLUME_DOWN);
/*     */   }
/*     */ 
/*     */   private class MusicProvider
/*     */     implements TikitagActionProvider
/*     */   {
/*     */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*     */     {
/* 108 */       MusicBlockService.MusicMemento musicMemento = (MusicBlockService.MusicMemento)memento;
/* 109 */       MusicActionContext musicCtx = new MusicActionContext(musicMemento.getCommand(), musicMemento.getResourceId());
/* 110 */       return new ActionAndMemento(musicCtx.getActionContext(), memento);
/*     */     }
/*     */   }
/*     */ 
/*     */   private static class MusicMemento extends BasicMemento
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     private final MusicCommand command;
/*     */     private final String resourceId;
/*     */ 
/*     */     public MusicMemento(MusicCommand command)
/*     */     {
/*  86 */       this(command, null);
/*     */     }
/*     */ 
/*     */     public MusicMemento(MusicCommand command, String resourceId) {
/*  90 */       super(MusicBlockService.MusicProvider.class);
/*  91 */       this.command = command;
/*  92 */       this.resourceId = resourceId;
/*     */     }
/*     */ 
/*     */     public MusicCommand getCommand() {
/*  96 */       return this.command;
/*     */     }
/*     */ 
/*     */     public String getResourceId() {
/* 100 */       return this.resourceId;
/*     */     }
/*     */   }
/*     */ }