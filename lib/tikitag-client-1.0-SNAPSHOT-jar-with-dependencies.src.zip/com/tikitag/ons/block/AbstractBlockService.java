/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*    */ import javax.ejb.EJB;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ public abstract class AbstractBlockService extends BaseTikiBlock
/*    */ {
/* 18 */   private final Logger log = Logger.getLogger(AbstractBlockService.class);
/*    */ 
/*    */   @EJB
/*    */   ActionProviderCatalog actionProviderCatalog;
/*    */ 
/*    */   public AbstractBlockService(String name) { super(name);
/*    */   }
/*    */ 
/*    */   public void start()
/*    */     throws Exception
/*    */   {
/* 28 */     for (TikitagActionProvider provider : getTikitagActionProviders()) {
/* 29 */       this.actionProviderCatalog.register(provider);
/*    */     }
/* 31 */     this.log.info("Registered action providers.");
/*    */   }
/*    */ 
/*    */   public void stop()
/*    */   {
/*    */   }
/*    */ }