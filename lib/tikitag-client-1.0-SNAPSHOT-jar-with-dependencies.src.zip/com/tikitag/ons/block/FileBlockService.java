/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.ActionAndMemento;
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.BasicMemento;
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.block.actioncontext.FileActionContext;
/*    */ import com.tikitag.ons.block.local.FileBlockFacade;
/*    */ import com.tikitag.ons.block.mx.GenericMIF;
/*    */ import com.tikitag.ons.block.remote.FileBlock;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import java.util.List;
/*    */ import org.jboss.annotation.ejb.Depends;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.block:name=File")
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/File/local")
/*    */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*    */ public class FileBlockService extends AbstractBlockService
/*    */   implements FileBlock, FileBlockFacade, GenericMIF
/*    */ {
/*    */   protected static final String NAME = "File";
/*    */ 
/*    */   public FileBlockService()
/*    */   {
/* 28 */     super("File");
/*    */   }
/*    */ 
/*    */   public List<TikitagActionProvider> getTikitagActionProviders()
/*    */   {
/* 33 */     return singleProvider(new FileProvider(null));
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento launch(String file)
/*    */   {
/* 38 */     return new FileMemento(file);
/*    */   }
/*    */ 
/*    */   private class FileProvider
/*    */     implements TikitagActionProvider
/*    */   {
/*    */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*    */     {
/* 61 */       String file = ((FileBlockService.FileMemento)memento).getFile();
/* 62 */       return new ActionAndMemento(new FileActionContext(file).getActionContext(), memento);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class FileMemento extends BasicMemento
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     private final String file;
/*    */ 
/*    */     public FileMemento(String file)
/*    */     {
/* 49 */       super(FileBlockService.FileProvider.class);
/* 50 */       this.file = file;
/*    */     }
/*    */ 
/*    */     public String getFile() {
/* 54 */       return this.file;
/*    */     }
/*    */   }
/*    */ }