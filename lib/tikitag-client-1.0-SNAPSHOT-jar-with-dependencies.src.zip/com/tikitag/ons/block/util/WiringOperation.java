/*    */ package com.tikitag.ons.block.util;
/*    */ 
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.block.TikiBlock;
/*    */ import com.tikitag.ons.block.wiring.WiringException;
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ import com.tikitag.ons.util.CamelCased;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class WiringOperation
/*    */ {
/*    */   private TikiBlock block;
/*    */   private String name;
/*    */   private String info;
/*    */   private Class<?>[] parameterTypes;
/*    */   private String[] parameterInfos;
/*    */ 
/*    */   public WiringOperation(TikiBlock block, String name, String info, Class<?>[] parameterTypes, String[] parameterInfos)
/*    */   {
/* 29 */     this.block = block;
/* 30 */     this.name = name;
/* 31 */     this.info = info;
/* 32 */     this.parameterTypes = parameterTypes;
/* 33 */     this.parameterInfos = parameterInfos;
/*    */   }
/*    */ 
/*    */   public TikiBlock getBlock() {
/* 37 */     return this.block;
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 41 */     return this.name;
/*    */   }
/*    */ 
/*    */   public String getInfo() {
/* 45 */     return this.info;
/*    */   }
/*    */ 
/*    */   public Class<?>[] getParameterTypes() {
/* 49 */     return this.parameterTypes;
/*    */   }
/*    */ 
/*    */   public String[] getParameterInfos() {
/* 53 */     return this.parameterInfos;
/*    */   }
/*    */ 
/*    */   public URN getURN() {
/* 57 */     return new URN(this.block.toURN().toString() + ":" + CamelCased.toDashSeparated(this.name));
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento invoke(Object[] args) throws WiringException {
/*    */     try {
/* 62 */       Method method = this.block.getClass().getMethod(this.name, this.parameterTypes);
/*    */ 
/* 69 */       return ((ActionProviderMemento)method.invoke(this.block, args));
/*    */     } catch (Exception e) {
/* 71 */       throw new WiringException("WiringScheme operation '" + this.name + "' failed!", e);
/*    */     }
/*    */   }
/*    */ }