/*    */ package com.tikitag.ons.block.util;
/*    */ 
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.block.TikiBlock;
/*    */ import com.tikitag.ons.util.Info;
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.ejb.Local;
/*    */ import javax.ejb.Remote;
/*    */ import org.apache.commons.lang.Validate;
/*    */ 
/*    */ public class Introspector
/*    */ {
/*    */   public static WiringOperation[] introspect(TikiBlock block)
/*    */   {
/* 25 */     Validate.notNull(block, "block is mandatory");
/*    */ 
/* 27 */     List result = new ArrayList();
/* 28 */     Method[] methods = block.getClass().getMethods();
/* 29 */     Class remoteInterface = resolveRemoteInterface(block.getClass());
/* 30 */     if (remoteInterface == null)
/* 31 */       throw new RuntimeException("Expected a remote interface!");
/* 32 */     methods = remoteInterface.getDeclaredMethods();
/* 33 */     for (Method method : methods) {
/* 34 */       if (method.getReturnType().equals(ActionProviderMemento.class)) {
/* 35 */         Info info = (Info)method.getAnnotation(Info.class);
/* 36 */         WiringOperation operation = new WiringOperation(block, method.getName(), (info == null) ? null : info.value(), method.getParameterTypes(), retainParameterAnnotations(method));
/* 37 */         result.add(operation);
/*    */       }
/*    */     }
/* 40 */     return ((WiringOperation[])result.toArray(new WiringOperation[result.size()]));
/*    */   }
/*    */ 
/*    */   public static Class<?> resolveRemoteInterface(Class<?> target) {
/* 44 */     Class[] interfaces = target.getInterfaces();
/* 45 */     for (Class declaredClass : interfaces) {
/* 46 */       if (declaredClass.isInterface()) {
/* 47 */         Local local = (Local)declaredClass.getAnnotation(Local.class);
/* 48 */         if (local != null) {
/* 49 */           Class candidate = resolveRemoteInterface(declaredClass);
/* 50 */           if (candidate != null)
/* 51 */             return candidate;
/*    */         }
/* 53 */         Remote remote = (Remote)declaredClass.getAnnotation(Remote.class);
/* 54 */         if (remote != null) {
/* 55 */           return declaredClass;
/*    */         }
/*    */       }
/*    */     }
/* 59 */     return null;
/*    */   }
/*    */ 
/*    */   private static String[] retainParameterAnnotations(Method method) {
/* 63 */     List infoList = new ArrayList();
/* 64 */     Annotation[][] allAnnotations = method.getParameterAnnotations();
/* 65 */     for (Annotation[] annotations : allAnnotations)
/* 66 */       infoList.add(firstInfo(annotations));
/* 67 */     return ((String[])infoList.toArray(new String[infoList.size()]));
/*    */   }
/*    */ 
/*    */   private static String firstInfo(Annotation[] annotations) {
/* 71 */     if (annotations != null) {
/* 72 */       for (Annotation annotation : annotations)
/* 73 */         if (annotation instanceof Info) {
/* 74 */           Info info = (Info)annotation;
/* 75 */           return info.value();
/*    */         }
/*    */     }
/* 78 */     return null;
/*    */   }
/*    */ }