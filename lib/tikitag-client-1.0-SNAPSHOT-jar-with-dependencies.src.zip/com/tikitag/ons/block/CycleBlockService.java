/*    */ package com.tikitag.ons.block;
/*    */ 
/*    */ import com.tikitag.ons.ActionAndMemento;
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.BasicMemento;
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.block.local.CycleBlockFacade;
/*    */ import com.tikitag.ons.block.mx.GenericMIF;
/*    */ import com.tikitag.ons.block.remote.CycleBlock;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*    */ import java.util.List;
/*    */ import org.jboss.annotation.ejb.Depends;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.block:name=Cycle")
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Block/Cycle/local")
/*    */ @Depends({"tikitag:service=ActionProviderCatalog"})
/*    */ public class CycleBlockService extends AbstractBlockService
/*    */   implements CycleBlockFacade, CycleBlock, GenericMIF
/*    */ {
/*    */   protected static final String NAME = "Cycle";
/*    */ 
/*    */   public CycleBlockService()
/*    */   {
/* 27 */     super("Cycle");
/*    */   }
/*    */ 
/*    */   public List<TikitagActionProvider> getTikitagActionProviders()
/*    */   {
/* 32 */     return singleProvider(new CycleProvider(null));
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento cycle(ActionProviderMemento[] elements) {
/* 36 */     return new CycleMemento(elements);
/*    */   }
/*    */ 
/*    */   private class CycleProvider
/*    */     implements TikitagActionProvider
/*    */   {
/*    */     public ActionAndMemento getTikitagAction(TagEvent tagEvent, ActionProviderMemento memento)
/*    */     {
/* 77 */       CycleBlockService.CycleMemento cycleMemento = (CycleBlockService.CycleMemento)memento;
/* 78 */       ActionProviderMemento targetMemento = cycleMemento.getCurrentElement();
/*    */ 
/* 81 */       ActionAndMemento targetActionAndMemento = CycleBlockService.this.actionProviderCatalog.invokeActionProvider(targetMemento, tagEvent);
/*    */ 
/* 84 */       cycleMemento.updateCurrentElement(targetActionAndMemento.getMemento());
/* 85 */       cycleMemento.incrementIndex();
/*    */ 
/* 87 */       return new ActionAndMemento(targetActionAndMemento.getAction(), cycleMemento);
/*    */     }
/*    */   }
/*    */ 
/*    */   private static class CycleMemento extends BasicMemento
/*    */   {
/*    */     private static final long serialVersionUID = 1L;
/*    */     private ActionProviderMemento[] elements;
/*    */     private int currentIndex;
/*    */ 
/*    */     public CycleMemento(ActionProviderMemento[] elements)
/*    */     {
/* 48 */       super(CycleBlockService.CycleProvider.class);
/* 49 */       if ((elements == null) || (elements.length == 0)) {
/* 50 */         throw new IllegalArgumentException("Elements should contain at least 1 element !");
/*    */       }
/* 52 */       this.elements = ((ActionProviderMemento[])elements.clone());
/* 53 */       this.currentIndex = 0;
/*    */     }
/*    */ 
/*    */     public ActionProviderMemento getCurrentElement() {
/* 57 */       return this.elements[this.currentIndex];
/*    */     }
/*    */ 
/*    */     public void updateCurrentElement(ActionProviderMemento memento) {
/* 61 */       this.elements[this.currentIndex] = memento;
/*    */     }
/*    */ 
/*    */     public void incrementIndex() {
/* 65 */       this.currentIndex += 1;
/* 66 */       if (this.currentIndex >= this.elements.length)
/* 67 */         this.currentIndex = 0;
/*    */     }
/*    */   }
/*    */ }