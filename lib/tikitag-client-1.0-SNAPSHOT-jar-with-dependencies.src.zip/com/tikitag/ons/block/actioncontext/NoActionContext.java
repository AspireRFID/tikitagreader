/*    */ package com.tikitag.ons.block.actioncontext;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class NoActionContext
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   public static final String APPLICATION_ID = "tikitag.standard.noaction";
/*    */ 
/*    */   public static NoActionContext fromActionContext(ConfigContainer context)
/*    */   {
/*    */     try
/*    */     {
/* 18 */       if (context.getName().equals("tikitag.standard.noaction")) {
/* 19 */         ConfigContainer ctx = context.getContainer("v1.0");
/* 20 */         if (ctx == null) {
/* 21 */           throw new NullPointerException("Could not find v1.0 context");
/*    */         }
/* 23 */         return new NoActionContext();
/*    */       }
/* 25 */       throw new IllegalArgumentException("Expecting a context identified by tikitag.standard.noaction, but found " + context.getName() + " instead");
/*    */     }
/*    */     catch (NullPointerException e) {
/* 28 */       throw new RuntimeException("Could not process ActionContext", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ConfigContainer getActionContext() {
/* 33 */     return new ConfigContainer("tikitag.standard.noaction").set(new ConfigContainer("v1.0"));
/*    */   }
/*    */ }