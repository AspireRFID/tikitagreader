/*    */ package com.tikitag.ons.block.actioncontext;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigAttribute;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class TagManagementActionContext
/*    */ {
/*    */   public static final String APPLICATION_ID = "tikitag.standard.tagManagement";
/*    */   private String message;
/*    */ 
/*    */   public TagManagementActionContext(String message)
/*    */   {
/* 12 */     this.message = message;
/*    */   }
/*    */ 
/*    */   public static TagManagementActionContext fromActionContext(ConfigContainer context) {
/*    */     try {
/* 17 */       if (context.getName().equals("tikitag.standard.tagManagement")) {
/* 18 */         ConfigContainer ctx = context.getContainer("v1.0");
/* 19 */         return new TagManagementActionContext(ctx.getAttribute("message").asString());
/*    */       }
/* 21 */       throw new IllegalArgumentException("Expecting a context identified by tikitag.standard.tagManagement, but found " + context.getName() + " instead");
/*    */     }
/*    */     catch (NullPointerException e) {
/* 24 */       throw new RuntimeException("Could not process ActionContext", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ConfigContainer getActionContext() {
/* 29 */     return new ConfigContainer("tikitag.standard.tagManagement").set(new ConfigContainer("v1.0").set(new ConfigAttribute("message", this.message)));
/*    */   }
/*    */ 
/*    */   public String getMessage()
/*    */   {
/* 36 */     return this.message;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 41 */     int prime = 31;
/* 42 */     int result = 1;
/* 43 */     result = 31 * result + ((this.message == null) ? 0 : this.message.hashCode());
/* 44 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 49 */     if (this == obj)
/* 50 */       return true;
/* 51 */     if (obj == null)
/* 52 */       return false;
/* 53 */     if (!(obj instanceof TagManagementActionContext))
/* 54 */       return false;
/* 55 */     TagManagementActionContext other = (TagManagementActionContext)obj;
/* 56 */     if (this.message == null) {
/* 57 */       if (other.message == null) break label59;
/* 58 */       return false;
/*    */     }
/* 60 */     label59: return (!(this.message.equals(other.message)));
/*    */   }
/*    */ }