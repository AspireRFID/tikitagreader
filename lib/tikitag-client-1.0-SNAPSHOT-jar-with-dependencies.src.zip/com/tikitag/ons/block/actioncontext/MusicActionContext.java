/*    */ package com.tikitag.ons.block.actioncontext;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigAttribute;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class MusicActionContext
/*    */ {
/*    */   public static final String APPLICATION_ID = "tikitag.standard.music";
/*    */   private MusicCommand command;
/*    */   private String resource;
/*    */ 
/*    */   public MusicActionContext(MusicCommand command, String resource)
/*    */   {
/* 13 */     this.command = command;
/* 14 */     this.resource = resource;
/*    */   }
/*    */ 
/*    */   public static MusicActionContext fromActionContext(ConfigContainer context) {
/*    */     try {
/* 19 */       if (context.getName().equals("tikitag.standard.music")) {
/* 20 */         ConfigContainer ctx = context.getContainer("v1.0");
/* 21 */         MusicCommand musicCommand = MusicCommand.valueOf(ctx.getAttribute("command").asString());
/* 22 */         String resource = ctx.getAttribute("resource").asString();
/* 23 */         return new MusicActionContext(musicCommand, resource);
/*    */       }
/* 25 */       throw new IllegalArgumentException("Expecting a context identified by tikitag.standard.music, but found " + context.getName() + " instead");
/*    */     }
/*    */     catch (NullPointerException e) {
/* 28 */       throw new RuntimeException("Could not process ActionContext", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ConfigContainer getActionContext() {
/* 33 */     return new ConfigContainer("tikitag.standard.music").set(new ConfigContainer("v1.0").set(new ConfigAttribute("command", this.command.name())).set(new ConfigAttribute("resource", this.resource)));
/*    */   }
/*    */ 
/*    */   public MusicCommand getCommand()
/*    */   {
/* 40 */     return this.command;
/*    */   }
/*    */ 
/*    */   public String getResource() {
/* 44 */     return this.resource;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 49 */     int prime = 31;
/* 50 */     int result = 1;
/* 51 */     result = 31 * result + ((this.command == null) ? 0 : this.command.hashCode());
/* 52 */     result = 31 * result + ((this.resource == null) ? 0 : this.resource.hashCode());
/* 53 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 58 */     if (this == obj)
/* 59 */       return true;
/* 60 */     if (obj == null)
/* 61 */       return false;
/* 62 */     if (!(obj instanceof MusicActionContext))
/* 63 */       return false;
/* 64 */     MusicActionContext other = (MusicActionContext)obj;
/* 65 */     if (this.command == null) {
/* 66 */       if (other.command == null) break label59;
/* 67 */       return false; }
/* 68 */     if (!(this.command.equals(other.command)))
/* 69 */       return false;
/* 70 */     if (this.resource == null) {
/* 71 */       label59: if (other.resource == null) break label91;
/* 72 */       return false;
/*    */     }
/* 74 */     label91: return (!(this.resource.equals(other.resource)));
/*    */   }
/*    */ }