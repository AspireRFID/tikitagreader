/*    */ package com.tikitag.ons.block.actioncontext;
/*    */ 
/*    */ public enum MusicCommand
/*    */ {
/*  4 */   PLAY_FILE, OPEN_URL, STOP, PLAY_PAUSE, NEXT_TRACK, PREVIOUS_TRACK, REWIND, FAST_FORWARD, VOLUME_UP, VOLUME_DOWN;
/*    */ 
/*    */   private boolean resourceRequired;
/*    */ 
/*    */   public boolean isResourceRequired()
/*    */   {
/* 26 */     return this.resourceRequired;
/*    */   }
/*    */ }