/*    */ package com.tikitag.ons.block.actioncontext;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigAttribute;
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ 
/*    */ public class FileActionContext
/*    */ {
/*    */   public static final String APPLICATION_ID = "tikitag.standard.file";
/*    */   private String file;
/*    */ 
/*    */   public FileActionContext(String file)
/*    */   {
/* 13 */     this.file = file;
/*    */   }
/*    */ 
/*    */   public static FileActionContext fromActionContext(ConfigContainer context) {
/*    */     try {
/* 18 */       if (context.getName().equals("tikitag.standard.file")) {
/* 19 */         ConfigContainer ctx = context.getContainer("v1.0");
/* 20 */         return new FileActionContext(ctx.getAttribute("file").asString());
/*    */       }
/* 22 */       throw new IllegalArgumentException("Expecting a context identified by tikitag.standard.file, but found " + context.getName() + " instead");
/*    */     }
/*    */     catch (NullPointerException e) {
/* 25 */       throw new RuntimeException("Could not process ActionContext", e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public ConfigContainer getActionContext() {
/* 30 */     return new ConfigContainer("tikitag.standard.file").set(new ConfigContainer("v1.0").set(new ConfigAttribute("file", this.file)));
/*    */   }
/*    */ 
/*    */   public String getFile()
/*    */   {
/* 37 */     return this.file;
/*    */   }
/*    */ 
/*    */   public int hashCode()
/*    */   {
/* 42 */     int prime = 31;
/* 43 */     int result = 1;
/* 44 */     result = 31 * result + ((this.file == null) ? 0 : this.file.hashCode());
/* 45 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean equals(Object obj)
/*    */   {
/* 50 */     if (this == obj)
/* 51 */       return true;
/* 52 */     if (obj == null)
/* 53 */       return false;
/* 54 */     if (!(obj instanceof FileActionContext))
/* 55 */       return false;
/* 56 */     FileActionContext other = (FileActionContext)obj;
/* 57 */     if (this.file == null) {
/* 58 */       if (other.file == null) break label59;
/* 59 */       return false;
/*    */     }
/* 61 */     label59: return (!(this.file.equals(other.file)));
/*    */   }
/*    */ }