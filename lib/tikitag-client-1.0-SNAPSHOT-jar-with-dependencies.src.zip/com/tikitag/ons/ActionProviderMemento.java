package com.tikitag.ons;

import java.io.Serializable;

public abstract interface ActionProviderMemento extends Serializable
{
  public abstract Class<? extends TikitagActionProvider> getActionProviderClass();
}