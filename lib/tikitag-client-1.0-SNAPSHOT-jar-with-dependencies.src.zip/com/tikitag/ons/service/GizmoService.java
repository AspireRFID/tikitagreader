/*    */ package com.tikitag.ons.service;
/*    */ 
/*    */ import com.tikitag.ons.service.mx.GizmoMIF;
/*    */ import java.io.PrintWriter;
/*    */ import java.io.StringWriter;
/*    */ import java.util.Arrays;
/*    */ import java.util.Iterator;
/*    */ import java.util.List;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.PersistenceContext;
/*    */ import javax.persistence.Query;
/*    */ import org.jboss.annotation.ejb.Management;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag:service=Gizmo")
/*    */ @Management(GizmoMIF.class)
/*    */ public class GizmoService
/*    */   implements GizmoMIF
/*    */ {
/*    */ 
/*    */   @PersistenceContext(unitName="tikitag")
/*    */   private EntityManager manager;
/*    */ 
/*    */   public String executeQuery(String query)
/*    */   {
/* 34 */     StringBuilder report = new StringBuilder(new StringBuilder().append("Query: ").append(query).append("\n").toString());
/*    */     try {
/* 36 */       List resultList = this.manager.createQuery(query).getResultList();
/* 37 */       int count = 1;
/* 38 */       for (Iterator i$ = resultList.iterator(); i$.hasNext(); ) { Object object = i$.next();
/* 39 */         if ((object != null) && (object instanceof Object[])) {
/* 40 */           object = Arrays.asList((Object[])(Object[])object);
/*    */         }
/* 42 */         report.append(count++);
/* 43 */         report.append(".\t");
/* 44 */         report.append((object == null) ? "<null>" : object.toString());
/* 45 */         report.append("\n");
/*    */       }
/* 47 */       report.append("\t\t");
/* 48 */       report.append(resultList.size());
/* 49 */       report.append(" result(s).\n");
/*    */     } catch (Exception e) {
/* 51 */       report.append("\n");
/* 52 */       StringWriter writer = new StringWriter();
/* 53 */       e.printStackTrace(new PrintWriter(writer));
/* 54 */       report.append(writer.getBuffer());
/*    */     }
/* 56 */     return report.toString();
/*    */   }
/*    */ 
/*    */   public String executeUpdate(String update)
/*    */   {
/* 63 */     StringBuilder report = new StringBuilder(new StringBuilder().append("Query: ").append(update).append("\n").toString());
/*    */     try {
/* 65 */       int count = this.manager.createQuery(update).executeUpdate();
/* 66 */       report.append(new StringBuilder().append("\n ").append(count).append(" entities updated.\n").toString());
/*    */     } catch (Exception e) {
/* 68 */       report.append("\n");
/* 69 */       StringWriter writer = new StringWriter();
/* 70 */       e.printStackTrace(new PrintWriter(writer));
/* 71 */       report.append(writer.getBuffer());
/*    */     }
/* 73 */     return report.toString();
/*    */   }
/*    */ }