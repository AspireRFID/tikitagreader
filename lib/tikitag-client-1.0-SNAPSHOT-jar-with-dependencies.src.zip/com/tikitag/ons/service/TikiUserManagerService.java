/*     */ package com.tikitag.ons.service;
/*     */ 
/*     */ import com.tikitag.ons.model.TikiUser;
/*     */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*     */ import com.tikitag.ons.service.mx.TikiUserManagerMIF;
/*     */ import com.tikitag.ons.service.util.NaiveSecurityServer;
/*     */ import com.tikitag.ons.service.util.SecurityResolver;
/*     */ import com.tikitag.ons.service.util.TikiUserContentProvider;
/*     */ import com.tikitag.util.DelegatingContentProvider;
/*     */ import com.tikitag.util.TreeString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import javax.ejb.EJB;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ 
/*     */ @Service(objectName="tikitag:service=Manager,type=TikiUser")
/*     */ public class TikiUserManagerService
/*     */   implements TikiUserManagerMIF, SecurityResolver
/*     */ {
/*  31 */   private static final Logger log = Logger.getLogger(TikiUserManagerService.class);
/*     */   private Thread serverThread;
/*     */   private NaiveSecurityServer server;
/*     */   private volatile boolean promiscuous;
/*     */ 
/*     */   @EJB
/*     */   TikiUserRepository userRepo;
/*     */ 
/*     */   public TikiUserManagerService()
/*     */   {
/*  35 */     this.promiscuous = false;
/*     */   }
/*     */ 
/*     */   public void create(String handle, String userName, String password, String[] roles, String email)
/*     */   {
/*  42 */     TikiUser user = new TikiUser(handle, userName, password.getBytes(), roles, email);
/*  43 */     this.userRepo.saveOrUpdate(user);
/*     */   }
/*     */ 
/*     */   public void delete(String userName)
/*     */   {
/*  48 */     TikiUser victim = this.userRepo.findByUserName(userName);
/*  49 */     if (victim != null)
/*  50 */       this.userRepo.delete(victim);
/*     */     else
/*  52 */       throw new RuntimeException(new StringBuilder().append("Could not find user with name '").append(userName).append("'!").toString());
/*     */   }
/*     */ 
/*     */   public String showAllUsers()
/*     */   {
/*  57 */     List tikiUserList = this.userRepo.findAll();
/*  58 */     DelegatingContentProvider contentProvider = new DelegatingContentProvider();
/*  59 */     contentProvider.register(TikiUser.class, new TikiUserContentProvider());
/*  60 */     TreeString treeString = new TreeString(contentProvider);
/*  61 */     return treeString.convert(tikiUserList);
/*     */   }
/*     */ 
/*     */   public String[] getUsers()
/*     */   {
/*  66 */     List result = new ArrayList();
/*  67 */     List userList = this.userRepo.findAll();
/*  68 */     for (TikiUser user : userList)
/*  69 */       result.add(new StringBuilder().append(user.getUserName()).append("(").append(user.getHandle()).append(")").toString());
/*  70 */     return ((String[])result.toArray(new String[result.size()]));
/*     */   }
/*     */ 
/*     */   public void setRoles(String userName, String roles)
/*     */   {
/*  75 */     TikiUser target = this.userRepo.findByUserName(userName);
/*  76 */     if (target != null) {
/*  77 */       target.setRoleStanza(roles);
/*  78 */       this.userRepo.saveOrUpdate(target);
/*     */     }
/*     */     else {
/*  81 */       throw new RuntimeException(new StringBuilder().append("Could not find user with name '").append(userName).append("'!").toString());
/*     */     }
/*     */   }
/*     */ 
/*     */   public String provision() {
/*  86 */     StringBuilder report = new StringBuilder("Provisioning users:\n");
/*  87 */     add("Zebulon Cardozo", "zcardozo", report);
/*  88 */     add("Donnie Darko", "ddarko", report);
/*  89 */     return report.toString();
/*     */   }
/*     */ 
/*     */   private void add(String handle, String userName, StringBuilder report)
/*     */   {
/* 100 */     TikiUser user = null;
/* 101 */     byte[] naivePassword = "tikitag".getBytes();
/*     */     try {
/* 103 */       user = new TikiUser(handle, userName, naivePassword, new String[] { "tiki:admin", "tiki:user" }, null);
/* 104 */       this.userRepo.saveOrUpdate(user);
/* 105 */       report.append(new StringBuilder().append(" - ").append(user.getHandle()).append("\n").toString());
/*     */     } catch (Exception e) {
/* 107 */       report.append("Couldn't store user!");
/* 108 */       if (user != null)
/* 109 */         report.append(new StringBuilder().append(" Problem with '").append(user.getHandle()).append("'!").toString());
/* 110 */       report.append("\n");
/*     */     }
/*     */   }
/*     */ 
/*     */   public String unprovision()
/*     */   {
/* 117 */     return null;
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 123 */     log.info(new StringBuilder().append("Tikitag Usurper ready! (").append(this.userRepo.getUsurper().getId()).append(")").toString());
/* 124 */     log.info(new StringBuilder().append("Tikitag Gimp ready! (").append(this.userRepo.getGimp().getId()).append(")").toString());
/* 125 */     log.info(new StringBuilder().append("Tikitag Drupal ready! (").append(this.userRepo.getDrupal().getId()).append(")").toString());
/* 126 */     this.server = new NaiveSecurityServer(this);
/* 127 */     this.serverThread = new Thread(this.server, "NaiveSecurityServer");
/* 128 */     this.serverThread.start();
/* 129 */     log.info("Naive Security Server started!");
/*     */   }
/*     */ 
/*     */   public void stop()
/*     */   {
/* 134 */     this.server.stop();
/* 135 */     this.serverThread.interrupt();
/*     */   }
/*     */ 
/*     */   public boolean getPromiscuous()
/*     */   {
/* 140 */     return this.promiscuous;
/*     */   }
/*     */ 
/*     */   public void setPromiscuous(boolean promiscuous)
/*     */   {
/* 145 */     this.promiscuous = promiscuous;
/*     */   }
/*     */ 
/*     */   public String[] resolveRoles(String userName, byte[] password) throws SecurityException
/*     */   {
/* 150 */     if (this.promiscuous)
/* 151 */       return new String[] { "PROMISCUOUS", "tiki:admin" };
/* 152 */     TikiUser user = this.userRepo.findByUserName(userName);
/* 153 */     if ((user != null) && (Arrays.equals(password, user.getPassword()))) {
/* 154 */       return user.roles();
/*     */     }
/* 156 */     throw new SecurityException("Authentication failure!");
/*     */   }
/*     */ }