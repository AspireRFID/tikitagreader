package com.tikitag.ons.service.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface ActionProviderCatalogMIF
{
}