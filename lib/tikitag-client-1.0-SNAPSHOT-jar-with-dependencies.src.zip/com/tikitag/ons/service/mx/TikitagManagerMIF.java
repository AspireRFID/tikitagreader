package com.tikitag.ons.service.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface TikitagManagerMIF
{
  public abstract void start()
    throws Exception;

  @Deprecated
  public abstract String provision();

  @Deprecated
  public abstract String unprovision();

  @Deprecated
  public abstract String test(String paramString);

  public abstract String showAllTikits();

  public abstract String[] getBlockURNs();

  public abstract String showAllWiringOperations();

  public abstract String whoami();
}