package com.tikitag.ons.service.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface GizmoMIF
{
  public abstract String executeQuery(String paramString);

  public abstract String executeUpdate(String paramString);
}