package com.tikitag.ons.service.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface TikiUserManagerMIF
{
  public abstract void start()
    throws Exception;

  public abstract void stop();

  public abstract void setPromiscuous(boolean paramBoolean);

  public abstract boolean getPromiscuous();

  public abstract String[] getUsers();

  public abstract String showAllUsers();

  public abstract void delete(String paramString);

  public abstract void create(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString, String paramString4);

  public abstract void setRoles(String paramString1, String paramString2);

  public abstract String provision();

  public abstract String unprovision();
}