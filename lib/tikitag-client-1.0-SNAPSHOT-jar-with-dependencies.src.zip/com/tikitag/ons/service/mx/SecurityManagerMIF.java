package com.tikitag.ons.service.mx;

import com.tikitag.security.Ticket;
import org.jboss.annotation.ejb.Management;

@Management
public abstract interface SecurityManagerMIF extends GenericMIF
{
  public abstract int getTicketExpiration();

  public abstract void setTicketExpiration(int paramInt);

  public abstract String getTicketParameterName();

  public abstract void setTicketParameterName(String paramString);

  public abstract boolean isDirect();

  public abstract void setDirect(boolean paramBoolean);

  public abstract String getEncryptionAlgorithm();

  public abstract void setEncryptionAlgorithm(String paramString);

  public abstract String getSigningAlgorithm();

  public abstract void setSigningAlgorithm(String paramString);

  public abstract boolean isEncrypted();

  public abstract void setEncrypted(boolean paramBoolean);

  public abstract boolean isSigned();

  public abstract void setSigned(boolean paramBoolean);

  public abstract Ticket validate(String paramString);

  public abstract String errorReport(String paramString);
}