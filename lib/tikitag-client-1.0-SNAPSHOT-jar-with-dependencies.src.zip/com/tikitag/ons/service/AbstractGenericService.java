package com.tikitag.ons.service;

import com.tikitag.ons.service.mx.GenericMIF;

public class AbstractGenericService
  implements GenericMIF
{
  public void create()
    throws Exception
  {
  }

  public void destroy()
  {
  }

  public void start()
    throws Exception
  {
  }

  public void stop()
  {
  }
}