/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import com.tikitag.ons.model.Tikit;
/*    */ import com.tikitag.ons.model.util.TikitId;
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TikitContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 11 */     if (object instanceof Tikit) {
/* 12 */       Tikit tikit = (Tikit)object;
/* 13 */       return new StringBuilder().append("Tikit[").append(tikit.getId()).append("]").toString();
/*    */     }
/* 15 */     return object.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 20 */     StringBuilder result = new StringBuilder();
/* 21 */     if ((object instanceof Tikit) && (attribute instanceof Token)) {
/* 22 */       Tikit tikit = (Tikit)object;
/* 23 */       Token tikitAttribute = (Token)attribute;
/* 24 */       result.append(tikitAttribute.getName());
/* 25 */       result.append(" = '");
/* 26 */       switch (1.$SwitchMap$com$tikitag$ons$service$util$TikitContentProvider$Token[tikitAttribute.ordinal()])
/*    */       {
/*    */       case 1:
/* 28 */         result.append(tikit.getName());
/* 29 */         break;
/*    */       case 2:
/* 31 */         TikiUser owner = tikit.getOwner();
/* 32 */         result.append((owner == null) ? "N/A" : new StringBuilder().append(owner.getUserName()).append("(").append(owner.getHandle()).append(")").toString());
/* 33 */         break;
/*    */       case 3:
/* 35 */         result.append(tikit.toId().toURN().getValue());
/*    */       }
/* 37 */       result.append("'");
/*    */     }
/* 39 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 44 */     Object[] result = EMPTY_OBJECT_ARRAY;
/* 45 */     if (object instanceof Tikit) {
/* 46 */       result = new Token[3];
/* 47 */       result[0] = Token.NAME;
/* 48 */       result[1] = Token.OWNER;
/* 49 */       result[2] = Token.URN;
/*    */     }
/* 51 */     return result;
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 56 */     Object[] result = EMPTY_OBJECT_ARRAY;
/* 57 */     if (object instanceof Tikit) {
/* 58 */       Tikit tikit = (Tikit)object;
/* 59 */       result = new Object[3];
/* 60 */       result[0] = tikit.getTemplateRef();
/* 61 */       result[1] = tikit.getTagAssociations();
/* 62 */       result[2] = tikit.getTikiActions();
/*    */     }
/* 64 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 70 */     return (!(object instanceof Tikit));
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 78 */     return (!(object instanceof Tikit));
/*    */   }
/*    */ 
/*    */   private static enum Token
/*    */   {
/* 83 */     URN, NAME, OWNER;
/*    */ 
/*    */     private String name;
/*    */ 
/*    */     public String getName()
/*    */     {
/* 92 */       return this.name;
/*    */     }
/*    */   }
/*    */ }