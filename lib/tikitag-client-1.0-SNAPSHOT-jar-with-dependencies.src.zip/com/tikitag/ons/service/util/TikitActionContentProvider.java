/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TikitAction;
/*    */ import com.tikitag.ons.model.util.URN;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TikitActionContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 11 */     StringBuilder result = new StringBuilder();
/* 12 */     if (object instanceof TikitAction) {
/* 13 */       TikitAction action = (TikitAction)object;
/* 14 */       result.append("TikitAction[");
/* 15 */       result.append(action.getId());
/* 16 */       result.append("]");
/*    */     }
/* 18 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 23 */     StringBuilder result = new StringBuilder();
/* 24 */     if ((object instanceof TikitAction) && (attribute.equals(URN.class))) {
/* 25 */       TikitAction action = (TikitAction)object;
/* 26 */       result.append("URN '");
/* 27 */       result.append(action.toURN().getValue());
/* 28 */       result.append("'");
/*    */     }
/* 30 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 35 */     Object[] result = TreeContentProvider.EMPTY_OBJECT_ARRAY;
/* 36 */     if (object instanceof TikitAction) {
/* 37 */       result = new Object[1];
/* 38 */       result[0] = URN.class;
/*    */     }
/* 40 */     return result;
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 45 */     Object[] result = TreeContentProvider.EMPTY_OBJECT_ARRAY;
/* 46 */     if (object instanceof TikitAction) {
/* 47 */       TikitAction action = (TikitAction)object;
/* 48 */       result = new Object[1];
/* 49 */       result[0] = action.getMemento();
/*    */     }
/* 51 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 56 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 61 */     return true;
/*    */   }
/*    */ }