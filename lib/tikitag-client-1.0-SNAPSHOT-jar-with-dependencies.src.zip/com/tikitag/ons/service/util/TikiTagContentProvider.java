/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiTag;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TikiTagContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 10 */     StringBuilder result = new StringBuilder();
/* 11 */     if (object instanceof TikiTag) {
/* 12 */       TikiTag tag = (TikiTag)object;
/* 13 */       result.append("TikiTag[");
/* 14 */       result.append(tag.getId());
/* 15 */       result.append("]");
/*    */     }
/* 17 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 22 */     StringBuilder result = new StringBuilder();
/* 23 */     if ((object instanceof TikiTag) && (attribute instanceof Token)) {
/* 24 */       TikiTag tag = (TikiTag)object;
/* 25 */       Token tikitAttribute = (Token)attribute;
/* 26 */       result.append(tikitAttribute.getName());
/* 27 */       result.append(" = '");
/* 28 */       switch (1.$SwitchMap$com$tikitag$ons$service$util$TikiTagContentProvider$Token[tikitAttribute.ordinal()])
/*    */       {
/*    */       case 1:
/* 30 */         result.append(tag.getTagId());
/*    */       }
/*    */ 
/* 33 */       result.append("'");
/*    */     }
/* 35 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 40 */     Object[] result = EMPTY_OBJECT_ARRAY;
/* 41 */     if (object instanceof TikiTag) {
/* 42 */       result = new Token[1];
/* 43 */       result[0] = Token.VALUE;
/*    */     }
/* 45 */     return result;
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 50 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 55 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 60 */     return false; }
/*    */ 
/*    */   private static enum Token {
/* 63 */     VALUE;
/*    */ 
/*    */     private String name;
/*    */ 
/*    */     public String getName()
/*    */     {
/* 72 */       return this.name;
/*    */     }
/*    */   }
/*    */ }