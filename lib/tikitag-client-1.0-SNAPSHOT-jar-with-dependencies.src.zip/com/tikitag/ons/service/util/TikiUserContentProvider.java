/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TikiUserContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 15 */     StringBuilder result = new StringBuilder();
/* 16 */     if (object instanceof TikiUser) {
/* 17 */       TikiUser user = (TikiUser)object;
/* 18 */       result.append("TikiUser[");
/* 19 */       result.append(user.getId());
/* 20 */       result.append("]");
/*    */     }
/* 22 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 27 */     StringBuilder result = new StringBuilder();
/* 28 */     if ((object instanceof TikiUser) && (attribute instanceof Token)) {
/* 29 */       TikiUser user = (TikiUser)object;
/* 30 */       Token tikitAttribute = (Token)attribute;
/* 31 */       result.append(tikitAttribute.getName());
/* 32 */       result.append(" = '");
/* 33 */       switch (1.$SwitchMap$com$tikitag$ons$service$util$TikiUserContentProvider$Token[tikitAttribute.ordinal()])
/*    */       {
/*    */       case 1:
/* 35 */         result.append(user.getUserName());
/* 36 */         break;
/*    */       case 2:
/* 38 */         result.append(user.getHandle());
/* 39 */         break;
/*    */       case 3:
/* 41 */         result.append(user.getRoleStanza());
/*    */       }
/*    */ 
/* 44 */       result.append("'");
/*    */     }
/* 46 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 51 */     Object[] result = EMPTY_OBJECT_ARRAY;
/* 52 */     if (object instanceof TikiUser) {
/* 53 */       result = new Token[3];
/* 54 */       result[0] = Token.NAME;
/* 55 */       result[1] = Token.HANDLE;
/* 56 */       result[2] = Token.ROLES;
/*    */     }
/* 58 */     return result;
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 63 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 68 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 73 */     return false; }
/*    */ 
/*    */   private static enum Token {
/* 76 */     NAME, HANDLE, ROLES;
/*    */ 
/*    */     private String name;
/*    */ 
/*    */     public String getName()
/*    */     {
/* 85 */       return this.name;
/*    */     }
/*    */   }
/*    */ }