/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.TagAssociation;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TagAssociationContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 10 */     StringBuilder result = new StringBuilder();
/* 11 */     if (object instanceof TagAssociation) {
/* 12 */       TagAssociation association = (TagAssociation)object;
/* 13 */       result.append("TagAssociation[");
/* 14 */       result.append(association.getId());
/* 15 */       result.append("]");
/*    */     }
/* 17 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 22 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 27 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 32 */     Object[] result = TreeContentProvider.EMPTY_OBJECT_ARRAY;
/* 33 */     if (object instanceof TagAssociation) {
/* 34 */       TagAssociation association = (TagAssociation)object;
/* 35 */       result = new Object[2];
/* 36 */       result[0] = association.getTag();
/* 37 */       result[1] = association.getAction();
/*    */     }
/* 39 */     return result;
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 49 */     return true;
/*    */   }
/*    */ }