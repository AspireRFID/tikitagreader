/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.model.Label;
/*    */ import com.tikitag.ons.model.TikiTemplateRef;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class TikiTemplateRefContentProvider
/*    */   implements TreeContentProvider
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 11 */     StringBuilder result = new StringBuilder();
/* 12 */     if (object instanceof TikiTemplateRef) {
/* 13 */       TikiTemplateRef ref = (TikiTemplateRef)object;
/* 14 */       result.append("TikiTemplateRef[");
/* 15 */       result.append(ref.getId());
/* 16 */       result.append("]");
/*    */     }
/* 18 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 23 */     StringBuilder result = new StringBuilder();
/* 24 */     if ((object instanceof TikiTemplateRef) && (attribute instanceof Token))
/*    */     {
/*    */       boolean first;
/* 25 */       TikiTemplateRef ref = (TikiTemplateRef)object;
/* 26 */       Token tikitAttribute = (Token)attribute;
/* 27 */       result.append(tikitAttribute.getName());
/* 28 */       result.append(" = '");
/* 29 */       switch (1.$SwitchMap$com$tikitag$ons$service$util$TikiTemplateRefContentProvider$Token[tikitAttribute.ordinal()])
/*    */       {
/*    */       case 1:
/* 31 */         result.append(ref.getName());
/* 32 */         break;
/*    */       case 2:
/* 34 */         first = true;
/* 35 */         for (Label label : ref.getLabels()) {
/* 36 */           if (first)
/* 37 */             first = false;
/*    */           else
/* 39 */             result.append(',');
/* 40 */           result.append(label);
/*    */         }
/*    */       }
/*    */ 
/* 44 */       result.append("'");
/*    */     }
/* 46 */     return result.toString();
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 51 */     Object[] result = EMPTY_OBJECT_ARRAY;
/* 52 */     if (object instanceof TikiTemplateRef) {
/* 53 */       result = new Token[2];
/* 54 */       result[0] = Token.NAME;
/* 55 */       result[1] = Token.LABELS;
/*    */     }
/* 57 */     return result;
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 62 */     throw new UnsupportedOperationException();
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 67 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 72 */     return false; }
/*    */ 
/*    */   private static enum Token {
/* 75 */     NAME, LABELS;
/*    */ 
/*    */     private String name;
/*    */ 
/*    */     public String getName()
/*    */     {
/* 84 */       return this.name;
/*    */     }
/*    */   }
/*    */ }