/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ import javax.interceptor.AroundInvoke;
/*    */ import javax.interceptor.InvocationContext;
/*    */ import javax.security.auth.login.LoginContext;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jboss.security.auth.callback.UsernamePasswordHandler;
/*    */ 
/*    */ public class SecurityOverrideInterceptor
/*    */ {
/* 12 */   public static final Logger log = Logger.getLogger(SecurityOverrideInterceptor.class);
/*    */ 
/*    */   @AroundInvoke
/*    */   public Object aroundInvoke(InvocationContext ctx) throws Exception
/*    */   {
/* 17 */     LoginContext loginContext = null;
/*    */     try {
/* 19 */       SecurityOverride override = (SecurityOverride)ctx.getMethod().getAnnotation(SecurityOverride.class);
/* 20 */       if ((override == null) || (!(override.ignore())))
/*    */       {
/* 23 */         override = (SecurityOverride)ctx.getTarget().getClass().getAnnotation(SecurityOverride.class); }
/* 24 */       if ((override != null) && (!(override.ignore()))) {
/* 25 */         log.warn("///////////////////////// ");
/* 26 */         log.warn("//// S E C U R I T Y //// Security override in place: switching user name to '" + override.userName() + "'!");
/* 27 */         log.warn("///////////////////////// ");
/*    */ 
/* 29 */         handler = new UsernamePasswordHandler(override.userName(), override.password());
/* 30 */         loginContext = new LoginContext("client-login", handler);
/* 31 */         loginContext.login();
/*    */       }
/*    */ 
/* 36 */       UsernamePasswordHandler handler = ctx.proceed();
/*    */ 
/* 41 */       return handler;
/*    */     }
/*    */     finally
/*    */     {
/* 39 */       if (loginContext != null) {
/* 40 */         loginContext.logout();
/* 41 */         loginContext = null;
/*    */       }
/*    */     }
/*    */   }
/*    */ }