/*     */ package com.tikitag.ons.service.util;
/*     */ 
/*     */ import com.tikitag.util.StringUtils;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStreamWriter;
/*     */ import java.io.PrintWriter;
/*     */ import java.io.Reader;
/*     */ import java.io.Writer;
/*     */ import java.net.InetAddress;
/*     */ import java.net.ServerSocket;
/*     */ import java.net.Socket;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.ScheduledExecutorService;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import org.apache.log4j.Logger;
/*     */ 
/*     */ public class NaiveSecurityServer
/*     */   implements Runnable
/*     */ {
/*  28 */   private static final Logger log = Logger.getLogger(NaiveSecurityServer.class);
/*     */   public static final int PORT = 6660;
/*     */   private static final int THREAD_POOL_SIZE = 8;
/*  32 */   private static final String TERMINATOR = System.getProperty("line.separator");
/*     */ 
/*  34 */   private volatile boolean running = false;
/*     */   private final ServerSocket serverSocket;
/*  36 */   private final ExecutorService pool = Executors.newFixedThreadPool(8);
/*  37 */   private final ScheduledExecutorService conversationReaper = Executors.newScheduledThreadPool(1);
/*     */   private final SecurityResolver resolver;
/*     */ 
/*     */   public NaiveSecurityServer(SecurityResolver resolver)
/*     */   {
/*  41 */     this.resolver = resolver;
/*     */     try {
/*  43 */       this.serverSocket = new ServerSocket(6660);
/*     */     } catch (Exception e) {
/*  45 */       throw new RuntimeException("Could not instantiate security server!");
/*     */     }
/*     */   }
/*     */ 
/*     */   public void run()
/*     */   {
/*  51 */     this.running = true;
/*  52 */     while (this.running) {
/*  53 */       Socket socket = null;
/*     */       try {
/*  55 */         socket = this.serverSocket.accept();
/*  56 */         this.pool.execute(new SocketHandler(socket, null)); } catch (Exception e) {
/*     */         try {
/*  58 */           socket.close(); } catch (Exception ignore) { }
/*  59 */         log.warn(new StringBuilder().append("Disconnecting from ").append((socket == null) ? "unknown" : socket.getInetAddress().getHostAddress()).append(" due to ").append(e.getMessage()).append("!").toString(), e);
/*     */       }
/*     */     }
/*  62 */     this.pool.shutdown();
/*     */   }
/*     */ 
/*     */   public void stop() {
/*  66 */     this.running = false;
/*     */     try { this.serverSocket.close(); } catch (Exception ignore) { }
/*  68 */     this.pool.shutdownNow();
/*  69 */     this.conversationReaper.shutdownNow();
/*     */   }
/*     */ 
/*     */   private String echo(Reader in, Writer out)
/*     */     throws IOException
/*     */   {
/* 134 */     StringBuffer buffer = new StringBuffer();
/*     */     do
/*     */     {
/*     */       int i;
/* 136 */       if ((i = in.read()) == -1) {
/*     */         break;
/*     */       }
/* 139 */       buffer.append((char)i); }
/* 140 */     while ((buffer.length() <= 1) || 
/* 141 */       (!(buffer.substring(buffer.length() - TERMINATOR.length()).equals(TERMINATOR))));
/*     */ 
/* 144 */     return buffer.substring(0, buffer.length() - TERMINATOR.length());
/*     */   }
/*     */ 
/*     */   private class ConversationInterrupter
/*     */     implements Runnable
/*     */   {
/*     */     private Thread thread;
/*     */     private NaiveSecurityServer.SocketHandler handler;
/* 152 */     private volatile boolean armed = true;
/*     */ 
/*     */     private ConversationInterrupter(NaiveSecurityServer.SocketHandler paramSocketHandler) {
/* 155 */       this.thread = Thread.currentThread();
/* 156 */       this.handler = paramSocketHandler;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/* 161 */       if (this.armed) {
/* 162 */         NaiveSecurityServer.log.warn("ConversationInterrupter: armed, ready, GONE!");
/* 163 */         this.thread.interrupt();
/* 164 */         this.handler.abort();
/*     */       }
/*     */     }
/*     */ 
/*     */     public void disarm() {
/* 169 */       this.armed = false;
/*     */     }
/*     */   }
/*     */ 
/*     */   private class SocketHandler
/*     */     implements Runnable
/*     */   {
/*     */     private final Socket socket;
/*     */ 
/*     */     private SocketHandler(Socket paramSocket)
/*     */     {
/*  77 */       this.socket = paramSocket;
/*     */     }
/*     */ 
/*     */     public void run()
/*     */     {
/*     */       try
/*     */       {
/*  84 */         NaiveSecurityServer.ConversationInterrupter interrupter = new NaiveSecurityServer.ConversationInterrupter(NaiveSecurityServer.this, this, null);
/*  85 */         NaiveSecurityServer.this.conversationReaper.schedule(interrupter, 20L, TimeUnit.SECONDS);
/*  86 */         InputStreamReader in = new InputStreamReader(this.socket.getInputStream());
/*  87 */         PrintWriter out = new PrintWriter(new OutputStreamWriter(this.socket.getOutputStream()));
/*  88 */         out.print("+ ELLO Tikitag Naive Security Server READY!");
/*  89 */         out.print(NaiveSecurityServer.TERMINATOR);
/*  90 */         out.print("? USER username: ");
/*  91 */         out.flush();
/*  92 */         String userName = NaiveSecurityServer.this.echo(in, out);
/*     */ 
/*  94 */         NaiveSecurityServer.log.info("? USER <- '" + userName + "'");
/*  95 */         out.print("? PASS password: ");
/*  96 */         out.flush();
/*  97 */         byte[] password = NaiveSecurityServer.this.echo(in, out).getBytes();
/*  98 */         NaiveSecurityServer.log.info("? PASS <- '" + new String(password) + "'");
/*     */         try {
/* 100 */           String[] reply = NaiveSecurityServer.this.resolver.resolveRoles(userName, password);
/* 101 */           out.print("= ROLE ");
/* 102 */           String roleStanza = StringUtils.toCommaSeperated(reply);
/* 103 */           out.print(roleStanza);
/* 104 */           out.print(NaiveSecurityServer.TERMINATOR);
/* 105 */           NaiveSecurityServer.log.info("= ROLE -> '" + roleStanza + "'");
/*     */         } catch (SecurityException se) {
/* 107 */           out.print("= FAIL");
/* 108 */           out.print(NaiveSecurityServer.TERMINATOR);
/*     */         } catch (Exception e) {
/* 110 */           NaiveSecurityServer.log.error("Unexpected", e);
/* 111 */           throw e;
/*     */         }
/* 113 */         out.print("- BYE!");
/* 114 */         out.print(NaiveSecurityServer.TERMINATOR);
/* 115 */         out.flush();
/* 116 */         NaiveSecurityServer.log.info("- BYE!");
/* 117 */         interrupter.disarm();
/*     */       } catch (Exception e) {
/* 119 */         NaiveSecurityServer.log.warn("Disconnecting from " + this.socket.getInetAddress().getHostAddress() + " due to " + e.getMessage() + " !", e);
/*     */       } finally {
/* 121 */         abort(); }
/*     */     }
/*     */ 
/*     */     public void abort() {
/*     */       try {
/* 126 */         this.socket.shutdownInput(); } catch (Exception ignore) { }
/*     */       try { this.socket.shutdownOutput(); } catch (Exception ignore) { }
/*     */       try { this.socket.close();
/*     */       }
/*     */       catch (Exception ignore)
/*     */       {
/*     */       }
/*     */     }
/*     */   }
/*     */ }