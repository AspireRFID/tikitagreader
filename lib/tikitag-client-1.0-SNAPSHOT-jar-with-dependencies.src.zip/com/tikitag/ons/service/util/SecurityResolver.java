package com.tikitag.ons.service.util;

public abstract interface SecurityResolver
{
  public abstract String[] resolveRoles(String paramString, byte[] paramArrayOfByte);
}