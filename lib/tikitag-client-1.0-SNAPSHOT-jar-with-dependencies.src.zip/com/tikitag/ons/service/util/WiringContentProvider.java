/*    */ package com.tikitag.ons.service.util;
/*    */ 
/*    */ import com.tikitag.ons.block.util.WiringOperation;
/*    */ import com.tikitag.util.InnerContentDelegate;
/*    */ import com.tikitag.util.TreeContentProvider;
/*    */ 
/*    */ public class WiringContentProvider
/*    */   implements TreeContentProvider, InnerContentDelegate
/*    */ {
/*    */   public String asString(Object object)
/*    */   {
/* 16 */     if (object instanceof WiringOperation) {
/* 17 */       WiringOperation operation = (WiringOperation)object;
/* 18 */       return "WiringOperation[" + operation.getURN() + "] " + operation.getName();
/*    */     }
/* 20 */     if (object instanceof ParameterTypeWithInfo) {
/* 21 */       ParameterTypeWithInfo parameterType = (ParameterTypeWithInfo)object;
/* 22 */       return "Parameter[" + parameterType.parameterType.getName() + "]";
/*    */     }
/* 24 */     return "?Unknown";
/*    */   }
/*    */ 
/*    */   public String asString(Object object, Object attribute)
/*    */   {
/* 29 */     if (object instanceof WiringOperation) {
/* 30 */       WiringOperation operation = (WiringOperation)object;
/* 31 */       return "Info '" + operation.getInfo() + "'";
/*    */     }
/* 33 */     if (object instanceof ParameterTypeWithInfo) {
/* 34 */       ParameterTypeWithInfo parameterType = (ParameterTypeWithInfo)object;
/* 35 */       return "Info '" + parameterType.info + "'";
/*    */     }
/* 37 */     return "?Unknown";
/*    */   }
/*    */ 
/*    */   public Object[] getAttributes(Object object)
/*    */   {
/* 42 */     if ((object instanceof WiringOperation) || (object instanceof WithInfo)) {
/* 43 */       return new Object[] { WithInfo.class };
/*    */     }
/* 45 */     return new Object[0];
/*    */   }
/*    */ 
/*    */   public Object[] getChildren(Object object)
/*    */   {
/* 50 */     if (object instanceof WiringOperation) {
/* 51 */       WiringOperation operation = (WiringOperation)object;
/* 52 */       Class[] parameterTypes = operation.getParameterTypes();
/* 53 */       String[] parameterInfos = operation.getParameterInfos();
/* 54 */       ParameterTypeWithInfo[] children = new ParameterTypeWithInfo[parameterTypes.length];
/* 55 */       for (int i = 0; i < parameterTypes.length; ++i)
/* 56 */         children[i] = new ParameterTypeWithInfo(parameterTypes[i], parameterInfos[i]);
/* 57 */       return children;
/*    */     }
/* 59 */     return new Object[0];
/*    */   }
/*    */ 
/*    */   public boolean hasAttributes(Object object)
/*    */   {
/* 64 */     return true;
/*    */   }
/*    */ 
/*    */   public boolean hasChildren(Object object)
/*    */   {
/* 69 */     if (object instanceof WiringOperation) {
/* 70 */       WiringOperation operation = (WiringOperation)object;
/* 71 */       return ((operation.getParameterTypes() != null) && (operation.getParameterTypes().length > 0));
/*    */     }
/* 73 */     return false;
/*    */   }
/*    */ 
/*    */   public Class<?>[] getSupportedClasses()
/*    */   {
/* 94 */     return new Class[] { ParameterTypeWithInfo.class };
/*    */   }
/*    */ 
/*    */   public class ParameterTypeWithInfo extends WiringContentProvider.WithInfo
/*    */   {
/*    */     public final Class<?> parameterType;
/*    */ 
/*    */     public ParameterTypeWithInfo(String parameterType)
/*    */     {
/* 86 */       super(WiringContentProvider.this, info);
/* 87 */       this.parameterType = parameterType;
/*    */     }
/*    */   }
/*    */ 
/*    */   private abstract class WithInfo
/*    */   {
/*    */     public final String info;
/*    */ 
/*    */     public WithInfo(String paramString)
/*    */     {
/* 79 */       this.info = paramString;
/*    */     }
/*    */   }
/*    */ }