/*     */ package com.tikitag.ons.service;
/*     */ 
/*     */ import com.tikitag.ons.model.TikiUser;
/*     */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*     */ import com.tikitag.ons.service.local.SecurityManager;
/*     */ import com.tikitag.ons.service.mx.SecurityManagerMIF;
/*     */ import com.tikitag.ons.service.util.SecurityOverride;
/*     */ import com.tikitag.security.AccessControlUtils;
/*     */ import com.tikitag.security.EncryptionStrategy;
/*     */ import com.tikitag.security.GenericEncryptionStrategy;
/*     */ import com.tikitag.security.GenericSigningStrategy;
/*     */ import com.tikitag.security.SecureTicket;
/*     */ import com.tikitag.security.SigningStrategy;
/*     */ import com.tikitag.security.Ticket;
/*     */ import com.tikitag.security.TicketDecoder;
/*     */ import com.tikitag.security.TicketEncoder;
/*     */ import com.tikitag.security.VisitorException;
/*     */ import com.tikitag.security.util.AbstractBytes;
/*     */ import com.tikitag.security.util.Nonce;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.net.URLEncoder;
/*     */ import java.security.Key;
/*     */ import java.security.KeyStore;
/*     */ import java.security.NoSuchAlgorithmException;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Collection;
/*     */ import java.util.Date;
/*     */ import java.util.Iterator;
/*     */ import java.util.StringTokenizer;
/*     */ import java.util.WeakHashMap;
/*     */ import java.util.concurrent.DelayQueue;
/*     */ import java.util.concurrent.Delayed;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ import javax.ejb.EJB;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ import org.jboss.annotation.security.SecurityDomain;
/*     */ 
/*     */ @Service(objectName="tikitag:service=Manager,type=Security")
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Service/Security/local")
/*     */ @SecurityDomain(value="tikitag", unauthenticatedPrincipal="tikigimp")
/*     */ @SecurityOverride(userName="tikiusurper")
/*     */ public class SecurityManagerService extends AbstractGenericService
/*     */   implements SecurityManager, SecurityManagerMIF
/*     */ {
/*  56 */   private static final Logger log = Logger.getLogger(SecurityManagerService.class);
/*     */ 
/*  58 */   private static final Pattern TICKET_PATTERN = Pattern.compile("\\{(.*)\\}");
/*     */   private static final String ENCRYPTION_ALIAS = "encryption";
/*     */   private static final String SIGNING_ALIAS = "signing";
/*     */ 
/*     */   @EJB
/*     */   private TikiUserRepository tikiUserRepo;
/*     */   private int ticketExpiration;
/*     */   private String ticketParameterName;
/*     */   private boolean direct;
/*     */   private DelayQueue<DelayedBytes> replayFence;
/*     */   private DelayQueue<DelayedBytes> indirectFence;
/*     */   private WeakHashMap<DelayedBytes, Ticket> ticketCache;
/*     */   private String encryptionAlgorithm;
/*     */   private String signingAlgorithm;
/*     */   private SecretKeySpec encryptionSecretKeySpec;
/*     */   private SecretKeySpec signingSecretKeySpec;
/*     */   private boolean encrypted;
/*     */   private boolean signed;
/*     */   private EncryptionStrategy encryptionStrategy;
/*     */   private SigningStrategy signingStrategy;
/*     */ 
/*     */   public SecurityManagerService()
/*     */   {
/*  67 */     this.ticketExpiration = 30000;
/*     */ 
/*  69 */     this.ticketParameterName = "tt";
/*     */ 
/*  71 */     this.direct = true;
/*     */ 
/*  73 */     this.replayFence = new DelayQueue();
/*     */ 
/*  75 */     this.indirectFence = new DelayQueue();
/*     */ 
/*  77 */     this.ticketCache = new WeakHashMap();
/*     */ 
/*  79 */     this.encryptionAlgorithm = "AES";
/*     */ 
/*  81 */     this.signingAlgorithm = "HmacSHA1";
/*     */ 
/*  87 */     this.encrypted = true;
/*     */ 
/*  89 */     this.signed = true;
/*     */   }
/*     */ 
/*     */   public void create()
/*     */     throws Exception
/*     */   {
/*  97 */     super.create();
/*     */ 
/*  99 */     Key encryptionKey = null;
/* 100 */     Key signingKey = null;
/* 101 */     KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
/* 102 */     FileInputStream in = null;
/*     */     try {
/* 104 */       File keyStoreFile = new File("/etc/tikitag/.keystore");
/* 105 */       if (keyStoreFile.exists()) {
/* 106 */         in = new FileInputStream(keyStoreFile);
/* 107 */         char[] password = "tikitag".toCharArray();
/* 108 */         keyStore.load(in, password);
/* 109 */         encryptionKey = keyStore.getKey("encryption", password);
/* 110 */         signingKey = keyStore.getKey("signing", password);
/*     */       } else {
/* 112 */         log.warn("///////////////////////// ");
/* 113 */         log.warn("//// S E C U R I T Y //// No external key store found; regenerating secret keys!");
/* 114 */         log.warn("///////////////////////// ");
/*     */ 
/* 116 */         encryptionKey = newEncryptionKey();
/* 117 */         signingKey = newSigningKey();
/*     */       }
/*     */     } catch (Exception e) {
/* 120 */       log.error("Could not process key store!", e);
/*     */     } finally {
/* 122 */       if (in != null) {
/* 123 */         in.close();
/*     */       }
/*     */     }
/* 126 */     this.encryptionSecretKeySpec = new SecretKeySpec(encryptionKey.getEncoded(), encryptionKey.getAlgorithm());
/* 127 */     this.signingSecretKeySpec = new SecretKeySpec(signingKey.getEncoded(), signingKey.getAlgorithm());
/*     */   }
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 133 */     setEncrypted(this.encrypted);
/* 134 */     setSigned(this.signed);
/*     */   }
/*     */ 
/*     */   private SecretKey newEncryptionKey() throws NoSuchAlgorithmException {
/* 138 */     KeyGenerator keyGenerator = KeyGenerator.getInstance(this.encryptionAlgorithm);
/* 139 */     keyGenerator.init(128);
/* 140 */     return keyGenerator.generateKey();
/*     */   }
/*     */ 
/*     */   private SecretKey newSigningKey() throws NoSuchAlgorithmException {
/* 144 */     KeyGenerator keyGenerator = KeyGenerator.getInstance(this.signingAlgorithm);
/* 145 */     keyGenerator.init(128);
/* 146 */     return keyGenerator.generateKey();
/*     */   }
/*     */ 
/*     */   public Ticket newTicket() {
/* 150 */     if (this.direct) {
/* 151 */       return newDirectTicket();
/*     */     }
/* 153 */     return newIndirectTicket();
/*     */   }
/*     */ 
/*     */   public Ticket newDirectTicket() {
/* 157 */     TikiUser user = this.tikiUserRepo.whoami();
/* 158 */     return new SecureTicket(user.getUserName(), user.getPassword(), newExpiration());
/*     */   }
/*     */ 
/*     */   public boolean isDirect() {
/* 162 */     return this.direct;
/*     */   }
/*     */ 
/*     */   public void setDirect(boolean direct) {
/* 166 */     this.direct = direct;
/*     */   }
/*     */ 
/*     */   public String getEncryptionAlgorithm() {
/* 170 */     return this.encryptionAlgorithm;
/*     */   }
/*     */ 
/*     */   public void setEncryptionAlgorithm(String encryptionAlgorithm) {
/* 174 */     this.encryptionAlgorithm = encryptionAlgorithm;
/*     */   }
/*     */ 
/*     */   public String getSigningAlgorithm()
/*     */   {
/* 179 */     return this.signingAlgorithm;
/*     */   }
/*     */ 
/*     */   public void setSigningAlgorithm(String signingAlgorithm)
/*     */   {
/* 184 */     this.signingAlgorithm = signingAlgorithm;
/*     */   }
/*     */ 
/*     */   public boolean isEncrypted()
/*     */   {
/* 189 */     return this.encrypted;
/*     */   }
/*     */ 
/*     */   public void setEncrypted(boolean encrypted)
/*     */   {
/* 194 */     this.encrypted = encrypted;
/* 195 */     if (encrypted) {
/* 196 */       this.encryptionStrategy = new GenericEncryptionStrategy(this.encryptionSecretKeySpec);
/* 197 */       log.info(new StringBuilder().append("Encryption enabled, using '").append(this.encryptionAlgorithm).append("'.").toString());
/*     */     } else {
/* 199 */       this.encryptionStrategy = null;
/* 200 */       log.info("Encryption disabled.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public boolean isSigned()
/*     */   {
/* 206 */     return this.signed;
/*     */   }
/*     */ 
/*     */   public void setSigned(boolean signed) {
/* 210 */     this.signed = signed;
/* 211 */     if (signed) {
/* 212 */       this.signingStrategy = new GenericSigningStrategy(this.signingSecretKeySpec);
/* 213 */       log.info(new StringBuilder().append("Signing enabled, using '").append(this.signingAlgorithm).append("'.").toString());
/*     */     } else {
/* 215 */       this.signingStrategy = SigningStrategy.newDefaultInstance();
/* 216 */       log.info("Signing disabled.");
/*     */     }
/*     */   }
/*     */ 
/*     */   public Ticket newIndirectTicket() {
/* 221 */     Ticket directTicket = newDirectTicket();
/* 222 */     int code = directTicket.hashCode();
/* 223 */     byte[] userNameBytes = new byte[17];
/* 224 */     new SecureRandom().nextBytes(userNameBytes);
/* 225 */     userNameBytes[0] = 0;
/* 226 */     String userName = new String(userNameBytes);
/* 227 */     Ticket indirectTicket = new SecureTicket(userName, String.valueOf(code).getBytes(), directTicket.getExpiration());
/* 228 */     DelayedBytes ticketKey = new DelayedBytes(userName.getBytes(), timeToLive(directTicket));
/* 229 */     this.ticketCache.put(ticketKey, directTicket);
/* 230 */     this.indirectFence.put(ticketKey);
/* 231 */     return indirectTicket;
/*     */   }
/*     */ 
/*     */   private int timeToLive(Ticket ticket) {
/* 235 */     return (int)(ticket.getExpiration().getTime() - new Date().getTime());
/*     */   }
/*     */ 
/*     */   public String newTicketParameter()
/*     */   {
/*     */     String result;
/* 240 */     Ticket ticket = newTicket();
/* 241 */     TicketEncoder encoder = new TicketEncoder();
/* 242 */     encoder.setEncryptionStrategy(this.encryptionStrategy);
/* 243 */     encoder.setSigningStrategy(this.signingStrategy);
/* 244 */     encoder.visit(ticket);
/* 245 */     String ticketAsString = encoder.silentResult();
/* 246 */     log.info(new StringBuilder().append("Created new ticket ").append(ticketAsString).toString());
/*     */     try
/*     */     {
/* 249 */       result = new StringBuilder().append(this.ticketParameterName).append("={").append(URLEncoder.encode(ticketAsString, "UTF-8")).append("}").toString();
/*     */     } catch (UnsupportedEncodingException e) {
/* 251 */       throw new RuntimeException("URL Encoding failed unexpectedly!");
/*     */     }
/* 253 */     return result;
/*     */   }
/*     */ 
/*     */   private Date newExpiration() {
/* 257 */     Date now = new Date();
/* 258 */     return new Date(now.getTime() + getTicketExpiration());
/*     */   }
/*     */ 
/*     */   public int getTicketExpiration()
/*     */   {
/* 263 */     return this.ticketExpiration;
/*     */   }
/*     */ 
/*     */   public void setTicketExpiration(int ticketExpiration)
/*     */   {
/* 268 */     this.ticketExpiration = ticketExpiration;
/*     */   }
/*     */ 
/*     */   public String getTicketParameterName() {
/* 272 */     return this.ticketParameterName;
/*     */   }
/*     */ 
/*     */   public void setTicketParameterName(String ticketParameterName) {
/* 276 */     this.ticketParameterName = ticketParameterName;
/*     */   }
/*     */ 
/*     */   private Ticket asTicket(String ticketParameterValue) throws VisitorException {
/* 280 */     Ticket result = null;
/* 281 */     String ticketInside = null;
/* 282 */     Matcher matcher = TICKET_PATTERN.matcher(ticketParameterValue);
/* 283 */     if (matcher.matches()) {
/* 284 */       ticketInside = matcher.group(1);
/*     */     }
/* 286 */     if (ticketInside != null) {
/* 287 */       String embeddedTicket = AccessControlUtils.wrap(ticketInside, 74);
/* 288 */       StringTokenizer tokenizer = new StringTokenizer(embeddedTicket);
/* 289 */       log.info("= Ticket Parameter Data: =================================================");
/* 290 */       while (tokenizer.hasMoreTokens()) {
/* 291 */         log.info(tokenizer.nextToken());
/*     */       }
/* 293 */       log.info("==========================================================================");
/* 294 */       TicketDecoder decoder = new TicketDecoder();
/* 295 */       decoder.setEncryptionStrategy(this.encryptionStrategy);
/* 296 */       decoder.setSigningStrategy(this.signingStrategy);
/* 297 */       decoder.with(ticketInside).visit(new SecureTicket("", new byte[0], new Date()));
/* 298 */       Ticket ticket = decoder.result();
/* 299 */       ticket = switchIfIndirect(ticket);
/* 300 */       if (isValid(ticket))
/* 301 */         result = ticket;
/*     */     }
/* 303 */     return result;
/*     */   }
/*     */ 
/*     */   public Ticket validate(String ticketParameterValue) {
/* 307 */     log.info(new StringBuilder().append("Validating parameter ").append(ticketParameterValue).toString());
/* 308 */     Ticket result = null;
/*     */     try {
/* 310 */       result = asTicket(ticketParameterValue);
/*     */     } catch (VisitorException ve) {
/* 312 */       log.error("Could not validate SSO ticket!", ve);
/*     */     }
/* 314 */     return result;
/*     */   }
/*     */ 
/*     */   public String errorReport(String ticketParameterValue) {
/* 318 */     StringBuilder errorReport = new StringBuilder("Ticket Reconstruction Error:\n");
/*     */     try {
/* 320 */       asTicket(ticketParameterValue);
/*     */     } catch (Exception e) {
/* 322 */       errorReport.append(e.toString());
/* 323 */       errorReport.append('\n');
/* 324 */       for (StackTraceElement element : e.getStackTrace()) {
/* 325 */         errorReport.append("    ");
/* 326 */         errorReport.append(element);
/* 327 */         errorReport.append('\n');
/*     */       }
/*     */     }
/* 330 */     return errorReport.toString();
/*     */   }
/*     */ 
/*     */   protected Ticket switchIfIndirect(Ticket ticket) {
/* 334 */     Ticket result = ticket;
/*     */ 
/* 336 */     this.indirectFence.drainTo(new NullCollection(null));
/* 337 */     byte[] userNameBytes = ticket.getUserName().getBytes();
/* 338 */     if ((userNameBytes != null) && (userNameBytes.length > 0) && (ticket.getUserName().getBytes()[0] == 0)) {
/* 339 */       DelayedBytes ticketKey = new DelayedBytes(userNameBytes, 0L);
/* 340 */       if (this.indirectFence.contains(ticketKey)) {
/* 341 */         Ticket cachedTicket = (Ticket)this.ticketCache.get(ticketKey);
/* 342 */         if (cachedTicket != null)
/* 343 */           result = cachedTicket;
/*     */       } else {
/* 345 */         result = null; }
/*     */     }
/* 347 */     return result;
/*     */   }
/*     */ 
/*     */   public boolean isValid(Ticket ticket)
/*     */   {
/* 353 */     this.replayFence.drainTo(new NullCollection(null));
/* 354 */     if (ticket == null)
/* 355 */       return false;
/* 356 */     long timeToLive = timeToLive(ticket);
/* 357 */     if (timeToLive > 0L) {
/* 358 */       DelayedBytes delayedNonce = new DelayedBytes(ticket.getNonce().getBytes(), timeToLive);
/* 359 */       if (this.replayFence.contains(delayedNonce)) {
/* 360 */         log.warn("Possible replay attack thwarted: ticket invalidated!");
/* 361 */         return false;
/*     */       }
/* 363 */       this.replayFence.put(delayedNonce);
/* 364 */       return true;
/*     */     }
/* 366 */     log.warn("Ticket has expired!");
/* 367 */     return false;
/*     */   }
/*     */ 
/*     */   private class NullCollection<E>
/*     */     implements Collection<E>
/*     */   {
/*     */     public boolean add(E e)
/*     */     {
/* 403 */       return true;
/*     */     }
/*     */ 
/*     */     public boolean addAll(Collection<? extends E> c)
/*     */     {
/* 408 */       return true;
/*     */     }
/*     */ 
/*     */     public void clear()
/*     */     {
/*     */     }
/*     */ 
/*     */     public boolean contains(Object o)
/*     */     {
/* 417 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean containsAll(Collection<?> c)
/*     */     {
/* 422 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean isEmpty()
/*     */     {
/* 427 */       return true;
/*     */     }
/*     */ 
/*     */     public Iterator<E> iterator()
/*     */     {
/* 432 */       throw new UnsupportedOperationException();
/*     */     }
/*     */ 
/*     */     public boolean remove(Object o)
/*     */     {
/* 437 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean removeAll(Collection<?> c)
/*     */     {
/* 442 */       return false;
/*     */     }
/*     */ 
/*     */     public boolean retainAll(Collection<?> c)
/*     */     {
/* 447 */       return false;
/*     */     }
/*     */ 
/*     */     public int size()
/*     */     {
/* 452 */       return 0;
/*     */     }
/*     */ 
/*     */     public Object[] toArray()
/*     */     {
/* 457 */       return new Object[0];
/*     */     }
/*     */ 
/*     */     public <T> T[] toArray(T[] a)
/*     */     {
/* 463 */       return ((Object[])new Object[0]);
/*     */     }
/*     */   }
/*     */ 
/*     */   private class DelayedBytes extends AbstractBytes
/*     */     implements Delayed
/*     */   {
/*     */     private long delayInMillis;
/*     */ 
/*     */     public DelayedBytes(byte[] paramArrayOfByte, long paramLong)
/*     */     {
/* 376 */       super(paramArrayOfByte);
/* 377 */       this.delayInMillis = delayInMillis;
/*     */     }
/*     */ 
/*     */     public long getDelay(TimeUnit unit)
/*     */     {
/* 382 */       return unit.convert(this.delayInMillis, TimeUnit.MILLISECONDS);
/*     */     }
/*     */ 
/*     */     public int compareTo(Delayed delayed)
/*     */     {
/* 387 */       long delay = delayed.getDelay(TimeUnit.MILLISECONDS);
/* 388 */       long thisDelay = getDelay(TimeUnit.MILLISECONDS);
/* 389 */       if (thisDelay < delay)
/* 390 */         return -1;
/* 391 */       if (thisDelay > delay) {
/* 392 */         return 1;
/*     */       }
/* 394 */       return 0;
/*     */     }
/*     */   }
/*     */ }