/*     */ package com.tikitag.ons.service;
/*     */ 
/*     */ import com.tikitag.ons.TikitagWebServiceException;
/*     */ import com.tikitag.ons.block.TikiBlock;
/*     */ import com.tikitag.ons.block.util.WiringOperation;
/*     */ import com.tikitag.ons.facade.local.CorrelationFacade;
/*     */ import com.tikitag.ons.facade.local.ManagementFacade;
/*     */ import com.tikitag.ons.facade.local.TikiBlocksFacade;
/*     */ import com.tikitag.ons.model.TagAssociation;
/*     */ import com.tikitag.ons.model.TikiTag;
/*     */ import com.tikitag.ons.model.TikiTemplateRef;
/*     */ import com.tikitag.ons.model.Tikit;
/*     */ import com.tikitag.ons.model.TikitAction;
/*     */ import com.tikitag.ons.model.util.ReaderId;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.ons.model.util.URN;
/*     */ import com.tikitag.ons.repository.local.TikiTagRepository;
/*     */ import com.tikitag.ons.repository.local.TikitRepository;
/*     */ import com.tikitag.ons.service.local.TikitagManager;
/*     */ import com.tikitag.ons.service.mx.TikitagManagerMIF;
/*     */ import com.tikitag.ons.service.util.SecurityOverride;
/*     */ import com.tikitag.ons.service.util.SecurityOverrideInterceptor;
/*     */ import com.tikitag.ons.service.util.TagAssociationContentProvider;
/*     */ import com.tikitag.ons.service.util.TikiTagContentProvider;
/*     */ import com.tikitag.ons.service.util.TikiTemplateRefContentProvider;
/*     */ import com.tikitag.ons.service.util.TikitActionContentProvider;
/*     */ import com.tikitag.ons.service.util.TikitContentProvider;
/*     */ import com.tikitag.ons.service.util.WiringContentProvider;
/*     */ import com.tikitag.ons.util.ServiceUtils;
/*     */ import com.tikitag.util.DelegatingContentProvider;
/*     */ import com.tikitag.util.IterableContentProvider;
/*     */ import com.tikitag.util.TreeString;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import javax.annotation.security.PermitAll;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.ejb.EJB;
/*     */ import javax.interceptor.Interceptors;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NameClassPair;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import org.apache.commons.lang.exception.ExceptionUtils;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.Service;
/*     */ import org.jboss.annotation.security.SecurityDomain;
/*     */ 
/*     */ @Service(objectName="tikitag:service=Manager,type=Tikit")
/*     */ @SecurityDomain(value="tikitag", unauthenticatedPrincipal="tikigimp")
/*     */ @SecurityOverride(userName="tikiusurper")
/*     */ @Interceptors({SecurityOverrideInterceptor.class})
/*     */ public class TikitagManagerService
/*     */   implements TikitagManager, TikitagManagerMIF
/*     */ {
/*  65 */   private static final Logger log = Logger.getLogger(TikitagManagerService.class);
/*     */ 
/*  67 */   private static final String[] TAGS = { "0437C6B9C00280", "0438B7B9C00280", "0438A4B9C00280", "0438C6B9C00280", "0438B6B9C00280", "049FF4B9C00280", "0438C7B9C00280", "0431E5B9C00280", "043783B9C00280", "043190B9C00280", "0432DDB9C00280", "0432F0B9C00280", "043288B9C00280", "0430C0B9C00280", "0437D7B9C00280" };
/*     */ 
/*     */   @EJB
/*     */   private TikiTagRepository tikiTagRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikitRepository tikitRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikiBlocksFacade tikiBlocksFacade;
/*     */ 
/*     */   @EJB
/*     */   private CorrelationFacade client;
/*     */ 
/*     */   @EJB
/*     */   private ManagementFacade management;
/*     */   private SecretKey sharedKey;
/*     */ 
/*     */   public void start()
/*     */     throws Exception
/*     */   {
/* 118 */     KeyGenerator kg = KeyGenerator.getInstance("DES");
/* 119 */     kg.init(56);
/* 120 */     this.sharedKey = kg.generateKey();
/*     */ 
/* 122 */     for (String identifier : TAGS) {
/* 123 */       TagId id = new TagId(identifier);
/* 124 */       TikiTag tag = this.tikiTagRepo.findByTagId(id);
/* 125 */       if (tag == null) {
/* 126 */         tag = new TikiTag(identifier);
/* 127 */         this.tikiTagRepo.saveOrUpdate(tag);
/* 128 */         log.info(new StringBuilder().append("Saved TikiTag[").append(identifier).append("]").toString());
/*     */       }
/*     */     }
/* 131 */     signature();
/*     */   }
/*     */ 
/*     */   private void signature() {
/* 135 */     BufferedReader reader = null;
/*     */     try {
/* 137 */       InputStream in = Thread.currentThread().getContextClassLoader().getResourceAsStream("tikitag.ascii");
/* 138 */       reader = new BufferedReader(new InputStreamReader(in));
/* 139 */       String line = "";
/*     */       do {
/* 141 */         log.info(line);
/* 142 */         line = reader.readLine(); }
/* 143 */       while (line != null);
/*     */     } catch (Exception e) {
/* 145 */       e.printStackTrace(); } finally {
/*     */       try {
/* 147 */         reader.close(); } catch (Exception ignore) {
/*     */       }
/*     */     }
/*     */   }
/*     */ 
/*     */   public SecretKey getSharedKey() {
/* 153 */     return this.sharedKey;
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   @Deprecated
/*     */   public String provision() {
/* 159 */     StringBuilder report = new StringBuilder("Provisioning persistent configuration:\n");
/* 160 */     report.append("Provisioning has been disabled at the moment!\n");
/*     */ 
/* 211 */     report.append("\n..done!");
/* 212 */     return report.toString();
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   @Deprecated
/*     */   public String unprovision()
/*     */   {
/* 248 */     StringBuilder report = new StringBuilder("Unprovisioning persistent configuration:\n");
/* 249 */     report.append("\n..done!");
/* 250 */     return report.toString();
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   @Deprecated
/*     */   public String test(String tag)
/*     */   {
/* 259 */     StringBuilder report = new StringBuilder("Testing tag:\n");
/*     */     try {
/* 261 */       TagInfo actionTag = new TagInfo(new TagId(tag));
/* 262 */       TagEvent tagEvent = TagEvent.touch(null, new ReaderId("00", null), actionTag, null);
/* 263 */       Object result = this.client.getTikitagAction(tagEvent);
/* 264 */       report.append(new StringBuilder().append("action: ").append(result).toString());
/*     */     } catch (Exception e) {
/* 266 */       report.append(" ..FAILED!\n");
/* 267 */       ServiceUtils.reportOnException(report, e);
/* 268 */       report.append("\n");
/*     */     }
/* 270 */     report.append("\n..done!");
/* 271 */     return report.toString();
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   @Deprecated
/*     */   public String getBlockIdentifiers()
/*     */   {
/* 281 */     StringBuilder report = new StringBuilder("Enumerating Blocks:\n");
/*     */     try
/*     */     {
/* 284 */       InitialContext context = new InitialContext();
/* 285 */       NamingEnumeration enumeration = context.list("Tikitag/ONS/Block");
/* 286 */       while (enumeration.hasMore()) {
/* 287 */         NameClassPair pair = (NameClassPair)enumeration.next();
/* 288 */         report.append(new StringBuilder().append(pair.getName()).append(" : ").append(pair.getClassName()).toString());
/* 289 */         report.append("\n");
/*     */       }
/*     */     } catch (Exception e) {
/* 292 */       report.append(" ..FAILED!\n");
/* 293 */       ServiceUtils.reportOnException(report, e);
/* 294 */       report.append("\n");
/*     */     }
/* 296 */     report.append("\n..done!");
/* 297 */     return report.toString();
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   public String showAllTikits()
/*     */   {
/* 303 */     List tikitList = this.tikitRepo.findAll();
/* 304 */     DelegatingContentProvider contentProvider = new DelegatingContentProvider();
/* 305 */     contentProvider.register(Tikit.class, new TikitContentProvider());
/* 306 */     contentProvider.register(TikiTemplateRef.class, new TikiTemplateRefContentProvider());
/* 307 */     contentProvider.register(TagAssociation.class, new TagAssociationContentProvider());
/* 308 */     contentProvider.register(TikiTag.class, new TikiTagContentProvider());
/* 309 */     contentProvider.register(TikitAction.class, new TikitActionContentProvider());
/* 310 */     TreeString treeString = new TreeString(contentProvider);
/* 311 */     return treeString.convert(tikitList);
/*     */   }
/*     */ 
/*     */   @SecurityOverride(ignore=true)
/*     */   @PermitAll
/*     */   public String[] getBlockURNs()
/*     */   {
/* 321 */     List result = new ArrayList();
/*     */     try {
/* 323 */       URN[] blockURNs = this.tikiBlocksFacade.enumerateBlockURNs();
/* 324 */       for (URN blockURN : blockURNs)
/* 325 */         result.add(blockURN.getValue());
/*     */     } catch (Exception e) {
/* 327 */       result.add("---\\/");
/* 328 */       result.add(e.toString());
/* 329 */       for (StackTraceElement element : e.getStackTrace())
/* 330 */         result.add(new StringBuilder().append("\tat ").append(element.toString()).toString());
/*     */     }
/* 332 */     return ((String[])result.toArray(new String[0]));
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   public String showAllWiringOperations() {
/* 337 */     StringBuilder report = new StringBuilder("WiringScheme Operations:\n");
/* 338 */     TikiBlock[] tikiBlocks = this.tikiBlocksFacade.enumerateBlocks();
/* 339 */     for (TikiBlock tikiBlock : tikiBlocks) {
/* 340 */       URN blockURN = tikiBlock.toURN();
/* 341 */       report.append(new StringBuilder().append("Block[").append(blockURN).append("] ").append(tikiBlock.getName()).toString());
/* 342 */       report.append('\n');
/* 343 */       DelegatingContentProvider contentProvider = new DelegatingContentProvider();
/* 344 */       contentProvider.register([Ljava.lang.Object.class, new IterableContentProvider());
/* 345 */       contentProvider.register(WiringOperation.class, new WiringContentProvider());
/* 346 */       TreeString treeString = new TreeString(contentProvider);
/*     */       try
/*     */       {
/* 349 */         WiringOperation[] wiringOperations = this.tikiBlocksFacade.enumerateWiringOperations(blockURN);
/* 350 */         report.append(treeString.convert(wiringOperations));
/*     */       } catch (TikitagWebServiceException e) {
/* 352 */         report.append(ExceptionUtils.getFullStackTrace(e));
/*     */       }
/* 354 */       report.append('\n');
/*     */     }
/* 356 */     return report.toString();
/*     */   }
/*     */ 
/*     */   @SecurityOverride(userName="tikiusurper")
/*     */   public String whoami()
/*     */   {
/* 362 */     return this.management.whoami();
/*     */   }
/*     */ }