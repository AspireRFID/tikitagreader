package com.tikitag.ons.service.local;

import com.tikitag.ons.ActionAndMemento;
import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.ActionProviderNotFoundException;
import com.tikitag.ons.TikitagActionProvider;
import com.tikitag.ons.model.util.TagEvent;
import javax.ejb.Local;

@Local
public abstract interface ActionProviderCatalog
{
  public abstract TikitagActionProvider getActionProvider(Class<? extends TikitagActionProvider> paramClass);

  public abstract ActionAndMemento invokeActionProvider(ActionProviderMemento paramActionProviderMemento, TagEvent paramTagEvent)
    throws ActionProviderNotFoundException;

  public abstract void register(TikitagActionProvider paramTikitagActionProvider);

  public abstract void unregister(TikitagActionProvider paramTikitagActionProvider);
}