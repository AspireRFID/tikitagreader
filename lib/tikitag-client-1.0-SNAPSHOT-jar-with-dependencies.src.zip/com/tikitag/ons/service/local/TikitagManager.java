package com.tikitag.ons.service.local;

import javax.crypto.SecretKey;
import javax.ejb.Local;

@Local
public abstract interface TikitagManager
{
  public abstract SecretKey getSharedKey();
}