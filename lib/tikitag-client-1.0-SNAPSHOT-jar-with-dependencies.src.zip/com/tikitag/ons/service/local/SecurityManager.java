package com.tikitag.ons.service.local;

import com.tikitag.security.Ticket;
import javax.ejb.Local;

@Local
public abstract interface SecurityManager
{
  public abstract Ticket newTicket();

  public abstract String newTicketParameter();

  public abstract int getTicketExpiration();

  public abstract boolean isValid(Ticket paramTicket);
}