/*    */ package com.tikitag.ons.service;
/*    */ 
/*    */ import com.tikitag.ons.ActionAndMemento;
/*    */ import com.tikitag.ons.ActionProviderMemento;
/*    */ import com.tikitag.ons.ActionProviderNotFoundException;
/*    */ import com.tikitag.ons.TikitagActionProvider;
/*    */ import com.tikitag.ons.model.util.TagEvent;
/*    */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*    */ import com.tikitag.ons.service.mx.ActionProviderCatalogMIF;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag:service=ActionProviderCatalog")
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Service/ActionProviderCatalog/local")
/*    */ public class ActionProviderCatalogService
/*    */   implements ActionProviderCatalog, ActionProviderCatalogMIF
/*    */ {
/*    */   private Map<Class<? extends TikitagActionProvider>, TikitagActionProvider> actionProviders;
/*    */ 
/*    */   public ActionProviderCatalogService()
/*    */   {
/* 22 */     this.actionProviders = new HashMap();
/*    */   }
/*    */ 
/*    */   public TikitagActionProvider getActionProvider(Class<? extends TikitagActionProvider> type)
/*    */   {
/* 28 */     return ((TikitagActionProvider)this.actionProviders.get(type));
/*    */   }
/*    */ 
/*    */   public void register(TikitagActionProvider provider)
/*    */   {
/* 35 */     this.actionProviders.put(provider.getClass(), provider);
/*    */   }
/*    */ 
/*    */   public void unregister(TikitagActionProvider provider)
/*    */   {
/* 42 */     this.actionProviders.remove(provider.getClass());
/*    */   }
/*    */ 
/*    */   public ActionAndMemento invokeActionProvider(ActionProviderMemento memento, TagEvent tagEvent)
/*    */     throws ActionProviderNotFoundException
/*    */   {
/* 49 */     TikitagActionProvider actionProvider = (TikitagActionProvider)this.actionProviders.get(memento.getActionProviderClass());
/* 50 */     if (actionProvider == null) {
/* 51 */       throw new ActionProviderNotFoundException("Failed to find TikitagActionProvider for " + memento.getActionProviderClass());
/*    */     }
/* 53 */     return actionProvider.getTikitagAction(tagEvent, memento);
/*    */   }
/*    */ }