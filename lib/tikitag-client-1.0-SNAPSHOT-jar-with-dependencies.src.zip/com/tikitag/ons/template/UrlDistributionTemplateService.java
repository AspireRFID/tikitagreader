/*    */ package com.tikitag.ons.template;
/*    */ 
/*    */ import com.tikitag.ons.block.wiring.ValuePoint;
/*    */ import com.tikitag.ons.block.wiring.Wire;
/*    */ import com.tikitag.ons.block.wiring.WiringScheme;
/*    */ import com.tikitag.ons.facade.local.ManagementFacade;
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TikitId;
/*    */ import com.tikitag.ons.template.local.UrlDistribution;
/*    */ import com.tikitag.ons.template.mx.UrlDistributionMIF;
/*    */ import com.tikitag.ons.util.ServiceUtils;
/*    */ import java.lang.reflect.Method;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.template:name=URLDistribution")
/*    */ public class UrlDistributionTemplateService extends AbstractTemplateService
/*    */   implements UrlDistribution, UrlDistributionMIF
/*    */ {
/*    */   public UrlDistributionTemplateService()
/*    */   {
/* 22 */     super("URL Distribution [internal]", "Distribute a URL to different parties.");
/*    */   }
/*    */ 
/*    */   private WiringScheme schemeFrom(String url) {
/* 26 */     WiringScheme result = new WiringScheme();
/* 27 */     ValuePoint value = ValuePoint.valueOf(url);
/* 28 */     Wire wire = new Wire("urn:tiki:block:url:launch", value);
/* 29 */     result.define(wire);
/* 30 */     return result;
/*    */   }
/*    */ 
/*    */   public void configure(String name, String url, TagId[] tagIds) throws TemplateException {
/*    */     try {
/* 35 */       TikitId tikitId = this.management.createTikit(name, this.ref, null, schemeFrom(url));
/* 36 */       for (TagId tagId : tagIds)
/* 37 */         this.management.associate(tagId, tikitId);
/*    */     } catch (Exception e) {
/* 39 */       throw new TemplateException(new StringBuilder().append("Could not configure Tikit '").append(name).append("'!").toString(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String configure(String name, String url, String[] hexIds) throws TemplateException
/*    */   {
/* 45 */     StringBuilder report = new StringBuilder("Configuring:\n");
/*    */     try {
/* 47 */       if (!(validArguments(name, url, hexIds))) {
/* 48 */         ServiceUtils.showInfo(report, configureMethod());
/*    */       } else {
/* 50 */         TagId[] tagIds = new TagId[hexIds.length];
/* 51 */         for (int i = 0; i < hexIds.length; ++i)
/* 52 */           tagIds[i] = new TagId(hexIds[i]);
/* 53 */         configure(name, url, tagIds);
/*    */       }
/*    */     } catch (Exception e) {
/* 56 */       ServiceUtils.reportOnException(report, e);
/*    */     }
/* 58 */     return report.toString();
/*    */   }
/*    */ 
/*    */   private Method configureMethod() throws SecurityException, NoSuchMethodException {
/* 62 */     return UrlDistributionMIF.class.getMethod("configure", new Class[] { String.class, String.class, [Ljava.lang.String.class });
/*    */   }
/*    */ 
/*    */   private boolean validArguments(String name, String url, String[] hexIds)
/*    */   {
/* 67 */     return ((name == null) || (name.equals("")));
/*    */   }
/*    */ }