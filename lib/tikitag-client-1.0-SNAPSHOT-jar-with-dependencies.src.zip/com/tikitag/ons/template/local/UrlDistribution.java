package com.tikitag.ons.template.local;

import com.tikitag.ons.model.util.TagId;
import com.tikitag.ons.template.TemplateException;
import javax.ejb.Local;

@Local
public abstract interface UrlDistribution
{
  public abstract void configure(String paramString1, String paramString2, TagId[] paramArrayOfTagId)
    throws TemplateException;
}