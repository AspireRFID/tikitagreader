package com.tikitag.ons.template.local;

import com.tikitag.ons.model.util.TagId;
import com.tikitag.ons.template.TemplateException;
import java.util.Date;
import javax.ejb.Local;

@Local
public abstract interface TimeOfDayGoogleSearchUrl
{
  public abstract void configure(String paramString1, Date paramDate, String paramString2, String paramString3, TagId paramTagId)
    throws TemplateException;
}