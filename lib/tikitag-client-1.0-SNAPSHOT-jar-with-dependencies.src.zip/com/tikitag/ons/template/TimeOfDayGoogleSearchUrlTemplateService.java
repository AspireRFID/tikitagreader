/*    */ package com.tikitag.ons.template;
/*    */ 
/*    */ import com.tikitag.ons.block.wiring.ValuePoint;
/*    */ import com.tikitag.ons.block.wiring.Wire;
/*    */ import com.tikitag.ons.block.wiring.WiringPoint;
/*    */ import com.tikitag.ons.block.wiring.WiringScheme;
/*    */ import com.tikitag.ons.facade.local.ManagementFacade;
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.model.util.TikitId;
/*    */ import com.tikitag.ons.template.local.TimeOfDayGoogleSearchUrl;
/*    */ import com.tikitag.ons.template.mx.TimeOfDayGoogleSearchUrlMIF;
/*    */ import com.tikitag.ons.util.ServiceUtils;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.lang.reflect.Method;
/*    */ import java.net.URLEncoder;
/*    */ import java.util.Date;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ @Service(objectName="tikitag.template:name=TimeOfDayGoogleSearchUrl")
/*    */ public class TimeOfDayGoogleSearchUrlTemplateService extends AbstractTemplateService
/*    */   implements TimeOfDayGoogleSearchUrl, TimeOfDayGoogleSearchUrlMIF
/*    */ {
/*    */   public TimeOfDayGoogleSearchUrlTemplateService()
/*    */   {
/* 26 */     super("Time Of Day [internal]", "It slices, it dices, it does time of day AND Google search!");
/*    */   }
/*    */ 
/*    */   private String asURL(String searchString) {
/* 30 */     String googleSearch = "http://www.google.com/search?q=";
/*    */     try {
/* 32 */       return new StringBuilder().append("http://www.google.com/search?q=").append(URLEncoder.encode(searchString, "UTF-8")).toString(); } catch (UnsupportedEncodingException e) {
/*    */     }
/* 34 */     return "error";
/*    */   }
/*    */ 
/*    */   private WiringScheme schemeFrom(Date switchDate, String beforeSearchString, String afterSearchString)
/*    */   {
/* 39 */     WiringScheme result = new WiringScheme();
/* 40 */     ValuePoint beforeSearch = ValuePoint.valueOf(asURL(beforeSearchString));
/* 41 */     ValuePoint afterSearch = ValuePoint.valueOf(asURL(afterSearchString));
/* 42 */     Wire beforeWire = new Wire("urn:tiki:block:url:launch", beforeSearch);
/* 43 */     Wire afterWire = new Wire("urn:tiki:block:url:launch", afterSearch);
/* 44 */     ValuePoint date = ValuePoint.valueOf(switchDate);
/* 45 */     Wire wire = new Wire("urn:tiki:block:time-of-day:get-action-provider", new WiringPoint[] { date, beforeWire, afterWire });
/* 46 */     result.define(wire);
/* 47 */     return result;
/*    */   }
/*    */ 
/*    */   public void configure(String name, Date switchDate, String beforeSearchString, String afterSearchString, TagId tagId) throws TemplateException {
/*    */     try {
/* 52 */       TikitId tikitId = this.management.createTikit(name, this.ref, null, schemeFrom(switchDate, beforeSearchString, afterSearchString));
/* 53 */       this.management.associate(tagId, tikitId);
/*    */     } catch (Exception e) {
/* 55 */       throw new TemplateException(new StringBuilder().append("Could not configure Tikit '").append(name).append("'!").toString(), e);
/*    */     }
/*    */   }
/*    */ 
/*    */   public String configure(String name, Date switchDate, String beforeSearchString, String afterSearchString, String hexId) throws TemplateException
/*    */   {
/* 61 */     StringBuilder report = new StringBuilder("Configuring:\n");
/*    */     try {
/* 63 */       if (!(validArguments(name, switchDate, beforeSearchString, afterSearchString, hexId)))
/* 64 */         ServiceUtils.showInfo(report, configureMethod());
/*    */       else
/* 66 */         configure(name, switchDate, beforeSearchString, afterSearchString, new TagId(hexId));
/*    */     } catch (Exception e) {
/* 68 */       ServiceUtils.reportOnException(report, e);
/*    */     }
/* 70 */     return report.toString();
/*    */   }
/*    */ 
/*    */   private Method configureMethod() throws SecurityException, NoSuchMethodException {
/* 74 */     return TimeOfDayGoogleSearchUrlMIF.class.getMethod("configure", new Class[] { String.class, Date.class, String.class, String.class, String.class });
/*    */   }
/*    */ 
/*    */   private boolean validArguments(String name, Date switchDate, String beforeSearchString, String afterSearchString, String hexId)
/*    */   {
/* 79 */     return ((name == null) || (name.equals("")));
/*    */   }
/*    */ }