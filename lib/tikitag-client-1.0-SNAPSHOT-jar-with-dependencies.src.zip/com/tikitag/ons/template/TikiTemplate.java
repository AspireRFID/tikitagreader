/*    */ package com.tikitag.ons.template;
/*    */ 
/*    */ import com.tikitag.ons.model.Label;
/*    */ import com.tikitag.ons.model.TikiTemplateRef;
/*    */ 
/*    */ public abstract class TikiTemplate
/*    */ {
/*    */   private TikiTemplateRef ref;
/*    */ 
/*    */   public TikiTemplate(String name, String description)
/*    */   {
/* 16 */     this.ref = new TikiTemplateRef(name, description, new Label[0]);
/*    */   }
/*    */ 
/*    */   public String getName() {
/* 20 */     return this.ref.getName();
/*    */   }
/*    */ 
/*    */   public String getDescription() {
/* 24 */     return this.ref.getDescription();
/*    */   }
/*    */ }