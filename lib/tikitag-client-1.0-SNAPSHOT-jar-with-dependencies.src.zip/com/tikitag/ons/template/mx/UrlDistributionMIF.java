package com.tikitag.ons.template.mx;

import com.tikitag.ons.template.TemplateException;
import com.tikitag.ons.util.Info;
import org.jboss.annotation.ejb.Management;

@Management
public abstract interface UrlDistributionMIF extends GenericMIF
{
  @Info("Configures a Tikit with the given arguments.")
  public abstract String configure(@Info("The resulting Tikit name.") String paramString1, @Info("The URL to distribute.") String paramString2, @Info("A comma-separated list of tag codes in hexadecimal format.") String[] paramArrayOfString)
    throws TemplateException;
}