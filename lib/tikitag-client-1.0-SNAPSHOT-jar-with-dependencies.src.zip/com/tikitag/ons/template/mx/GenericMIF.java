package com.tikitag.ons.template.mx;

import org.jboss.annotation.ejb.Management;

@Management
public abstract interface GenericMIF
{
  public abstract void start()
    throws Exception;

  public abstract void stop();

  public abstract void register();
}