package com.tikitag.ons.template.mx;

import com.tikitag.ons.template.TemplateException;
import com.tikitag.ons.util.Info;
import java.util.Date;
import org.jboss.annotation.ejb.Management;

@Management
public abstract interface TimeOfDayGoogleSearchUrlMIF extends GenericMIF
{
  @Info("Configures a Tikit with the given arguments.")
  public abstract String configure(@Info("The resulting Tikit name.") String paramString1, @Info("The switching date in the format HH:MM:SS.") Date paramDate, @Info("The Google search term used before and including the switching date.") String paramString2, @Info("The Google search term used after the switching date.") String paramString3, @Info("The tag code in hexadecimal format.") String paramString4)
    throws TemplateException;
}