/*    */ package com.tikitag.ons.template;
/*    */ 
/*    */ public class TemplateException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public TemplateException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TemplateException(String message)
/*    */   {
/* 14 */     super(message);
/*    */   }
/*    */ 
/*    */   public TemplateException(Throwable cause) {
/* 18 */     super(cause);
/*    */   }
/*    */ 
/*    */   public TemplateException(String message, Throwable cause) {
/* 22 */     super(message, cause);
/*    */   }
/*    */ }