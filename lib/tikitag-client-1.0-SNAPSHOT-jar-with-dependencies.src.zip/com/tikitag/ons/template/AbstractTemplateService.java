/*    */ package com.tikitag.ons.template;
/*    */ 
/*    */ import com.tikitag.ons.facade.local.ManagementFacade;
/*    */ import com.tikitag.ons.model.Label;
/*    */ import com.tikitag.ons.model.TikiTemplateRef;
/*    */ import com.tikitag.ons.repository.local.TikiTemplateRefRepository;
/*    */ import java.io.UnsupportedEncodingException;
/*    */ import java.net.URI;
/*    */ import java.net.URLEncoder;
/*    */ import javax.ejb.EJB;
/*    */ import org.apache.log4j.Logger;
/*    */ import org.jboss.annotation.ejb.Service;
/*    */ 
/*    */ public abstract class AbstractTemplateService extends TikiTemplate
/*    */ {
/* 18 */   private static final Logger log = Logger.getLogger(AbstractTemplateService.class);
/*    */   protected TikiTemplateRef ref;
/*    */ 
/*    */   @EJB
/*    */   protected ManagementFacade management;
/*    */ 
/*    */   @EJB
/*    */   protected TikiTemplateRefRepository tikiTemplateRefRepo;
/*    */ 
/*    */   public AbstractTemplateService(String name, String description)
/*    */   {
/* 29 */     super(name, description);
/*    */   }
/*    */ 
/*    */   public void start() throws Exception {
/* 33 */     log.warn("Internal Tikit template auto-registration disabled!");
/*    */   }
/*    */ 
/*    */   public void register()
/*    */   {
/* 38 */     this.ref = this.tikiTemplateRefRepo.findByName(getName());
/* 39 */     if (this.ref == null) {
/* 40 */       this.ref = new TikiTemplateRef(getName(), getDescription(), new Label[0]);
/* 41 */       this.ref.setCreateUri(getCreateURI());
/* 42 */       this.ref = ((TikiTemplateRef)this.tikiTemplateRefRepo.saveOrUpdate(this.ref));
/*    */     }
/*    */   }
/*    */ 
/*    */   private URI getCreateURI() {
/* 47 */     Service serviceAnnotation = (Service)super.getClass().getAnnotation(Service.class);
/* 48 */     if (serviceAnnotation == null)
/* 49 */       throw new RuntimeException("This is supposed to be an EJB3 service (" + super.getClass() + ")?");
/* 50 */     String objectName = serviceAnnotation.objectName();
/*    */     try {
/* 52 */       return URI.create("/jmx-console/HtmlAdaptor?action=inspectMBean&name=" + URLEncoder.encode(objectName, "UTF-8"));
/*    */     } catch (UnsupportedEncodingException uee) {
/* 54 */       throw new RuntimeException("UTF-8 is not supported?", uee);
/*    */     }
/*    */   }
/*    */ 
/*    */   public void stop()
/*    */   {
/*    */   }
/*    */ }