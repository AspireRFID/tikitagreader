/*    */ package com.tikitag.ons;
/*    */ 
/*    */ public class ActionProviderNotFoundException extends RuntimeException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public ActionProviderNotFoundException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ActionProviderNotFoundException(String message)
/*    */   {
/* 18 */     super(message);
/*    */   }
/*    */ 
/*    */   public ActionProviderNotFoundException(Throwable cause) {
/* 22 */     super(cause);
/*    */   }
/*    */ 
/*    */   public ActionProviderNotFoundException(String message, Throwable cause) {
/* 26 */     super(message, cause);
/*    */   }
/*    */ }