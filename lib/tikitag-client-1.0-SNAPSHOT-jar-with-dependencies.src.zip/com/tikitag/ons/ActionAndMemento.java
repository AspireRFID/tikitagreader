/*    */ package com.tikitag.ons;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import javax.persistence.Embeddable;
/*    */ 
/*    */ @Embeddable
/*    */ public class ActionAndMemento
/*    */ {
/*    */   private ConfigContainer action;
/*    */   private ActionProviderMemento memento;
/*    */ 
/*    */   protected ActionAndMemento()
/*    */   {
/*    */   }
/*    */ 
/*    */   public ActionAndMemento(ConfigContainer action, ActionProviderMemento memento)
/*    */   {
/* 23 */     this.action = action;
/* 24 */     this.memento = memento;
/*    */   }
/*    */ 
/*    */   public ConfigContainer getAction() {
/* 28 */     return this.action;
/*    */   }
/*    */ 
/*    */   public ActionProviderMemento getMemento() {
/* 32 */     return this.memento;
/*    */   }
/*    */ }