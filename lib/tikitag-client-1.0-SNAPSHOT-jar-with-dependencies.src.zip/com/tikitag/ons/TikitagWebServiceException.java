/*    */ package com.tikitag.ons;
/*    */ 
/*    */ public class TikitagWebServiceException extends TikitagException
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public TikitagWebServiceException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TikitagWebServiceException(String message, Throwable cause)
/*    */   {
/* 21 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public TikitagWebServiceException(String message) {
/* 25 */     super(message);
/*    */   }
/*    */ 
/*    */   public TikitagWebServiceException(Throwable cause) {
/* 29 */     super(cause);
/*    */   }
/*    */ }