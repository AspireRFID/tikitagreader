/*    */ package com.tikitag.ons.util;
/*    */ 
/*    */ public final class CamelCased
/*    */ {
/*    */   private String source;
/*    */ 
/*    */   public static String toDashSeparated(String source)
/*    */   {
/* 11 */     CamelCased camelCased = new CamelCased(source);
/* 12 */     return camelCased.asDashSeparated();
/*    */   }
/*    */ 
/*    */   public CamelCased(String source)
/*    */   {
/* 18 */     if (!(isJavaIdentifier(source)))
/* 19 */       throw new IllegalArgumentException("Only legal Java identifiers are allowed!");
/* 20 */     this.source = source;
/*    */   }
/*    */ 
/*    */   public String asDashSeparated() {
/* 24 */     StringBuffer buffer = new StringBuffer(this.source);
/* 25 */     int index = 0;
/* 26 */     char lastCharacter = '\0';
/* 27 */     while (index < buffer.length()) {
/* 28 */       char character = buffer.charAt(index);
/* 29 */       if (Character.isUpperCase(character)) {
/* 30 */         buffer.setCharAt(index, Character.toLowerCase(character));
/* 31 */         if (index > 0) {
/* 32 */           if (index < buffer.length() - 1) {
/* 33 */             if (!(Character.isUpperCase(buffer.charAt(index + 1)))) {
/* 34 */               buffer.insert(index, '-');
/* 35 */               ++index;
/*    */             }
/* 37 */             else if (Character.isLowerCase(lastCharacter)) {
/* 38 */               buffer.insert(index, '-');
/* 39 */               ++index;
/*    */             }
/*    */           }
/* 42 */           else if (!(Character.isUpperCase(lastCharacter))) {
/* 43 */             buffer.insert(index, '-');
/* 44 */             ++index;
/*    */           }
/*    */         }
/*    */       }
/* 48 */       lastCharacter = character;
/* 49 */       ++index;
/*    */     }
/* 51 */     return buffer.toString();
/*    */   }
/*    */ 
/*    */   public boolean isJavaIdentifier(String s) {
/* 55 */     if ((s.length() == 0) || (!(Character.isJavaIdentifierStart(s.charAt(0))))) {
/* 56 */       return false;
/*    */     }
/* 58 */     for (int i = 1; i < s.length(); ++i) {
/* 59 */       if (!(Character.isJavaIdentifierPart(s.charAt(i)))) {
/* 60 */         return false;
/*    */       }
/*    */     }
/* 63 */     return true;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 68 */     return this.source;
/*    */   }
/*    */ }