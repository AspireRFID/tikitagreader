/*    */ package com.tikitag.ons.util;
/*    */ 
/*    */ import java.lang.annotation.Annotation;
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class ServiceUtils
/*    */ {
/*    */   public static void reportOnException(StringBuilder report, Exception e)
/*    */   {
/*  9 */     report.append(e.getMessage());
/* 10 */     for (StackTraceElement element : e.getStackTrace()) {
/* 11 */       report.append('\t');
/* 12 */       report.append(element.toString());
/* 13 */       report.append('\n');
/*    */     }
/*    */   }
/*    */ 
/*    */   public static void showInfo(StringBuilder report, Method method) {
/* 18 */     Info info = (Info)method.getAnnotation(Info.class);
/* 19 */     if (info != null) {
/* 20 */       report.append(info.value());
/* 21 */       report.append('\n');
/*    */     } else {
/* 23 */       report.append("No additional information on method available!");
/* 24 */       report.append('\n');
/*    */     }
/* 26 */     ClassWithInfo[] classWithInfos = getParameterInfos(method);
/* 27 */     for (int i = 0; i < classWithInfos.length; ++i) {
/* 28 */       report.append(classWithInfos[i].className());
/* 29 */       report.append(": ");
/* 30 */       report.append(classWithInfos[i].info());
/*    */     }
/*    */   }
/*    */ 
/*    */   public static ClassWithInfo[] getParameterInfos(Method method) {
/* 35 */     ClassWithInfo[] result = new ClassWithInfo[method.getParameterTypes().length];
/* 36 */     Class[] paramterTypes = method.getParameterTypes();
/* 37 */     Annotation[][] allAnnotations = method.getParameterAnnotations();
/* 38 */     for (int i = 0; i < result.length; ++i)
/* 39 */       result[i] = new ClassWithInfo(paramterTypes[i], firstInfo(allAnnotations[i]));
/* 40 */     return result;
/*    */   }
/*    */ 
/*    */   public static Info firstInfo(Annotation[] annotations) {
/* 44 */     if (annotations != null)
/* 45 */       for (Annotation annotation : annotations)
/* 46 */         if (annotation instanceof Info)
/* 47 */           return ((Info)annotation);
/* 48 */     return null;
/*    */   }
/*    */ 
/*    */   public static class ClassWithInfo
/*    */   {
/*    */     public Class<?> clazz;
/*    */     public Info info;
/*    */ 
/*    */     public ClassWithInfo(Class<?> clazz, Info info) {
/* 57 */       if (clazz == null)
/* 58 */         throw new NullPointerException("Class argument cannot be null!");
/* 59 */       this.clazz = clazz;
/* 60 */       this.info = info;
/*    */     }
/*    */ 
/*    */     public String className() {
/* 64 */       return this.clazz.getSimpleName();
/*    */     }
/*    */ 
/*    */     public String info() {
/* 68 */       return ((this.info == null) ? "No information available." : this.info.value());
/*    */     }
/*    */   }
/*    */ }