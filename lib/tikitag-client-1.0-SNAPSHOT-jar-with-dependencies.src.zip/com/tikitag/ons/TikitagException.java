/*    */ package com.tikitag.ons;
/*    */ 
/*    */ public class TikitagException extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   public TikitagException()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TikitagException(String message, Throwable cause)
/*    */   {
/* 24 */     super(message, cause);
/*    */   }
/*    */ 
/*    */   public TikitagException(String message)
/*    */   {
/* 31 */     super(message);
/*    */   }
/*    */ 
/*    */   public TikitagException(Throwable cause)
/*    */   {
/* 38 */     super(cause);
/*    */   }
/*    */ }