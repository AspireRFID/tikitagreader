/*    */ package com.tikitag.ons;
/*    */ 
/*    */ import com.tikitag.util.config.xml.ConfigContainer;
/*    */ import java.io.Serializable;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ import org.apache.commons.lang.ObjectUtils;
/*    */ import org.apache.commons.lang.builder.ToStringBuilder;
/*    */ import org.apache.commons.lang.builder.ToStringStyle;
/*    */ 
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ @XmlRootElement(name="tikitagAction")
/*    */ public class TikitagAction
/*    */   implements Serializable
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */ 
/*    */   @XmlElement(name="container")
/*    */   private ConfigContainer container;
/*    */ 
/*    */   public TikitagAction()
/*    */   {
/*    */   }
/*    */ 
/*    */   public TikitagAction(ConfigContainer container)
/*    */   {
/* 32 */     this.container = container;
/*    */   }
/*    */ 
/*    */   public String getName()
/*    */   {
/* 37 */     return ((ConfigContainer)ObjectUtils.defaultIfNull(getContainer(), new ConfigContainer(""))).getName();
/*    */   }
/*    */ 
/*    */   public ConfigContainer getContainer()
/*    */   {
/* 42 */     return this.container;
/*    */   }
/*    */ 
/*    */   public void setContainer(ConfigContainer container) {
/* 46 */     this.container = container;
/*    */   }
/*    */ 
/*    */   public String toString()
/*    */   {
/* 51 */     return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
/*    */   }
/*    */ }