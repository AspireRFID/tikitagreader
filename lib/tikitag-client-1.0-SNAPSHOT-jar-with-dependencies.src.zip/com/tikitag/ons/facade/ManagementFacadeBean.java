/*     */ package com.tikitag.ons.facade;
/*     */ 
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.block.local.TagManagementBlockFacade;
/*     */ import com.tikitag.ons.block.wiring.WiringException;
/*     */ import com.tikitag.ons.block.wiring.WiringScheme;
/*     */ import com.tikitag.ons.facade.local.ManagementFacade;
/*     */ import com.tikitag.ons.facade.local.TikiBlocksFacade;
/*     */ import com.tikitag.ons.facade.remote.ManagementProxy;
/*     */ import com.tikitag.ons.model.TagAssociation;
/*     */ import com.tikitag.ons.model.TikiTag;
/*     */ import com.tikitag.ons.model.TikiTemplateRef;
/*     */ import com.tikitag.ons.model.TikiUser;
/*     */ import com.tikitag.ons.model.Tikit;
/*     */ import com.tikitag.ons.model.TikitAction;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TikitId;
/*     */ import com.tikitag.ons.model.util.URN;
/*     */ import com.tikitag.ons.repository.local.TagAssociationRepository;
/*     */ import com.tikitag.ons.repository.local.TikiTagRepository;
/*     */ import com.tikitag.ons.repository.local.TikiTemplateRefRepository;
/*     */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*     */ import com.tikitag.ons.repository.local.TikitRepository;
/*     */ import com.tikitag.ons.service.util.TagAssociationContentProvider;
/*     */ import com.tikitag.ons.service.util.TikiTagContentProvider;
/*     */ import com.tikitag.ons.service.util.TikiTemplateRefContentProvider;
/*     */ import com.tikitag.ons.service.util.TikitActionContentProvider;
/*     */ import com.tikitag.ons.service.util.TikitContentProvider;
/*     */ import com.tikitag.util.DelegatingContentProvider;
/*     */ import com.tikitag.util.TreeString;
/*     */ import java.security.Principal;
/*     */ import java.util.List;
/*     */ import java.util.concurrent.atomic.AtomicLong;
/*     */ import javax.annotation.Resource;
/*     */ import javax.annotation.security.PermitAll;
/*     */ import javax.ejb.EJB;
/*     */ import javax.ejb.SessionContext;
/*     */ import javax.ejb.Stateless;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.RemoteBinding;
/*     */ import org.jboss.annotation.security.SecurityDomain;
/*     */ 
/*     */ @Stateless
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Facade/Management/local")
/*     */ @RemoteBinding(jndiBinding="Tikitag/ONS/Facade/Management/remote")
/*     */ @SecurityDomain(value="tikitag", unauthenticatedPrincipal="tikigimp")
/*     */ public class ManagementFacadeBean
/*     */   implements ManagementFacade, ManagementProxy
/*     */ {
/*  60 */   private static final Logger log = Logger.getLogger(ManagementFacadeBean.class);
/*     */ 
/*  63 */   private static final AtomicLong requestCounter = new AtomicLong(0L);
/*     */ 
/*     */   @EJB
/*     */   private TikitRepository tikitRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikiUserRepository tikiUserRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikiTemplateRefRepository tikiTemplateRefRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikiTagRepository tikiTagRepository;
/*     */ 
/*     */   @EJB
/*     */   private TagAssociationRepository tagAssociationRepository;
/*     */ 
/*     */   @EJB
/*     */   private TagManagementBlockFacade tagManagementBlock;
/*     */ 
/*     */   @EJB
/*     */   private TikiBlocksFacade tikiBlocks;
/*     */ 
/*     */   @Resource
/*     */   SessionContext ctx;
/*     */ 
/*     */   public Tikit findTikitById(Long id)
/*     */   {
/*  91 */     return ((Tikit)this.tikitRepo.findById(id));
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   public List<Tikit> getTikits() {
/*  96 */     return this.tikitRepo.findByUser(this.tikiUserRepo.whoami());
/*     */   }
/*     */ 
/*     */   public void deleteTikit(Tikit tikit) {
/* 100 */     this.tikitRepo.delete(tikit);
/*     */   }
/*     */ 
/*     */   public List<TikiTemplateRef> getTikiTemplates() {
/* 104 */     return this.tikiTemplateRefRepo.findAll();
/*     */   }
/*     */ 
/*     */   public String getTikiUserName() {
/* 108 */     return this.ctx.getCallerPrincipal().getName();
/*     */   }
/*     */ 
/*     */   public void logoutTikiUser()
/*     */   {
/*     */   }
/*     */ 
/*     */   public TagId detectTag() {
/* 116 */     return this.tagManagementBlock.detectTag(this.tikiUserRepo.whoami(), 5000L);
/*     */   }
/*     */ 
/*     */   public TikitId createTikit(String name, TikiTemplateRef ref, byte[] templateConfig, WiringScheme scheme)
/*     */     throws WiringException
/*     */   {
/* 123 */     ref = (TikiTemplateRef)this.tikiTemplateRefRepo.saveOrUpdate(ref);
/* 124 */     Tikit tikit = new Tikit(name, ref);
/* 125 */     tikit.setOwner(this.tikiUserRepo.whoami());
/* 126 */     tikit.setTemplateConfig(templateConfig);
/* 127 */     for (String actionId : scheme) {
/* 128 */       ActionProviderMemento memento = this.tikiBlocks.lay(scheme.getWire(actionId));
/* 129 */       TikitAction action = new TikitAction(actionId, tikit.toId(), memento);
/* 130 */       tikit.register(action);
/*     */     }
/*     */ 
/* 133 */     tikit = (Tikit)this.tikitRepo.saveOrUpdate(tikit);
/* 134 */     log.debug("Persisted Tikit:\n" + toTreeString(tikit));
/* 135 */     return tikit.toId();
/*     */   }
/*     */ 
/*     */   private String toTreeString(Tikit tikit) {
/* 139 */     DelegatingContentProvider contentProvider = new DelegatingContentProvider();
/* 140 */     contentProvider.register(Tikit.class, new TikitContentProvider());
/* 141 */     contentProvider.register(TikiTemplateRef.class, new TikiTemplateRefContentProvider());
/* 142 */     contentProvider.register(TagAssociation.class, new TagAssociationContentProvider());
/* 143 */     contentProvider.register(TikiTag.class, new TikiTagContentProvider());
/* 144 */     contentProvider.register(TikitAction.class, new TikitActionContentProvider());
/* 145 */     TreeString treeString = new TreeString(contentProvider);
/* 146 */     return treeString.convert(tikit);
/*     */   }
/*     */ 
/*     */   public String getTikitFromTag(String hexId) {
/* 150 */     TagAssociation tagAssociation = this.tagAssociationRepository.findByTagId(new TagId(hexId));
/* 151 */     return ((tagAssociation == null) ? "" : tagAssociation.toString());
/*     */   }
/*     */ 
/*     */   public void associate(TagId tagId, TikitId tikitId, String actionId) {
/* 155 */     TikiTag tag = this.tikiTagRepository.findByTagId(tagId);
/* 156 */     if (tag == null) {
/* 157 */       tag = new TikiTag(tagId.getIdentifier());
/* 158 */       tag = (TikiTag)this.tikiTagRepository.saveOrUpdate(tag);
/*     */     }
/* 160 */     Tikit tikit = this.tikitRepo.findByTikitId(tikitId);
/* 161 */     tikit.associate(tag, actionId);
/* 162 */     tikit = (Tikit)this.tikitRepo.saveOrUpdate(tikit);
/* 163 */     log.debug("Updated Tikit:\n" + toTreeString(tikit));
/*     */   }
/*     */ 
/*     */   public void associate(TagId tagId, TikitId tikitId) {
/* 167 */     associate(tagId, tikitId, "default");
/*     */   }
/*     */ 
/*     */   public void associate(URN tagURN, URN actionURN) {
/* 171 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public TikiTemplateRef findTemplateRef(String name)
/*     */   {
/* 176 */     return this.tikiTemplateRefRepo.findByName(name);
/*     */   }
/*     */ 
/*     */   public TikiTemplateRef register(TikiTemplateRef ref) {
/* 180 */     return ((TikiTemplateRef)this.tikiTemplateRefRepo.saveOrUpdate(ref));
/*     */   }
/*     */ 
/*     */   public String whoami()
/*     */   {
/* 187 */     return this.tikiUserRepo.whoami().getUserName() + " is a " + this.tikiUserRepo.whoami().getRoleStanza();
/*     */   }
/*     */ 
/*     */   public boolean unregister(TikiTemplateRef ref)
/*     */   {
/*     */     try {
/* 193 */       this.tikiTemplateRefRepo.delete(ref);
/* 194 */       return true;
/*     */     } catch (Throwable t) {
/* 196 */       log.error("Failed to delete template ref " + ref + ", due to " + t.getMessage(), t); }
/* 197 */     return false;
/*     */   }
/*     */ 
/*     */   public void handleRequest(String requestId, WiringScheme scheme, byte[] templateConfig)
/*     */   {
/* 203 */     log.debug("handleRequest(" + requestId + ", " + scheme + ", " + templateConfig + ")");
/*     */   }
/*     */ 
/*     */   public String newRequestTokenForApplicationCreate()
/*     */   {
/* 208 */     return Long.toString(requestCounter.incrementAndGet());
/*     */   }
/*     */ }