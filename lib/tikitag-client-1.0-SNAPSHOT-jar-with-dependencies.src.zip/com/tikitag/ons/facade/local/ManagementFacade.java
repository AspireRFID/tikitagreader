package com.tikitag.ons.facade.local;

import com.tikitag.ons.facade.remote.ManagementProxy;
import com.tikitag.ons.model.TikiTemplateRef;
import com.tikitag.ons.model.Tikit;
import java.util.List;
import javax.ejb.Local;

@Local
public abstract interface ManagementFacade extends ManagementProxy
{
  public abstract List<Tikit> getTikits();

  public abstract Tikit findTikitById(Long paramLong);

  public abstract void deleteTikit(Tikit paramTikit);

  public abstract String getTikiUserName();

  public abstract void logoutTikiUser();

  public abstract List<TikiTemplateRef> getTikiTemplates();

  public abstract String whoami();

  public abstract String newRequestTokenForApplicationCreate();
}