package com.tikitag.ons.facade.local;

import com.tikitag.ons.ActionProviderMemento;
import com.tikitag.ons.TikitagWebServiceException;
import com.tikitag.ons.block.TikiBlock;
import com.tikitag.ons.block.util.WiringOperation;
import com.tikitag.ons.block.wiring.Wire;
import com.tikitag.ons.block.wiring.WiringException;
import com.tikitag.ons.block.wiring.WiringScheme;
import com.tikitag.ons.model.util.URN;
import java.util.Map;
import javax.ejb.Local;

@Local
public abstract interface TikiBlocksFacade
{
  public abstract URN[] enumerateBlockURNs();

  public abstract TikiBlock[] enumerateBlocks();

  public abstract TikiBlock findBlock(URN paramURN);

  public abstract WiringOperation[] enumerateWiringOperations(URN paramURN)
    throws TikitagWebServiceException;

  public abstract WiringOperation findWiringOperation(URN paramURN);

  public abstract Map<String, ActionProviderMemento> lay(WiringScheme paramWiringScheme)
    throws WiringException;

  public abstract ActionProviderMemento lay(Wire paramWire)
    throws WiringException;
}