package com.tikitag.ons.facade.local;

import com.tikitag.ons.facade.remote.UserManagementProxy;
import javax.ejb.Local;

@Local
public abstract interface UserManagementFacade extends UserManagementProxy
{
}