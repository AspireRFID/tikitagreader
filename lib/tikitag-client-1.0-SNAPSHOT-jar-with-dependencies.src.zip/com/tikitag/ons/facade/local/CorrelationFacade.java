package com.tikitag.ons.facade.local;

import com.tikitag.ons.facade.remote.CorrelationProxy;
import javax.ejb.Local;

@Local
public abstract interface CorrelationFacade extends CorrelationProxy
{
}