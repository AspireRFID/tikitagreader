/*     */ package com.tikitag.ons.facade;
/*     */ 
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.TikitagWebServiceException;
/*     */ import com.tikitag.ons.block.TikiBlock;
/*     */ import com.tikitag.ons.block.util.Introspector;
/*     */ import com.tikitag.ons.block.util.WiringOperation;
/*     */ import com.tikitag.ons.block.wiring.ValuePoint;
/*     */ import com.tikitag.ons.block.wiring.Wire;
/*     */ import com.tikitag.ons.block.wiring.WireArray;
/*     */ import com.tikitag.ons.block.wiring.WiringException;
/*     */ import com.tikitag.ons.block.wiring.WiringPoint;
/*     */ import com.tikitag.ons.block.wiring.WiringScheme;
/*     */ import com.tikitag.ons.facade.local.TikiBlocksFacade;
/*     */ import com.tikitag.ons.model.util.URN;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import javax.ejb.Stateless;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NameClassPair;
/*     */ import javax.naming.NamingEnumeration;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.security.SecurityDomain;
/*     */ 
/*     */ @Stateless
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Facade/TikiBlocks/local")
/*     */ @SecurityDomain(value="tikitag", unauthenticatedPrincipal="tikiusurper")
/*     */ public class TikiBlocksFacadeBean
/*     */   implements TikiBlocksFacade
/*     */ {
/*     */   public URN[] enumerateBlockURNs()
/*     */   {
/*  45 */     List result = new ArrayList();
/*     */     try {
/*  47 */       for (TikiBlock tikiBlock : enumerateBlocks())
/*  48 */         result.add(tikiBlock.toURN());
/*     */     } catch (Exception e) {
/*  50 */       e.printStackTrace();
/*     */     }
/*  52 */     return ((URN[])result.toArray(new URN[result.size()]));
/*     */   }
/*     */ 
/*     */   public TikiBlock[] enumerateBlocks()
/*     */   {
/*  59 */     List result = new ArrayList();
/*     */     try {
/*  61 */       InitialContext context = new InitialContext();
/*  62 */       NamingEnumeration enumeration = context.list("Tikitag/ONS/Block");
/*  63 */       while (enumeration.hasMore()) {
/*  64 */         NameClassPair pair = (NameClassPair)enumeration.next();
/*  65 */         TikiBlock block = (TikiBlock)context.lookup("Tikitag/ONS/Block/" + pair.getName() + "/local");
/*  66 */         result.add(block);
/*     */       }
/*     */     } catch (Exception e) {
/*  69 */       e.printStackTrace();
/*     */     }
/*  71 */     return ((TikiBlock[])result.toArray(new TikiBlock[result.size()]));
/*     */   }
/*     */ 
/*     */   public TikiBlock findBlock(URN blockURN)
/*     */   {
/*     */     try
/*     */     {
/*  81 */       InitialContext context = new InitialContext();
/*  82 */       NamingEnumeration enumeration = context.list("Tikitag/ONS/Block");
/*  83 */       while (enumeration.hasMore()) {
/*  84 */         NameClassPair pair = (NameClassPair)enumeration.next();
/*  85 */         TikiBlock block = (TikiBlock)context.lookup("Tikitag/ONS/Block/" + pair.getName() + "/local");
/*  86 */         if (blockURN.equals(block.toURN()))
/*  87 */           return block;
/*     */       }
/*     */     } catch (Exception e) {
/*  90 */       e.printStackTrace();
/*     */     }
/*     */ 
/*  93 */     return null;
/*     */   }
/*     */ 
/*     */   public WiringOperation[] enumerateWiringOperations(URN blockURN)
/*     */     throws TikitagWebServiceException
/*     */   {
/* 100 */     TikiBlock block = findBlock(blockURN);
/* 101 */     if (block != null) {
/* 102 */       return Introspector.introspect(block);
/*     */     }
/* 104 */     throw new TikitagWebServiceException("Can't find corresponding block for \"" + blockURN + "\"");
/*     */   }
/*     */ 
/*     */   public WiringOperation findWiringOperation(URN operationURN)
/*     */   {
/* 111 */     int index = operationURN.getValue().lastIndexOf(58);
/* 112 */     URN blockURN = new URN(operationURN.getValue().substring(0, index));
/*     */ 
/* 114 */     TikiBlock block = findBlock(blockURN);
/*     */ 
/* 116 */     WiringOperation[] operations = Introspector.introspect(block);
/* 117 */     for (WiringOperation operation : operations) {
/* 118 */       if (operation.getURN().equals(operationURN))
/* 119 */         return operation;
/*     */     }
/* 121 */     return null;
/*     */   }
/*     */ 
/*     */   public Map<String, ActionProviderMemento> lay(WiringScheme wiring)
/*     */     throws WiringException
/*     */   {
/* 129 */     throw new UnsupportedOperationException();
/*     */   }
/*     */ 
/*     */   public ActionProviderMemento lay(Wire wire)
/*     */     throws WiringException
/*     */   {
/* 138 */     WiringOperation operation = findWiringOperation(wire.getURN());
/* 139 */     if (operation == null)
/* 140 */       throw new WiringException("WiringScheme operation '" + wire.getURN() + "' could not be found!");
/* 141 */     WiringPoint[] points = wire.getPoints();
/* 142 */     Object[] arguments = new Object[points.length];
/* 143 */     for (int i = 0; i < points.length; ++i) {
/* 144 */       WiringPoint point = points[i];
/* 145 */       if (point instanceof Wire) {
/* 146 */         arguments[i] = lay((Wire)point);
/* 147 */       } else if (point instanceof WireArray) {
/* 148 */         WireArray array = (WireArray)point;
/* 149 */         ActionProviderMemento[] mementos = new ActionProviderMemento[array.size()];
/* 150 */         for (int j = 0; j < array.size(); ++j)
/* 151 */           mementos[j] = lay(array.get(j));
/* 152 */         arguments[i] = mementos;
/*     */       } else {
/* 154 */         arguments[i] = ((ValuePoint)point).getValue();
/*     */       }
/*     */     }
/* 157 */     return operation.invoke(arguments);
/*     */   }
/*     */ }