/*     */ package com.tikitag.ons.facade;
/*     */ 
/*     */ import com.tikitag.ons.ActionAndMemento;
/*     */ import com.tikitag.ons.ActionProviderMemento;
/*     */ import com.tikitag.ons.TikitagAction;
/*     */ import com.tikitag.ons.block.remote.TagManagementBlock;
/*     */ import com.tikitag.ons.facade.local.CorrelationFacade;
/*     */ import com.tikitag.ons.facade.remote.CorrelationProxy;
/*     */ import com.tikitag.ons.model.TagAssociation;
/*     */ import com.tikitag.ons.model.TikitAction;
/*     */ import com.tikitag.ons.model.util.ChangeEvent;
/*     */ import com.tikitag.ons.model.util.PingEvent;
/*     */ import com.tikitag.ons.model.util.TagEvent;
/*     */ import com.tikitag.ons.model.util.TagEvent.TagEventType;
/*     */ import com.tikitag.ons.model.util.TagId;
/*     */ import com.tikitag.ons.model.util.TagInfo;
/*     */ import com.tikitag.ons.model.util.UserIdentifedTagEvent;
/*     */ import com.tikitag.ons.repository.local.TagAssociationRepository;
/*     */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*     */ import com.tikitag.ons.service.local.ActionProviderCatalog;
/*     */ import com.tikitag.util.config.xml.ConfigContainer;
/*     */ import java.security.Principal;
/*     */ import javax.annotation.Resource;
/*     */ import javax.annotation.security.PermitAll;
/*     */ import javax.ejb.EJB;
/*     */ import javax.ejb.SessionContext;
/*     */ import javax.ejb.Stateless;
/*     */ import javax.jws.WebService;
/*     */ import org.apache.log4j.Logger;
/*     */ import org.jboss.annotation.ejb.LocalBinding;
/*     */ import org.jboss.annotation.ejb.RemoteBinding;
/*     */ import org.jboss.annotation.security.SecurityDomain;
/*     */ import org.jboss.wsf.spi.annotation.WebContext;
/*     */ 
/*     */ @Stateless
/*     */ @LocalBinding(jndiBinding="Tikitag/ONS/Facade/Correlation/local")
/*     */ @RemoteBinding(jndiBinding="Tikitag/ONS/Facade/Correlation/remote")
/*     */ @WebService(endpointInterface="com.tikitag.ons.facade.remote.CorrelationProxy", name="Tikitag", serviceName="CorrelationProxy", targetNamespace="http://www.tikitag.com")
/*     */ @WebContext(contextRoot="/tikitag-soap", urlPattern="/correlation/*", authMethod="BASIC", transportGuarantee="NONE", secureWSDLAccess=false)
/*     */ @SecurityDomain("tikitag")
/*     */ public class CorrelationFacadeBean
/*     */   implements CorrelationFacade, CorrelationProxy
/*     */ {
/*  55 */   private static final Logger log = Logger.getLogger(CorrelationFacadeBean.class);
/*     */ 
/*     */   @EJB
/*     */   private TagAssociationRepository tagAssociationRepo;
/*     */ 
/*     */   @EJB
/*     */   private TikiUserRepository tikiUserRepo;
/*     */ 
/*     */   @EJB
/*     */   private TagManagementBlock tagManagementBlock;
/*     */ 
/*     */   @EJB
/*     */   private ActionProviderCatalog actionProviderCatalog;
/*     */ 
/*     */   @Resource
/*     */   SessionContext ctx;
/*     */ 
/*     */   @PermitAll
/*     */   public TikitagAction getTikitagAction(TagEvent tagEvent)
/*     */   {
/*     */     try
/*     */     {
/*  78 */       Principal principal = this.ctx.getCallerPrincipal();
/*  79 */       log.info(".getTikitagAction(..) from principal -> " + principal.getName());
/*     */     } catch (Exception e) {
/*  81 */       e.printStackTrace();
/*     */     }
/*  83 */     log.debug("getTikitagAction(" + tagEvent + ")");
/*     */ 
/*  85 */     tagEvent = new UserIdentifedTagEvent(this.tikiUserRepo.whoami(), tagEvent);
/*     */ 
/*  87 */     ConfigContainer container = null;
/*  88 */     if ((tagEvent.getTagEventType() == TagEvent.TagEventType.PUT) || (tagEvent.getTagEventType() == TagEvent.TagEventType.TOUCH)) {
/*  89 */       TagInfo actionTag = tagEvent.getActionTag();
/*  90 */       TagId tagId = actionTag.getTagId();
/*  91 */       TagAssociation association = null;
/*  92 */       ActionProviderMemento memento = null;
/*  93 */       TikitAction action = null;
/*  94 */       container = this.actionProviderCatalog.invokeActionProvider(this.tagManagementBlock.getTagDetector(), tagEvent).getAction();
/*  95 */       if (container == null) {
/*  96 */         association = this.tagAssociationRepo.findByTagId(tagId);
/*  97 */         if (association != null) {
/*  98 */           action = association.getAction();
/*  99 */           memento = action.getMemento();
/*     */         }
/*     */         else {
/* 102 */           log.info("No action associated...");
/* 103 */           memento = this.tagManagementBlock.defaultMemento();
/*     */         }
/*     */         try {
/* 106 */           ActionAndMemento actionAndMemento = this.actionProviderCatalog.invokeActionProvider(memento, tagEvent);
/* 107 */           container = actionAndMemento.getAction();
/* 108 */           if (association != null) {
/* 109 */             action.setMemento(actionAndMemento.getMemento());
/* 110 */             association.setAction(action);
/* 111 */             this.tagAssociationRepo.saveOrUpdate(association);
/*     */           }
/*     */         } catch (Exception e) {
/* 114 */           log.error("Error occured in the ActionProvider associated with " + tagId, e);
/* 115 */           throw new RuntimeException("Error occured in the ActionProvider associated with " + tagId, e);
/*     */         }
/*     */       }
/*     */     }
/*     */     else {
/* 120 */       container = this.tagManagementBlock.noAction();
/*     */     }
/*     */ 
/* 123 */     TikitagAction result = new TikitagAction();
/* 124 */     result.setContainer(container);
/* 125 */     log.debug("Returning result: " + result);
/* 126 */     return result;
/*     */   }
/*     */ 
/*     */   public void changeEvent(ChangeEvent changeEvent)
/*     */   {
/*     */   }
/*     */ 
/*     */   @PermitAll
/*     */   public void ping(PingEvent pingEvent)
/*     */     throws CorrelatorException_Exception
/*     */   {
/*     */   }
/*     */ }