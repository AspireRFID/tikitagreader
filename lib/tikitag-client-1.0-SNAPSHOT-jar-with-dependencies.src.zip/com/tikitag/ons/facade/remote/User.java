/*    */ package com.tikitag.ons.facade.remote;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import javax.xml.bind.annotation.XmlAccessType;
/*    */ import javax.xml.bind.annotation.XmlAccessorType;
/*    */ import javax.xml.bind.annotation.XmlElement;
/*    */ import javax.xml.bind.annotation.XmlRootElement;
/*    */ 
/*    */ @XmlRootElement
/*    */ @XmlAccessorType(XmlAccessType.NONE)
/*    */ public class User
/*    */ {
/*    */ 
/*    */   @XmlElement(required=true)
/*    */   private String userName;
/*    */ 
/*    */   @XmlElement
/*    */   private byte[] password;
/*    */ 
/*    */   @XmlElement(name="role")
/*    */   private List<String> roles;
/*    */ 
/*    */   @XmlElement
/*    */   private String displayName;
/*    */ 
/*    */   @XmlElement
/*    */   private String email;
/*    */ 
/*    */   public User(String userName, byte[] password, List<String> roles, String displayName, String email)
/*    */   {
/* 35 */     this.userName = userName;
/* 36 */     this.password = password;
/* 37 */     this.roles = roles;
/* 38 */     this.displayName = displayName;
/* 39 */     this.email = email;
/*    */   }
/*    */ 
/*    */   User()
/*    */   {
/*    */   }
/*    */ 
/*    */   public static User fromTikiUser(TikiUser tikiUser)
/*    */   {
/* 48 */     return new User(tikiUser.getUserName(), tikiUser.getPassword(), Arrays.asList(tikiUser.roles()), tikiUser.getHandle(), tikiUser.getEmail());
/*    */   }
/*    */ 
/*    */   public TikiUser toTikiUser() {
/* 52 */     return new TikiUser(this.displayName, this.userName, this.password, (this.roles != null) ? (String[])this.roles.toArray(new String[this.roles.size()]) : new String[0], this.email);
/*    */   }
/*    */ 
/*    */   public String getUserName() {
/* 56 */     return this.userName;
/*    */   }
/*    */ 
/*    */   public byte[] getPassword()
/*    */   {
/* 61 */     return this.password;
/*    */   }
/*    */ 
/*    */   public List<String> getRoles()
/*    */   {
/* 66 */     return this.roles;
/*    */   }
/*    */ 
/*    */   public String getDisplayName()
/*    */   {
/* 71 */     return this.displayName;
/*    */   }
/*    */ 
/*    */   public String getEmail()
/*    */   {
/* 76 */     return this.email;
/*    */   }
/*    */ }