package com.tikitag.ons.facade.remote;

import javax.ejb.Remote;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

@Remote
@WebService(name="Tikitag", targetNamespace="http://www.tikitag.com")
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, parameterStyle=SOAPBinding.ParameterStyle.BARE, use=SOAPBinding.Use.LITERAL)
public abstract interface UserManagementProxy
{
  @WebMethod
  public abstract void createUser(User paramUser);

  @WebMethod
  public abstract User getUser(String paramString);

  @WebMethod
  public abstract boolean updateUser(User paramUser);

  @WebMethod
  public abstract boolean deleteUser(String paramString);
}