package com.tikitag.ons.facade.remote;

import com.tikitag.ons.TikitagAction;
import com.tikitag.ons.facade.CorrelatorException_Exception;
import com.tikitag.ons.model.util.ChangeEvent;
import com.tikitag.ons.model.util.PingEvent;
import com.tikitag.ons.model.util.TagEvent;
import javax.ejb.Remote;
import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.jws.soap.SOAPBinding;
import javax.jws.soap.SOAPBinding.ParameterStyle;
import javax.jws.soap.SOAPBinding.Style;
import javax.jws.soap.SOAPBinding.Use;

@Remote
@WebService(name="Tikitag", targetNamespace="http://www.tikitag.com")
@SOAPBinding(style=SOAPBinding.Style.DOCUMENT, parameterStyle=SOAPBinding.ParameterStyle.BARE, use=SOAPBinding.Use.LITERAL)
public abstract interface CorrelationProxy
{
  @WebMethod
  public abstract void ping(PingEvent paramPingEvent)
    throws CorrelatorException_Exception;

  @WebMethod
  public abstract void changeEvent(ChangeEvent paramChangeEvent)
    throws CorrelatorException_Exception;

  @WebMethod
  public abstract TikitagAction getTikitagAction(TagEvent paramTagEvent)
    throws CorrelatorException_Exception;
}