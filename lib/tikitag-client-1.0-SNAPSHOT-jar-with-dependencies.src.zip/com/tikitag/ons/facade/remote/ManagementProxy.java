package com.tikitag.ons.facade.remote;

import com.tikitag.ons.block.wiring.WiringException;
import com.tikitag.ons.block.wiring.WiringScheme;
import com.tikitag.ons.model.TikiTemplateRef;
import com.tikitag.ons.model.util.TagId;
import com.tikitag.ons.model.util.TikitId;
import com.tikitag.ons.model.util.URN;
import javax.ejb.Remote;

@Remote
public abstract interface ManagementProxy
{
  public abstract void handleRequest(String paramString, WiringScheme paramWiringScheme, byte[] paramArrayOfByte);

  public abstract TikitId createTikit(String paramString, TikiTemplateRef paramTikiTemplateRef, byte[] paramArrayOfByte, WiringScheme paramWiringScheme)
    throws WiringException;

  public abstract void associate(TagId paramTagId, TikitId paramTikitId, String paramString);

  public abstract void associate(TagId paramTagId, TikitId paramTikitId);

  public abstract void associate(URN paramURN1, URN paramURN2);

  public abstract TagId detectTag();

  public abstract String getTikitFromTag(String paramString);

  public abstract TikiTemplateRef findTemplateRef(String paramString);

  public abstract TikiTemplateRef register(TikiTemplateRef paramTikiTemplateRef);

  public abstract boolean unregister(TikiTemplateRef paramTikiTemplateRef);
}