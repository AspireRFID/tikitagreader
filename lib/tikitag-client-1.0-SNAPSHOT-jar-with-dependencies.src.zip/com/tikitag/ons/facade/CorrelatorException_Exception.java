/*    */ package com.tikitag.ons.facade;
/*    */ 
/*    */ import com.tikitag.ons.facade.local.CorrelatorException;
/*    */ import javax.jws.soap.SOAPBinding;
/*    */ import javax.jws.soap.SOAPBinding.ParameterStyle;
/*    */ import javax.jws.soap.SOAPBinding.Style;
/*    */ import javax.jws.soap.SOAPBinding.Use;
/*    */ import javax.xml.ws.WebFault;
/*    */ 
/*    */ @WebFault(name="CorrelatorException")
/*    */ @SOAPBinding(style=SOAPBinding.Style.DOCUMENT, parameterStyle=SOAPBinding.ParameterStyle.BARE, use=SOAPBinding.Use.LITERAL)
/*    */ public class CorrelatorException_Exception extends Exception
/*    */ {
/*    */   private static final long serialVersionUID = 1L;
/*    */   private CorrelatorException clientFacadeException;
/*    */ 
/*    */   public CorrelatorException_Exception()
/*    */   {
/*    */   }
/*    */ 
/*    */   public CorrelatorException_Exception(String arg0, Throwable arg1)
/*    */   {
/* 26 */     super(arg0, arg1);
/*    */   }
/*    */ 
/*    */   public CorrelatorException_Exception(String arg0, CorrelatorException clientFacadeException, Throwable arg1) {
/* 30 */     super(arg0, arg1);
/* 31 */     this.clientFacadeException = clientFacadeException;
/*    */   }
/*    */ 
/*    */   public CorrelatorException_Exception(String arg0) {
/* 35 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public CorrelatorException_Exception(String arg0, CorrelatorException clientFacadeException) {
/* 39 */     super(arg0);
/* 40 */     this.clientFacadeException = clientFacadeException;
/*    */   }
/*    */ 
/*    */   public CorrelatorException_Exception(Throwable arg0) {
/* 44 */     super(arg0);
/*    */   }
/*    */ 
/*    */   public CorrelatorException getFaultInfo()
/*    */   {
/* 50 */     return this.clientFacadeException;
/*    */   }
/*    */ }