/*    */ package com.tikitag.ons.facade;
/*    */ 
/*    */ import com.tikitag.ons.facade.local.UserManagementFacade;
/*    */ import com.tikitag.ons.facade.remote.User;
/*    */ import com.tikitag.ons.facade.remote.UserManagementProxy;
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*    */ import javax.annotation.security.RolesAllowed;
/*    */ import javax.ejb.EJB;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.jws.WebService;
/*    */ import org.jboss.annotation.ejb.LocalBinding;
/*    */ import org.jboss.annotation.ejb.RemoteBinding;
/*    */ import org.jboss.annotation.security.SecurityDomain;
/*    */ import org.jboss.wsf.spi.annotation.WebContext;
/*    */ 
/*    */ @Stateless
/*    */ @LocalBinding(jndiBinding="Tikitag/ONS/Facade/UserManagement/local")
/*    */ @RemoteBinding(jndiBinding="Tikitag/ONS/Facade/UserManagement/remote")
/*    */ @SecurityDomain(value="tikitag", unauthenticatedPrincipal="tikigimp")
/*    */ @WebService(endpointInterface="com.tikitag.ons.facade.remote.UserManagementProxy", name="Tikitag", serviceName="CorrelationProxy", targetNamespace="http://www.tikitag.com")
/*    */ @WebContext(contextRoot="/tikitag-soap", urlPattern="/userManagement/*", authMethod="BASIC", transportGuarantee="NONE", secureWSDLAccess=false)
/*    */ @RolesAllowed({"tiki:admin", "tiki:usurper", "tiki:drupal"})
/*    */ public class UserManagementFacadeBean
/*    */   implements UserManagementFacade, UserManagementProxy
/*    */ {
/*    */ 
/*    */   @EJB
/*    */   private TikiUserRepository userRepo;
/*    */ 
/*    */   public void createUser(User newUser)
/*    */   {
/* 37 */     this.userRepo.saveOrUpdate(newUser.toTikiUser());
/*    */   }
/*    */ 
/*    */   public boolean deleteUser(String userName) {
/* 41 */     TikiUser user = this.userRepo.findByUserName(userName);
/* 42 */     if (user != null) {
/* 43 */       this.userRepo.delete(user);
/* 44 */       return true;
/*    */     }
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   public User getUser(String userName) {
/* 50 */     TikiUser tikiUser = this.userRepo.findByUserName(userName);
/* 51 */     if (tikiUser == null) {
/* 52 */       return null;
/*    */     }
/* 54 */     return User.fromTikiUser(tikiUser);
/*    */   }
/*    */ 
/*    */   public boolean updateUser(User updatedUser)
/*    */   {
/* 60 */     TikiUser user = this.userRepo.findByUserName(updatedUser.getUserName());
/* 61 */     if (user != null) {
/* 62 */       TikiUser tikiUser = updatedUser.toTikiUser();
/* 63 */       if (updatedUser.getPassword() != null) {
/* 64 */         user.setPassword(tikiUser.getPassword());
/*    */       }
/* 66 */       if (updatedUser.getRoles() != null) {
/* 67 */         user.setRoleStanza(tikiUser.getRoleStanza());
/*    */       }
/* 69 */       if (updatedUser.getDisplayName() != null) {
/* 70 */         user.setHandle(tikiUser.getHandle());
/*    */       }
/* 72 */       if (updatedUser.getEmail() != null) {
/* 73 */         user.setEmail(tikiUser.getEmail());
/*    */       }
/* 75 */       this.userRepo.saveOrUpdate(user);
/* 76 */       return true;
/*    */     }
/* 78 */     return false;
/*    */   }
/*    */ }