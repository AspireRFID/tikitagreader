/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiTag;
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.repository.local.TikiTagRepository;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.NoResultException;
/*    */ import javax.persistence.Query;
/*    */ 
/*    */ @Stateless
/*    */ public class JPATikiTagRepository extends JPARepository<TikiTag>
/*    */   implements TikiTagRepository
/*    */ {
/*    */   public TikiTag findByTagId(TagId tagId)
/*    */   {
/* 15 */     String queryStr = "from TikiTag tt where tt.tagId=:tagId";
/* 16 */     Query query = this.manager.createQuery(queryStr).setParameter("tagId", tagId);
/*    */     try
/*    */     {
/* 19 */       return ((TikiTag)query.getSingleResult()); } catch (NoResultException e) {
/*    */     }
/* 21 */     return null;
/*    */   }
/*    */ }