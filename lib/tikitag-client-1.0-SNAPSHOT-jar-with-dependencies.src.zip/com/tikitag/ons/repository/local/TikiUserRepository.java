package com.tikitag.ons.repository.local;

import com.tikitag.ons.model.TikiUser;
import com.tikitag.ons.repository.Repository;
import javax.ejb.Local;

@Local
public abstract interface TikiUserRepository extends Repository<TikiUser>
{
  public abstract TikiUser getUsurper();

  public abstract TikiUser getGimp();

  public abstract TikiUser getDrupal();

  public abstract TikiUser findByUserName(String paramString);

  public abstract TikiUser whoami();
}