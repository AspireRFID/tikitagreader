package com.tikitag.ons.repository.local;

import com.tikitag.ons.model.TikiTemplateRef;
import com.tikitag.ons.repository.Repository;
import javax.ejb.Local;

@Local
public abstract interface TikiTemplateRefRepository extends Repository<TikiTemplateRef>
{
  public abstract TikiTemplateRef findByName(String paramString);
}