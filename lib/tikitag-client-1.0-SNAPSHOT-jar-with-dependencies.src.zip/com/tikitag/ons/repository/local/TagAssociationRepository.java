package com.tikitag.ons.repository.local;

import com.tikitag.ons.model.TagAssociation;
import com.tikitag.ons.model.util.TagId;
import com.tikitag.ons.repository.Repository;
import javax.ejb.Local;

@Local
public abstract interface TagAssociationRepository extends Repository<TagAssociation>
{
  public abstract TagAssociation findByTagId(TagId paramTagId);
}