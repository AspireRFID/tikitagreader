package com.tikitag.ons.repository.local;

import com.tikitag.ons.model.TikiUser;
import com.tikitag.ons.model.Tikit;
import com.tikitag.ons.model.util.TikitId;
import com.tikitag.ons.repository.Repository;
import java.util.List;
import javax.ejb.Local;

@Local
public abstract interface TikitRepository extends Repository<Tikit>
{
  public abstract List<Tikit> findByUser(TikiUser paramTikiUser);

  public abstract Tikit findByTikitId(TikitId paramTikitId);
}