package com.tikitag.ons.repository;

import com.tikitag.ons.model.BaseEntity;
import java.util.List;

public abstract interface Repository<T extends BaseEntity>
{
  public abstract T findById(Long paramLong);

  public abstract List<T> findAll();

  public abstract T saveOrUpdate(T paramT);

  public abstract void delete(T paramT);
}