/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.BaseEntity;
/*    */ import java.lang.reflect.ParameterizedType;
/*    */ import java.util.List;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.PersistenceContext;
/*    */ import javax.persistence.Query;
/*    */ 
/*    */ public abstract class JPARepository<T extends BaseEntity>
/*    */   implements Repository<T>
/*    */ {
/*    */ 
/*    */   @PersistenceContext(unitName="tikitag")
/*    */   protected EntityManager manager;
/*    */   private Class<T> entityClass;
/*    */ 
/*    */   public JPARepository()
/*    */   {
/* 26 */     ParameterizedType genericSuperclass = (ParameterizedType)super.getClass().getGenericSuperclass();
/* 27 */     this.entityClass = ((Class)genericSuperclass.getActualTypeArguments()[0]);
/*    */   }
/*    */ 
/*    */   public T findById(Long id)
/*    */   {
/* 35 */     return ((BaseEntity)this.manager.find(this.entityClass, id));
/*    */   }
/*    */ 
/*    */   public List<T> findAll()
/*    */   {
/* 43 */     return this.manager.createQuery("from " + this.entityClass.getName()).getResultList();
/*    */   }
/*    */ 
/*    */   public T saveOrUpdate(T object)
/*    */   {
/* 50 */     return ((BaseEntity)this.manager.merge(object));
/*    */   }
/*    */ 
/*    */   public void delete(T object)
/*    */   {
/* 57 */     object = (BaseEntity)this.manager.merge(object);
/* 58 */     this.manager.remove(object);
/*    */   }
/*    */ }