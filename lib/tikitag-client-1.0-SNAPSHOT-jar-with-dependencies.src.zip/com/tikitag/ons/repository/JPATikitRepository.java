/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import com.tikitag.ons.model.Tikit;
/*    */ import com.tikitag.ons.model.util.TikitId;
/*    */ import com.tikitag.ons.repository.local.TikitRepository;
/*    */ import com.tikitag.util.HexFormatter;
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.Query;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ @Stateless
/*    */ public class JPATikitRepository extends JPARepository<Tikit>
/*    */   implements TikitRepository
/*    */ {
/* 20 */   private static final Logger log = Logger.getLogger(JPATikitRepository.class);
/*    */ 
/*    */   public List<Tikit> findByUser(TikiUser user)
/*    */   {
/*    */     List result;
/*    */     try
/*    */     {
/* 27 */       Query q = this.manager.createQuery("SELECT t FROM Tikit t WHERE t.owner.userName=:userName");
/* 28 */       q.setParameter("userName", user.getUserName());
/* 29 */       result = q.getResultList();
/*    */     } catch (Exception e) {
/* 31 */       result = new ArrayList(0);
/* 32 */       log.error("Query failure", e);
/*    */     }
/* 34 */     return result;
/*    */   }
/*    */ 
/*    */   public Tikit findByTikitId(TikitId tikitId)
/*    */   {
/*    */     Tikit result;
/*    */     try {
/* 41 */       Query q = this.manager.createQuery("SELECT t FROM Tikit t WHERE t.name=:name");
/* 42 */       String name = new String(HexFormatter.fromHexString(tikitId.getIdentifier()));
/* 43 */       q.setParameter("name", name);
/* 44 */       result = (Tikit)q.getSingleResult();
/*    */     } catch (Exception e) {
/* 46 */       result = null;
/* 47 */       log.error("Query failure", e);
/*    */     }
/* 49 */     return result;
/*    */   }
/*    */ }