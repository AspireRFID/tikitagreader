/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiUser;
/*    */ import com.tikitag.ons.repository.local.TikiUserRepository;
/*    */ import java.security.Principal;
/*    */ import javax.annotation.Resource;
/*    */ import javax.ejb.SessionContext;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.NoResultException;
/*    */ import javax.persistence.Query;
/*    */ import org.apache.log4j.Logger;
/*    */ 
/*    */ @Stateless
/*    */ public class JPATikiUserRepository extends JPARepository<TikiUser>
/*    */   implements TikiUserRepository
/*    */ {
/* 24 */   private static final Logger log = Logger.getLogger(JPATikiUserRepository.class);
/*    */   private final TikiUser TIKI_USURPER;
/*    */   private final TikiUser TIKI_GIMP;
/*    */   private final TikiUser TIKI_DRUPAL;
/*    */ 
/*    */   @Resource
/*    */   SessionContext ctx;
/*    */ 
/*    */   public JPATikiUserRepository()
/*    */   {
/* 26 */     this.TIKI_USURPER = new TikiUser("Tikitag Usurper", "tikiusurper", "tikitag".getBytes(), new String[] { "tiki:usurper", "tiki:admin", "tiki:user" }, null);
/* 27 */     this.TIKI_GIMP = new TikiUser("Tikitag Gimp", "tikigimp", "tikitag".getBytes(), new String[] { "tiki:gimp" }, null);
/* 28 */     this.TIKI_DRUPAL = new TikiUser("Tikitag Drupal", "tikidrupal", "drupal".getBytes(), new String[] { "tiki:drupal" }, null);
/*    */   }
/*    */ 
/*    */   public TikiUser getUsurper()
/*    */   {
/* 34 */     TikiUser result = null;
/* 35 */     result = findByUserName("tikiusurper");
/* 36 */     if (result == null)
/* 37 */       result = (TikiUser)saveOrUpdate(this.TIKI_USURPER);
/* 38 */     return result;
/*    */   }
/*    */ 
/*    */   public TikiUser getGimp() {
/* 42 */     TikiUser result = null;
/* 43 */     result = findByUserName("tikigimp");
/* 44 */     if (result == null)
/* 45 */       result = (TikiUser)saveOrUpdate(this.TIKI_GIMP);
/* 46 */     return result;
/*    */   }
/*    */ 
/*    */   public TikiUser getDrupal() {
/* 50 */     TikiUser result = null;
/* 51 */     result = findByUserName("tikidrupal");
/* 52 */     if (result == null) {
/* 53 */       result = (TikiUser)saveOrUpdate(this.TIKI_DRUPAL);
/*    */     }
/* 55 */     return result;
/*    */   }
/*    */ 
/*    */   public TikiUser findByUserName(String userName)
/*    */   {
/* 60 */     TikiUser result = null;
/*    */     try {
/* 62 */       Query q = this.manager.createQuery("SELECT tu FROM TikiUser tu WHERE tu.userName=:userName");
/* 63 */       q.setParameter("userName", userName);
/* 64 */       result = (TikiUser)q.getSingleResult(); } catch (NoResultException ignore) {
/*    */     }
/* 66 */     return result;
/*    */   }
/*    */ 
/*    */   public TikiUser whoami()
/*    */   {
/* 71 */     TikiUser result = null;
/*    */     try {
/* 73 */       Principal principal = this.ctx.getCallerPrincipal();
/* 74 */       log.debug(" whoami? is looking for principal '" + principal.getName() + "'");
/* 75 */       result = findByUserName(principal.getName());
/* 76 */       if (result == null)
/* 77 */         result = getGimp();
/*    */     }
/*    */     catch (Exception e) {
/* 80 */       result = getGimp();
/* 81 */       log.warn("///////////////////////// ");
/* 82 */       log.warn("//// S E C U R I T Y //// Gimp on the loose: an unexpected exception (" + e + ") occurred!");
/* 83 */       log.warn("///////////////////////// ");
/*    */     }
/* 85 */     log.debug("whoami? -> " + result);
/* 86 */     return result;
/*    */   }
/*    */ }