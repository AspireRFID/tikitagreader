/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.TagAssociation;
/*    */ import com.tikitag.ons.model.util.TagId;
/*    */ import com.tikitag.ons.repository.local.TagAssociationRepository;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.NoResultException;
/*    */ import javax.persistence.Query;
/*    */ 
/*    */ @Stateless
/*    */ public class JPATagAssociationRepository extends JPARepository<TagAssociation>
/*    */   implements TagAssociationRepository
/*    */ {
/*    */   public TagAssociation findByTagId(TagId tagId)
/*    */   {
/* 16 */     Query query = this.manager.createQuery("from TagAssociation ta where ta.tag.tagId=:tagId").setParameter("tagId", tagId);
/*    */     try {
/* 18 */       return ((TagAssociation)query.getSingleResult()); } catch (NoResultException e) {
/*    */     }
/* 20 */     return null;
/*    */   }
/*    */ }