/*    */ package com.tikitag.ons.repository;
/*    */ 
/*    */ import com.tikitag.ons.model.TikiTemplateRef;
/*    */ import com.tikitag.ons.repository.local.TikiTemplateRefRepository;
/*    */ import javax.ejb.Stateless;
/*    */ import javax.persistence.EntityManager;
/*    */ import javax.persistence.NoResultException;
/*    */ import javax.persistence.Query;
/*    */ 
/*    */ @Stateless
/*    */ public class JPATikiTemplateRefRepository extends JPARepository<TikiTemplateRef>
/*    */   implements TikiTemplateRefRepository
/*    */ {
/*    */   public TikiTemplateRef findByName(String name)
/*    */   {
/* 14 */     Query q = this.manager.createQuery("from TikiTemplateRef ttr where ttr.name=:name");
/* 15 */     q.setParameter("name", name);
/*    */     try
/*    */     {
/* 18 */       return ((TikiTemplateRef)q.getSingleResult()); } catch (NoResultException e) {
/*    */     }
/* 20 */     return null;
/*    */   }
/*    */ }